#include "DatSlice.hpp"

#include "DatPoint.hpp"
#include "MscDebug.hpp"




bool DatSlice::applyDoubleSquareRoot( float velocity , const char * sourceAttr , const char * receiverAttr )
{
  myErrorMessage.erase(); 
  // check input
  if ( sourceAttr == 0 || receiverAttr == 0 ) {
    myErrorMessage.printf( "DatSlice::applyDoubleSquareRoot(): empty input" );
    return false ;
  }
  // must have the headers
  bool bSource , bReceiver ;
  int sourceId   = getHeaderId( sourceAttr   , false , bSource   );
  int receiverId = getHeaderId( receiverAttr , false , bReceiver );
  if ( bSource == false || bReceiver == false ) {
    myErrorMessage.printf( "DatSlice::applyDoubleSquareRoot(): undefined headers '%s' or '%s'" ,
                           sourceAttr , receiverAttr );
    return false ;    
  }
  // check data 
  if ( myNumberOfTraces != myHeaders.find( sourceId   )->second.myVector.size() ||
       myNumberOfTraces != myHeaders.find( receiverId )->second.myVector.size() ) {
    myErrorMessage.printf( "DatSlice::applyDoubleSquareRoot(): '%s' or '%s' headers have wrong size (not %d)" ,
                           sourceAttr , receiverAttr , myNumberOfTraces );
    return false ;
  }
  // apply move out
  for ( int traceIndex=0 ; traceIndex < myNumberOfTraces ; ++traceIndex ) {
    // the move outs are provided in decimeters
    float sourceValue     = myHeaders.find( sourceId   )->second.myVector[traceIndex] ;
    float receiverValue   = myHeaders.find( receiverId )->second.myVector[traceIndex] ;
    float moveOutInMeters = 0.1f * (sourceValue + receiverValue); // 1 decimeter = 0.1 meter
    // vertical moveout in the array = (time in seconds used to travel) / (vertical time in millisecond)
    //int   moveOutNumber = int( ((moveOutInMeters / velocity) / (0.001f * mySampleIntervalMs)) + 0.5f ) ;
    int   moveOutNumber = int( ( (moveOutInMeters) / (0.001f * mySampleIntervalMs *velocity)) + 0.5f );
    // cerr << "moveOutNumber at index " << traceIndex << " is " << moveOutNumber << endl;
    // move the values in the array
    if ( moveOutNumber == 0 ) continue ;
    float * buffer = getBufferAtTraceIndex( traceIndex );
    int   sampleIndex=0;
    // move down
    if ( moveOutNumber > 0 ) {
      for ( sampleIndex=(myNumberOfSamples-1) ; sampleIndex >= moveOutNumber ; --sampleIndex ) {
        buffer[sampleIndex] = buffer[sampleIndex-moveOutNumber];
      }
      // fill the start with 0
      for ( ; sampleIndex >= 0 ; --sampleIndex ) {
        buffer[sampleIndex] = 0.0f;
      }
    }
    // move up
    else {
      for ( sampleIndex=0 ; sampleIndex < (myNumberOfSamples-moveOutNumber) ; ++sampleIndex ) {
        buffer[sampleIndex] = buffer[sampleIndex+moveOutNumber];
      }
      // fill the end with 0
      for ( ; sampleIndex < myNumberOfSamples ; ++sampleIndex ) {
        buffer[sampleIndex] = 0.0f;
      }
    }
  }
  return true ;
}



std::vector< int > DatSlice::getIntervalVector( const DatPointIntervalType & intervals )
{
  static const char * METHOD_NAME = "getIntervalVector()" ;
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME , "Intervals %ld  SampleMs %g" , intervals.size() , mySampleIntervalMs );

  // define statistics of intervals (if any)
  std::vector< int > intervalVector ;
  int numberOfNulls = 0 ;
  if ( mySampleIntervalMs > 0.0f && intervals.empty() == false ) {
    
    // vector to store the sums
    std::vector< std::pair< int , float > > statistics ;
    int i=0 ;
    for ( i=0 ; i < myNumberOfSamples ; ++i ) {
      std::pair< int , float > pr( 0 , 0.0f );
      statistics.push_back( pr );
    }
    
    // cumulate the statistics
    DatPointIntervalType::const_iterator iter ;
    for ( iter=intervals.begin() ; iter != intervals.end() ; ++iter ) {
      // map for this location
      const std::map< int , int > & interval = iter->second ;
      std::map< int , int >::const_iterator mapIter ;
      int   firstTime = -9999 , endT=0 ;
      for ( mapIter=interval.begin() ; mapIter != interval.end() ; ++mapIter ) {
        // first time on the location
        if ( firstTime == -9999 ) { firstTime = mapIter->first ; }
        // define min max
        int intervalBetweenStartEnd = int(mapIter->second / mySampleIntervalMs);
        int startT = int((mapIter->first - firstTime) / mySampleIntervalMs) ;
        endT       = startT + intervalBetweenStartEnd ;
        if ( startT < 0 ) { startT = 0 ; } if ( startT >= myNumberOfSamples ) { startT = (myNumberOfSamples-1) ; }
        if ( endT   < 0 ) { endT   = 0 ; } if ( endT   >= myNumberOfSamples ) { endT   = (myNumberOfSamples-1) ; }
        // add to statistics 
        for ( i=startT ; i <= endT ; ++i ) {
          statistics[i].first  += 1 ;
          statistics[i].second += intervalBetweenStartEnd ;
        }
      }
      // add last interval (till the end ...)
      if ( endT != 0 ) {
        for ( i=endT ; i < myNumberOfSamples ; ++i ) {
          statistics[i].first  += 1 ;
          statistics[i].second += (myNumberOfSamples-1-endT) ;
        }
      }
    }
    
    // define the average one
    for ( i=0 ; i < myNumberOfSamples ; ++i ) {
      if ( statistics[i].first  !=  0 ) { statistics[i].second /= statistics[i].first ; }
      if ( statistics[i].second ==  0.0f  ) {
        numberOfNulls += 1 ;
        MscDg::error( CLASS_NAME , METHOD_NAME , " Null at %g ms" , (i * mySampleIntervalMs) );
      }
      intervalVector.push_back( int(statistics[i].second + 0.05f) );
      if ( dbOn == true ) { MscDg::print( "  Ms:%g  Interval:%d" , (i*mySampleIntervalMs) , statistics[i].second ); }
    }
    
    // errors ...
    if ( numberOfNulls != 0 ) { intervalVector.clear(); }
  }

  // default values if can't do better...
  if ( intervalVector.empty() == true ) {
    for ( int i=0 ; i < myNumberOfSamples ; ++i ) {
      if ( i < 500 ) intervalVector.push_back( 62 ); // 2 sec => 250 ms window
      else if ( i < 1000 ) intervalVector.push_back( 100 ); // 2->4 sec => 400 ms window
      else if ( i < 2000 ) intervalVector.push_back( 250 ); // 4->8 sec => 1000 ms window
      else intervalVector.push_back( 500 ); // 8->12 sec => 2000 ms window
    }
    MscDg::error( CLASS_NAME , METHOD_NAME , "Intervals %ld  SampleMs %g USING DEFAULT (%d nulls observed)" ,
                 intervals.size() , mySampleIntervalMs , numberOfNulls );
  }
  else if ( dbOn == true ) {
    MscDg::print( "  Using provided intervals" );
  }

  return intervalVector ;
}



std::shared_ptr< DatPointFunctionType > DatSlice::snapPicksToAmplitude( const TwoIntKey & location ,
                                                                        const std::shared_ptr<DatPointFunctionType> & inputFunction ,
                                                                        float snapWindowInMs ,
                                                                        const std::vector< int > & intervalVector )
{
  static const char * METHOD_NAME = "snapPicksToAmplitude()" ;
  bool DbOn = MscDg::trace( CLASS_NAME , METHOD_NAME ,
                            "Locaton %d %d  LineNumber %d  TraceNumber %d  IsInline %d  IsTwoD %d  SnapMs %g  Intervals %ld" ,
                            location.getPrime() , location.getSecondary() ,
                            myLineNumber , myTraceNumber , myIsInline , myIsTwoD ,
                            snapWindowInMs , intervalVector.size() );

  // variables
  int numberOfInitialPicks = 0 ; // number of picks at the start
  int numberOfFinalPicks   = 0 ; // number of snapped picks
  int halfWindowSize       = 0 ; // half size of search window
  float * traceAtLocation  = 0 ; // seismic trace for this locationtrace
  std::shared_ptr< DatPointFunctionType > snappedFunction ; // returned function


  // should always be the case
  if ( mySampleIntervalMs > 0.0f ) {
    halfWindowSize  = int(snapWindowInMs / mySampleIntervalMs);
    halfWindowSize /= 2 ;    
  }
  // time window is too small
  if ( halfWindowSize == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "window size is too small (Rms %g ms with increment of %g ms)" ,
                 snapWindowInMs , mySampleIntervalMs );
  }
  // no picks
  else if ( inputFunction.get() == nullptr || inputFunction->isEmpty() == true ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "no picks at %d %d" , location.getPrime() , location.getSecondary() );
  }
  // nothing to do if the slice does not have the location
  else if ( (traceAtLocation = getBufferAtLocation( location )) == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "no trace at %d %d" , location.getPrime() , location.getSecondary() );
  }
  // move in window
  else {

    int firstAmplitudeIndex  = 0 ; // at what time is the amplitude no null

    //--------------------------------------------------
    // find the first non-null amplitude . It's the start for checking the density .
    //--------------------------------------------------
    int i=0 ;
    for ( i=0 ; i < myNumberOfSamples ; ++i ) {
      if ( traceAtLocation[i] != 0.0f ) {
        firstAmplitudeIndex = i ;
        break;
      }
    }

    // number of generated picks
    numberOfInitialPicks = inputFunction->getNumberOfValues();

    //--------------------------------------------------
    // moved picks (time in "ms" && velocity in "float")
    //--------------------------------------------------

    std::map< int , float > snappedIndexes ;
    std::map< int , float >::const_iterator snapIter ;
    // see the provided picks
    int   indexOnTrace = -1 , lastTimeMs = -1 ;
    float amplitudeOnTrace = 0.0f ;
    bool  isFirstPick = true ; // it will stop at the first non null maximum .
    DatPointFunctionType::FunctionConstIterator funcIter ;
    for ( funcIter = inputFunction->getFunctionStart() ; funcIter != inputFunction->getFunctionEnd() ; ++funcIter ) {
      // index of the trace
      lastTimeMs = funcIter->first ;
      i = (int)((float(lastTimeMs) - myFirstSampleMs) / mySampleIntervalMs);
      if ( i < 0 || myNumberOfSamples <= i ) { continue ; }
      // kepp track of the last pick and its amplitude
      indexOnTrace     = i ;
      amplitudeOnTrace = traceAtLocation[i] ;
      // define the window ...
      int startIndex   = (indexOnTrace - halfWindowSize) ;
      int stopIndex    = (indexOnTrace + halfWindowSize) ;
      if ( isFirstPick == true ) { startIndex = indexOnTrace ; } // avoid the first pick to go up
      // ... but stay inside the seismic section
      int lastIndex    = (myNumberOfSamples - 1);
      if ( startIndex  <  0 ) { startIndex = 0 ; }
      if ( stopIndex   <  0 ) { stopIndex  = 0 ; }
      if ( startIndex  >= lastIndex ) { startIndex = lastIndex ; }
      if ( stopIndex   >= lastIndex ) { stopIndex  = lastIndex ; }
      // ready to snap
      if ( startIndex < stopIndex ) {
        // find largest amplitude in the window
        float snapAmplitude = -90000.0f ;
        int   snapIndex     = -1 ;
        for ( i=startIndex ; i <= stopIndex ; ++i ) {
          float amplitude = traceAtLocation[i] ;
          if ( amplitude > snapAmplitude ) {
            snapAmplitude = amplitude ;
            snapIndex     = indexOnTrace ;
          }
          // for the first pick , stop at the first maximum
          else if ( isFirstPick == true && snapIndex != -1 ) {
            break;
          }
        }
        // add it to be interpolated (if the amplitude is not null: case if above the water bottom)
        if ( snapIndex >= firstAmplitudeIndex ) { 
          snappedIndexes[ snapIndex ] = snapAmplitude ;
          isFirstPick = false ;
        }
      }
    }
    // keep the last pick unchanged
    if ( indexOnTrace != -1 ) { snappedIndexes[ indexOnTrace ] = amplitudeOnTrace ; }

    //--------------------------------------------------
    // filter using the interval (depends on the depth) .
    // At least 2 points should be present
    //--------------------------------------------------

    if ( snappedIndexes.size() >= 2 && intervalVector.empty() == false ) {

      std::map< int , float > newSnappedIndexes ;

      // keep the first and last picks unchanged
      std::map< int , float >::const_iterator beginIter = snappedIndexes.begin();
      std::map< int , float >::const_iterator endIter   = snappedIndexes.end()  ;
      --endIter ; // last one. It exists as "snappedIndexes" is not empty
      newSnappedIndexes[ beginIter->first ] = beginIter->second ;
      newSnappedIndexes[ endIter->first   ] = endIter->second   ;

      // *** where to start . As the first pick is kept, limit the first interval  *** 18/11/2015
      int lastIndex = beginIter->first + intervalVector[ beginIter->first ] ;

      // second one. It exists as there are at least 2 picks 
      ++beginIter ; 
      // define the indexes to use . Ignore first and last picks
      std::vector< int > indexedVector ;
      for ( snapIter=beginIter ; snapIter != endIter ; ++snapIter ) {
        indexedVector.push_back( snapIter->first );
      }

      // *** first interval . find the highest amplitude in each interval starting from the current
      int currentPick = 0 ;
      while ( 0 <= currentPick && currentPick < indexedVector.size() ) {

         // the interval for this pick
        int currentIndex = indexedVector[currentPick];       

        // CHANGE : 18/11/2015 . As the first pick is kept, limit the first interval
        // lastIndex    = currentIndex + intervalVector[ currentIndex ];

        // last found . find largest amplitude in the window
        int   lastFound     = -1 ;
        float snapAmplitude = -90000.0f ;
 
        // find largest amplitude in the window
        for ( i=currentPick ; i < indexedVector.size() ; ++i ) {

          // reached the end of the interval
          currentIndex = indexedVector[i];
          if ( currentIndex >= lastIndex ) {
            break;
          }
          // find the highest amplitude
          float amplitude = snappedIndexes.find(currentIndex)->second ;
          if ( amplitude > snapAmplitude ) {
            snapAmplitude = amplitude ;
            currentPick   = i ; // it defines the highest value in the interval
          }
          // still in the interval
          lastFound = i ;
        }

        // keep the pick (it can be the sorted one)
        currentIndex = indexedVector[currentPick];
        newSnappedIndexes[ currentIndex ] = snappedIndexes.find(currentIndex)->second ;

        // *** move to next interval
        currentPick = (lastFound + 1) ;
        // the end for the next pick
        if ( 0 <= currentPick && currentPick < indexedVector.size() ) {
          lastIndex = currentIndex + intervalVector[ currentIndex ];
        }
      }

      // now use the decimated values
      snappedIndexes = newSnappedIndexes ;
    }
    
    //--------------------------------------------------
    // save the snapped values
    //--------------------------------------------------

    if ( snappedIndexes.empty() == false ) {
      // function
      snappedFunction = std::shared_ptr<DatPointFunctionType>(new DatPointFunctionType());
      // populate function
      int timeMs = 0 ;
      for ( snapIter=snappedIndexes.begin() ; snapIter != snappedIndexes.end() ; ++snapIter ) {
        timeMs = int(myFirstSampleMs + (snapIter->first) * mySampleIntervalMs);
        // interpolate and add
        std::shared_ptr< DatPoint > vp( new DatPoint( DatPoint::interpolateDatPoint( inputFunction , timeMs ) ) );
        snappedFunction->putDataInFunction( timeMs , vp );  
      }
      // add the last pick (if not already inside)
      if ( lastTimeMs > (timeMs + 40) ) { 
        std::shared_ptr< DatPoint > vp( new DatPoint( DatPoint::interpolateDatPoint( inputFunction , lastTimeMs ) ) );
        snappedFunction->putDataInFunction( lastTimeMs , vp );       
      }
      // picks
      numberOfFinalPicks = snappedFunction->getNumberOfValues();
    }
  }
  
  // debug
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Location(%d %d) Snapped %d into %d picks" ,
                location.getPrime() , location.getSecondary() , numberOfInitialPicks , numberOfFinalPicks );
  
  return snappedFunction ;
}


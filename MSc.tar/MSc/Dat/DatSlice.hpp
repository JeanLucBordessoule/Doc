#ifndef DAT_SLICE_HPP
#define DAT_SLICE_HPP

#include <map>
#include <memory>
#include <vector>

#include "DatLocation.hpp"
#include "DatPoint.hpp"
#include "MscString.hpp"



/** storage of values in memory.
  * Memory can be stored in vectors (variable length) or in arrays.
  */
class DatArray {
public :
  enum DataType { NOTYPE , INT32 , INT64 , FLOAT32 };
  DatArray( const MscString & = "" , DataType = NOTYPE );
  const MscString & getName() const { return myName ; }
  DataType          getDataType() const { return myDataType; }
  void              setDataType( DataType t ) { myDataType = t ; }
  /** horizontal dimension / number of columns of the array.
   *  If 1 it is only a vector of data */
  int     getNumberOfTraces() const ;
  /** vertical dimension of the array */
  int     getLengthOfTrace() const ;
  /** get the pointer to the memory starting at a given postion */
  float * getFloat32Pointer( size_t firstPosition );
  /** provide values for the interval and the first sample. E.g.: times in ms. */
  float   getSampleRate() const { return mySampleRate ; }
  float   getFirstSampleLocation() const { return myFirstSampleLocation; }
  /** management of the memory */
  bool    hasMovableMemory() const ;
  bool    releaseMemory();
  bool    getFloat32Vector( MscString &errorMessage , const MscString &storeString , std::vector< float > & );
private:
  MscString myName                = ""     ;
  DataType  myDataType            = NOTYPE ;
  float     mySampleRate          = 1.0f   ;
  float     myFirstSampleLocation = 0.0f   ;
};


// access to the data storage (file, database)
class DatStorage {
public:
  enum StoreType {
    ST_UNDEFINED        = (0L)    ,
    ST_WITH_PANELS      = (1L<<0) ,
    ST_SEISMIC_SECTION  = (1L<<1) ,
    ST_STACK_PANELS     = (ST_WITH_PANELS | ST_SEISMIC_SECTION) ,
    ST_RESTACK          =  ST_STACK_PANELS ,
    ST_SEMBLANCE        = (1L<<2) ,
    ST_VERACITY         = (1L<<3) ,
    ST_GATHER           = (1L<<4) ,
    ST_VELOCITY         = (1L<<5) ,
    ST_GUIDE            = (1L<<6) ,
    ST_VELPAC           = (1L<<7) , // VELPAC store
    ST_CMB              = (1L<<8) ,
    ST_TIKKIM           = (1L<<9) ,
    // flags for changing to a VELPAC set of data
    ST_DEFAULT_REQUIRED = ST_STACK_PANELS | ST_SEMBLANCE | ST_VERACITY | ST_GATHER
  } ;
  enum { UndefinedNumber = -1 };
  static const char * DEPTH_SOURCE   ;
  static const char * DEPTH_RECEIVER ;

  DatStorage();
  const MscString & getName() const { return myName ; }
  static MscString getReferenceOfAliasHeaderName( const MscString & );
  bool             readAttributeRange( MscString & errorMessage ,
                                       DatArray  &              , //
                                       size_t    firstPosition  = 1 , // position starts at 1.
                                       size_t    lastPosition   = 0 , // if 0, it's till the end.
                                       bool      acceptAlias    = true ); // accept similar header name
  static void printf( const char * userMessage , int storeType );
private:
  MscString myName ;
};



/** DatSlice is designed to encapsulate the data and the location of a float array.
 * The use is:
 * * slice such as a seismic section (gather, stacks panels, semblance).
*/
class DatSlice {

public :
  static const char * CLASS_NAME ;

  /** type of the array.
   * The horizontal (trace) storage differs according to the type:
   * gather    : offset values . Hence located in 1 place.
   * semblance : panel values  . Hence located in 1 place.
   * stacks    : trace numbers . Hence values for a line.
   */

  /** Operation on the data from the buffer */
  enum Operation { OPE_SET=0 , OPE_ADD , OPE_MULTIPLY , OPE_DIVIDE };

  /** constructor: if 'buffer' is empty, memory is allocated and owned
   *  else the 'buffer' is provided, the memory is destroyed if 'bufferIsOwned' is 'true'.
   */
  DatSlice( int numTraces  = 0 , int numSamples = 0 ,
            float * buffer = nullptr , bool bufferIsOwned = false );
  DatSlice( const DatSlice & );
  DatSlice( DatArray & attribute , DatArray::DataType dataType );
  const DatSlice & operator=( const DatSlice & );
  ~DatSlice();

  /** TYPE */
  void        setStoreType( DatStorage::StoreType t ) { myStoreType = t ; }
  int         getStoreType() const { return myStoreType ; }
  /** is 'true' if it is of same type and have same size */
  bool        hasSameCharacteristics( DatSlice * ) const ;

  /** LOCATION  */
  /** location: storage of a unique location (gather, semblance) */
  void        setLocation( int  l , int  t , bool  b , bool  i=false ) { myLineNumber=l ; myTraceNumber=t ; myIsInline=b ; myIsTwoD=i ;}
  void        getLocation( int &l , int &t , bool &b , bool &i       ) { l=myLineNumber ; t=myTraceNumber ; b=myIsInline ; i=myIsTwoD ; }
  /** line: storage of the values of a line (stacks)*/ 
  void        setLine( int l , bool b , bool t ) { myLineNumber = l ; myIsInline = b ; myIsTwoD = t ;}
  bool        getIsInline() const { return myIsInline ; }
  bool        getIsTwoD()   const { return myIsTwoD   ; }
  void        setPanelNumber( int p ) { myPanelNumber = p ; }
  int         getPanelNumber() const { return myPanelNumber ; }
  /** get the location */
  int         getTraceNumber() const { return myTraceNumber ; }
  TwoIntKey   getTwoIntKey() const { return myIsInline ? TwoIntKey(myLineNumber,myTraceNumber) : TwoIntKey(myTraceNumber,myLineNumber) ; }
  TwoIntKey   getTwoIntKey( int traceIndex , int headerId=0 , bool * outOfRange = 0 );
  /** update the line , trace number . Needed in 2D as the line number is not defined .... */
  void        checkLocation( int lineNumber , bool isInline , bool isTwoD );
  void        checkLocation( int lineNumber , int  traceNumber , bool isInline , bool isTwoD );
  
  /** HEADERS : information for each trace , The 'headerId' is used for the storage in a map
   * See private declaration of 'map< int , HeaderHolder >' ,
   * a vector of float is stored . */
  void        allocateHeader( MscString name = "" , int headerId = 0 , DatArray::DataType = DatArray::FLOAT32 );
  MscString   readHeader( MscString name , const std::shared_ptr< DatStorage > & storage , int headerId=-1 );
  std::vector< int >       getHeaderIds() const ;
  std::vector< MscString > getHeaderNames() const ;
  MscString   getHeaderName    ( int headerId ) const ;
  DatArray::DataType    getHeaderDataType( int headerId ) const ;
  void        setHeaderDataType( int headerId , DatArray::DataType );
  int         getHeaderId( MscString name , bool useFlexibleHeaders , bool & isDefined ) const ;

  void        setHeader( int traceIndex , float , int headerId=0 , bool * outOfRange = 0 );
  float       getHeader( int traceIndex , int headerId=0 , bool * outOfRange = 0 ) ;
  std::vector<float> getHeaderValues( int headerId=0 , bool * outOfRange = 0 ) ;
  int         getHeaderTraceIndex( float value , int headerId=0 , bool * outOfRange = 0 ) ;

  /** TRACES */
  int         getNumberOfTraces()  const   { return myNumberOfTraces   ; }

  /** SAMPLES : set */
  void        setFirstSampleMs( float f )  { myFirstSampleMs   = f     ; }
  void        setSampleIntervalMs( float f ) ;
  void        setSampleIntervalSeconds( float f ) { setSampleIntervalMs( 1000 * f ); }
  /**         : get */
  float       getFirstSampleMs() const     { return myFirstSampleMs    ; }
  float       getSampleIntervalMs() const  { return mySampleIntervalMs ; }
  float       getSampleIntervalSeconds() const { return 0.001f * getSampleIntervalMs() ; }
  int         getNumberOfSamples() const   { return myNumberOfSamples  ; }
  /**           get the index related to this time */
  int         getSampleIndex( float timeMs , bool * outOfRange = 0 );
  /**           get the time (in ms) related to this index */
  int         getSampleTimeMs( int );

  /** BUFFER  : set : allocate will initialize */
  bool        allocateMemory( int numTraces  , int numSamples  , float initValue = 0 );
  bool        setBufferValue( int traceIndex , int sampleIndex , float value , Operation = OPE_SET );
  /**         : get */
  size_t      getBufferSize() const { return myNumberOfTraces*myNumberOfSamples*sizeof(float); }
  float       getBufferValue( int traceIndex , int sampleIndex ) ;

  /**         : get buffer at the start (WARNING: it's the responsability of the application to respect the limits) */
  float     * getBuffer( int * numTraces=0 , int * numSamples=0 ) const ;
  /**         : get buffer at the start of a trace */
  float     * getBufferAtTraceIndex( int traceIndex , bool * outOfRange = 0 ) const ;
  /**         : get buffer at the start of a given location. NULL if none */
  float     * getBufferAtLocation( const TwoIntKey & );

  /** ERROR MESSAGE (is emptied before an operation) */
  MscString   getErrorMessage() const { return  myErrorMessage ; }

  /** TESTING METHODS */
  void        addHeaderForTesting( MscString name , float startValue , float incrementValue );


  /** OPERATIONS (as defined in "DatSliceOperations.cpp") **/
  bool        applyDoubleSquareRoot( float velocity ,
                                     const char * sourceAttr   = DatStorage::DEPTH_SOURCE   ,  // "SP_ST"  ,
                                     const char * receiverAttr = DatStorage::DEPTH_RECEIVER ); // "RCV_ST" );
  /** find the interval according to the depth */
  std::vector< int > getIntervalVector( const DatPointIntervalType & intervals );
  /** snap according to the amplitude */
  std::shared_ptr< DatPointFunctionType > snapPicksToAmplitude( const TwoIntKey & location , const std::shared_ptr<DatPointFunctionType> & ,
                                                                float snapWindowInMs , const std::vector< int > & intervals );
  
protected :

  /***** TYPE (StoreType)      */
  DatStorage::StoreType  myStoreType ;

  /***** LOCATION              */
  int         myLineNumber     ;
  int         myTraceNumber    ; // for SEMBLANCE , GATHER .
  // for STACK_PANEL , headerIndex "1" is the trace name ('offset' along the line)
  int         myPanelNumber    ; // for STACK_PANEL
  bool        myIsInline       ;
  bool        myIsTwoD         ;

  /***** TRACES  (horizontal)  */
  int         myNumberOfTraces ;
  /** header for each trace : used by the seismic section (slice) */
  class HeaderHolder {
  public :
    HeaderHolder( MscString n="" , DatArray::DataType d = DatArray::FLOAT32 ) { myName=n ; myDataType=d ; }
    MscString          myName     ;
    std::vector<float> myVector   ;
    DatArray::DataType myDataType ;
  };
  typedef std::map< int , HeaderHolder > Headers ;
  Headers     myHeaders          ;

  /***** SAMPLES (vertical)    */
  int         myNumberOfSamples  ;
  /** first sample and interval time */
  float       myFirstSampleMs    ;
  float       mySampleIntervalMs ;

  /***** BUFFER [ traceIndex * myNumberOfSamples + sampleIndex ] */
  float     * myBuffer           ;  
  bool        myBufferIsOwned    ;
  MscString   myErrorMessage     ;

private :

  /** initialize */
  void        myInitialize()     ;
};



#endif

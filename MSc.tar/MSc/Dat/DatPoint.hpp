#ifndef DAT_POINT_HPP
#define DAT_POINT_HPP

#include <map>
#include <memory>

#include "DatLocation.hpp"
#include "DatField.hpp"

class DatPoint ;
typedef   DatFunction< int, DatPoint >                          DatPointFunctionType  ;
typedef   DatField< TwoIntKey , int , DatPoint >                DatPointDataModelType ;
typedef   std::map< TwoIntKey , std::shared_ptr<DatPointFunctionType> > DatPointFieldType ;
typedef   std::map< TwoIntKey , std::map< int , int > >         DatPointIntervalType  ;


class DatPoint
{

public:
  
  enum NoVelData   { NOVEL = -200, NOFOC = 0, NOPANEL = -200 };
  enum CreationType{ CREATION_MANUAL = 1, CREATION_GENERATED };

  DatPoint();
  DatPoint( float velocity=0.0f , float fourthOrder=0.0f , float anisotropy=0.0f , float panel=0 , CreationType creation=CREATION_MANUAL );
  DatPoint( const DatPoint & );
  bool operator==( const DatPoint & );
  bool operator!=( const DatPoint & );
  const DatPoint& operator= (const DatPoint & );

  ~DatPoint();
  
  DatPoint interpWithRatio( const DatPoint &d2, const double &ratio );
  
  /** returns 'true' if a change occurred */
  bool setVelocity    ( float f ) { if ( myVelocity    != f ) { myVelocity    = f ; return true; } else { return false; } }
  bool setFourthOrder ( float f ) { if ( myFourthOrder != f ) { myFourthOrder = f ; return true; } else { return false; } }
  bool setAnisotropy  ( float f ) { if ( myAnisotropy  != f ) { myAnisotropy  = f ; return true; } else { return false; } }
  bool setPanel       ( float f ) { if ( myPanel       != f ) { myPanel       = f ; return true; } else { return false; } }
  bool setCreationType( const CreationType pt   ) { if (myCreationType != pt) { myCreationType = pt; return true; } else { return false; } }

  float        getVelocity()     const { return myVelocity     ; }
  float        getFourthOrder()  const { return myFourthOrder  ; }
  float        getAnisotropy()   const { return myAnisotropy   ; }
  float        getPanel()        const { return myPanel        ; }
  CreationType getCreationType() const { return myCreationType ; }

private:  
  
  void myInitialize();

  float         myVelocity     = 0.0f ;
  float         myFourthOrder  = 0.0f ;
  float         myAnisotropy   = 0.0f ;
  int           myPanel        = 0.0f ;
  CreationType  myCreationType = CREATION_MANUAL ;

  //=============================================
  // OTHER INFORMATION TO BE ADDED HERE: reference point (history of changes)...
  //=============================================

  //=============================================
  // STATIC METHODS
  //=============================================

public :

  static DatPoint interpolateDatPoint( std::shared_ptr< DatPointFunctionType > func , int timeMs );

};



#endif

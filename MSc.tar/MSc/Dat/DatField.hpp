#ifndef DAT_FUNCTION_HPP
#define DAT_FUNCTION_HPP

#include <iostream>
#include <map>
#include <memory>

#include "MscDebug.hpp"
#include "MscString.hpp"


/** DatFunction defines the values along a line.
 *  Generally, it is a vertical line, for instance for a velocity function inside seimic section.
 *  It store the values in a map, with the key being a parameter and the value stored in a shared pointer. */



template < class B, class C >
class DatFunction {
public:
  typedef B funcKey;
  typedef C funcData;
  typedef std::map<funcKey,std::shared_ptr<funcData>,std::less<funcKey> > DatFunctionType;
  typedef typename DatFunctionType::iterator       FunctionIterator;
  typedef typename DatFunctionType::const_iterator ConstFunctionIterator;
  typedef typename DatFunctionType::const_iterator FunctionConstIterator;
  typedef typename DatFunctionType::value_type     FunctionValueType;

private:
  DatFunctionType myDatFunction ;
  /** time depth: storage of the modifying depth (horizon) */
  float                myTimeDepthMs      ;
public:

  DatFunction() { myTimeDepthMs = 0 ; }

  void  setTimeDepthMs( float t ) { myTimeDepthMs = t ; }
  float getTimeDepthMs()    const { return myTimeDepthMs ; }

  C DoLinearInterpolation( B lKey, C lData, B hKey, C hData, B slice)
  {
    // to be defined .
    return lData ;
  }

  virtual ~DatFunction()
  {
    clear();
  }

  void clear()
  {
    FunctionIterator iter ;
    for ( iter = myDatFunction.begin() ; iter != myDatFunction.end() ; ++iter ) {
      iter->second = NULL;
    }
    myDatFunction.clear();
  }
  void removeAll()
  {
    clear();
  }


  DatFunction( const DatFunction &that )
  {
    // Use the assignment operator to do the copy.
    *this = that;
  }

  /** This assignment operator properly creates a new velocity function with
   * its own fresh pointers to the data values.*/
  DatFunction &operator=( const DatFunction &that )
  {
    if ( this != &that ) {
      // time depth
      myTimeDepthMs = that.myTimeDepthMs ;
      // function
      removeAll();
      FunctionConstIterator iter ;
      for ( iter = that.myDatFunction.begin() ; iter != that.myDatFunction.end() ; ++iter ) {
        putDataInFunction( iter->first , std::shared_ptr<funcData>( new funcData( *(iter->second) ) ) );
      }
    }
    return *this;
  }

  bool operator==( const DatFunction &that )
  {
    if ( this != &that ) {
      // time depth *is ignored* . What matters is the velocity function
      // function only
      if ( myDatFunction.size() != that.myDatFunction.size() ) { return false ; }
      FunctionIterator      thisIter = getFunctionStart();
      FunctionConstIterator thatIter = that.getFunctionConstStart();
      for ( ; isFunctionDone(thisIter) == false ; ++thisIter , ++thatIter ) {
        if (  thisIter->first            !=  thatIter->first           ) { return false ; }
        if (  thisIter->second.isEmpty() != thatIter->second.isEmpty() ) { return false ; }
        if (  thisIter->second.isEmpty() == false ) {
          if ( *thisIter->second != *thatIter->second ) { return false ; }
        }
      }
    }
    return true;
  }

  bool operator!=( const DatFunction &that )
  {
    return !( *this == that );
  }

  /** This helper function may be used to add data to a
  * DatFunctionType. The key and data are inserted into the
  * func. It returns 'true' if the value has been added or motified */
  bool putDataInFunction( funcKey fkey, funcData data)
  {
    FunctionIterator iter = myDatFunction.find( fkey );
    if ( iter != myDatFunction.end() ) {
      // same
      if ( *iter->second == data ) {
        return false;
      }
      myDatFunction.erase( fkey );
    }
    std::shared_ptr< funcData > handle( new funcData(data) );
    typename DatFunctionType::value_type v( fkey, handle );
    myDatFunction.insert( v );
    return true;
  }

  /** This helper function may be used to add data to a
  * DatFunctionType. The key and data are inserted into the
  * func.*/
  void putDataInFunction( funcKey fkey, std::shared_ptr<funcData> data)
  {
    FunctionIterator iter = myDatFunction.find( fkey );
    if ( iter != myDatFunction.end() ) myDatFunction.erase( fkey );
    typename DatFunctionType::value_type v( fkey, data );
    myDatFunction.insert( v );
  }

  /** This function returns the number of pairs in a
  * VelocityFuntionType . This is the size of the std::map.*/
  int getNumberOfValues( ) const
  {
    return myDatFunction.size();
  }

  /** This method returns the value at the start of an interval */
  funcData intervalValue(  const funcKey & slice , bool & isInsideFunction ,
                           const char * callerName , const char * methodName )
  {
    // exception if empty
    isEmpty( "intervalValue" , callerName , methodName );
    // at a value
    FunctionIterator ison = myDatFunction.find( slice );
    if ( ison != myDatFunction.end() ) {
      isInsideFunction = true ;
      return *(((FunctionValueType)*ison).second);
    }
    // before the first pick
    FunctionIterator high = myDatFunction.upper_bound( slice );
    if ( high == myDatFunction.begin() ) {
      isInsideFunction = false ;
      return *(((FunctionValueType)*high).second);
    }
    // after the last pick
    if ( high == myDatFunction.end() ) {
      --high;
      isInsideFunction = false ;
      return *(((FunctionValueType)*high).second);
    }
    // between 2 values, move to previous (at the start of the interval)
    --high;
    return *(((FunctionValueType)*high).second);
  }

  /** This method returns an interpolated funcData value that
  * corresponds to the value of at slice within func. */
  funcData functionInterpolate(  const funcKey & slice , const char * callerName , const char * methodName )
  {
    // exception if empty
    isEmpty( "functionInterpolate" , callerName , methodName );
    //
    FunctionIterator ison = myDatFunction.find( slice );
    if ( ison == myDatFunction.end() ) {
      FunctionIterator high = myDatFunction.upper_bound( slice );
      if ( high == myDatFunction.begin() ) return *(((FunctionValueType)*high).second);
      if ( high == myDatFunction.end() ) {
        --high;
        return *(((FunctionValueType)*high).second);
      }
      FunctionIterator low = high;
      --low;
      funcKey  lKey  = ( (FunctionValueType) *low).first;
      funcKey  hKey  = ( (FunctionValueType) *high).first;
      funcData lData = *(( (FunctionValueType) *low).second);
      funcData hData = *(( (FunctionValueType) *high).second);
      return DoLinearInterpolation( lKey, lData, hKey, hData, slice);
    }
    else {
      return *(((FunctionValueType)*ison).second);
    }
  }

  /** REMOVE ONCE IT'S PROVED THERE ARE NO ISSUES */
public :
  funcData functionInterpolate(  const funcKey & slice )
  {
    return functionInterpolate( slice , "CLASS" , "UNDEFINED" );
  }
public :

  /** This method returns an interpolated funcData value that
  * corresponds to the value of at slice within func.
  * It takes in account extrapolateLinearTop and extrapolateLinearBottom flags .
  * Unmodified caller is the module (source code not altered ) */
  funcData functionInterpolateWithMask(  const funcKey& slice,
                                         bool extrapolateLinearTop, bool extrapolateLinearBottom ,
                                         const char * callerName , const char * methodName )
  {
    // exception if empty
    isEmpty( "functionInterpolateWithMask" , callerName , methodName );
    //
    FunctionIterator ison = myDatFunction.find( slice );
    if ( ison == myDatFunction.end() ) {
      FunctionIterator high = myDatFunction.upper_bound( slice );
      if ( high == myDatFunction.begin() ) {
        if(extrapolateLinearTop && myDatFunction.size() > 1) {
          funcKey lKey = ( (FunctionValueType) *high).first;
          funcData lData = *(( (FunctionValueType) *high).second);
          ++high;
          funcKey hKey = ( (FunctionValueType) *high).first;
          funcData hData = *(( (FunctionValueType) *high).second);
          return DoLinearInterpolation( lKey, lData, hKey, hData, slice);
        }
        else {
          return *(((FunctionValueType)*high).second);
        }
      }
      if ( high == myDatFunction.end() ) {
        --high;
        if(extrapolateLinearBottom && myDatFunction.size() > 1) {
          funcKey lKey = ( (FunctionValueType) *high).first;
          funcData lData = *(( (FunctionValueType) *high).second);
          --high;
          funcKey hKey = ( (FunctionValueType) *high).first;
          funcData hData = *(( (FunctionValueType) *high).second);
          return DoLinearInterpolation( lKey, lData, hKey, hData, slice);
        }
        else {
          return *(((FunctionValueType)*high).second);
        }
      }
      FunctionIterator low = high;
      --low;
      funcKey lKey = ( (FunctionValueType) *low).first;
      funcKey hKey = ( (FunctionValueType) *high).first;
      funcData lData = *(( (FunctionValueType) *low).second);
      funcData hData = *(( (FunctionValueType) *high).second);
      return DoLinearInterpolation( lKey, lData, hKey, hData, slice);
    } else {
      return *(((FunctionValueType)*ison).second);
    }
  }

  FunctionIterator getFunctionStart()
  {
    return ( myDatFunction.begin() );
  }

  FunctionConstIterator getFunctionStart() const
  {
    return ( myDatFunction.begin() );
  }

  FunctionConstIterator getFunctionConstStart() const
  {
    return ( myDatFunction.begin() );
  }

  FunctionIterator getFunctionEnd()
  {
    return ( myDatFunction.end() );
  }

  FunctionConstIterator getFunctionEnd() const
  {
    return ( myDatFunction.end() );
  }

  FunctionConstIterator getFunctionConstEnd() const
  {
    return ( myDatFunction.end() );
  }

  FunctionIterator getPickIterator( const funcKey& fkey )
  {
    return myDatFunction.find( fkey );
  }

  FunctionConstIterator getPickIterator( const funcKey& fkey ) const
  {
    return myDatFunction.find( fkey );
  }

  FunctionConstIterator getPickConstIterator( const funcKey& fkey ) const
  {
    return myDatFunction.find( fkey );
  }

  bool isFunctionDone( const FunctionIterator& iter )
  {
    return ( iter == myDatFunction.end() );
  }

  bool isFunctionDone( const FunctionConstIterator& iter ) const
  {
    return ( iter == myDatFunction.end() );
  }

  bool isFunctionConstDone( const FunctionConstIterator& iter ) const
  {
    return ( iter == myDatFunction.end() );
  }

  std::pair<FunctionIterator,FunctionIterator> findTwoClosestValues( const funcKey& fkey , const char * callerName , const char * methodName )
  {
    // exception if empty
    isEmpty( "findTwoClosestValues" , callerName , methodName );
    //
    FunctionIterator ison = myDatFunction.find( fkey );
    if ( ison == myDatFunction.end() ) {
      FunctionIterator high = myDatFunction.upper_bound( fkey );
      if ( high == myDatFunction.begin() ) {
        return ( std::pair<FunctionIterator,FunctionIterator>( high, high ) );
      }
      if ( high == myDatFunction.end() ) {
        --high;
        return ( std::pair<FunctionIterator,FunctionIterator>(high,high) );
      }
      FunctionIterator low = high;
      --low;
      return ( std::pair<FunctionIterator,FunctionIterator>( low , high ) );
    }
    else {
      return ( std::pair<FunctionIterator,FunctionIterator>( ison, ison ) );
    }
  }

  std::shared_ptr<funcData> getFunctionData( const FunctionConstIterator& iter ) const
  {
    return ( ((FunctionValueType) *iter).second );
  }

  funcKey getFunctionKey( const FunctionConstIterator& iter ) const
  {
    return ( (funcKey) ((FunctionValueType) *iter).first );
  }

  std::pair<funcKey,funcKey> getFunctionTimeRange( const char * callerName , const char * methodName ) const
  {
    // exception if empty
    isEmpty( "getFunctionTimeRange" , callerName , methodName );
    //
    FunctionConstIterator lst = myDatFunction.end();
    --lst;
    return std::pair<funcKey,funcKey>( getFunctionKey(myDatFunction.begin()),getFunctionKey(lst) );
  }

  /** check function is not empty . Aborts if the method name is provided .
   * MUST keep the option to have 0 parameters for the test without crash */
  bool isEmpty( const char * method = 0 , const char * className = 0 , const char * methodName = 0 ) const
  {
    bool b = myDatFunction.empty() ;
    // abort if it's empty and a method is provided
    if ( b == true && method != 0 ) {
      MscString msg;
      if ( className == 0 ) { className = "" ; }
      if ( methodName == 0 ) {
        msg.printf( "No data in Velocity Function for '%s' called by '%s'" , method , className );
      }
      else {
        msg.printf( "No data in Velocity Function for '%s' called by '%s::%s'" , method , className , methodName );
      }
      MscDg::error( className , methodName , msg );
    }
    return b ;
  }

  bool removeKey( const funcKey& key )
  {
    if ( myDatFunction.find(key) != myDatFunction.end() ) {
      myDatFunction.erase( key );
      return true ;
    }
    else {
      return false ;
    }
  }


  bool removeKey( const funcKey& key , funcKey tolerance )
  {
    if ( myDatFunction.empty() == true ) { return false ; }
    if ( myDatFunction.find(key) != myDatFunction.end() ) {
      myDatFunction.erase( key );
      return true ;
    }
    if ( ! tolerance ) { return false; }
    std::pair<FunctionIterator,FunctionIterator> nearest = findTwoClosestValues(key);
    funcKey distLower = (key  - nearest.first) ;
    funcKey distUpper = (nearest.second - key) ;
    // too far away
    if (distLower > tolerance && distUpper > tolerance) { return false; }
    // consider nearest value
    if ( distLower < distUpper ) {
      myDatFunction.erase( nearest.first );
    }
    else {
      myDatFunction.erase( nearest.second );
    }
    return true;
  }

};



/** DatField has a map of locations (used as keys), the values being 'DatFunction'
 * This template takes 3 classes as arguments ( A,B,C).
 * The first argument, class A, is a Key Value to be used in Locating each function.
 * Classes B and C make up the function defined at Class A.
 * Class B, is the  is typedefed as funcKey.
 * Class C is typedefed as funcData.
 *
 * If class B and C are not either int, float or double,
 * they require several methods to be implemented.
 * */



#include <iostream>
#include <map>
#include <memory>

#include "MscDebug.hpp"
#include "MscString.hpp"



template < class A , class B , class C > class DatField {
public:

  typedef A locationKey ;
  typedef B funcKey     ;
  typedef C funcData    ;

  typedef DatFunction<funcKey,funcData>                   VelFunctionType           ;
  typedef std::map<locationKey,std::shared_ptr< VelFunctionType >,std::less<locationKey> > DatFieldType ;
  typedef typename DatFieldType::iterator                 FieldIterator             ;
  typedef typename DatFieldType::const_iterator           FieldConstIterator        ;
  typedef typename DatFieldType::reverse_iterator         ReverseFieldIterator      ;
  typedef typename DatFieldType::const_reverse_iterator   ReverseFieldConstIterator ;
  typedef typename DatFieldType::value_type               FieldValueType            ;

private:

  /** The This map stores a VelFunctionType at each locationKey,*/
  DatFieldType myField ;

public:

  /** Default Constructor*/
  DatField() {}

  C DoLinearInterpolation( B lKey, C lData, B hKey, C hData, B slice )
  {
    return lData ; //tbd
  }

  C DoLinearInterpolate( C & lData, C & hData, double ratio )
  {
    return lData ; //tbd
  }


  /** Default Destructor.*/
  virtual ~DatField()
  {
    clear();
  }

  /** clear */
  virtual void clear()
  {
    for ( FieldIterator iter = myField.begin() ; iter != myField.end() ; ++iter ) {
      (*iter).second = NULL;
    }
    myField.clear();
  }


  /** Given a locationKey and VelocityFunctionType, the function is
   * inserted into the Velocity  Field using the key as the
   * location. If a function already exsists at this key it is
   * replaced with func. This method is how data is placed into the
   * veloctiy Field.*/
  virtual void putFunctionInField( locationKey vkey , std::shared_ptr<VelFunctionType> func )
  {
    (void)deleteFunction( vkey );
    typename DatFieldType::value_type v( vkey, func );
    myField.insert( v );
  }


  /** Given an interger index the locationKey in the DatField that is
   * currently at the given index is returned.*/
  locationKey getKey( int index , const char * callerName , const char * methodName ) const
  {
    FieldConstIterator iter =  myField.begin();
    for ( int i = 0 ; i < index ; ++i , ++iter ) {
      if ( iter == myField.end() ) {
        MscString msg;
        if ( methodName == 0 ) {
          msg.printf( "Index %d not in the Velocity Field: %s" , index , callerName ? callerName : "" );
        }
        else {
          msg.printf( "Index %d not in the Velocity Field: %s::%s" , index , callerName ? callerName : "" , methodName );
        }
        throw std::exception( msg , "DatField::getKey" );
      }
    }
    return iter->first;
  }


  /** Given an integer index a std::shared_ptr to a VelocityFunctionType in
   * the DatField that is currently at the given index is
   * returned.*/
  std::shared_ptr<VelFunctionType> getFunction( int index , const char * callerName , const char * methodName ) const
  {
    FieldConstIterator iter = myField.begin();
    for ( int i = 0 ; i < index ; ++i , ++iter ) {
      if ( iter == myField.end() ) {
        MscString msg;
        if ( methodName == 0 ) {
          msg.printf( "Index %d not in the Velocity Field: %s" , index , callerName ? callerName : "" );
        }
        else {
          msg.printf( "Index %d not in the Velocity Field: %s::%s" , index , callerName ? callerName : "" , methodName );
        }
        throw std::exception( msg , "DatField::getFunction" );
      }
    }
    return iter->second;
  }

  /** REMOVE ONCE IT'S PROVEN THERE ARE NO ISSUES */
public :
  std::shared_ptr<VelFunctionType> getFunction( int index ) const
  {
    return getFunction( index , "CLASS" , "UNDEFINED" );
  }
public :


  /** This function returns the current number of Velocity Functions
   * in the Velocity field.*/
  int getNumberOfFunctions() const
  {
    return myField.size();
  }

  /** Get the function for a location. Returns '0' if not present */
  VelFunctionType * getFunctionAtLocation( const locationKey & a , bool addIfMissing = false )
  {
    FieldIterator iter = myField.find(a);
    if ( iter == myField.end() || iter->second.isEmpty() == true ) {
      if ( addIfMissing == false ) {
        return 0;
      }
      // add it
      myField[a] = new VelFunctionType();
      iter=myField.find(a);
    }
    return iter->second->get() ;
  }

  /** Add a location. Return 'true' if the location was not present. */
  bool addFunction( const locationKey & a )
  {
    FieldIterator iter=myField.find(a);
    if ( iter != myField.end() && iter->second.isEmpty() == false ) { return false; }
    myField[a] = new VelFunctionType();
    return true;
  }

  /** Add a value. Returns 'true' if the value has been replaced or added (a change occurred).
   * Add the function if needed */
  bool addValue( const locationKey & a , funcKey b , funcData c )
  {
    VelFunctionType * func = getValuesAtLocation(a,true);
    return func->putDataInFunction( b , c );
  }

  /** Delete a location. Return 'true' if the location was present and has been deleted */
  bool deleteLocation( const locationKey & a )
  {
    FieldIterator iter=myField.find(a);
    if ( iter == myField.end() ) { return false; }
    myField.erase(iter);
    return true;
  }

  /** Delete a value. Return 'true' if the value was present and has been removed.
   *  Delete the Function if the function is empty */
  bool deleteValue( const locationKey & a , funcKey b , funcKey tolerance = 0 )
  {
    bool valueHasBeenDeleted = false ;
    VelFunctionType * func = getValuesAtLocation(a,false);
    if ( func != 0 ) {
      // return 'true' if
      valueHasBeenDeleted = func->removeKey(b,tolerance);
      // delete location if needed
      if ( valueHasBeenDeleted == true && func->isEmpty() == true ) {
        deleteLocation(a);
      }
    }
    return valueHasBeenDeleted;
  }

  /** Given a locationKey and funcKey an interval funcData is returned.*/
  funcData getIntervalValue( const locationKey& vkey , const funcKey& slice , bool & isInsideFunction ,
                             const char * callerName , const char * methodName ) const
  {
    isInsideFunction = false;
    FieldConstIterator iter = myField.find( vkey );
    if ( hasValues(iter) == false ) {
      return funcData();
    }
    return ( iter->second->intervalValue( slice , isInsideFunction , callerName , methodName ) );
  }

  /** Given a locationKey and funcKey an interpolated funcData is returned.*/
  funcData getSliceValue( const locationKey& vkey , const funcKey& slice , const char * callerName , const char * methodName ) const
  {
    FieldConstIterator iter = myField.find( vkey );
    if ( hasValues(iter) == false ) {
      return funcData();
    }
    return ( iter->second->functionInterpolate( slice , callerName , methodName ) );
  }


  /** provide a linearInterSliceValue Function that takes the two closest functions as
      an argument and the ratio */
  funcData linearInterpSliceValueWithFuncsAndRatio( const std::pair<FieldIterator,FieldIterator> & lowAndHigh ,
                                                    double & ratio,
                                                    const locationKey & vkey ,
                                                    const funcKey & slice ,
                                                    const char * callerName ,
                                                    const char * methodName ) const
  {
    FieldIterator low  = lowAndHigh.first ;
    FieldIterator high = lowAndHigh.second;
    // exception if empty
    if ( hasValues(low) == false || hasValues(high) == false ) {
      MscString msg;
      if ( methodName == 0 ) {
        msg.printf( "No data in Velocity Field for 'linearInterpSliceValueWithFuncsAndRatio' called by '%s'" ,
                    callerName ? callerName : "" );
      }
      else {
        msg.printf( "No data in Velocity Field for 'linearInterpSliceValueWithFuncsAndRatio' called by '%s::%s'" ,
                    callerName ? callerName : "" , methodName );
      }
      throw std::exception( msg , "DatField::hasValues" );
    }
    //
    if ( low == high ) {
      std::shared_ptr<VelFunctionType> func = (*high).second;
      return ( func->functionInterpolate(  slice , callerName , methodName ) );
    }
    std::shared_ptr<VelFunctionType> func = (*high).second;
    funcData hData = func->functionInterpolate(  slice , callerName , methodName );
    func = (*low).second;
    funcData lData = func->functionInterpolate(  slice , callerName , methodName );
    return DoLinearInterpolate( lData, hData, ratio );
  }


  /** provide a linearInterpSliceValue function that takes the two closest functions as
      an argument*/
  funcData linearInterpSliceValueWithFunctions( const std::pair<FieldIterator,FieldIterator> & lowAndHigh ,
                                                const locationKey & vkey ,
                                                const funcKey & slice ,
                                                const char * callerName ,
                                                const char * methodName ) const
  {
    FieldIterator low  = lowAndHigh.first ;
    FieldIterator high = lowAndHigh.second;
    // exception if empty
    if ( hasValues(low) == false || hasValues(high) == false ) {
      MscString msg;
      if ( methodName == 0 ) {
        msg.printf( "No data in Velocity Field for 'linearInterpSliceValueWithFunctions' called by '%s'" ,
                    callerName ? callerName : "" );
      }
      else {
        msg.printf( "No data in Velocity Field for 'linearInterpSliceValueWithFunctions' called by '%s::%s'" ,
                    callerName ? callerName : "" , methodName );
      }
      throw std::exception( msg , "DatField::hasValues" );
    }
    //
    if ( low == high ) {
      std::shared_ptr<VelFunctionType> func = (*high).second;
      return ( func->functionInterpolate( slice , callerName , methodName ) );
    }
    locationKey lkey = (*low ).first;
    locationKey hkey = (*high).first;
    std::shared_ptr<VelFunctionType> func = (*high).second;
    funcData hData = func->functionInterpolate( slice , callerName , methodName );
    func = (*low).second;
    funcData lData = func->functionInterpolate( slice , callerName , methodName );
    return DoLinearInterpolation( lkey, lData, hkey, hData, vkey);
  }



  /** Given a locationKey and a slice value the Interpolated funcData at
   * the slice value at the Key Location even if a function is not
   * present at that location. This is accomplished by computing a
   *  interpolation between locationKeys.*/
  funcData linearInterpIntervalValue( const locationKey& vkey, const funcKey& slice ,
                                      bool & isInsideFunction ,
                                      const char * callerName , const char * methodName )
  {
    isInsideFunction = false ;
    // exception if empty
    hasValues( "linearInterpIntervalValue" , callerName , methodName );
    // at a function (can be inside at function)
    FieldIterator iter = myField.find( vkey );
    if ( iter != myField.end() ) {
      return iter->second->intervalValue( slice , isInsideFunction , callerName , methodName );
    }
    // before , after
    bool b ;
    std::pair<FieldIterator,FieldIterator> nearest = findTwoClosestFunctionsWithValues( vkey ,
                                                                                        callerName , methodName );
    if ( nearest.first == nearest.second ) {
      return nearest.first->second->intervalValue( slice , b , callerName , methodName );
    }
    // between
    funcData firstData  = nearest.first ->second->intervalValue( slice , b , callerName , methodName );
    funcData secondData = nearest.second->second->intervalValue( slice , b , callerName , methodName );
    return DoLinearInterpolation( nearest.first ->first , firstData  ,
                                  nearest.second->first , secondData ,
                                  vkey );
  }



  /** Given a locationKey and a slice value the Interpolated funcData at
   * the slice value at the Key Location even if a function is not
   * present at that location. This is accomplished by computing a
   * linear interpolation between locationKeys.*/
  funcData linearInterpSliceValue( const locationKey& vkey, const funcKey& slice ,
                                   const char * callerName , const char * methodName ) const
  {
    // exception if empty
    hasValues("linearInterpSliceValue",callerName,methodName);
    //
    FieldConstIterator ison = myField.find( vkey );
    if ( ison == myField.end() ) {
      FieldConstIterator high = myField.upper_bound( vkey );
      locationKey hkey;
      if ( high == myField.begin() ) {
        std::shared_ptr<VelFunctionType> func = (*high).second;
        return ( func->functionInterpolate( slice , callerName , methodName ) );
      }
      if ( high == myField.end() ) {
        --high;
        std::shared_ptr<VelFunctionType> func = (*high).second;
        return ( func->functionInterpolate( slice , callerName , methodName ) );
      }
      hkey = (*high).first;
      if (  ! hkey.isSamePrime( vkey ) ) {
        --high;
      }
      hkey = (*high).first;
      if ( ! hkey.isSamePrime( vkey ) ) {
        std::shared_ptr<VelFunctionType> func = (*high).second;
        return ( func->functionInterpolate( slice , callerName , methodName ) );
      }
      if ( high == myField.begin() ) {
        std::shared_ptr<VelFunctionType> func = (*high).second;
        return ( func->functionInterpolate( slice , callerName , methodName ) );
      }
      FieldConstIterator low = high;
      --low;
      locationKey lkey = (*low).first;
      if ( ! lkey.isSamePrime( vkey ) ) {
        std::shared_ptr<VelFunctionType> func = (*high).second;
        return ( func->functionInterpolate( slice , callerName , methodName ) );
      }
      std::shared_ptr<VelFunctionType> func = (*high).second;
      funcData hData = func->functionInterpolate( slice , callerName , methodName );
      func = (*low).second;
      funcData lData = func->functionInterpolate( slice , callerName , methodName );
      return DoLinearInterpolation( lkey, lData, hkey, hData, vkey);
    }
    else {
      std::shared_ptr<VelFunctionType> func = (*ison).second;
      return ( func->functionInterpolate( slice , callerName , methodName ) );
    }
  }


  std::shared_ptr<VelFunctionType> findFunction( const locationKey & vkey , const char * callerName , const char * methodName ) const
  {
    FieldConstIterator iter = myField.find( vkey );
    if ( iter==myField.end() ) {
      MscString msg ;
      if ( callerName != 0 ) {
        if ( methodName == 0 ) {
          msg.printf( "Can't find velocity function for: %s" , callerName );
        }
        else {
          msg.printf( "Can't find velocity function for %s::%s" , callerName , methodName );
        }
      }
      else {
        msg.printf( "Can't find velocity function" );
      }
      throw std::exception( msg , "DatField::findFunction" );
    }
    return ( iter->second );
  }


  bool isFunctionHere( const locationKey& vkey ) const
  {
    return ( myField.find( vkey ) != myField.end() );
  }


  bool deleteFunction( const locationKey& vkey )
  {
    FieldIterator iter = myField.find( vkey );
    if ( iter == myField.end() ) return false;
    (*iter).second = NULL;
    myField.erase( iter );
    return true;
  }


  /** test the iterator refers to a no-null function .
  * STATIC method can't test the 'end' */
  static bool HasValues( FieldConstIterator iter )
  {
    return ( iter->second.isEmpty() == false && iter->second->isEmpty() == false );
  }

  bool hasValues( FieldConstIterator iter ) const
  {
    return ( iter != myField.end() && iter->second.isEmpty() == false && iter->second->isEmpty() == false );
  }

  bool hasValues( FieldIterator iter )
  {
    return ( iter != myField.end() && iter->second.isEmpty() == false && iter->second->isEmpty() == false );
  }

  /** test if there are Values. Throw exception if callerName is not null */
  bool hasValues( const char * method = 0 , const char * callerName = 0 , const char * methodName = 0 ) const
  {
    FieldConstIterator iter ;
    for ( iter = myField.begin() ; iter != myField.end() ; ++iter ) {
      if ( hasValues(iter) == true ) {
        return true;
      }
    }
    // no Values
    if ( method != 0 ) {
      MscString msg;
      if ( methodName == 0 ) {
        msg.printf( "No data in Velocity Field for '%s' called by '%s'" ,
                    method , callerName ? callerName : "" );
      }
      else {
        msg.printf( "No data in Velocity Field for '%s' called by '%s::%s'" ,
                    method , callerName ? callerName : "" , methodName );
      }
      throw std::exception( msg , "DatField::hasValues" );
    }
    return false;
  }

  bool isEmpty( const char * method = 0 , const char * callerName = 0 , const char * methodName = 0 ) const
  {
    return (hasValues(method,callerName,methodName) == false);
  }


  int getNumberOfValues() const
  {
    int num = 0 ;
    FieldConstIterator iter ;
    for ( iter = myField.begin(); iter != myField.end(); ++iter ) {
      if ( hasValues(iter) == true ) {
        num += iter->second->getNumberOfValues() ;
      }
    }
    return num ;
  }

  std::pair<FieldIterator,FieldIterator> findTwoClosestFunctions( const locationKey & vkey ,
                                                                  const char * callerName , const char * methodName )
  {
    // exception is empty
    if ( myField.empty() == true ) {
      MscString msg;
      if ( methodName == 0 ) {
        msg.printf( "No data in Velocity Field for 'findTwoClosestFunctions' called by '%s'" ,
                    callerName ? callerName : "" );
      }
      else {
        msg.printf( "No data in Velocity Field for 'findTwoClosestFunctions' called by '%s::%s'" ,
                    callerName ? callerName : "" , methodName );
      }
      throw std::exception( msg , "DatField::hasValues" );
    }
    //
    FieldIterator ison = myField.find( vkey );
    if ( ison == myField.end() ) {
      FieldIterator high = myField.upper_bound( vkey );
      if ( high == myField.begin() ) return ( std::pair<FieldIterator,FieldIterator>(high,high) );
      if ( high == myField.end() ) {
        --high;
        return ( std::pair<FieldIterator,FieldIterator>(high,high) );
      }
      if ( high == myField.begin() ) return ( std::pair<FieldIterator,FieldIterator>(high,high) );
      FieldIterator low = high;
      --low;
      return ( std::pair<FieldIterator,FieldIterator>(low,high) );
    }
    else {
      return ( std::pair<FieldIterator,FieldIterator>(ison,ison) );
    }
  }



  std::pair<FieldIterator,FieldIterator> findTwoClosestFunctionsWithValues( const locationKey & vkey ,
                                                                            const char * callerName , const char * methodName )
  {
    // exception is empty
    hasValues("findTwoClosestFunctionsWithValues" , callerName , methodName );
    // use the default function... (faster)
    std::pair<FieldIterator,FieldIterator> closestFunc = findTwoClosestFunctions( vkey , callerName , methodName );
    bool lowHasValues  = hasValues(closestFunc.first );
    bool highHasValues = hasValues(closestFunc.second);
    if ( lowHasValues && highHasValues ) {
      return closestFunc;
    }
    // find ...
    FieldIterator low  = myField.end();
    FieldIterator high = myField.end();
    for ( FieldIterator iter = myField.begin() ; iter != myField.end() ; ++iter ) {
      if ( hasValues(iter) == true ) {
        // initialize
        if ( low == myField.end() ) {
          low   = iter;
          high  = iter;
        }
        // compare
        else {
          // low < iter <= vkey
          if ( ( (*low).first  <  (*iter).first ) && ! ( vkey < (*iter).first ) ) {
            low  = iter;
          }
          // vkey <= iter < high
          if ( ! ( (*iter).first < vkey ) && ( (*iter).first <  (*high).first)  ) {
            high = iter; // upper_bound
          }
        }
      }
    }
    // check (should not happen as catch at the start)
    if ( low == myField.end() ) {
      MscString msg;
      if ( methodName == 0 ) {
        msg.printf( "No data in Velocity Field for 'findTwoClosestFunctionsWithValues:1' called by '%s'" ,
                    callerName ? callerName : "" );
      }
      else {
        msg.printf( "No data in Velocity Field for 'findTwoClosestFunctionsWithValues:1' called by '%s::%s'" ,
                    callerName ? callerName : "" , methodName );
      }
      throw std::exception( msg , "DatField::findTwoClosestFunctionsWithValues" );
    }
    // message if algorithm differs ... (could happen if < used instead of <= in upper_bound ?)
    if ( lowHasValues  && closestFunc.first  != low ) {
      std::cerr << "DatField::findTwoClosestFunctionsWithValues:1 : low differs !" << std::endl;
    }
    if ( highHasValues && closestFunc.second != high ) {
      std::cerr << "DatField::findTwoClosestFunctionsWithValues:1 : high differs !" << std::endl;
    }
    return ( std::pair<FieldIterator,FieldIterator>(low,high) );
  }


  FieldIterator getFieldStart()
  {
    return myField.begin();
  }


  FieldConstIterator getFieldStart() const
  {
    return myField.begin();
  }

  FieldConstIterator getFieldConstStart() const
  {
    return myField.begin();
  }


  FieldIterator getFieldEnd()
  {
    return myField.end();
  }


  FieldConstIterator getFieldEnd() const
  {
    return myField.end();
  }

  FieldConstIterator getFieldConstEnd() const
  {
    return myField.end();
  }


  ReverseFieldIterator getReverseFieldStart()
  {
    return myField.rbegin();
  }


  ReverseFieldConstIterator getReverseFieldStart() const
  {
    return myField.rbegin();
  }

  ReverseFieldConstIterator getReverseFieldConstStart() const
  {
    return myField.rbegin();
  }

  bool isFieldDone( const FieldIterator & iter )
  {
    return ( iter == myField.end() );
  }

  bool isFieldDone( const FieldConstIterator & iter ) const
  {
    return ( iter == myField.end() );
  }

  bool isFieldConstDone( const FieldConstIterator & iter ) const
  {
    return ( iter == myField.end() );
  }

  bool isReverseFieldDone( const ReverseFieldIterator & iter )
  {
    return ( iter == myField.rend() );
  }

  bool isReverseFieldDone( const ReverseFieldConstIterator & iter ) const
  {
    return ( iter == myField.rend() );
  }

  bool isReverseFieldConstDone( const ReverseFieldConstIterator & iter ) const
  {
    return ( iter == myField.rend() );
  }

  locationKey getKey( const FieldIterator & iter )
  {
    return ( iter->first );
  }

  const locationKey & getKey( const FieldConstIterator & iter ) const
  {
    return ( iter->first );
  }

  const locationKey & getConstKey( const FieldConstIterator & iter ) const
  {
    return ( iter->first );
  }

  std::shared_ptr<VelFunctionType> getFunction( const FieldIterator & iter )
  {
    return ( iter->second );
  }

  const std::shared_ptr<VelFunctionType> & getFunction( const FieldConstIterator & iter ) const
  {
    return ( iter->second );
  }

  const std::shared_ptr< const VelFunctionType > & getConstFunction( const FieldConstIterator & iter ) const
  {
    return ( iter->second );
  }


};





#endif



#include "DatPoint.hpp"
#include "MscDebug.hpp"


DatPoint::DatPoint( float velocity , float fourthOrder , float anisotropy , float panel , DatPoint::CreationType creation )
{
  myVelocity     = velocity    ;
  myFourthOrder  = fourthOrder ;
  myAnisotropy   = anisotropy  ;
  myPanel        = panel       ;
  myCreationType = creation    ;
}


DatPoint::DatPoint( const DatPoint & vp )
{
  *this = vp;
}


bool DatPoint::operator==( const DatPoint &that )
{
  if ( this == &that ) return true;
  if ( myVelocity     != that.myVelocity     ) return false;
  if ( myFourthOrder  != that.myFourthOrder  ) return false;
  if ( myAnisotropy   != that.myAnisotropy   ) return false;
  if ( myPanel        != that.myPanel        ) return false;
  if ( myCreationType != that.myCreationType ) return false;
  return true;
}


bool DatPoint::operator!=( const DatPoint &that )
{
  return !( *this == that );
}


const DatPoint& DatPoint::operator=(const DatPoint& that)
{
  if ( this != &that ) {
    myVelocity     = that.myVelocity     ;
    myFourthOrder  = that.myFourthOrder  ;
    myAnisotropy   = that.myAnisotropy   ;
    myPanel        = that.myPanel        ;
    myCreationType = that.myCreationType ;
  }
  return *this;
}


DatPoint::~DatPoint()
{
}


DatPoint DatPoint::interpWithRatio( const DatPoint & d2 , const double & ratio )
{
  float v = getVelocity()    + (float) ( ratio * (double) ( d2.getVelocity()    - getVelocity()    ) );
  float f = getFourthOrder() + (float) ( ratio * (double) ( d2.getFourthOrder() - getFourthOrder() ) );
  float a = getAnisotropy()  + (float) ( ratio * (double) ( d2.getAnisotropy()  - getAnisotropy()  ) );
  float p = getPanel()       + (float) ( ratio * (double) ( d2.getPanel()       - getPanel()       ) );
  DatPoint vp(v,f,a,p,CreationType::CREATION_GENERATED);
  return vp;
}


//-----------------------------------------------------------------------//
//-----------------------------------------------------------------------//
//         Static Methods                                                //
//-----------------------------------------------------------------------//
//-----------------------------------------------------------------------//

static const char * CLASS_NAME = "DatPoint" ;

/**
 ** interpolate value
 **/
DatPoint DatPoint::interpolateDatPoint( std::shared_ptr< DatPointFunctionType > func , int timeMs )
{
  static const char * METHOD_NAME = "interpolateDatPoint()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "TimeMs %d" , timeMs );

  // on a time or before the first or after the last
  std::pair< DatPointFunctionType::FunctionConstIterator ,
        DatPointFunctionType::FunctionConstIterator > pr =
    func->findTwoClosestValues( timeMs , CLASS_NAME , METHOD_NAME );
  if ( pr.first == pr.second ) {
    return *pr.first->second;
  }
  // one is before and one is after
  else {
    float ratio = float(timeMs - pr.first->first) / float(pr.second->first - pr.first->first);
    float v = pr.first->second->getVelocity() + ratio * ( pr.second->second->getVelocity() - pr.first->second->getVelocity() ) ;
    // keep the interval values intact. Return the values of the previous pick.
    float f = pr.first->second->getFourthOrder();
    float a = pr.first->second->getAnisotropy();
    float p = pr.first->second->getPanel();
    DatPoint DatPoint(v,f,a,p,CreationType::CREATION_GENERATED);
    return DatPoint ;
  }
}


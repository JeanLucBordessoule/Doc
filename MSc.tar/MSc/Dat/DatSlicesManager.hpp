#ifndef DATA_SLICES_MANAGER_HPP
#define DATA_SLICES_MANAGER_HPP

/** DatSlicesManager : manage a set of slices. */

#include <memory>
#include <vector>

#include "DatSlice.hpp"
#include "MscMessageProvider.hpp"


class DatSlicesManager : public MscMessageProvider
{
public :
  static const char * CLASS_NAME ;

  /** created for a given store */
  DatSlicesManager( DatStorage::StoreType );
  ~DatSlicesManager() {}

  /** storage of the sections */
  typedef std::vector< std::shared_ptr< DatSlice > > SeismicSectionMap ;

  /** seismic section */
  const SeismicSectionMap   & getSeismicSectionMap() const { return mySeismicSections ; }
  std::shared_ptr< DatSlice > getSeismicSectionAtSlice( int sliceNumber ) const ;
  /** print some details about them (for debug purpose) */
  void                        print() const ;

protected :
  
  /** type of data */
  const DatStorage::StoreType myStoreType       ;
  /** storage of the sections */
  SeismicSectionMap           mySeismicSections ;
};


#endif


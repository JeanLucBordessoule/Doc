#ifndef DAT_FUNCTION_HPP
#define DAT_FUNCTION_HPP

#include <map>
#include <memory>

#include "MscString.hpp"




template < class B, class C >
class DatFunction {
public:
  typedef B funcKey;
  typedef C funcData;
  typedef std::map<funcKey,std::shared_ptr<funcData>,std::less<funcKey> > DatFunctionType;
  typedef typename DatFunctionType::iterator       FunctionIterator;
  typedef typename DatFunctionType::const_iterator ConstFunctionIterator;
  typedef typename DatFunctionType::const_iterator FunctionConstIterator;
  typedef typename DatFunctionType::value_type     FunctionValueType;

private:
  DatFunctionType myDatFunction ;
  /** time depth: storage of the modifying depth (horizon) */
  float                myTimeDepthMs      ;
public:

  DatFunction() { myTimeDepthMs = 0 ; }

  void  setTimeDepthMs( float t ) { myTimeDepthMs = t ; }
  float getTimeDepthMs()    const { return myTimeDepthMs ; }

  C DoLinearInterpolation( B lKey, C lData, B hKey, C hData, B slice)
  {
    // to be defined .
    return lData ;
  }

  virtual ~DatFunction()
  {
    clear();
  }

  void clear()
  {
    FunctionIterator iter ;
    for ( iter = myDatFunction.begin() ; iter != myDatFunction.end() ; ++iter ) {
      iter->second = NULL;
    }
    myDatFunction.clear();
  }
  void removeAll()
  {
    clear();
  }


  DatFunction( const DatFunction &that )
  {
    // Use the assignment operator to do the copy.
    *this = that;
  }

  /** This assignment operator properly creates a new velocity function with
   * its own fresh pointers to the data values.*/
  DatFunction &operator=( const DatFunction &that )
  {
    if ( this != &that ) {
      // time depth
      myTimeDepthMs = that.myTimeDepthMs ;
      // function
      removeAll();
      FunctionConstIterator iter ;
      for ( iter = that.myDatFunction.begin() ; iter != that.myDatFunction.end() ; ++iter ) {
        putDataInFunction( iter->first , std::shared_ptr<funcData>( new funcData( *(iter->second) ) ) );
      }
    }
    return *this;
  }

  bool operator==( const DatFunction &that )
  {
    if ( this != &that ) {
      // time depth *is ignored* . What matters is the velocity function
      // function only
      if ( myDatFunction.size() != that.myDatFunction.size() ) { return false ; }
      FunctionIterator      thisIter = getFunctionStart();
      FunctionConstIterator thatIter = that.getFunctionConstStart();
      for ( ; isFunctionDone(thisIter) == false ; ++thisIter , ++thatIter ) {
        if (  thisIter->first            !=  thatIter->first           ) { return false ; }
        if (  thisIter->second.isEmpty() != thatIter->second.isEmpty() ) { return false ; }
        if (  thisIter->second.isEmpty() == false ) {
          if ( *thisIter->second != *thatIter->second ) { return false ; }
        }
      }
    }
    return true;
  }

  bool operator!=( const DatFunction &that )
  {
    return !( *this == that );
  }

  /** This helper function may be used to add data to a
  * DatFunctionType. The key and data are inserted into the
  * func. It returns 'true' if the value has been added or motified */
  bool putDataInFunction( funcKey fkey, funcData data)
  {
    FunctionIterator iter = myDatFunction.find( fkey );
    if ( iter != myDatFunction.end() ) {
      // same
      if ( *iter->second == data ) {
        return false;
      }
      myDatFunction.erase( fkey );
    }
    std::shared_ptr< funcData > handle( new funcData(data) );
    typename DatFunctionType::value_type v( fkey, handle );
    myDatFunction.insert( v );
    return true;
  }

  /** This helper function may be used to add data to a
  * DatFunctionType. The key and data are inserted into the
  * func.*/
  void putDataInFunction( funcKey fkey, std::shared_ptr<funcData> data)
  {
    FunctionIterator iter = myDatFunction.find( fkey );
    if ( iter != myDatFunction.end() ) myDatFunction.erase( fkey );
    typename DatFunctionType::value_type v( fkey, data );
    myDatFunction.insert( v );
  }

  /** This function returns the number of pairs in a
  * VelocityFuntionType . This is the size of the std::map.*/
  int getNumberOfPicks( ) const
  {
    return myDatFunction.size();
  }

  /** This method returns the value at the start of an interval */
  funcData intervalValue(  const funcKey & slice , bool & isInsideFunction ,
                           const char * callerName , const char * methodName )
  {
    // exception if empty
    isEmpty( "intervalValue" , callerName , methodName );
    // at a value
    FunctionIterator ison = myDatFunction.find( slice );
    if ( ison != myDatFunction.end() ) {
      isInsideFunction = true ;
      return *(((FunctionValueType)*ison).second);
    }
    // before the first pick
    FunctionIterator high = myDatFunction.upper_bound( slice );
    if ( high == myDatFunction.begin() ) {
      isInsideFunction = false ;
      return *(((FunctionValueType)*high).second);
    }
    // after the last pick
    if ( high == myDatFunction.end() ) {
      --high;
      isInsideFunction = false ;
      return *(((FunctionValueType)*high).second);
    }
    // between 2 picks
    // move to previous (at the start of the interval)
    --high;
    return *(((FunctionValueType)*high).second);
  }

  /** This method returns an interpolated funcData value that
  * corresponds to the value of at slice within func. */
  funcData functionInterpolate(  const funcKey & slice , const char * callerName , const char * methodName )
  {
    // exception if empty
    isEmpty( "functionInterpolate" , callerName , methodName );
    //
    FunctionIterator ison = myDatFunction.find( slice );
    if ( ison == myDatFunction.end() ) {
      FunctionIterator high = myDatFunction.upper_bound( slice );
      if ( high == myDatFunction.begin() ) return *(((FunctionValueType)*high).second);
      if ( high == myDatFunction.end() ) {
        --high;
        return *(((FunctionValueType)*high).second);
      }
      FunctionIterator low = high;
      --low;
      funcKey  lKey  = ( (FunctionValueType) *low).first;
      funcKey  hKey  = ( (FunctionValueType) *high).first;
      funcData lData = *(( (FunctionValueType) *low).second);
      funcData hData = *(( (FunctionValueType) *high).second);
      return DoLinearInterpolation( lKey, lData, hKey, hData, slice);
    }
    else {
      return *(((FunctionValueType)*ison).second);
    }
  }

  /** REMOVE ONCE IT'S PROVED THERE ARE NO ISSUES */
public :
  funcData functionInterpolate(  const funcKey & slice )
  {
    return functionInterpolate( slice , "CLASS" , "UNDEFINED" );
  }
public :

  /** This method returns an interpolated funcData value that
  * corresponds to the value of at slice within func.
  * It takes in account extrapolateLinearTop and extrapolateLinearBottom flags .
  * Unmodified caller is the module (source code not altered ) */
  funcData functionInterpolateWithMask(  const funcKey& slice,
                                         bool extrapolateLinearTop, bool extrapolateLinearBottom ,
                                         const char * callerName , const char * methodName )
  {
    // exception if empty
    isEmpty( "functionInterpolateWithMask" , callerName , methodName );
    //
    FunctionIterator ison = myDatFunction.find( slice );
    if ( ison == myDatFunction.end() ) {
      FunctionIterator high = myDatFunction.upper_bound( slice );
      if ( high == myDatFunction.begin() ) {
        if(extrapolateLinearTop && myDatFunction.size() > 1) {
          funcKey lKey = ( (FunctionValueType) *high).first;
          funcData lData = *(( (FunctionValueType) *high).second);
          ++high;
          funcKey hKey = ( (FunctionValueType) *high).first;
          funcData hData = *(( (FunctionValueType) *high).second);
          return DoLinearInterpolation( lKey, lData, hKey, hData, slice);
        }
        else {
          return *(((FunctionValueType)*high).second);
        }
      }
      if ( high == myDatFunction.end() ) {
        --high;
        if(extrapolateLinearBottom && myDatFunction.size() > 1) {
          funcKey lKey = ( (FunctionValueType) *high).first;
          funcData lData = *(( (FunctionValueType) *high).second);
          --high;
          funcKey hKey = ( (FunctionValueType) *high).first;
          funcData hData = *(( (FunctionValueType) *high).second);
          return DoLinearInterpolation( lKey, lData, hKey, hData, slice);
        }
        else {
          return *(((FunctionValueType)*high).second);
        }
      }
      FunctionIterator low = high;
      --low;
      funcKey lKey = ( (FunctionValueType) *low).first;
      funcKey hKey = ( (FunctionValueType) *high).first;
      funcData lData = *(( (FunctionValueType) *low).second);
      funcData hData = *(( (FunctionValueType) *high).second);
      return DoLinearInterpolation( lKey, lData, hKey, hData, slice);
    } else {
      return *(((FunctionValueType)*ison).second);
    }
  }

  FunctionIterator getFunctionStart()
  {
    return ( myDatFunction.begin() );
  }

  FunctionConstIterator getFunctionStart() const
  {
    return ( myDatFunction.begin() );
  }

  FunctionConstIterator getFunctionConstStart() const
  {
    return ( myDatFunction.begin() );
  }

  FunctionIterator getFunctionEnd()
  {
    return ( myDatFunction.end() );
  }

  FunctionConstIterator getFunctionEnd() const
  {
    return ( myDatFunction.end() );
  }

  FunctionConstIterator getFunctionConstEnd() const
  {
    return ( myDatFunction.end() );
  }

  FunctionIterator getPickIterator( const funcKey& fkey )
  {
    return myDatFunction.find( fkey );
  }

  FunctionConstIterator getPickIterator( const funcKey& fkey ) const
  {
    return myDatFunction.find( fkey );
  }

  FunctionConstIterator getPickConstIterator( const funcKey& fkey ) const
  {
    return myDatFunction.find( fkey );
  }

  bool isFunctionDone( const FunctionIterator& iter )
  {
    return ( iter == myDatFunction.end() );
  }

  bool isFunctionDone( const FunctionConstIterator& iter ) const
  {
    return ( iter == myDatFunction.end() );
  }

  bool isFunctionConstDone( const FunctionConstIterator& iter ) const
  {
    return ( iter == myDatFunction.end() );
  }

  std::pair<FunctionIterator,FunctionIterator> findTwoClosestPicks( const funcKey& fkey , const char * callerName , const char * methodName )
  {
    // exception if empty
    isEmpty( "findTwoClosestPicks" , callerName , methodName );
    //
    FunctionIterator ison = myDatFunction.find( fkey );
    if ( ison == myDatFunction.end() ) {
      FunctionIterator high = myDatFunction.upper_bound( fkey );
      if ( high == myDatFunction.begin() ) {
        return ( std::pair<FunctionIterator,FunctionIterator>( high, high ) );
      }
      if ( high == myDatFunction.end() ) {
        --high;
        return ( std::pair<FunctionIterator,FunctionIterator>(high,high) );
      }
      FunctionIterator low = high;
      --low;
      return ( std::pair<FunctionIterator,FunctionIterator>( low , high ) );
    }
    else {
      return ( std::pair<FunctionIterator,FunctionIterator>( ison, ison ) );
    }
  }

  std::shared_ptr<funcData> getFunctionData( const FunctionConstIterator& iter ) const
  {
    return ( ((FunctionValueType) *iter).second );
  }

  funcKey getFunctionKey( const FunctionConstIterator& iter ) const
  {
    return ( (funcKey) ((FunctionValueType) *iter).first );
  }

  std::pair<funcKey,funcKey> getFunctionTimeRange( const char * callerName , const char * methodName ) const
  {
    // exception if empty
    isEmpty( "getFunctionTimeRange" , callerName , methodName );
    //
    FunctionConstIterator lst = myDatFunction.end();
    --lst;
    return std::pair<funcKey,funcKey>( getFunctionKey(myDatFunction.begin()),getFunctionKey(lst) );
  }

  /** check function is not empty . Aborts if the method name is provided .
   * MUST keepthe option to have 0 parameters for the test without crash */
  bool isEmpty( const char * method = 0 , const char * callerName = 0 , const char * methodName = 0 ) const
  {
    bool b = myDatFunction.empty() ;
    // abort if it's empty and a method is provided
    if ( b == true && method != 0 ) {
      MscString msg;
      if ( callerName == 0 ) { callerName = "DatFunction::isEmpty" ; }
      if ( methodName == 0 ) {
        msg.printf( "No data in Velocity Function for '%s' called by '%s'" , method , callerName );
      }
      else {
        msg.printf( "No data in Velocity Function for '%s' called by '%s::%s'" , method , callerName , methodName );
      }
      throw std::exception( msg , "functionInterpolate" );
    }
    return b ;
  }

  bool removeKey( const funcKey& key )
  {
    if ( myDatFunction.find(key) != myDatFunction.end() ) {
      myDatFunction.erase( key );
      return true ;
    }
    else {
      return false ;
    }
  }

  bool removeKey( const funcKey& key , funcKey tolerance )
  {
    if ( myDatFunction.empty() == true ) { return false ; }
    if ( myDatFunction.find(key) != myDatFunction.end() ) {
      myDatFunction.erase( key );
      return true ;
    }
    if ( ! tolerance ) { return false; }
    std::pair<FunctionIterator,FunctionIterator> nearest = findTwoClosestPicks(key);
    funcKey distLower = (key  - nearest.first) ;
    funcKey distUpper = (nearest.second - key) ;
    // too far away
    if (distLower > tolerance && distUpper > tolerance) { return false; }
    // consider nearest value
    if ( distLower < distUpper ) {
      myDatFunction.erase( nearest.first );
    }
    else {
      myDatFunction.erase( nearest.second );
    }
    return true;
  }

};



#endif



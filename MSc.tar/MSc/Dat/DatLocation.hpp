#ifndef DAT_LOCATION_HPP
#define DAT_LOCATION_HPP

#include <map>


/** This class encapsulates a pair of integers used as a key.
 *  The secondary value is optional and will be defaulted to 'NoValue'.
*/
class BinPos ;
class TwoIntKey {
public:
/** Constructor that takes a primary value to use as the Primary
 * key and a secondary value.*/
  TwoIntKey( int prime, int secondary );
/** Constructor that takes a BinPos.*/
  TwoIntKey( const BinPos& bp );
/** Constructor that takes a primary value only and set the secondary to NoValue */
  TwoIntKey( int prime );
/** Default Constructor */
  TwoIntKey();
  /** Default Destructor*/
  ~TwoIntKey();
  /** The less operator that compares two keys.*/
  bool operator<( const TwoIntKey& ) const;
  /** The equality operator that compares two keys.*/
  bool operator==( const TwoIntKey& ) const;
  bool operator!=( const TwoIntKey& ) const;
  /** Get the primary component. */
  int  getPrime() const;
  /** Get secondary component. */
  int  getSecondary() const;
  /** Computes the interpolation ratio of \this between two other keys.
   * This calculation is based solely on the secondary component of the keys.
   * The returned value will be 0.0 if \this==k1 and 1.0 if \this==k2. */
  double computeInterpRatio( const TwoIntKey& k1, const TwoIntKey& k2 ) const;
  /** Return true if both TwoIntKeys have the same primary value. */
  bool isSamePrime( const TwoIntKey& ) const;
  /** Return the euclidian distance (x*x+y*y) to the point */
  double euclidianDistanceTo( const TwoIntKey& ) const;
  /** Return the bloc distance (abs[x]+abs[y]) to the point */
  int  manhattanDistanceTo( const TwoIntKey& ) const;

  /** set undefined location */
  static TwoIntKey Undefined ;
  void setUndefined() { *this = Undefined; }
  bool isUndefined() const { return (*this == Undefined); }

private:
  std::pair<int,int> myKeys;
};


/** The BinPos class is used to hold a Inline/Crossline coordinate. */
class BinPos {
public:
  /** Default constructor. */
  BinPos();
  /** Constructor from an inline and crossline. */
  BinPos(int iline, int xline);
  /** Construct from a TwoIntKey. */
  BinPos(const TwoIntKey& key);
  /** Copy constructor.*/
  BinPos(const BinPos& rhs);
  /** Destructor. */
  ~BinPos();
  /** Assignment operator. */
  BinPos& operator=(const BinPos& rhs);
  /** Equality operator. */
  bool operator==(const BinPos& rhs) const;
  /** In-equality operator. */
  bool operator!=(const BinPos& rhs) const;
  /** The less-than operator. */
  bool operator<( const BinPos &) const;
  /** Retrieve the Inline component. */
  int getInline(void) const;
  /** Retrieve the Crossline component. */
  int getCrossline(void) const;
  /** Set the Inline component.*/
  void setInline(int iline);
  /** Set the Crossline component. */
  void setCrossline(int xline);
  /** Output operator for debugging. */
  friend std::ostream& operator << (std::ostream& os, const BinPos& rhs);
  /** set both inline and crossline in a single call  */
  void setInlineAndCrossline(int iline, int xline);

  /** set undefined location */
  static BinPos Undefined ;
  void setUndefined() { *this = Undefined; }
  bool isUndefined() const { return (*this == Undefined); }

private:
  /** Inline component. */
  int myInline ;
  /** Crossline component. */
  int myXline  ;
};

#endif

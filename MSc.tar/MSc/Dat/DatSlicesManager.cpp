#include "MscDebug.hpp"
#include "DatSlicesManager.hpp"
//#include "DatStorage.hpp"


const char * DatSlicesManager::CLASS_NAME = "DatSlicesManager" ;



void DatStorage::printf( const char * userMessage , int storeType )
{
  static struct {
    DatStorage::StoreType myStoreType ;
    const char          * myString    ;
  } StoreStrings[] = {
    { DatStorage::ST_WITH_PANELS      , "ST_WITH_PANELS"     } ,
    { DatStorage::ST_SEISMIC_SECTION  , "ST_SEISMIC_SECTION" } ,
    { DatStorage::ST_SEMBLANCE        , "ST_SEMBLANCE"       } ,
    { DatStorage::ST_VERACITY         , "ST_VERACITY"        } ,
    { DatStorage::ST_GATHER           , "ST_GATHER"          } ,
    { DatStorage::ST_VELOCITY         , "ST_VELOCITY"        } ,
    { DatStorage::ST_GUIDE            , "ST_GUIDE"           } ,
    { DatStorage::ST_VELPAC           , "ST_VELPAC"          } ,
    { DatStorage::ST_CMB              , "ST_CMB"             } ,
    { DatStorage::ST_TIKKIM           , "ST_TIKKIM"          }
  };
  static int number = sizeof(StoreStrings) / sizeof(StoreStrings[0]) ;

  if ( userMessage == 0 ) { userMessage = "" ; }
  MscString message ;
  if ( storeType == DatStorage::ST_UNDEFINED ) {
    message.printf( "%s  Type %d  DatStorage::ST_UNDEFINED" , userMessage , storeType );
  }
  else {
    message.printf( "%s  Types %d\n" , userMessage , storeType );
    for ( int i=0 ; i < number ; ++i ) {
      if ( storeType & StoreStrings[i].myStoreType ) {
        MscString tmp ;
        tmp.printf( "     %s\n" , StoreStrings[i].myString );
        message += tmp ;
      }
    }
  }
  MscDg::print( message );
}





DatSlicesManager::DatSlicesManager( DatStorage::StoreType st )
  : myStoreType(st)
{
  static const char * METHOD_NAME = "DatSlicesManager()" ;
  if ( MscDg::trace( CLASS_NAME , METHOD_NAME , "" ) == true ) {
    DatStorage::printf( 0 , st );
  }
}



std::shared_ptr< DatSlice > DatSlicesManager::getSeismicSectionAtSlice( int sliceNumber ) const
{
  static const char * METHOD_NAME = "getSeismicSectionAtSlice()" ;
  std::shared_ptr< DatSlice > section ;
  
  DatSlicesManager::SeismicSectionMap::const_iterator iter ;
  for ( iter=mySeismicSections.begin() ; iter != mySeismicSections.end() ; ++iter ) {
    // should not happen.
    if ( iter->get() == nullptr ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Empty Slice" );
      continue;
    }
    // slice being stored
    int sectionSliceNumber = (myStoreType == DatStorage::ST_STACK_PANELS) ? (*iter)->getPanelNumber() : (*iter)->getTraceNumber() ;
    if ( sectionSliceNumber == sliceNumber ) {
      section = (*iter);
      break;
    }
  }
 
  // debug
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME , "SliceNumber %d %s" , sliceNumber ,
                            (section.get()==nullptr) ? "not found" : "is present" );
  if ( dbOn == true && section.get() == nullptr ) { DatSlicesManager::print(); }

  return section ;
}



void DatSlicesManager::print() const
{
  DatSlicesManager::SeismicSectionMap::const_iterator iter ;
  for ( iter=mySeismicSections.begin() ; iter != mySeismicSections.end() ; ++iter ) {
    if ( iter->get() == nullptr ) {
      MscDg::print( "  IS EMPTY" );
      continue;
    }
    MscDg::print( "     Primary:%d Secondary:%d" ,
                 (*iter)->getTwoIntKey().getPrime() , (*iter)->getTwoIntKey().getSecondary() );
  }
}




#include "DatSlice.hpp"

#include "MscDebug.hpp"
#include "MscString.hpp"



const char * DatSlice::CLASS_NAME = "DatSlice" ;



DatSlice::DatSlice( int numTraces , int  numSamples , float * array , bool bufferIsOwned )
{
  static const char * METHOD_NAME = "DatSlice()" ;

  myInitialize();
  // use provided memory or allocate buffer
  if ( array != 0 ) {
    myBufferIsOwned    = bufferIsOwned ;
    myBuffer           = array         ;
    myNumberOfTraces   = numTraces     ;
    myNumberOfSamples  = numSamples    ;
  }
  else {
    allocateMemory( numTraces , numSamples );
  }
  // debug
  MscDg::trace( CLASS_NAME , METHOD_NAME , "(Array) NumberOfTraces %d   NumberOfSamples %d   BufferIsOwned %d" ,
                myNumberOfTraces , myNumberOfSamples , myBufferIsOwned );
}


DatSlice::DatSlice( DatArray & attribute , DatArray::DataType dataType )
{
  static const char * METHOD_NAME = "DatSlice()" ;

  myInitialize();

  // *** buffer
  // check the type
  if ( attribute.getDataType() != DatArray::FLOAT32 || dataType != DatArray::FLOAT32 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME ,
                 "Use of memory type (%d,%d) that is not Float32 (%d) is not implemented at the moment" ,
                 attribute.getDataType() , dataType , DatArray::FLOAT32 );
  }
  // take ownership of provided memory (move memory)
  else if ( attribute.hasMovableMemory() == true ) {
    myNumberOfTraces  = attribute.getNumberOfTraces() ;
    myNumberOfSamples = attribute.getLengthOfTrace()  ;
    myBuffer          = attribute.getFloat32Pointer(1);
    myBufferIsOwned   = true ;
    attribute.releaseMemory() ;
  }
  // allocate memory.
  else {
    // buffer
    allocateMemory(  attribute.getNumberOfTraces() , attribute.getLengthOfTrace() );
    if ( myBuffer != nullptr ) {
      memcpy( myBuffer , attribute.getFloat32Pointer(1) , myNumberOfTraces * myNumberOfSamples * sizeof(float) );
    }
  }

  // values
  setSampleIntervalMs( attribute.getSampleRate() );
  setFirstSampleMs( attribute.getFirstSampleLocation() );

  // consistency (either not the correct type or was empty)
  if ( myBuffer == 0 ) { myNumberOfTraces=0 ; myNumberOfSamples=0 ; }

  // debug
  MscDg::trace( CLASS_NAME , METHOD_NAME , "(Attribute) NumberOfTraces %d   NumberOfSamples %d   BufferIsOwned %d" ,
               myNumberOfTraces , myNumberOfSamples , myBufferIsOwned );
}



DatSlice::DatSlice( const DatSlice & model )
{
  static const char * METHOD_NAME = "DatSlice()" ;
  myInitialize();
  *this = model ;
  // debug
  MscDg::trace( CLASS_NAME , METHOD_NAME , "(Copy) NumberOfTraces %d   NumberOfSamples %d   BufferIsOwned %d" ,
               myNumberOfTraces , myNumberOfSamples , myBufferIsOwned );
}


const DatSlice & DatSlice::operator=( const DatSlice & model )
{
  if ( &model != this ) {
    // buffer
    allocateMemory( model.myNumberOfTraces , model.myNumberOfSamples );
    if ( myBuffer != 0 ) {
      std::memcpy( myBuffer , model.myBuffer , myNumberOfTraces * myNumberOfSamples * sizeof(float) );
    }
    // type
    myStoreType        = model.myStoreType        ;
    // location
    myLineNumber       = model.myLineNumber       ;
    myTraceNumber      = model.myTraceNumber      ;
    myPanelNumber      = model.myPanelNumber      ;
    myIsInline         = model.myIsInline         ;
    myIsTwoD           = model.myIsTwoD           ;
    // sample
    myFirstSampleMs    = model.myFirstSampleMs    ;
    mySampleIntervalMs = model.mySampleIntervalMs ; 
    // headers
    myHeaders          = model.myHeaders          ;
  }
  // done
  return *this ;
}


void DatSlice::myInitialize()
{
  // type
  myStoreType        = DatStorage::ST_UNDEFINED ;

  // location
  myLineNumber       = DatStorage::UndefinedNumber ;
  myTraceNumber      = DatStorage::UndefinedNumber ;
  myPanelNumber      = 0      ;
  myIsInline         = true   ;
  myIsTwoD           = true   ;

  // traces
  myNumberOfTraces   = 0      ;

  // samples
  myNumberOfSamples  = 0      ;
  myFirstSampleMs    = 0.000f ;
  mySampleIntervalMs = 4.000f ;

  // buffer
  myBuffer           = 0      ;
  myBufferIsOwned    = true   ;  

  // headers
  myHeaders.clear();
}


DatSlice::~DatSlice()
{
  // same as: allocateMemory(0,0);
  if ( myBufferIsOwned == true ) {
    delete [] myBuffer ;
  }
  myHeaders.clear();
}


bool DatSlice::hasSameCharacteristics( DatSlice * model ) const
{
  if ( model == 0    ) return false ;
  if ( model == this ) return true  ;
  if ( model->getStoreType()        != getStoreType()        ||
       model->getFirstSampleMs()    != getFirstSampleMs()    ||
       model->getSampleIntervalMs() != getSampleIntervalMs() ||
       model->getNumberOfSamples()  != getNumberOfSamples()  ) {
    return false ;
  }
  return true ;
}



void DatSlice::checkLocation( int lineNumber , bool isInline , bool isTwoD )
{
  static const char * METHOD_NAME = "checkLocation" ;
  if ( myLineNumber != lineNumber || myIsInline != isInline || myIsTwoD != isTwoD ) {
    // tell
    MscDg::error( CLASS_NAME , METHOD_NAME , "Line %d -> %d IsInline %d -> %d IsTwoD %d -> %d" ,
                 myLineNumber , lineNumber , myIsInline , isInline , myIsTwoD , isTwoD );
    // change
    myLineNumber = lineNumber ;
    myIsInline   = isInline   ;
    myIsTwoD     = isTwoD     ;
  }
}


void DatSlice::checkLocation( int lineNumber , int traceNumber , bool isInline , bool isTwoD )
{
  static const char * METHOD_NAME = "checkLocation" ;
  if ( myLineNumber != lineNumber || myTraceNumber != traceNumber ||
       myIsInline   != isInline   || myIsTwoD      != isTwoD       ) {
    // tell
    MscDg::error( CLASS_NAME , METHOD_NAME , "Line %d -> %d  Trace %d -> %d  IsInline %d -> %d  IsTwoD %d -> %d" ,
                 myLineNumber , lineNumber , myTraceNumber , traceNumber ,
                 myIsInline   , isInline   , myIsTwoD      , isTwoD      );
    // change
    myLineNumber  = lineNumber  ;
    myTraceNumber = traceNumber ;
    myIsInline    = isInline    ;
    myIsTwoD      = isTwoD      ;
  }
}



void DatSlice::allocateHeader( MscString name , int headerId , DatArray::DataType dataType )
{
  static const char * METHOD_NAME = "allocateHeader()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Name '%s'  HeaderId %d  DatArray::DataType %d  NumberOfTraces %d" ,
               name.c_str() , headerId , dataType , myNumberOfTraces );

  myErrorMessage.erase(); 
  myHeaders[ headerId ] = HeaderHolder( name , dataType );
  if ( myNumberOfTraces > 0 ) {
    myHeaders[ headerId ].myVector.reserve( myNumberOfTraces );
    // need to set value before they are used (else size is still '0')
    for ( int i=0 ; i < myNumberOfTraces ; ++i ) {
      myHeaders[ headerId ].myVector.push_back( -9999 );
    }
  }
}



MscString  DatSlice::readHeader(  MscString name , const std::shared_ptr< DatStorage > & store , int headerId )
{
  static const char * METHOD_NAME = "readHeader()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "Header '%s'  Id %d" , name.c_str() , headerId );

  myErrorMessage.erase();
  // at the end 
  if ( headerId == -1 ) {
    if ( myHeaders.empty() == false ) { headerId = myHeaders.rbegin()->first ; }
    if ( headerId < 2 ) { headerId = 2 ; }
  }
  // find if present
  DatSlice::Headers::iterator iter ;
  if ( (iter=myHeaders.find( headerId )) != myHeaders.end() ) {
    myErrorMessage.printf( "Header %d already present and is '%s' with %ld values (trying to add '%s')" , 
                           headerId , iter->second.myName.c_str() , iter->second.myVector.size() , name.c_str() );
    return myErrorMessage ;
  }
  // allocate header
  allocateHeader( name , headerId );
  iter = myHeaders.find( headerId );
  if ( iter == myHeaders.end() ) {
    myErrorMessage.printf( "Can't allocate Header %d (trying to add '%s')" , 
                           headerId , name.c_str() );
    return myErrorMessage ;
  }
  // read attribute from a spcific header (with Alias header name)
  DatArray attribute( name );
  store->readAttributeRange( myErrorMessage , attribute , 1 , 0 , true );
  if ( myErrorMessage.isEmpty() == true &&
       // extract the values
       attribute.getFloat32Vector( myErrorMessage , store->getName() , iter->second.myVector ) == true ) {
    // check ...
    if ( iter->second.myVector.size() != myNumberOfTraces ) {
      myErrorMessage.printf( "Mismatch of the size %ld %d" , iter->second.myVector.size() , myNumberOfTraces );
    }
  }
  // done
  return myErrorMessage ;
}



std::vector< int > DatSlice::getHeaderIds() const
{
  std::vector< int > headers ;
  DatSlice::Headers::const_iterator iter ;
  for ( iter=myHeaders.begin() ; iter != myHeaders.end() ; ++iter ) {
    headers.push_back( iter->first );
  }
  return headers ;
}


std::vector< MscString > DatSlice::getHeaderNames() const
{
  std::vector< MscString > headers ;
  DatSlice::Headers::const_iterator iter ;
  for ( iter=myHeaders.begin() ; iter != myHeaders.end() ; ++iter ) {
    headers.push_back( iter->second.myName );
  }
  return headers ;
}


MscString DatSlice::getHeaderName( int headerId ) const
{
  static const char * METHOD_NAME = "getHeaderName()" ;
  DatSlice::Headers::const_iterator iter = myHeaders.find( headerId );
  if ( iter == myHeaders.end() ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Header %d not found" , headerId );
    return "";
  }
  else {
    return iter->second.myName ;
  }
}


DatArray::DataType DatSlice::getHeaderDataType( int headerId ) const
{
  static const char * METHOD_NAME = "getHeaderDatArray::DataType()" ;
  DatSlice::Headers::const_iterator iter = myHeaders.find( headerId );
  if ( iter == myHeaders.end() ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Header %d not found" , headerId );
    return DatArray::NOTYPE ;
  }
  else {
    return iter->second.myDataType ;
  }  
}


void DatSlice::setHeaderDataType( int headerId , DatArray::DataType dataType )
{
  static const char * METHOD_NAME = "setHeaderDatArray::DataType()" ;
  DatSlice::Headers::iterator iter = myHeaders.find( headerId );
  if ( iter == myHeaders.end() ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Header %d not found" , headerId );
  }
  else {
    iter->second.myDataType = dataType ;
  }  
}


int DatSlice::getHeaderId( MscString name , bool useAliasHeaderNames , bool & foundIt ) const
{
  static const char * METHOD_NAME = "getHeaderId()" ;

  foundIt = false ;
  int headerId = 0 ;
  if ( name.isEmpty() == true ) {
    // nothing to do
  }
  else if ( useAliasHeaderNames == false ) {
    for ( Headers::const_iterator iter=myHeaders.begin() ; iter != myHeaders.end() ; ++iter ) {
      if ( iter->second.myName == name ) {
        headerId = iter->first ;
        foundIt = true ;
        break ;
      }
    }
  }
  else {
    MscString headerName = DatStorage::getReferenceOfAliasHeaderName(name);
    for ( Headers::const_iterator iter=myHeaders.begin() ; iter != myHeaders.end() ; ++iter ) {
      if ( headerName == DatStorage::getReferenceOfAliasHeaderName(iter->second.myName) ) {
        headerId = iter->first ;
        foundIt = true ;
        break ;
      }
    } 
  }
 
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Name '%s' UseAliasHeader %d %s" ,
               name.c_str() , useAliasHeaderNames , (foundIt ? "found" : "*not* found ") );
  return headerId ;
}


void DatSlice::setHeader( int traceIndex , float value , int headerId , bool * outOfRange )
{
  static const char * METHOD_NAME = "setHeader()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "TraceIndex %d  HeaderId %d -> Value %g" , traceIndex , headerId , value );
  
  myErrorMessage.erase(); 
  Headers::iterator iter = myHeaders.find( headerId );
  int numberOfTraces=0;
  // check
  if ( iter == myHeaders.end() ) {
    myErrorMessage.printf( "DatSlice::setHeader() header %d not found amongst the %ld" ,
                           headerId , myHeaders.size() );
  }
  else if ( traceIndex < 0 || (numberOfTraces=int(iter->second.myVector.size())) <= traceIndex ) {
    myErrorMessage.printf( "DatSlice::setHeader() trace %d out of range [0,%d]" ,
                           traceIndex , numberOfTraces );
  }
  // set
  else {
    iter->second.myVector[ traceIndex ] = value;
  }
  // error message
  if ( myErrorMessage.isEmpty() == false ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , myErrorMessage );
  }
  if ( outOfRange != 0 ) { *outOfRange = ( myErrorMessage.isEmpty() == false ); }
}


float DatSlice::getHeader( int traceIndex , int headerId , bool * outOfRange )
{
  static const char * METHOD_NAME = "getHeader()" ;
  myErrorMessage.erase(); 
  Headers::iterator iter = myHeaders.find( headerId );
  int size=0;
  float header = 0.0f ;
  // check
  if ( iter == myHeaders.end() ) {
    myErrorMessage.printf( "DatSlice::getHeader() header %d not found" ,
                           headerId );
  }
  else if ( traceIndex < 0 || (size=int(iter->second.myVector.size())) <= traceIndex ) {
    myErrorMessage.printf( "DatSlice::getHeader(%d) trace %d out of range [0,%d]" ,
                           headerId , traceIndex , size );
  }
  // get
  else {
    header = iter->second.myVector[ traceIndex ];
  }
  // error message
  if ( myErrorMessage.isEmpty() == false ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , myErrorMessage );
  }
  if ( outOfRange != 0 ) *outOfRange = ( myErrorMessage.isEmpty() == false );
  return header ;
}


std::vector<float> DatSlice::getHeaderValues( int headerId , bool * outOfRange )
{
  static const char * METHOD_NAME = "getHeaderValues()" ;
  myErrorMessage.erase(); 
  Headers::iterator iter = myHeaders.find( headerId ); 
  if ( iter == myHeaders.end() ) {
    myErrorMessage.printf( "DatSlice::getHeaderValues() header %d not found" ,
                           headerId );
    MscDg::error( CLASS_NAME , METHOD_NAME , myErrorMessage );
    if ( outOfRange != 0 ) *outOfRange = true;
    std::vector<float> values ;
    return values;
  }
  else {
    if ( outOfRange != 0 ) *outOfRange = false;
    return iter->second.myVector;
  }
}


int DatSlice::getHeaderTraceIndex( float value , int headerId , bool * outOfRange )
{
  static const char * METHOD_NAME = "()" ;
  myErrorMessage.erase(); 
  Headers::iterator iter = myHeaders.find( headerId );
  int index = -1 ;
  // check
  if ( iter == myHeaders.end() ) {
    myErrorMessage.printf( "DatSlice::getHeaderTraceIndex() header %d not found" ,
                           headerId );
  }
  // get
  else {
    int size = int(iter->second.myVector.size()) ;
    for ( index = 0 ; index < size ; ++index ) {
      if ( iter->second.myVector[index] == value ) {
        break ;
      }
    }
    if ( index == size ) {
      myErrorMessage.printf( "DatSlice::getHeaderTraceIndex(%d) value %f not found in %d traces" ,
                             headerId , value , size );   
    }
  }
  // results
  if ( myErrorMessage.isEmpty() == false ) { 
    MscDg::error( CLASS_NAME , METHOD_NAME , myErrorMessage );
    index = -1 ;
  }
  if ( outOfRange != 0 ) *outOfRange = ( myErrorMessage.isEmpty() == false ); 
  return index ;
}


void DatSlice::setSampleIntervalMs( float f )
{
  static const char * METHOD_NAME = "setSampleIntervalMs()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Value %g => %g" , mySampleIntervalMs , f );
  mySampleIntervalMs = f ;     
}


bool DatSlice::allocateMemory( int numTraces , int numSamples , float initValue )
{
  static const char * METHOD_NAME = "allocateMemory()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "NumberOfTraces %d  NumberOfSamples %d" , numTraces , numSamples );

  myErrorMessage.erase(); 
  bool aChangeOccurred = false ;
  if ( numTraces  < 0 ) numTraces  = 0 ;
  if ( numSamples < 0 ) numSamples = 0 ;
  if ( numTraces * numSamples == 0 ) {
    numTraces  = 0 ;
    numSamples = 0 ;
  }
  bool refresh = false ;
  // buffer needs to be resized
  if ( myNumberOfTraces != numTraces || myNumberOfSamples != numSamples ) {
    if ( myBufferIsOwned == true ) {
      delete [] myBuffer ;
    }
    myBufferIsOwned    = true ;
    myBuffer           = 0    ;
    myNumberOfTraces   = 0    ;
    myNumberOfSamples  = 0    ;
    aChangeOccurred    = true ;
  }
  // re-allocate buffer
  if ( aChangeOccurred == true ) {
    myBuffer = new (std::nothrow) float[ numTraces * numSamples ];
    myBufferIsOwned = true ;
    if ( myBuffer == 0 ) {
      if ( numTraces * numSamples != 0 ) {
        myErrorMessage.printf( "DatSlice::allocateMemory(%d,%d) failed" ,
                               numTraces , numSamples );
        MscDg::error( CLASS_NAME , METHOD_NAME , myErrorMessage );
      }
    }
    else {
      myNumberOfTraces  = numTraces  ;
      myNumberOfSamples = numSamples ;
      for ( int i=0 ; i < myNumberOfTraces * myNumberOfSamples ; ++i ) {
        myBuffer[i] = initValue;
      }
    }
  }
  // initialize the headers
  myHeaders.clear();
  return aChangeOccurred ;
}


int   DatSlice::getSampleIndex( float timeMs , bool *outOfRange )
{
  static const char * METHOD_NAME = "()" ;
  // index
  int index = 0 ;
  if ( mySampleIntervalMs <= 0.0f ) {
    if ( outOfRange != 0 ) {
      *outOfRange = true ; // should never happen...
    }
    MscDg::error( CLASS_NAME , METHOD_NAME , "%g ms: Null or negative interval (sampling %g ms)" ,
                 timeMs , mySampleIntervalMs );
  }
  else {
    index = int((timeMs - myFirstSampleMs) / mySampleIntervalMs);
  }
  // negative index
  if ( index < 0 ) {
    if ( outOfRange != 0 ) {
      *outOfRange = true ; // should never happen...
    }
    MscDg::error( CLASS_NAME , METHOD_NAME , "%g ms: before first sample at %g ms" ,
                 timeMs , myFirstSampleMs );
    index = 0 ;
  }
  // out of range
  else if ( myNumberOfSamples <= index ) {
    if ( outOfRange != 0 ) {
      *outOfRange = true ;
    }
    else {
      float last = myFirstSampleMs + myNumberOfSamples * mySampleIntervalMs;
      MscDg::error( CLASS_NAME , METHOD_NAME , "%g ms: after last sample at %g ms" ,
                   timeMs , mySampleIntervalMs );
    }
    index = myNumberOfSamples - 1;
  }
  // is okay
  else if ( outOfRange != 0 ) {
    *outOfRange = false;
  }
  return index ;
}


int DatSlice::getSampleTimeMs( int index )
{
  static const char * METHOD_NAME = "getSampleTimeMs()" ;
  int value = (int)(myFirstSampleMs + index * mySampleIntervalMs );
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Index %d Value %g" , index , value );
  return value ;
}


TwoIntKey DatSlice::getTwoIntKey( int traceIndex , int headerId , bool * outOfRange )
{
  TwoIntKey key ;
  int traceNumber = int( 0.5f + getHeader( traceIndex , headerId , outOfRange ));
  if ( myIsInline == true ) {
    key = TwoIntKey( myLineNumber , traceNumber ); // inline , crossline
  }
  else {
    key = TwoIntKey( traceNumber , myLineNumber ); 
  }
  return key ; 
}


bool DatSlice::setBufferValue( int traceIndex , int sampleIndex , float value ,
                               DatSlice::Operation operation )
{
  static const char * METHOD_NAME = "setBufferValue()" ;
  bool isOk = true ;
  if ( traceIndex  < 0 || myNumberOfTraces  <= traceIndex ||
       sampleIndex < 0 || myNumberOfSamples <= sampleIndex ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Range Error: Trace: 0 <= %d < %d  Sample 0 <= 0 < %d" ,
                 traceIndex , myNumberOfTraces , sampleIndex , myNumberOfSamples );
    isOk = false ;
  }
  else {
    switch ( operation ) {
    case DatSlice::OPE_SET :
      myBuffer[ traceIndex * myNumberOfSamples + sampleIndex ]  = value ;
      break ;
    case DatSlice::OPE_ADD :
      myBuffer[ traceIndex * myNumberOfSamples + sampleIndex ] += value ;
      break ;
    case DatSlice::OPE_MULTIPLY :
      myBuffer[ traceIndex * myNumberOfSamples + sampleIndex ] *= value ;
      break ;
    case DatSlice::OPE_DIVIDE :
      if ( value != 0.0f ) {
        myBuffer[ traceIndex * myNumberOfSamples + sampleIndex ] /= value ;
      }
      break ;
    default:
      MscDg::error( CLASS_NAME , METHOD_NAME , "Operation %d is not implemented" , operation );
      isOk = false ;
    }
  }
  return isOk ;
}


float DatSlice::getBufferValue( int traceIndex , int sampleIndex )
{
  static const char * METHOD_NAME = "getBufferValue()" ;
  float value = 0.0f ;
  if ( traceIndex  < 0 || myNumberOfTraces  <= traceIndex ||
       sampleIndex < 0 || myNumberOfSamples <= sampleIndex ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Range Error: Trace: 0 <= %d < %d  Sample 0 <= 0 < %d" ,
                 traceIndex , myNumberOfTraces , sampleIndex , myNumberOfSamples );
  }
  else {
    value = myBuffer[ traceIndex * myNumberOfSamples + sampleIndex ] ;
  }
  return value ;
}


float * DatSlice::getBuffer( int * numTraces , int * numSamples ) const
{
  if ( numTraces  != 0 ) *numTraces  = myNumberOfTraces  ;
  if ( numSamples != 0 ) *numSamples = myNumberOfSamples ;
  return myBuffer ;
}


float * DatSlice::getBufferAtTraceIndex( int traceIndex , bool * outOfRange ) const
{
  static const char * METHOD_NAME = "getBufferAtTraceIndex()" ;
  if ( traceIndex  < 0 || myNumberOfTraces  <= traceIndex ) {
    if ( outOfRange != 0 ) { *outOfRange = true ; }
    MscDg::error( CLASS_NAME , METHOD_NAME , "Range error: Trace %d not in range 0-%d" ,
                 traceIndex , myNumberOfTraces );
    return myBuffer ;
  }
  else {
    if ( outOfRange != 0 ) { *outOfRange = false ; }
    return myBuffer + ( traceIndex * myNumberOfSamples ) ;
  }
}



float * DatSlice::getBufferAtLocation( const TwoIntKey & location )
{
  static const char * METHOD_NAME = "getBufferAtLocation()" ;

  // index of the trace on the section
  int traceIndex  = -1 ;
  
  // is on the line
  if ( (myIsInline == true  && myLineNumber == location.getPrime    ()) || 
       (myIsInline == false && myLineNumber == location.getSecondary()) ) {
    // find the headers for this line
    int headerValue = -1 ;
    const std::vector<float> * headers = 0 ;
    if ( myStoreType == DatStorage::ST_STACK_PANELS ) {
      // header is the trace number
      headerValue = myIsInline ? location.getSecondary() : location.getPrime() ;
      // index of the trace header is "1" .
      // See: "DatSlice::allocateHeader()" and "buStoreUtl::readStoreAtGroup()"
      if ( myHeaders.find(1) != myHeaders.end() ) { headers = & myHeaders.find(1)->second.myVector ; }
    }
    // check
    if ( headers == 0 ) {
      MscDg::fatal( CLASS_NAME , METHOD_NAME , "No header or Not implemented for type %d (STACKS is %d)" ,
                    myStoreType , DatStorage::ST_STACK_PANELS );
    }
    else if ( headers->size() != (size_t)myNumberOfTraces ) {
      MscDg::fatal( CLASS_NAME , METHOD_NAME , "Size mismatch %d  %d" , headers->size() , myNumberOfTraces );
    }
    // find the index of the header
    for ( int currentIndex = 0 ; currentIndex < myNumberOfTraces ; ++currentIndex ) {
      if ( (*headers)[currentIndex] == headerValue ) {
        traceIndex = currentIndex ;
        break;
      }
    }
  }

  // index has been found
  if ( traceIndex != -1 ) {
    bool outOfRange = true ;
    float * buffer  = getBufferAtTraceIndex( traceIndex , &outOfRange );
    return outOfRange ? 0 : buffer ;
  }
  else {
    return 0;
  }
}



void DatSlice::addHeaderForTesting( MscString name , float startValue , float incrementValue )
{
  // do nothing if already defined
  bool isDefined ;
  int headerId = getHeaderId( name , false , isDefined );
  if ( isDefined == true ) return ;
  // find last header id
  headerId = 0 ;
  for ( Headers::iterator iter=myHeaders.begin() ; iter != myHeaders.end() ; ++iter ) {
    if ( headerId < iter->first ) headerId = iter->first ;
  }
  headerId += 1 ;
  // add it
  allocateHeader( name , headerId , DatArray::FLOAT32 );
  // add values
  for ( int traceIndex=0 ; traceIndex < myNumberOfTraces ; ++traceIndex ) {
    setHeader( traceIndex , (startValue + traceIndex * incrementValue) , headerId );
  }
}

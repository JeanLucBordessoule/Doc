#include "MainWindow.hpp"

#include <GuiForms.hpp>


/** Basic application: show the use of file description.
 *  TOOLBAR:
 *  MENUBAR
 *
 **/


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{

}

MainWindow::~MainWindow()
{

}

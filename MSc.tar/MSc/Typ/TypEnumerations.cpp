#include "TypEnumerations.hpp"

#include <map>

#include "MscDataHolder.hpp"


//===============================================================================================
//===============================================================================================
//===============================================================================================
// ****    COLORS : BASE COLOURS
//===============================================================================================
//===============================================================================================
//===============================================================================================

// Windows colours . See: QAssistant and search for QColor.
static Typ::ValuesStruct ColorVALUES[] = {
  //
  { Typ::COL_RED          , "RED"          , "Red"    , 0 , Typ::COL_RED     } ,
  { Typ::COL_GREEN        , "GREEN"        , "Green"  , 0 , Typ::COL_GREEN   } ,
  { Typ::COL_BLUE         , "BLUE"         , "Blue"   , 0 , Typ::COL_BLUE    } ,
  { Typ::COL_CYAN         , "CYAN"         , "Cyan"   , 0 , Typ::COL_CYAN    } ,
  { Typ::COL_MAGENTA      , "MAGENTA"      , "Magenta", 0 , Typ::COL_MAGENTA } ,
  { Typ::COL_YELLOW       , "YELLOW"       , "Yellow" , 0 , Typ::COL_YELLOW  } ,
  { Typ::COL_ORANGE       , "ORANGE"       , "Orange" , 0 , Typ::COL_ORANGE  } ,
  //
  { Typ::COL_DARK_RED     , "DARK_RED"     , "Dark Red"     , 0 , Typ::COL_DARK_RED     } ,
  { Typ::COL_DARK_GREEN   , "DARK_GREEN"   , "Dark Green"   , 0 , Typ::COL_DARK_GREEN   } ,
  { Typ::COL_DARK_BLUE    , "DARK_BLUE"    , "Dark Blue"    , 0 , Typ::COL_DARK_BLUE    } ,
  { Typ::COL_DARK_CYAN    , "DARK_CYAN"    , "Dark Cyan"    , 0 , Typ::COL_DARK_CYAN    } ,
  { Typ::COL_DARK_MAGENTA , "DARK_MAGENTA" , "Dark Magenta" , 0 , Typ::COL_DARK_MAGENTA } ,
  { Typ::COL_DARK_YELLOW  , "DARK_YELLOW"  , "Dark Yellow"  , 0 , Typ::COL_DARK_YELLOW  } ,
  //
  { Typ::COL_BLACK        , "BLACK"        , "Black"        , 0 , Typ::COL_BLACK      } ,
  { Typ::COL_DARK_GRAY    , "EXTRA_GREY"   , "Dark Grey"    , 0 , Typ::COL_DARK_GRAY  } ,
  { Typ::COL_GRAY         , "DARK_GREY"    , "Grey"         , 0 , Typ::COL_GRAY       } ,
  { Typ::COL_LIGHT_GRAY   , "LIGHT_GREY"   , "Light Grey"   , 0 , Typ::COL_LIGHT_GRAY } ,
  { Typ::COL_FRAME        , "FRAME"        , "Frame color"  , 0 , Typ::COL_FRAME      } ,
  { Typ::COL_WHITE        , "WHITE"        , "White"        , 0 , Typ::COL_WHITE      }
  // user defined colors . Values are: Typ::COL_USER_1, Typ::COL_USER_1+1, Flags are USER_1, USER_2, ...
} ;


// Windows colours
static Typ::ValuesStruct ColorShortVALUES[] = {
  { Typ::COL_BLACK    , "BLACK"       , "Black"        , 0 , Typ::COL_BLACK   } ,
  { Typ::COL_WHITE    , "WHITE"       , "White"        , 0 , Typ::COL_WHITE   } ,
  { Typ::COL_RED      , "RED"         , "Red"          , 0 , Typ::COL_RED     } ,
  { Typ::COL_GREEN    , "GREEN"       , "Green"        , 0 , Typ::COL_GREEN   } ,
  { Typ::COL_BLUE     , "BLUE"        , "Blue"         , 0 , Typ::COL_BLUE    } ,
  { Typ::COL_CYAN     , "CYAN"        , "Cyan"         , 0 , Typ::COL_CYAN    } ,
  { Typ::COL_MAGENTA  , "MAGENTA"     , "Magenta"      , 0 , Typ::COL_MAGENTA } ,
  { Typ::COL_YELLOW   , "YELLOW"      , "Yellow"       , 0 , Typ::COL_YELLOW  }
};


static Typ::ValuesStruct ColormapVALUES[] = {
  // *** FIXED_COLOR
  // first column
  { Typ::COLORMAP_SEGCOLORMAP          , "SEGCOLORMAP"          , "SEB Colormap"           , 0 , -1 },
  { Typ::COLORMAP_SEGFUCHSIABANDS      , "SEGFUCHSIABANDS"      , "SEG Fuchsia Bands"      , 0 , -1 },
  { Typ::COLORMAP_BGRCONTRASTBANDS     , "BGRCONTRASTBANDS"     , "Banded BGR 1"           , 0 , -1 },
  { Typ::COLORMAP_BGRCONTRASTBANDS2    , "BGRCONTRASTBANDS2"    , "Banded GBR 2"           , 0 , -1 },
  { Typ::COLORMAP_BANDEDRAINBOW        , "BANDEDRAINBOW"        , "Banded Rainbox"         , 0 , -1 },
  { Typ::COLORMAP_WHITEANCHOREDRAINBOW , "WHITEANCHOREDRAINBOW" , "White-Anchored Rainbox" , 0 , -1 },
  { Typ::COLORMAP_RAINBOXMIX           , "RAINBOXMIX"           , "Rainbox Mix"            , 0 , -1 },
  { Typ::COLORMAP_ILLUMINATEDEXTREMES  , "ILLUMINATEDEXTREMES"  , "Illuminated Extremes"   , 0 , -1 },
  { Typ::COLORMAP_HIGHLIGHTEDEXTREMES  , "HIGHLIGHTEDEXTREMES"  , "Highlighted Extremes"   , 0 , -1 },
  { Typ::COLORMAP_LANDMARK             , "LANDMARK"             , "Landmark"               , 0 , -1 },
  { Typ::COLORMAP_IPGMAP               , "IPGMAP"               , "IFG Map"                , 0 , -1 },
  // second column
  { Typ::COLORMAP_ROLLINGRAMPS  , "ROLLINGRAMPS"  , "Rolling Ramps"   , 0 , -1 },
  { Typ::COLORMAP_CRAZYZEBRA    , "CRAZYZEBRA"    , "Crazy Zebra"     , 0 , -1 },
  { Typ::COLORMAP_BLUERAINBOW   , "BLUERAINBOW"   , "Blue Shift"      , 0 , -1 },
  { Typ::COLORMAP_BLUESQUEEZE   , "BLUESQUEEZE"   , "Blue Squeeze"    , 0 , -1 },
  { Typ::COLORMAP_BANDEDTIEDYE  , "BANDEDTIEDYE"  , "Banded Tie Dye"  , 0 , -1 },
  { Typ::COLORMAP_PURPLEHAZE    , "PURPLEHAZE"    , "Purple Haze"     , 0 , -1 },
  { Typ::COLORMAP_BLUEGREYRED   , "BLUEGREYRED"   , "Blue Grey Red"   , 0 , -1 },
  { Typ::COLORMAP_BLUEYELLOWRED , "BLUEYELLOWRED" , "Blue Yellow Red" , 0 , -1 },
  { Typ::COLORMAP_VOXELGEO      , "VOXELGEO"      , "VoxelGeo"        , 0 , -1 },
  { Typ::COLORMAP_SMALLVORTEX   , "SMALLVORTEX"   , "Small Vortex"    , 0 , -1 },
  { Typ::COLORMAP_GEOVEL        , "GEOVEL"        , "GeoVel"          , 0 , -1 },
  // third column
  { Typ::COLORMAP_SMALLTIGER             , "SMALLTIGER"             , "Small Tiger"               , 0 , -1 },
  { Typ::COLORMAP_BIGTIGER               , "BIGTIGER"               , "Big Tiger"                 , 0 , -1 },
  { Typ::COLORMAP_SICKTIGER              , "SICKTIGER"              , "Sick Tiger"                , 0 , -1 },
  { Typ::COLORMAP_PERTURBATION           , "PERTURBATION"           , "Perturbation"              , 0 , -1 },
  { Typ::COLORMAP_PRIMARYCOLORS          , "PRIMARYCOLORS"          , "Primary Colors"            , 0 , -1 },
  { Typ::COLORMAP_BP_ABERDEEN            , "BP_ABERDEEN"            , "BP Aberdeen"               , 0 , -1 },
  { Typ::COLORMAP_SEMBLANCESPECTRUM      , "SEMBLANCESPECTRUM"      , "Semblance Spectrum"        , 0 , -1 },
  { Typ::COLORMAP_ACQUISITIONFOLDOFCOVER , "ACQUISITIONFOLDOFCOVER" , "Acquisition Fold of Cover" , 0 , -1 },
  { Typ::COLORMAP_FOLDMAP                , "FOLDMAP"                , "Fold Map"                  , 0 , -1 },
  { Typ::COLORMAP_BIGVORTEX              , "BIGVORTEX"              , "Large Vortex"              , 0 , -1 },
  { Typ::COLORMAP_REDWBLK                , "REDWBLK"                , "RedBblk"                   , 0 , -1 },
  // fourth column
  { Typ::COLORMAP_BANDEDRGV        , "BANDEDRGV"        , "Banded RGV"       , 0 , -1 },
  //
  { Typ::COLORMAP_GRAYSCALE_65     , "GRAYSCALE_65"     , "Black->White 65"  , 0 , -1 },
  { Typ::COLORMAP_STANDARD_WINDOWS , "STANDARD_WINDOWS" , "Standard Windows" , 0 , -1 },
  { Typ::COLORMAP_SEISMICREDBLUE   , "SEISMICREDBLUE"   , "Seismic Red Blue" , 0 , -1 },
  //
  { Typ::COLORMAP_STEP145AMPD      , "STEP145AMPD"      , "Step145Ampd"      , 0 , -1 },
  { Typ::COLORMAP_ANGLE45DIP60     , "ANGLE45DIP60"     , "Angle45Dip60"     , 0 , -1 },
  { Typ::COLORMAP_ANGLE3           , "ANGLE3"           , "Angle 3"          , 0 , -1 },
  { Typ::COLORMAP_ANGLE4           , "ANGLE4"           , "Angle 4"          , 0 , -1 },
  //
  { Typ::COLORMAP_BP_RMS           , "BP_RMS"           , "BP RMS"           , 0 , -1 },
  { Typ::COLORMAP_BP_NORMALISED_RMS, "BP_NORMALISED_RMS", "BP Normalised RMS", 0 , -1 },
  { Typ::COLORMAP_BP_RMS_RATIO     , "BP_RMS_RATIO"     , "BP RMS Ratio"     , 0 , -1 },
  // *** MONITOR_FRIENDLY
  { Typ::COLORMAP_PUREBLUEGREENRED  , "PureBlueGreenRed"  , "Pure Blue->Green->Red"  , 0 , Typ::COL_AQUA },
  { Typ::COLORMAP_PUREGREENREDBLUE  , "PureGreenRedBlue"  , "Pure Green->Red->Blue"  , 0 , Typ::COL_AQUA },
  { Typ::COLORMAP_PUREREDBLUEGREEN  , "PureRedBlueGreen"  , "Pure Red->Blue->Green"  , 0 , Typ::COL_AQUA },
  { Typ::COLORMAP_MUDDYBLUEGREENRED , "MuddyBlueGreenRed" , "Muddy Blue->Green->Red" , 0 , Typ::COL_AQUA },
  { Typ::COLORMAP_MUDDYGREENREDBLUE , "MuddyGreenRedBlue" , "Muddy Green->Red->Blue" , 0 , Typ::COL_AQUA },
  { Typ::COLORMAP_MUDDYREDBLUEGREEN , "MuddyRedBlueGreen" , "Muddy Red->Blue->Green" , 0 , Typ::COL_AQUA },
  // *** SPECTRUM
  { Typ::COLORMAP_PUREEMSPECTRUM          , "VisibleRegionOfTheEMSpectrum" , "Visible Region of the EM Spectrum"       , 0 , Typ::COL_NAVY },
  { Typ::COLORMAP_PUREBLUEGREENREDMAGENTA , "BlueCyanYellowRedMagenta"     , "Blue, Cyan, Green, Yellow, Red, Magenta" , 0 , Typ::COL_NAVY },
  // *** PLOTTER_FRIENDLY
  { Typ::COLORMAP_CYANMAGENTAYELLOW , "CyanMagentaYellow" , "Cyan->Magenta->Yellow" , 0 , Typ::COL_YELLOW },
  { Typ::COLORMAP_MAGENTAYELLOWCYAN , "MagentaYellowCyan" , "Magenta->Yellow->Cyan" , 0 , Typ::COL_YELLOW },
  { Typ::COLORMAP_YELLOWCYANMAGENTA , "YellowCyanMagenta" , "Yellow->Cyan->Magenta" , 0 , Typ::COL_YELLOW },
  // *** GREY_SCALE
  { Typ::COLORMAP_BLACKWHITE      , "BlackWhite"      , "Black->White"        , 0 , Typ::COL_SILVER },
  { Typ::COLORMAP_BLACKWHITEBLACK , "BlackWhiteBlack" , "Black->White->Black" , 0 , Typ::COL_SILVER },
  { Typ::COLORMAP_WHITEBLACK      , "WhiteBlack"      , "White->Black"        , 0 , Typ::COL_SILVER },
  { Typ::COLORMAP_WHITEBLACKWHITE , "WhiteBlackWhite" , "White->Black->White" , 0 , Typ::COL_SILVER },
  // *** WHITE_CENTERED
  { Typ::COLORMAP_BLUEWHITERED       , "BlueWhiteRed"       , "Blue->White->Red"       , 0 , Typ::COL_WHITE },
  { Typ::COLORMAP_BLUEWHITEYELLOW    , "BlueWhiteYellow"    , "Blue->White->Yellow"    , 0 , Typ::COL_WHITE },
  { Typ::COLORMAP_GREENWHITERED      , "GreenWhiteRead"     , "Green->White->Red"      , 0 , Typ::COL_WHITE },
  { Typ::COLORMAP_BLUEWHITEGREEN     , "BlueWhiteGreen"     , "Blue->White->Green"     , 0 , Typ::COL_WHITE },
  { Typ::COLORMAP_CYANWHITEMAGENTA   , "CyanWhiteMagenta"   , "Cyan->White->Magenta"   , 0 , Typ::COL_WHITE },
  { Typ::COLORMAP_YELLOWWHITEMAGENTA , "YellowWhiteMagenta" , "Yellow->White->Magenta" , 0 , Typ::COL_WHITE },
  { Typ::COLORMAP_CYANWHITEYELLOW    , "CyanWhiteYellow"    , "Cyan->White->Yellow"    , 0 , Typ::COL_WHITE },
  // *** COL_TYPE_MISCELLANEOUS
  { Typ::COLORMAP_HOTBLACK        , "Hotblack"        , "Hotblack"         , 0 , Typ::COL_MAGENTA },
  { Typ::COLORMAP_DIVAN           , "Divan"           , "Divan"            , 0 , Typ::COL_MAGENTA },
  { Typ::COLORMAP_SINGAPORESHADES , "SingaporeShades" , "Singapore shades" , 0 , Typ::COL_MAGENTA },
  { Typ::COLORMAP_CHICRAINBOW     , "ChicRainbox"     , "Chic Rainbox"     , 0 , Typ::COL_MAGENTA }
};



//===============================================================================================
//===============================================================================================
//===============================================================================================
// DRAWING PARAMETERS, lines, font, text, array (e.g.: seismic image)
//===============================================================================================
//===============================================================================================
//===============================================================================================

/** Line attriTypte types **/

static Typ::ValuesStruct LineStyleVALUES[] = {
  { Typ::LS_SOLID       , "LS_SOLID"      , 0 , "cgLsSolid"      , -1 } ,
  { Typ::LS_EMPTY       , "LS_EMPTY"      , 0 , "cmewhite"       , -1 } ,
  { Typ::LS_DOT         , "LS_DOT"        , 0 , "cgLsDot"        , -1 } ,
  { Typ::LS_DASH        , "LS_DASH"       , 0 , "cgLsDash"       , -1 } ,
  { Typ::LS_DASHDOT     , "LS_DASHDOT"    , 0 , "cgLsDashDot"    , -1 } ,
  { Typ::LS_DASHDOTDOT  , "LS_DASHDOTDOT" , 0 , "cgLsDashDotDot" , -1 }
};
static Typ::ValuesStruct LineStyleShortVALUES[] = {
  { Typ::LS_SOLID       , "LS_SOLID"      , 0 , "cgLsSolid"      , -1 } ,
  { Typ::LS_DOT         , "LS_DOT"        , 0 , "cgLsDot"        , -1 } ,
  { Typ::LS_DASH        , "LS_DASH"       , 0 , "cgLsDash"       , -1 } ,
  { Typ::LS_DASHDOT     , "LS_DASHDOT"    , 0 , "cgLsDashDot"    , -1 } ,
  { Typ::LS_DASHDOTDOT  , "LS_DASHDOTDOT" , 0 , "cgLsDashDotDot" , -1 }
};

static Typ::ValuesStruct LineEndCapVALUES[] = {
  { Typ::LEC_DEFAULT , "LEC_DEFAULT" , 0 , 0 , -1 } ,
  { Typ::LEC_ROUND   , "LEC_ROUND"   , 0 , 0 , -1 } ,
  { Typ::LEC_SQUARE  , "LEC_SQUARE"  , 0 , 0 , -1 } ,
  { Typ::LEC_FLAT    , "LEC_FLAT"    , 0 , 0 , -1 }
};

static Typ::ValuesStruct LineJoinVALUES[] = {
  { Typ::LJ_DEFAULT  , "LJ_DEFAULT" , 0 , 0 , -1 } ,
  { Typ::LJ_ROUND    , "LJ_ROUND"   , 0 , 0 , -1 } ,
  { Typ::LJ_BEVEL    , "LJ_BEVEL"   , 0 , 0 , -1 } ,
  { Typ::LJ_MITER    , "LJ_MITER"   , 0 , 0 , -1 }
};

static Typ::ValuesStruct DimUnitVALUES[] = {
  { Typ::DU_PIXEL        , "DU_PIXEL"        , 0 , 0 , -1 } ,
  { Typ::DU_POINT        , "DU_POINT"        , 0 , 0 , -1 } ,
  { Typ::DU_SCALED_POINT , "DU_SCALED_POINT" , 0 , 0 , -1 }
};
static Typ::ValuesStruct MarkerStyleVALUES[] = {
  { Typ::MS_EMPTY   , "MS_EMPTY"   , "Empty"   , 0 , -1 } ,
  { Typ::MS_DOT     , "MS_DOT"     , "Dot"     , 0 , -1 } ,
  { Typ::MS_PLUS    , "MS_PLUS"    , "Plus"    , 0 , -1 } ,
  { Typ::MS_STAR    , "MS_STAR"    , "Star"    , 0 , -1 } ,
  { Typ::MS_CIRCLE  , "MS_CIRCLE"  , "Circle"  , 0 , -1 } ,
  { Typ::MS_CROSS   , "MS_CROSS"   , "Cross"   , 0 , -1 } ,
  { Typ::MS_SQUARE  , "MS_SQUARE"  , "Square"  , 0 , -1 } ,
  { Typ::MS_PATTERN , "MS_PATTERN" , "Pattern" , 0 , -1 }
};
static Typ::ValuesStruct MarkerStyleShortVALUES[] = {
  { Typ::MS_DOT     , "MS_DOT"     , "Dot"    , 0 , -1 } ,
  { Typ::MS_PLUS    , "MS_PLUS"    , "Plus"   , 0 , -1 } ,
  { Typ::MS_STAR    , "MS_STAR"    , "Star"   , 0 , -1 } ,
  { Typ::MS_CIRCLE  , "MS_CIRCLE"  , "Cross"  , 0 , -1 } ,
  { Typ::MS_CROSS   , "MS_CROSS"   , "Circle" , 0 , -1 } ,
  { Typ::MS_SQUARE  , "MS_SQUARE"  , "Square" , 0 , -1 }
};

/** Attribute types **/

static Typ::ValuesStruct FillStyleVALUES[] = {
  { Typ::FS_SOLID        , "FS_SOLID"        , "Solid"        , 0 , -1 } ,
  { Typ::FS_EMPTY        , "FS_EMPTY"        , "Empty"        , 0 , -1 } ,
  { Typ::FS_HORIZONTAL   , "FS_HORIZONTAL"   , "Horizontal"   , 0 , -1 } ,
  { Typ::FS_VERTICAL     , "FS_VERTICAL"     , "Vertical"     , 0 , -1 } ,
  { Typ::FS_FDIAGONAL    , "FS_FDIAGONAL"    , "F Diagonal"   , 0 , -1 } ,
  { Typ::FS_BDIAGONAL    , "FS_BDIAGONAL"    , "B Diagonal"   , 0 , -1 } ,
  { Typ::FS_CROSS        , "FS_CROSS"        , "Cross"        , 0 , -1 } ,
  { Typ::FS_DIAGCROSS    , "FS_DIAGCROSS"    , "Diag Cross"   , 0 , -1 } ,
  { Typ::FS_PATTERN      , "FS_PATTERN"      , "Pattern"      , 0 , -1 } ,
  { Typ::FS_CUSTOM_BRUSH , "FS_CUSTOM_BRUSH" , "Custom Brush" , 0 , -1 }
};

/** Font attriTypte types **/

static Typ::ValuesStruct FontWeightVALUES[] = {
  { Typ::WT_DEFAULT    , "WT_DEFAULT"    , "Default"     , 0 , -1 } ,
  { Typ::WT_THIN       , "WT_THIN"       , "Thin"        , 0 , -1 } ,
  { Typ::WT_EXTRALIGHT , "WT_EXTRALIGHT" , "Extra Light" , 0 , -1 } ,
  { Typ::WT_LIGHT      , "WT_LIGHT"      , "Light"       , 0 , -1 } ,
  { Typ::WT_NORMAL     , "WT_NORMAL"     , "Normal"      , 0 , -1 } ,
  { Typ::WT_MEDIUM     , "WT_MEDIUM"     , "Medium"      , 0 , -1 } ,
  { Typ::WT_SEMIBOLD   , "WT_SEMIBOLD"   , "Semi Bold"   , 0 , -1 } ,
  { Typ::WT_BOLD       , "WT_BOLD"       , "Bold"        , 0 , -1 } ,
  { Typ::WT_EXTRABOLD  , "WT_EXTRABOLD"  , "Extra Bold"  , 0 , -1 } ,
  { Typ::WT_HEAVY      , "WT_HEAVY"      , "Heavy"       , 0 , -1 }
};

static Typ::ValuesStruct FontSizeVALUES[] = {
  { Typ::SZ_8   , "SZ_8"   , "8"  , 0 , -1 } ,
  { Typ::SZ_10  , "SZ_10"  , "10" , 0 , -1 } ,
  { Typ::SZ_11  , "SZ_11"  , "11" , 0 , -1 } ,
  { Typ::SZ_12  , "SZ_12"  , "12" , 0 , -1 } ,
  { Typ::SZ_14  , "SZ_14"  , "14" , 0 , -1 } ,
  { Typ::SZ_16  , "SZ_16"  , "16" , 0 , -1 } ,
  { Typ::SZ_18  , "SZ_18"  , "18" , 0 , -1 } ,
  { Typ::SZ_20  , "SZ_20"  , "20" , 0 , -1 } ,
  { Typ::SZ_24  , "SZ_24"  , "24" , 0 , -1 } ,
  { Typ::SZ_28  , "SZ_28"  , "28" , 0 , -1 } ,
  { Typ::SZ_32  , "SZ_32"  , "32" , 0 , -1 } ,
  { Typ::SZ_36  , "SZ_36"  , "36" , 0 , -1 } ,
  { Typ::SZ_40  , "SZ_40"  , "40" , 0 , -1 } ,
  { Typ::SZ_44  , "SZ_44"  , "44" , 0 , -1 } ,
  { Typ::SZ_48  , "SZ_48"  , "48" , 0 , -1 }
};

static Typ::ValuesStruct FontSlantVALUES[] = {
  { Typ::SL_NORMAL  , "SL_NORMAL"  , "Normal"  , 0 , -1 } ,
  { Typ::SL_ITALIC  , "SL_ITALIC"  , "Italic"  , 0 , -1 } ,
  { Typ::SL_OBLIQUE , "SL_OBLIQUE" , "Oblique" , 0 , -1 }
};

static Typ::ValuesStruct FontAttributeVALUES[] = {
  { Typ::FA_NORMAL    , "FA_NORMAL"    , "Normal"     , 0 , -1 } ,
  { Typ::FA_UNDERLINE , "FA_UNDERLINE" , "Underline"  , 0 , -1 } ,
  { Typ::FA_STRIKEOUT , "FA_STRIKEOUT" , "Strike Out" , 0 , -1 } ,
  { Typ::FA_UNDERLINE_STRIKEOUT , "FA_UNDERLINE_STRIKEOUT" , "Unterline Strileout" , 0 , -1 }
};

static Typ::ValuesStruct FontFamilyVALUES[] = {
  { Typ::FM_DEFAULT    , "FM_DEFAULT"    , "Default"    , 0 , -1 } ,
  { Typ::FM_ROMAN      , "FM_ROMAN"      , "Roman"      , 0 , -1 } ,
  { Typ::FM_SWISS      , "FM_SWISS"      , "Swiss"      , 0 , -1 } ,
  { Typ::FM_MODERN     , "FM_MODERN"     , "Modern"     , 0 , -1 } ,
  { Typ::FM_SCRIPT     , "FM_SCRIPT"     , "Script"     , 0 , -1 } ,
  { Typ::FM_DECORATIVE , "FM_DECORATIVE" , "Decorative" , 0 , -1 } ,
  { Typ::FM_SERIF      , "FM_SERIF"      , "Serif"      , 0 , -1 } ,
  { Typ::FM_SANS_SERIF , "FM_SANS_SERIF" , "Sans Serif" , 0 , -1 } ,
  { Typ::FM_MONOSPACED , "FM_MONOSPACED" , "Monospaced" , 0 , -1 }
};

static Typ::ValuesStruct FontTechnologyVALUES[] = {
  { Typ::FT_EMPTY    , "FT_EMPTY"    , "Empty"    , 0 , -1 } ,
  { Typ::FT_NATIVE   , "FT_NATIVE"   , "Native"   , 0 , -1 } ,
  { Typ::FT_TRUETYPE , "FT_TRUETYPE" , "TrueType" , 0 , -1 } ,
  { Typ::FT_OLF      , "FT_OLF"      , "OLF"      , 0 , -1 } ,
  { Typ::FT_SCALABLE , "FT_SCALABLE" , "Scalable" , 0 , -1 } ,
  { Typ::FT_DEFAULT  , "FT_DEFAULT"  , "Default"  , 0 , -1 }
};

static Typ::ValuesStruct FontSizeModeVALUES[] = {
  { Typ::FSM_DEFAULT         , "FSM_DEFAULT"         , "Driver default"                , 0 , -1 } ,
  { Typ::FSM_HEIGHT          , "FSM_HEIGHT"          , "Height of M"                   , 0 , -1 } ,
  { Typ::FSM_DEPTH           , "FSM_DEPTH"           , "Depth of g"                    , 0 , -1 } ,
  { Typ::FSM_DESCENT         , "FSM_DESCENT"         , "WIN32 analog"                  , 0 , -1 } ,
  { Typ::FSM_HEIGHT_GAP      , "FSM_HEIGHT_GAP"      , "Gap above symbols for accent etc" , 0 , -1 } ,
  { Typ::FSM_INTERNALLEADING , "FSM_INTERNALLEADING" , "WIN32 analog"                  , 0 , -1 } ,
  { Typ::FSM_ASCENT          , "FSM_ASCENT"          , "Height of A with accent"       , 0 , -1 } ,
  { Typ::FSM_EMHEIGHT	      , "FSM_EMHEIGHT"        , "Height of Mg (also em height)" , 0 , -1 } ,
  { Typ::FSM_MAXHEIGHT       , "FSM_MAXHEIGHT"       , "Maximum character height"      , 0 , -1 }
};

/** Alignment, Order of graphics layers **/

static Typ::ValuesStruct AlignmentVALUES[] = {
  { Typ::AL_V_TOP      , "AL_V_TOP"      , "Top"      , 0 , -1 } ,
  { Typ::AL_V_CENTER   , "AL_V_CENTER"   , "Center"   , 0 , -1 } ,
  { Typ::AL_V_BOTTOM   , "AL_V_BOTTOM"   , "Bottom"   , 0 , -1 } ,
  { Typ::AL_V_BASELINE , "AL_V_BASELINE" , "Baseline" , 0 , -1 } ,
  { Typ::AL_H_LEFT     , "AL_H_LEFT"     , "Left"     , 0 , -1 } ,
  { Typ::AL_H_CENTER   , "AL_H_CENTER"   , "Center"   , 0 , -1 } ,
  { Typ::AL_H_RIGHT    , "AL_H_RIGHT"    , "Right"    , 0 , -1 }
};

static Typ::ValuesStruct PointTagVALUES[] = {
  { Typ::PT_ILLEGAL   , "PT_ILLEGAL"  , 0 , 0 , -1 } ,
  { Typ::PT_REGULAR   , "PT_REGULAR"  , 0 , 0 , -1 } ,
  { Typ::PT_BEZIER    , "PT_BEZIER"   , 0 , 0 , -1 } ,
  { Typ::PT_OPEN_END  , "PT_OPEN_END" , 0 , 0 , -1 } ,
  { Typ::PT_CLOSE_END , "PT_OPEN_END" , 0 , 0 , -1 }
};

static Typ::ValuesStruct OrderVALUES[] = {
  { Typ::ORD_BESIDE    , "ORD_BESIDE"    , 0 , 0 , -1 } ,
  { Typ::ORD_ABOVE     , "ORD_ABOVE"     , 0 , 0 , -1 } ,
  { Typ::ORD_BELOW     , "ORD_BELOW"     , 0 , 0 , -1 } ,
  { Typ::ORD_ABOVE_ONE , "ORD_ABOVE_ONE" , 0 , 0 , -1 } ,
  { Typ::ORD_BELOW_ONE , "ORD_BELOW_ONE" , 0 , 0 , -1 } ,
  { Typ::ORD_FRONT     , "ORD_FRONT"     , 0 , 0 , -1 } ,
  { Typ::ORD_BACK      , "ORD_BACK"      , 0 , 0 , -1 }
};

/** Float array drawing (Float Array such as seismic image: trace is vertical) **/

static Typ::ValuesStruct TraceTypeVALUES[] = {
  { Typ::TR_NORMAL   , "TR_NORMAL"   , 0 , 0 , -1 } ,
  { Typ::TR_KILLED   , "TR_KILLED"   , 0 , 0 , -1 } ,
  { Typ::TR_REVERSED , "TR_REVERSED" , 0 , 0 , -1 } ,
  { Typ::TR_GAP      , "TR_GAP"      , 0 , 0 , -1 }
};

static Typ::ValuesStruct SampleUnitsVALUES[] = {
  { Typ::SU_TIME         , "SU_TIME"         , 0 , 0 , -1 } ,
  { Typ::SU_DEPTH_FEET   , "SU_DEPTH_FEET"   , 0 , 0 , -1 } ,
  { Typ::SU_DEPTH_METERS , "SU_DEPTH_METERS" , 0 , 0 , -1 }
};

static Typ::ValuesStruct SeismicInterpolationTypeVALUES[] = {
  { Typ::SIT_STEP      , "SIT_STEP"      , 0 , 0 , -1 } ,
  { Typ::SIT_LINEAR    , "SIT_LINEAR"    , 0 , 0 , -1 } ,
  { Typ::SIT_QUADRATIC , "SIT_QUADRATIC" , 0 , 0 , -1 }
};

static Typ::ValuesStruct SeismicClipTypeVALUES[] = {
  { Typ::SCT_NOCLIP , "SCT_NOCLIP"  , 0 , 0 , -1 } ,
  { Typ::SCT_FILL   , "SCT_FILL"    , 0 , 0 , -1 } ,
  { Typ::SCT_WIGGLE , "SCT_WIGGLE"  , 0 , 0 , -1 }
};

static Typ::ValuesStruct SeismicPlotTypeVALUES[] = {
  // base values
  { Typ::SPT_WIGGLE               , "SPT_WIGGLE"               , 0 , 0 , -1 } ,
  { Typ::SPT_POSITIVE_FILL        , "SPT_POSITIVE_FILL"        , 0 , 0 , -1 } ,
  { Typ::SPT_NEGATIVE_FILL        , "SPT_NEGATIVE_FILL"        , 0 , 0 , -1 } ,
  { Typ::SPT_COLOR                , "SPT_COLOR"                , 0 , 0 , -1 } ,
  { Typ::SPT_LOBE                 , "SPT_LOBE"                 , 0 , 0 , -1 } ,
  { Typ::SPT_DENSITY              , "SPT_DENSITY"              , 0 , 0 , -1 } ,
  { Typ::SPT_INTERPOLATED_DENSITY , "SPT_INTERPOLATED_DENSITY" , 0 , 0 , -1 } ,
  // composite values
  { Typ::SPT_POSITIVE_FILL_AND_WIGGLE   , "SPT_POSITIVE_FILL_AND_WIGGLE"  , 0 , 0 , -1 } ,
  { Typ::SPT_NEGATIVE_FILL_AND_WIGGLE   , "SPT_NEGATIVE_FILL_AND_WIGGLE"  , 0 , 0 , -1 } ,
  { Typ::SPT_POSITIVE_AND_NEGATIVE_FILL , "SPT_POSITIVE_AND_NEGATIVE_FILL", 0 , 0 , -1 } ,
  { Typ::SPT_POSITIVE_COLOR_FILL        , "SPT_POSITIVE_COLOR_FILL"       , 0 , 0 , -1 } ,
  { Typ::SPT_NEGATIVE_COLOR_FILL        , "SPT_NEGATIVE_COLOR_FILL"       , 0 , 0 , -1 } ,
  { Typ::SPT_DENSITY_AND_WIGGLE         , "SPT_DENSITY_AND_WIGGLE"        , 0 , 0 , -1 } ,
  { Typ::SPT_DENSITY_AND_POSITIVE_FILL  , "SPT_DENSITY_AND_POSITIVE_FILL" , 0 , 0 , -1 } ,
  { Typ::SPT_DENSITY_AND_NEGATIVE_FILL  , "SPT_DENSITY_AND_NEGATIVE_FILL" , 0 , 0 , -1 } ,
  { Typ::SPT_COLOR_FILL                 , "SPT_COLOR_FILL"                , 0 , 0 , -1 } ,
  { Typ::SPT_LOBE_FILL                  , "SPT_LOBE_FILL"                 , 0 , 0 , -1 }
  // else it's saved as an integer
};

static Typ::ValuesStruct SeismicNormModeVALUES[] = {
  { Typ::SNM_DEFAULT       , "SNM_DEFAULT"       , 0 , 0 , -1 } ,
  { Typ::SNM_DATA_TYPE     , "SNM_DATA_TYPE"     , 0 , 0 , -1 } ,
  { Typ::SNM_TRACE_MAXIMUM , "SNM_TRACE_MAXIMUM" , 0 , 0 , -1 } ,
  { Typ::SNM_TRACE_AVERAGE , "SNM_TRACE_AVERAGE" , 0 , 0 , -1 } ,
  { Typ::SNM_TRACE_RMS     , "SNM_TRACE_RMS"     , 0 , 0 , -1 } ,
  { Typ::SNM_LIMITS        , "SNM_LIMITS"        , 0 , 0 , -1 }
};



//===============================================================================================
//===============================================================================================
//===============================================================================================
// PRINTING OPTIONS (for instance, in Qt)
//===============================================================================================
//===============================================================================================
//===============================================================================================

static Typ::ValuesStruct  ImageOutputVALUES[] =
{
  { Typ::IMG_O_FILE    , "IMG_O_FILE"    , "Save Image in File" , 0 , -1 },
  { Typ::IMG_O_PRINTER , "IMG_O_PRINTER" , "Send to Printer"    , 0 , -1 }
};

static Typ::ValuesStruct  ImageDepthVALUES[] =
{
  { Typ::IMG_D_1       , "IMG_D_1"  , "1 (bitmap)"      ,  0 , -1 },
  { Typ::IMG_D_8       , "IMG_D_8"  , "8 (color)"       ,  0 , -1 },
  { Typ::IMG_D_16      , "IMG_D_16" , "16"              ,  0 , -1 },
  { Typ::IMG_D_24      , "IMG_D_24" , "24 (best color)" ,  0 , -1 }
};

static Typ::ValuesStruct  ImageFormatVALUES[] =
{
  { Typ::IMG_F_BMP	 , "IMG_F_BMP"  , "bmp"  , 0 , -1 }, // Windows Bitmap
  { Typ::IMG_F_GIF	 , "IMG_F_GIF"  , "gif"  , 0 , -1 }, // Graphic Interchange Format (optional)
  { Typ::IMG_F_JPG	 , "IMG_F_JPG"  , "jpg"  , 0 , -1 }, // Joint Photographic Experts Group
  { Typ::IMG_F_JPEG  , "IMG_F_JPEG" , "jpeg" , 0 , -1 }, // Joint Photographic Experts Group
  { Typ::IMG_F_MNG	 , "IMG_F_MNG"  , "mng"  , 0 , -1 }, // Multiple-image Network Graphics
  { Typ::IMG_F_PNG	 , "IMG_F_PNG"  , "png"  , 0 , -1 }, // Portable Network Graphics
  { Typ::IMG_F_PBM	 , "IMG_F_PBM"  , "pbm"  , 0 , -1 }, // Portable Bitmap
  { Typ::IMG_F_PGM	 , "IMG_F_PGM"  , "pgm"  , 0 , -1 }, // Portable Graymap
  { Typ::IMG_F_PPM	 , "IMG_F_PPM"  , "ppm"  , 0 , -1 }, // Portable Pixmap
  { Typ::IMG_F_TIF   , "IMG_F_TIF"  , "tif"  , 0 , -1 }, // Tagged Image File Format
  { Typ::IMG_F_TIFF  , "IMG_F_TIFF" , "tiff" , 0 , -1 }, // Tagged Image File Format
  { Typ::IMG_F_XBM	 , "IMG_F_XBM"  , "xbm"  , 0 , -1 }, // X11 Bitmap
  { Typ::IMG_F_XPM	 , "IMG_F_XPM"  , "xpm"  , 0 , -1 }, // X11 Pixmap
  { Typ::IMG_F_SVG   , "IMG_F_SVG"  , "svg"  , 0 , -1 }, // Scalable Vector Graphics
  { Typ::IMG_F_TGA   , "IMG_F_TGA"  , "tga"  , 0 , -1 }, // Targa Image Format
  // printer
  { Typ::IMG_F_PDF   , "IMG_F_PDF"  , "pdf"  , 0 , -1 }, // Acrobat reader
  { Typ::IMG_F_PS    , "IMG_F_PS"   , "ps"   , 0 , -1 }  // PostScript
};

static Typ::ValuesStruct  ImageScalingVALUES[] =
{
  { Typ::IMG_S_FIT      , "IMG_S_FIT"      , "Scale to Fit"   , 0 , -1 },
  { Typ::IMG_S_ORIGINAL , "IMG_S_ORIGINAL" , "Original Size"  , 0 , -1 }
};

static Typ::ValuesStruct  PrinterColorModeVALUES[] =
{
  { Typ::PRT_CM_COLOR     , "PRT_CM_COLOR"     , "Color" , 0 , -1 },
  { Typ::PRT_CM_GRAYSCALE , "PRT_CM_GRAYSCALE" , "Gray"  , 0 , -1 }
};

static Typ::ValuesStruct  PrinterOrientationVALUES[] =
{
  { Typ::PRT_OR_PORTRAIT  , "PRT_OR_PORTRAIT"  , "Portrait"  , 0 , -1 },
  { Typ::PRT_OR_LANDSCAPE , "PRT_OR_LANDSCAPE" , "Landscape" , 0 , -1 }
};

static Typ::ValuesStruct  PrinterResolutionVALUES[] =
{
  { Typ::PRT_PM_SCREEN_RESOLUTION , "PRT_PM_SCREEN_RESOLUTION" , "Screen" , 0 , -1 },
  { Typ::PRT_PM_HIGH_RESOLUTION   , "PRT_PM_HIGH_RESOLUTION"   , "High"   , 0 , -1 }
};



//===============================================================================================
//===============================================================================================
//===============================================================================================
// APPLICATION OPTIONS: set of parameters that apply to the application.
//===============================================================================================
//===============================================================================================
//===============================================================================================

static Typ::ValuesStruct FontTypeVALUES[] = {
  { Typ::FNT_TITLE            , "FNT_TITLE"            , "Title"            , 0 , -1 },
  { Typ::FNT_SECTION_TITLE    , "FNT_SECTION_TITLE"    , "Section Title"    , 0 , -1 },
  { Typ::FNT_VERTICAL_MAJOR   , "FNT_VERTICAL_MAJOR"   , "Vertical Major"   , 0 , -1 },
  { Typ::FNT_VERTICAL_MINOR   , "FNT_VERTICAL_MINOR"   , "Vertical Minor"   , 0 , -1 },
  { Typ::FNT_HORIZONTAL_MAJOR , "FNT_HORIZONTAL_MAJOR" , "Horizontal Major" , 0 , -1 },
  { Typ::FNT_HORIZONTAL_MINOR , "FNT_HORIZONTAL_MINOR" , "Horizontal Minor" , 0 , -1 },
  { Typ::FNT_TIMESLICE_INLINE_MAJOR    , "FNT_TIMESLICE_INLINE"    , "Timeslice Inline"    , 0 , -1 },
  { Typ::FNT_TIMESLICE_CROSSLINE_MINOR , "FNT_TIMESLICE_CROSSLINE" , "Timeslice Crossline" , 0 , -1 },
  //
  { Typ::FNT_CONTOUR_LINE     , "FNT_COUTOUR_LINE"     , "Contour Line" , 0 , -1 },
  { Typ::FNT_HORIZON          , "FNT_HORIZON"          , "Horizon"      , 0 , -1 }
};

static Typ::ValuesStruct AxisTypeVALUES[] = {
  { Typ::AXI_VERTICAL_TIME       , "AXI_VERTICAL_TIME"       , "Time (vertical axis)"        , 0 , -1 },
  { Typ::AXI_HORIZONTAL_VELOCITY , "AXI_HORIZONTAL_VELOCITY" , "Velocity (horizontal axis)" , 0 , -1 },
  { Typ::AXI_HORIZONTAL_SIGNAL   , "AXI_HORIZONTAL_SIGNAL"   , "Signal (horizontal axis)"   , 0 , -1 }
};

static Typ::ValuesStruct CursorTypeVALUES[] = {
  { Typ::CRS_NONE      , "CRS_NONE"      , "None"      , 0 , -1 },
  { Typ::CRS_ANY       , "CRS_ANY"       , "Any"       , 0 , -1 },
  { Typ::CRS_WEST_EAST , "CRS_WEST_EAST" , "West East" , 0 , -1 }
};

static Typ::ValuesStruct SoundModeVALUES[] = {
  { Typ::SND_BEEP      , "SND_BEEP"      , "Beep"   , 0 , -1 },
  { Typ::SND_VISUAL    , "SND_VISUAL"    , "Visual" , 0 , -1 }
};

static Typ::ValuesStruct DeleteModeVALUES[] = {
  { Typ::DEL_DRAG      , "DEL_DRAG"      , "Drag"     , 0 , -1 },
  { Typ::DEL_REGION    , "DEL_REGION"    , "Region"   , 0 , -1 },
  { Typ::DEL_FUNCTION  , "DEL_FUNCTION"  , "Function" , 0 , -1 }
};




//===============================================================================================
//===============================================================================================
//===============================================================================================
// OBTAINING VALUES
//===============================================================================================
//===============================================================================================
//===============================================================================================


/** get the array of values (the size of the array is provided) */
const Typ::ValuesStruct   * Typ::getValues( MscDataItem::DataType dataHolderType , int & numberOfValues , bool &isPresent );
const Typ::ValuesStruct   * Typ::getValues( MscDataItem::DataType dataHolderType , int & numberOfValues );
std::vector< Typ::ValuesStruct > Typ::getValues( MscDataItem::DataType dataHolderType , int firstId , int lastId );

/** find out if a value exists (value or the flag) */
bool                        Typ::hasValue ( MscDataItem::DataType dataHolderType , int );
bool                        Typ::hasValue ( MscDataItem::DataType dataHolderType , const MscString & );

/** for a specific value , get the flags (used when writing) , or
   *  get the array of values corresponding to the flag (used when reading) */
const Typ::ValuesStruct   & Typ::getValue ( MscDataItem::DataType dataHolderType , int , bool &isPresent );
const Typ::ValuesStruct   & Typ::getValue ( MscDataItem::DataType dataHolderType , int );
const Typ::ValuesStruct   & Typ::getValue ( MscDataItem::DataType dataHolderType , const MscString & , bool &isPresent );
const Typ::ValuesStruct   & Typ::getValue ( MscDataItem::DataType dataHolderType , const MscString & );

/** font identification to show to the user */
MscString Typ::getFontLabel( int fontFamily , int fontSize , int fontSlant , int fontWeight );


//***************************************************************************************//
// ***********                   DEFINITION OF VALUES                   ***************  //
//***************************************************************************************//


/** values */
static struct {
  MscDataItem::DataType     myTypeId ;
  const Typ::ValuesStruct * myValues ;
  int                       myNumber ;
} GraphicsValues[] =
{
  // colors
  { MscDataItem::DT_INT_Color           , ColorVALUES           , sizeof(ColorVALUES)           / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_ColorShort      , ColorShortVALUES      , sizeof(ColorShortVALUES)      / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_Colormap        , ColormapVALUES        , sizeof(ColormapVALUES)        / sizeof( Typ::ValuesStruct ) },
  //{ MscDataItem::DT_INT_ColormapType  , ColormapTypeVALUES    , sizeof(ColormapTypeVALUES)    / sizeof( Typ::ValuesStruct ) }
  // AttributeTypes
  { MscDataItem::DT_INT_LineStyle       , LineStyleVALUES       , sizeof(LineStyleVALUES)       / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_LineStyleShort  , LineStyleShortVALUES  , sizeof(LineStyleShortVALUES)  / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_LineEndCap      , LineEndCapVALUES      , sizeof(LineEndCapVALUES)      / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_LineJoin        , LineJoinVALUES        , sizeof(LineJoinVALUES)        / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_DimUnit         , DimUnitVALUES         , sizeof(DimUnitVALUES)         / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_MarkerStyle     , MarkerStyleVALUES     , sizeof(MarkerStyleVALUES)     / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_MarkerStyleShort, MarkerStyleShortVALUES, sizeof(MarkerStyleShortVALUES)/ sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_FillStyle       , FillStyleVALUES       , sizeof(FillStyleVALUES)       / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_FontWeight      , FontWeightVALUES      , sizeof(FontWeightVALUES)      / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_FontSize        , FontSizeVALUES        , sizeof(FontSizeVALUES)        / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_FontSlant       , FontSlantVALUES       , sizeof(FontSlantVALUES)       / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_FontAttribute   , FontAttributeVALUES   , sizeof(FontAttributeVALUES)   / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_FontFamily      , FontFamilyVALUES      , sizeof(FontFamilyVALUES)      / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_FontTechnology  , FontTechnologyVALUES  , sizeof(FontTechnologyVALUES)  / sizeof( Typ::ValuesStruct ) },
  // BasicTypes
  { MscDataItem::DT_INT_Alignment       , AlignmentVALUES       , sizeof(AlignmentVALUES)       / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_PointTag        , PointTagVALUES        , sizeof(PointTagVALUES)        / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_Order           , OrderVALUES           , sizeof(OrderVALUES)           / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_FontSizeMode    , FontSizeModeVALUES    , sizeof(FontSizeModeVALUES)    / sizeof( Typ::ValuesStruct ) },
  // SeismicConstants
  { MscDataItem::DT_INT_TraceType       , TraceTypeVALUES       , sizeof(TraceTypeVALUES)       / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_SampleUnits     , SampleUnitsVALUES     , sizeof(SampleUnitsVALUES)     / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_SeismicInterpolationType , SeismicInterpolationTypeVALUES ,
    sizeof(SeismicInterpolationTypeVALUES) / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_SeismicClipType , SeismicClipTypeVALUES , sizeof(SeismicClipTypeVALUES) / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_SeismicPlotType , SeismicPlotTypeVALUES , sizeof(SeismicPlotTypeVALUES) / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_SeismicNormMode , SeismicNormModeVALUES , sizeof(SeismicNormModeVALUES) / sizeof( Typ::ValuesStruct ) },
  // image, printer
  { MscDataItem::DT_INT_ImageOutput     , ImageOutputVALUES  , sizeof(ImageOutputVALUES)  / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_ImageDepth      , ImageDepthVALUES   , sizeof(ImageDepthVALUES)   / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_ImageFormat     , ImageFormatVALUES  , sizeof(ImageFormatVALUES)  / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_ImageScaling    , ImageScalingVALUES , sizeof(ImageScalingVALUES) / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_PrinterColorMode   , PrinterColorModeVALUES   , sizeof(PrinterColorModeVALUES)   / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_PrinterOrientation , PrinterOrientationVALUES , sizeof(PrinterOrientationVALUES) / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_PrinterResolution  , PrinterResolutionVALUES  , sizeof(PrinterResolutionVALUES)  / sizeof( Typ::ValuesStruct ) },
  // font, axis, options
  { MscDataItem::DT_INT_FontType        , FontTypeVALUES   , sizeof(FontTypeVALUES)   / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_AxisType        , AxisTypeVALUES   , sizeof(AxisTypeVALUES)   / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_CursorMode      , CursorTypeVALUES , sizeof(CursorTypeVALUES) / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_SoundMode       , SoundModeVALUES  , sizeof(SoundModeVALUES)  / sizeof( Typ::ValuesStruct ) },
  { MscDataItem::DT_INT_DeleteMode      , DeleteModeVALUES , sizeof(DeleteModeVALUES) / sizeof( Typ::ValuesStruct ) }
};
static const int NumberOfGraphicsValues = sizeof(GraphicsValues) / sizeof(GraphicsValues[0]);


const Typ::ValuesStruct * TypGraphicGetValues( int /*MscDataItem::DataType*/ typeId , int & number , bool &isPresent )
{
  for ( int i=0 ; i < NumberOfGraphicsValues ; ++i ) {
    if ( GraphicsValues[i].myTypeId == typeId ) {
      number    = GraphicsValues[i].myNumber ;
      isPresent = true ;
      return GraphicsValues[i].myValues ;
    }
  }
  number    = 0 ;
  isPresent = false ;
  return 0;
}






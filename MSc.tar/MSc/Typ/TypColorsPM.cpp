#include "TypColorsPM.hpp"

#include <assert.h>
#include <map>

#include "MscDebug.hpp"
#include "MscDataHolder.hpp"
#include "TypEnumerations.hpp"
#include "TypOptionsPM.hpp"


/** get a specific color */
static std::map< int , Typ::ColorCreateInfo > ColorsMap ; // initialized below in "Typ::getColor()".
const Typ::ColorCreateInfo & Typ::getColor( int colorId )
{
  // initialize pre-defined values
  if ( ColorsMap.empty() == true ) {
    ColorsMap[ Typ::COL_BLACK        ] = Typ::ColorCreateInfo(   0 ,   0 ,   0 );
    ColorsMap[ Typ::COL_DARK_RED     ] = Typ::ColorCreateInfo( 128 ,   0 ,   0 );
    ColorsMap[ Typ::COL_DARK_GREEN   ] = Typ::ColorCreateInfo(   0 , 128 ,   0 );
    ColorsMap[ Typ::COL_DARK_YELLOW  ] = Typ::ColorCreateInfo( 128 , 128 ,   0 );
    ColorsMap[ Typ::COL_DARK_BLUE    ] = Typ::ColorCreateInfo(   0 ,   0 , 128 );
    ColorsMap[ Typ::COL_DARK_MAGENTA ] = Typ::ColorCreateInfo( 128 ,   0 , 128 );
    ColorsMap[ Typ::COL_DARK_CYAN    ] = Typ::ColorCreateInfo(   0 , 128 , 128 );
    ColorsMap[ Typ::COL_LIGHT_GRAY   ] = Typ::ColorCreateInfo( 192 , 192 , 192 ); // light grey
    ColorsMap[ Typ::COL_GRAY         ] = Typ::ColorCreateInfo( 128 , 128 , 128 );
    ColorsMap[ Typ::COL_RED          ] = Typ::ColorCreateInfo( 255 ,   0 ,   0 );
    ColorsMap[ Typ::COL_GREEN        ] = Typ::ColorCreateInfo(   0 , 255 ,   0 );
    ColorsMap[ Typ::COL_YELLOW       ] = Typ::ColorCreateInfo( 255 , 255 ,   0 );
    ColorsMap[ Typ::COL_BLUE         ] = Typ::ColorCreateInfo(   0 ,   0 , 255 );
    ColorsMap[ Typ::COL_MAGENTA      ] = Typ::ColorCreateInfo( 255,    0 , 255 );
    ColorsMap[ Typ::COL_WHITE        ] = Typ::ColorCreateInfo( 255 , 255 , 255 );
    ColorsMap[ Typ::COL_CYAN         ] = Typ::ColorCreateInfo(   0 , 255 , 255 );
    ColorsMap[ Typ::COL_FRAME        ] = Typ::ColorCreateInfo( 212 , 208 , 200 ); // color of the frame of a window (gray)
    ColorsMap[ Typ::COL_DARK_GRAY    ] = Typ::ColorCreateInfo(  96 ,  96 ,  96 ); // dark gray
    ColorsMap[ Typ::COL_ORANGE       ] = Typ::ColorCreateInfo( 255 , 170 ,   0 );
  }
  
  // find  the color
  std::map< int , Typ::ColorCreateInfo >::const_iterator iter = ColorsMap.find( colorId );
  
  // not found so provide existing color
  if ( iter == ColorsMap.end() ) {
    int numberOfColors = ColorsMap.size();
    // error
    iter = ColorsMap.find( colorId % numberOfColors ); // use round-trip of existing colours
  }
  return iter->second ;
}






//===============================================================================================
//===============================================================================================
//===============================================================================================
// ****    COLOR CLASS 
//===============================================================================================
//===============================================================================================
//===============================================================================================



const char * Typ::ColorCreateInfo::CLASS_NAME = "ColorCreateInfo" ;


Typ::ColorCreateInfo::ColorCreateInfo( int r , int g , int b , int a )
{
  myRed   = (unsigned char)r ;
  myGreen = (unsigned char)g ;
  myBlue  = (unsigned char)b ;
  myAlpha = (unsigned char)a ; 
}


bool Typ::ColorCreateInfo::operator== ( const ColorCreateInfo & c ) const
{
  // ignore the alpha (opacity)
  return ( myRed   == c.myRed   &&
           myGreen == c.myGreen &&
           myBlue  == c.myBlue  );
}


const Typ::ColorCreateInfo & Typ::ColorCreateInfo::operator= ( const Typ::ColorCreateInfo & c )
{
  if ( this != &c ) {
    myRed   = c.myRed  ;
    myGreen = c.myGreen;
    myBlue  = c.myBlue ;
    myAlpha = c.myAlpha; 
  }
  return *this ;
}



const Typ::ColorCreateInfo & Typ::ColorCreateInfo::operator= ( const Typ::FloatColor & c )
{
  static const float multiplier = 255.0f ;
  myRed   = (unsigned char)int(multiplier * c.myRed  );
  myGreen = (unsigned char)int(multiplier * c.myGreen);
  myBlue  = (unsigned char)int(multiplier * c.myBlue );
  myAlpha = (unsigned char)int(multiplier * c.myAlpha);  
  return *this ; 
}



float Typ::ColorCreateInfo::getSaturation() const
{
  return 0;
}


float Typ::ColorCreateInfo::getBrightness() const
{
  return 0;
}



bool Typ::ColorCreateInfo::setSaturation( float )
{
  return false;
}


bool Typ::ColorCreateInfo::setBrightness( float )
{
  return false;
}


int Typ::ColorCreateInfo::checkFloat( float value )
{
  if ( value <=  0.0f ) { return 0 ; }
  else if ( value >= 255.0f ) { return 255; }
  else return int(value); 
}


//===============================//


const char * Typ::FloatColor::CLASS_NAME = "FloatColor";


Typ::FloatColor::FloatColor( float r , float g , float b , float a )
{
  myRed   = myCheck(r);
  myGreen = myCheck(g);
  myBlue  = myCheck(b);
  myAlpha = myCheck(a);
}



const Typ::FloatColor & Typ::FloatColor::operator= ( const Typ::FloatColor & c )
{
  if ( this != &c ) {
    myRed   = c.myRed  ;
    myGreen = c.myGreen;
    myBlue  = c.myBlue ;
    myAlpha = c.myAlpha; 
  }
  return *this ;
}


const Typ::FloatColor & Typ::FloatColor::operator= ( const Typ::ColorCreateInfo & c )
{
  static const float multiplier = 1.0f / 255.0f ;
  myRed   = myCheck(multiplier * c.myRed  );
  myGreen = myCheck(multiplier * c.myGreen);
  myBlue  = myCheck(multiplier * c.myBlue );
  myAlpha = myCheck(multiplier * c.myAlpha);  
  return *this ;
}


float Typ::FloatColor::myCheck( float value )
{
  static const char * METHOD_NAME = "myCheck()" ;
  if ( value < 0.0f ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "value %g changed to 0.0f" , value );
    value = 0.0f ; 
  }
  if ( value > 1.0f ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "value %g changed to 1.0f" , value );
    value = 1.0f ; 
  }
  return value ;
}




//===============================================================================================
//===============================================================================================
//===============================================================================================
// INTERNAL    INTERNAL    INTERNAL    INTERNAL    INTERNAL    INTERNAL  INTERNAL    INTERNAL    
//=============================================================================================== START START
// ****    COLORMAP CLASS    INTERNAL CLASS   . USED FOR THE STORAGE OF THE DEFAULT VALUES
//===============================================================================================
//===============================================================================================
//===============================================================================================


class TypColormapDefinitions
{

public:

  /**===========================================
   * ===========================================
   * Definitions
   * ===========================================
   * ======================================== */
  
  static const  Typ::ColormapInfo  & getColormapInfo( int colormapId , bool & isPresent );
  // 
  static const char               * getGuiNameFromColormapId( Typ::ColormapId );
  static Typ::ColormapId             getColormapIdFromGuiName( const MscString & name );
  static const Typ::ColorCreateInfo * getColorsFromColormapId( Typ::ColormapId , int & numberOfColors , int & preferedNumberOfColors , int & increment );
  static const Typ::ColorCreateInfo * interpolateColors( const Typ::ColorCreateInfo * TypildInColors , int numberOfTypildInColors , int numberOfColors );


private:

  /**===========================================
   * ===========================================
   * Color Functions
   * ===========================================
   * ======================================== */

  static const Typ::ColorCreateInfo *getSEGColormap( int & );
  static const Typ::ColorCreateInfo *getSmallTiger( int & );
  static const Typ::ColorCreateInfo *getBigTiger( int & );
  static const Typ::ColorCreateInfo *getSEGFuchsiaBands( int & );
  static const Typ::ColorCreateInfo *getBGRContrastBands( int & );
  static const Typ::ColorCreateInfo *getBGRContrastBands2( int & );
  static const Typ::ColorCreateInfo *getBlueRainbow( int & );
  static const Typ::ColorCreateInfo *getBandedTieDye( int & );
  static const Typ::ColorCreateInfo *getStandardWindows( int & );
  static const Typ::ColorCreateInfo *getPrimaryColors( int & );
  static const Typ::ColorCreateInfo *getRollingRamps( int & );
  static const Typ::ColorCreateInfo *getCrazyZebra( int & );
  static const Typ::ColorCreateInfo *getPerturbation( int & );
  static const Typ::ColorCreateInfo *getBandedRainbow( int & );
  static const Typ::ColorCreateInfo *getBlueGreyRed( int & );
  static const Typ::ColorCreateInfo *getBlueSqueeze( int & );
  static const Typ::ColorCreateInfo *getHighlightedExtremes( int & );
  static const Typ::ColorCreateInfo *getIlluminatedExtremes( int & );
  static const Typ::ColorCreateInfo *getLandmark( int & );
  static const Typ::ColorCreateInfo *getPurpleHaze( int & );
  static const Typ::ColorCreateInfo *getRainbowMix( int & );
  static const Typ::ColorCreateInfo *getIPGMap( int & );
  static const Typ::ColorCreateInfo *getBlueYellowRed( int & );
  static const Typ::ColorCreateInfo *getSemblanceSpectrum( int & );
  static const Typ::ColorCreateInfo *getSickTiger( int & );
  static const Typ::ColorCreateInfo *getStep145Ampd( int & );
  static const Typ::ColorCreateInfo *getWhiteAnchoredRainbow( int & );
  static const Typ::ColorCreateInfo *getAcquisitionFoldOfCover( int & );
  static const Typ::ColorCreateInfo *getFoldMap( int & );
  static const Typ::ColorCreateInfo *getHotBlack( int & );
  static const Typ::ColorCreateInfo *getBlackWhite( int & );
  static const Typ::ColorCreateInfo *getBlackWhiteBlack( int & );
  static const Typ::ColorCreateInfo *getWhiteBlack( int & );
  static const Typ::ColorCreateInfo *getWhiteBlackWhite( int & );
  static const Typ::ColorCreateInfo *getPureRedBlueGreen( int & );
  static const Typ::ColorCreateInfo *getMuddyRedBlueGreen( int & );
  static const Typ::ColorCreateInfo *getPureGreenRedBlue( int & );
  static const Typ::ColorCreateInfo *getMuddyGreenRedBlue( int & );
  static const Typ::ColorCreateInfo *getPureBlueGreenRed( int & );
  static const Typ::ColorCreateInfo *getMuddyBlueGreenRed( int & );
  static const Typ::ColorCreateInfo *getPureBlueGreenRedMagenta( int & );
  static const Typ::ColorCreateInfo *getPureEMSpectrum( int & );
  static const Typ::ColorCreateInfo *getBlueWhiteRed( int & );
  static const Typ::ColorCreateInfo *getBlueWhiteYellow( int & );
  static const Typ::ColorCreateInfo *getGreenWhiteRed( int & );
  static const Typ::ColorCreateInfo *getBlueWhiteGreen( int & );
  static const Typ::ColorCreateInfo *getCyanWhiteMagenta( int & );
  static const Typ::ColorCreateInfo *getYellowWhiteMagenta( int & );
  static const Typ::ColorCreateInfo *getCyanWhiteYellow( int & );
  static const Typ::ColorCreateInfo *getCyanMagentaYellow( int & );
  static const Typ::ColorCreateInfo *getMagentaYellowCyan( int & );
  static const Typ::ColorCreateInfo *getYellowCyanMagenta( int & );
  static const Typ::ColorCreateInfo *getDivan( int & );
  static const Typ::ColorCreateInfo *getSingaporeShades( int & );
  static const Typ::ColorCreateInfo *getChicRainbow( int & );
  static const Typ::ColorCreateInfo *getVoxelGeo( int & );
  static const Typ::ColorCreateInfo *getSmallVortex( int & );
  static const Typ::ColorCreateInfo *getBigVortex( int & );
  static const Typ::ColorCreateInfo *getGeoVel( int & n , int zeroColor ); // default was (-1)
  static const Typ::ColorCreateInfo *getGeoVel( int & n ) { return getGeoVel(n,(-1)); }
  static const Typ::ColorCreateInfo *getRedWblk( int & ); /* An xCGG colour map */
  static const Typ::ColorCreateInfo *getAngle45Dip60( int & ); /* xCGG coour map */
  static const Typ::ColorCreateInfo *getBandedRGV( int & );
  static const Typ::ColorCreateInfo *getBP_Aberdeen( int & );
  static const Typ::ColorCreateInfo *getAngle4( int & );
  static const Typ::ColorCreateInfo *getAngle3( int & );
  static const Typ::ColorCreateInfo *getBWGreyScale65( int & );
  static const Typ::ColorCreateInfo *getSeismicRedBlue( int & );
  static const Typ::ColorCreateInfo *getBpRms( int & );
  static const Typ::ColorCreateInfo *getBpNormalisedRms( int & );
  static const Typ::ColorCreateInfo *getBpRmsRatio( int & );


  static Typ::FloatColor       toFloatColor( int r16 , int g16 , int b16 , int scaling = 0xFFFF );
  static Typ::ColorCreateInfo myColors[ Typ::MAXIMUM_NUMBER_OF_COLORS ];
  static Typ::ColorCreateInfo myInterpolatedColors[ Typ::MAXIMUM_NUMBER_OF_COLORS ];
  static Typ::ColormapInfo   myColormapInfos[]   ;
  static int                 myNumberOfColorInfo ;

  static int                 myMultipleOf( int , int , bool adjustmentMargin=true );

};





//===============================================================================================
//===============================================================================================
//===============================================================================================
// ****    COLORMAP FUNCTIONS  (FIXED COLORS)
//===============================================================================================
//===============================================================================================
//===============================================================================================




const Typ::ColorCreateInfo * TypColormapDefinitions::getSEGColormap( int &numberOfColors )
{
  numberOfColors = 64;

  int i = 0;
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0417182,0.0588693,0.980377);
  myColors[i++] = Typ::FloatColor(0.0831769,0.117479,0.960906);
  myColors[i++] = Typ::FloatColor(0.124086,0.175525,0.941665);
  myColors[i++] = Typ::FloatColor(0.164202,0.232761,0.922805);
  myColors[i++] = Typ::FloatColor(0.203235,0.288884,0.904448);
  myColors[i++] = Typ::FloatColor(0.24094,0.343633,0.886717);
  myColors[i++] = Typ::FloatColor(0.277028,0.396735,0.869734);
  myColors[i++] = Typ::FloatColor(0.311223,0.447913,0.85362);
  myColors[i++] = Typ::FloatColor(0.343282,0.496895,0.838514);
  myColors[i++] = Typ::FloatColor(0.37293,0.543389,0.824537);
  myColors[i++] = Typ::FloatColor(0.399878,0.587137,0.811795);
  myColors[i++] = Typ::FloatColor(0.42388,0.627863,0.800427);
  myColors[i++] = Typ::FloatColor(0.444663,0.665278,0.79057);
  myColors[i++] = Typ::FloatColor(0.461952,0.699138,0.78233);
  myColors[i++] = Typ::FloatColor(0.475486,0.729122,0.775845);
  myColors[i++] = Typ::FloatColor(0.484977,0.755001,0.771237);
  myColors[i++] = Typ::FloatColor(0.490196,0.776471,0.768627);
  myColors[i++] = Typ::FloatColor(0.49102,0.793408,0.767987);
  myColors[i++] = Typ::FloatColor(0.488197,0.806302,0.768765);
  myColors[i++] = Typ::FloatColor(0.482628,0.815778,0.770245);
  myColors[i++] = Typ::FloatColor(0.475196,0.822461,0.771695);
  myColors[i++] = Typ::FloatColor(0.466819,0.826993,0.772396);
  myColors[i++] = Typ::FloatColor(0.458396,0.829999,0.771649);
  myColors[i++] = Typ::FloatColor(0.450843,0.832105,0.768734);
  myColors[i++] = Typ::FloatColor(0.445045,0.833936,0.762936);
  myColors[i++] = Typ::FloatColor(0.441917,0.836133,0.753536);
  myColors[i++] = Typ::FloatColor(0.442374,0.839307,0.739818);
  myColors[i++] = Typ::FloatColor(0.447303,0.844099,0.721065);
  myColors[i++] = Typ::FloatColor(0.457633,0.851148,0.696559);
  myColors[i++] = Typ::FloatColor(0.474235,0.861067,0.665599);
  myColors[i++] = Typ::FloatColor(0.498039,0.87451,0.627451);
  myColors[i++] = Typ::FloatColor(0.529534,0.891752,0.581781);
  myColors[i++] = Typ::FloatColor(0.567712,0.91191,0.529763);
  myColors[i++] = Typ::FloatColor(0.611093,0.933715,0.472923);
  myColors[i++] = Typ::FloatColor(0.658289,0.955932,0.412833);
  myColors[i++] = Typ::FloatColor(0.70782,0.97734,0.351034);
  myColors[i++] = Typ::FloatColor(0.758282,0.996674,0.289052);
  myColors[i++] = Typ::FloatColor(0.808225,1.0,0.228443);
  myColors[i++] = Typ::FloatColor(0.856229,1.0,0.170733);
  myColors[i++] = Typ::FloatColor(0.900832,1.0,0.117494);
  myColors[i++] = Typ::FloatColor(0.940627,1.0,0.0702678);
  myColors[i++] = Typ::FloatColor(0.974151,1.0,0.0305791);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.970672,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.932204,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.886229,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.834363,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.77818,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.719326,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.659388,0.0);
  myColors[i++] = Typ::FloatColor(0.996078,0.6,0.0);
  myColors[i++] = Typ::FloatColor(0.988937,0.542443,0.00746166);
  myColors[i++] = Typ::FloatColor(0.983398,0.48687,0.0130007);
  myColors[i++] = Typ::FloatColor(0.979339,0.433082,0.0167391);
  myColors[i++] = Typ::FloatColor(0.976577,0.380896,0.0189059);
  myColors[i++] = Typ::FloatColor(0.97499,0.330159,0.0196384);
  myColors[i++] = Typ::FloatColor(0.974426,0.280659,0.0191348);
  myColors[i++] = Typ::FloatColor(0.974731,0.232242,0.0175784);
  myColors[i++] = Typ::FloatColor(0.975769,0.184726,0.0151217);
  myColors[i++] = Typ::FloatColor(0.977386,0.137911,0.0119631);
  myColors[i++] = Typ::FloatColor(0.979446,0.0916457,0.00827039);
  myColors[i++] = Typ::FloatColor(0.981811,0.0457313,0.00421149);
  myColors[i++] = Typ::FloatColor(0.984314,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getSmallTiger( int &numberOfColors )
{
  numberOfColors = 21;

  int i = 0;
  myColors[i++] = Typ::FloatColor(0.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0714275,0.0714275,0.0714275);
  myColors[i++] = Typ::FloatColor(0.142855,0.142855,0.142855);
  myColors[i++] = Typ::FloatColor(0.214282,0.214282,0.214282);
  myColors[i++] = Typ::FloatColor(0.28571,0.28571,0.28571);
  myColors[i++] = Typ::FloatColor(0.357137,0.357137,0.357137);
  myColors[i++] = Typ::FloatColor(0.428565,0.428565,0.428565);
  myColors[i++] = Typ::FloatColor(0.499992,0.499992,0.499992);
  myColors[i++] = Typ::FloatColor(0.57142,0.57142,0.57142);
  myColors[i++] = Typ::FloatColor(0.642847,0.642847,0.642847);
  myColors[i++] = Typ::FloatColor(0.714275,0.714275,0.714275);
  myColors[i++] = Typ::FloatColor(0.785702,0.785702,0.785702);
  myColors[i++] = Typ::FloatColor(0.85713,0.85713,0.85713);
  myColors[i++] = Typ::FloatColor(0.928557,0.928557,0.928557);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.833326,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.666651,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.499992,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.166659,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBigTiger( int &numberOfColors )
{
  numberOfColors = 65;

  int i = 0;
  myColors[i++] = Typ::FloatColor(0.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0255283,0.0254368,0.0252232);
  myColors[i++] = Typ::FloatColor(0.0510719,0.0508736,0.0504463);
  myColors[i++] = Typ::FloatColor(0.0766155,0.0763104,0.0756695);
  myColors[i++] = Typ::FloatColor(0.102159,0.101747,0.100893);
  myColors[i++] = Typ::FloatColor(0.127703,0.127184,0.126116);
  myColors[i++] = Typ::FloatColor(0.153246,0.152621,0.151339);
  myColors[i++] = Typ::FloatColor(0.17879,0.178058,0.176562);
  myColors[i++] = Typ::FloatColor(0.204334,0.203494,0.201801);
  myColors[i++] = Typ::FloatColor(0.229877,0.228931,0.227024);
  myColors[i++] = Typ::FloatColor(0.255421,0.254368,0.252247);
  myColors[i++] = Typ::FloatColor(0.280964,0.279805,0.27747);
  myColors[i++] = Typ::FloatColor(0.306508,0.305241,0.302693);
  myColors[i++] = Typ::FloatColor(0.332052,0.330678,0.327916);
  myColors[i++] = Typ::FloatColor(0.357595,0.356115,0.35314);
  myColors[i++] = Typ::FloatColor(0.383139,0.381552,0.378378);
  myColors[i++] = Typ::FloatColor(0.408682,0.406989,0.403601);
  myColors[i++] = Typ::FloatColor(0.434226,0.432425,0.428824);
  myColors[i++] = Typ::FloatColor(0.45977,0.457862,0.454047);
  myColors[i++] = Typ::FloatColor(0.485313,0.483299,0.479271);
  myColors[i++] = Typ::FloatColor(0.510857,0.508736,0.504494);
  myColors[i++] = Typ::FloatColor(0.5364,0.534173,0.529717);
  myColors[i++] = Typ::FloatColor(0.561944,0.559609,0.55494);
  myColors[i++] = Typ::FloatColor(0.587488,0.585046,0.580179);
  myColors[i++] = Typ::FloatColor(0.613031,0.610483,0.605402);
  myColors[i++] = Typ::FloatColor(0.638575,0.63592,0.630625);
  myColors[i++] = Typ::FloatColor(0.664118,0.661357,0.655848);
  myColors[i++] = Typ::FloatColor(0.689662,0.686793,0.681071);
  myColors[i++] = Typ::FloatColor(0.715206,0.71223,0.706294);
  myColors[i++] = Typ::FloatColor(0.740749,0.737667,0.731517);
  myColors[i++] = Typ::FloatColor(0.766293,0.763104,0.756756);
  myColors[i++] = Typ::FloatColor(0.791836,0.78854,0.781979);
  myColors[i++] = Typ::FloatColor(0.81738,0.813977,0.807202);
  myColors[i++] = Typ::FloatColor(0.842924,0.839414,0.832425);
  myColors[i++] = Typ::FloatColor(0.868467,0.864851,0.857649);
  myColors[i++] = Typ::FloatColor(0.894011,0.890288,0.882872);
  myColors[i++] = Typ::FloatColor(0.919554,0.915724,0.908095);
  myColors[i++] = Typ::FloatColor(0.945098,0.941176,0.933333);
  myColors[i++] = Typ::FloatColor(1.0,0.959182,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.922286,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.88539,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.848508,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.811612,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.774716,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.737835,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.700938,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.664042,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.627146,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.590265,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.553368,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.516472,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.479591,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.442695,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.405798,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.368917,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.332021,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.295125,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.258228,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.221347,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.184451,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.147555,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.110674,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0737774,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0368811,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getSEGFuchsiaBands( int &numberOfColors )
{
  numberOfColors = 64;

  int i = 0;
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0417182,0.058854,0.980377);
  myColors[i++] = Typ::FloatColor(0.0831617,0.117464,0.960891);
  myColors[i++] = Typ::FloatColor(0.124071,0.175525,0.941665);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.203235,0.288884,0.904433);
  myColors[i++] = Typ::FloatColor(0.24094,0.343618,0.886717);
  myColors[i++] = Typ::FloatColor(0.277028,0.396735,0.869734);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.343267,0.496895,0.838514);
  myColors[i++] = Typ::FloatColor(0.372915,0.543389,0.824537);
  myColors[i++] = Typ::FloatColor(0.399878,0.587137,0.81178);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.444648,0.665263,0.79057);
  myColors[i++] = Typ::FloatColor(0.461952,0.699138,0.782315);
  myColors[i++] = Typ::FloatColor(0.475471,0.729122,0.775845);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.490181,0.776471,0.768612);
  myColors[i++] = Typ::FloatColor(0.491005,0.793393,0.767987);
  myColors[i++] = Typ::FloatColor(0.488182,0.806302,0.768765);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.475181,0.822446,0.771695);
  myColors[i++] = Typ::FloatColor(0.466804,0.826978,0.772381);
  myColors[i++] = Typ::FloatColor(0.458381,0.829984,0.771649);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.445045,0.833921,0.762936);
  myColors[i++] = Typ::FloatColor(0.441917,0.836118,0.753521);
  myColors[i++] = Typ::FloatColor(0.442359,0.839292,0.739803);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.457618,0.851133,0.696544);
  myColors[i++] = Typ::FloatColor(0.47422,0.861067,0.665599);
  myColors[i++] = Typ::FloatColor(0.498024,0.87451,0.627451);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.567712,0.91191,0.529763);
  myColors[i++] = Typ::FloatColor(0.611078,0.933715,0.472923);
  myColors[i++] = Typ::FloatColor(0.658274,0.955932,0.412833);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.758282,0.996674,0.289052);
  myColors[i++] = Typ::FloatColor(0.808225,1.0,0.228443);
  myColors[i++] = Typ::FloatColor(0.856214,1.0,0.170718);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.940612,1.0,0.0702678);
  myColors[i++] = Typ::FloatColor(0.974136,1.0,0.0305791);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.932189,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.886229,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.834348,0.0);
  myColors[i++] = Typ::FloatColor(0.780392,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.719326,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.659373,0.0);
  myColors[i++] = Typ::FloatColor(0.996063,0.6,0.0);
  myColors[i++] = Typ::FloatColor(0.776471,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.983383,0.48687,0.0130007);
  myColors[i++] = Typ::FloatColor(0.979324,0.433082,0.0167239);
  myColors[i++] = Typ::FloatColor(0.976562,0.380896,0.0188907);
  myColors[i++] = Typ::FloatColor(0.776471,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.974426,0.280644,0.0191196);
  myColors[i++] = Typ::FloatColor(0.974716,0.232227,0.0175784);
  myColors[i++] = Typ::FloatColor(0.975769,0.184726,0.0151217);
  myColors[i++] = Typ::FloatColor(0.776471,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.979431,0.0916457,0.00827039);
  myColors[i++] = Typ::FloatColor(0.981796,0.0457313,0.00421149);
  myColors[i++] = Typ::FloatColor(0.984314,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBandedTieDye( int &numberOfColors )
{
  numberOfColors = 101;

  int i = 0;
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0208286,0.979156);
  myColors[i++] = Typ::FloatColor(0.0,0.0416571,0.958328);
  myColors[i++] = Typ::FloatColor(0.0,0.0624857,0.937499);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.104158,0.895827);
  myColors[i++] = Typ::FloatColor(0.0,0.124987,0.874998);
  myColors[i++] = Typ::FloatColor(0.0,0.14583,0.854154);
  myColors[i++] = Typ::FloatColor(0.0,0.166659,0.833326);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.208331,0.791653);
  myColors[i++] = Typ::FloatColor(0.0,0.22916,0.770825);
  myColors[i++] = Typ::FloatColor(0.0,0.249989,0.749996);
  myColors[i++] = Typ::FloatColor(0.0,0.270832,0.729152);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.31249,0.687495);
  myColors[i++] = Typ::FloatColor(0.0,0.333333,0.666651);
  myColors[i++] = Typ::FloatColor(0.0,0.354162,0.645823);
  myColors[i++] = Typ::FloatColor(0.0,0.37499,0.624994);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.416663,0.583322);
  myColors[i++] = Typ::FloatColor(0.0,0.437491,0.562493);
  myColors[i++] = Typ::FloatColor(0.0,0.45832,0.541665);
  myColors[i++] = Typ::FloatColor(0.0,0.479164,0.520821);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.520821,0.479164);
  myColors[i++] = Typ::FloatColor(0.0,0.541665,0.45832);
  myColors[i++] = Typ::FloatColor(0.0,0.562493,0.437491);
  myColors[i++] = Typ::FloatColor(0.0,0.583322,0.416663);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.624994,0.37499);
  myColors[i++] = Typ::FloatColor(0.0,0.645823,0.354162);
  myColors[i++] = Typ::FloatColor(0.0,0.666667,0.333318);
  myColors[i++] = Typ::FloatColor(0.0,0.687495,0.31249);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.729152,0.270832);
  myColors[i++] = Typ::FloatColor(0.0,0.749996,0.249989);
  myColors[i++] = Typ::FloatColor(0.0,0.770825,0.22916);
  myColors[i++] = Typ::FloatColor(0.0,0.791653,0.208331);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.833326,0.166659);
  myColors[i++] = Typ::FloatColor(0.0,0.854154,0.14583);
  myColors[i++] = Typ::FloatColor(0.0,0.874998,0.124987);
  myColors[i++] = Typ::FloatColor(0.0,0.895827,0.104158);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.937499,0.0624857);
  myColors[i++] = Typ::FloatColor(0.0,0.958328,0.0416571);
  myColors[i++] = Typ::FloatColor(0.0,0.979156,0.0208286);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.979156,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.958328,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.937499,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.895827,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.874998,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.854154,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.833326,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.791653,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.770825,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.749996,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.729152,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.687495,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.666651,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.645823,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.624994,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.583322,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.562493,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.541665,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.520821,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.479164,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.45832,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.437491,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.416663,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.37499,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.354162,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.333318,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.31249,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.270832,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.249989,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.22916,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.208331,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.166659,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.14583,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.124987,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.104158,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0624857,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0416571,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0208286,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBGRContrastBands( int &numberOfColors )
{
  numberOfColors = 101;

  int i = 0;
  myColors[i++] = Typ::FloatColor(0.32549,0.960784,0.862745);
  myColors[i++] = Typ::FloatColor(0.0,0.0399939,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0799878,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.119997,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.159991,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.239994,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.279988,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.319997,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.359991,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.439994,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.479988,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.519997,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.559991,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.6,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.679988,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.719997,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.759991,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.8,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.879988,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.919997,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.959991,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.959991);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.879988);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.839994);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.8);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.759991);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.679988);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.639994);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.6);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.559991);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.519997);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.439994);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.4);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.359991);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.319997);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.239994);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.2);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.159991);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.119997);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0799878);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0399939,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0799878,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.119997,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.2,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.239994,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.279988,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.319997,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.359991,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.439994,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.479988,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.519997,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.559991,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.639994,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.679988,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.719997,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.759991,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.8,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.879988,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.919997,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.959991,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.919997,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.879988,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.839994,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.8,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.759991,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.679988,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.639994,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.6,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.559991,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.479988,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.439994,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.4,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.359991,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.319997,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.239994,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.2,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.159991,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.119997,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0399939,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBGRContrastBands2( int &numberOfColors )
{
  numberOfColors = 101;

  int i = 0;
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0399939,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0799878,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.119997,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.159991,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.239994,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.279988,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.319997,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.359991,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.439994,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.479988,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.519997,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.559991,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.6,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.679988,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.719997,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.759991,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.8,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.879988,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.919997,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.959991,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.959991);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.879988);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.839994);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.8);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.759991);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.679988);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.639994);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.6);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.559991);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.519997);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.439994);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.4);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.359991);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.319997);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.239994);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.2);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.159991);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.119997);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0799878);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0399939,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0799878,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.119997,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.2,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.239994,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.279988,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.319997,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.359991,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.439994,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.479988,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.519997,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.559991,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.639994,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.679988,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.719997,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.759991,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.8,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.879988,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.919997,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.959991,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.919997,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.879988,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.839994,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.8,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.759991,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.679988,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.639994,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.6,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.559991,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.479988,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.439994,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.4,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.359991,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.319997,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.239994,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.2,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.159991,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.119997,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0399939,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBlueRainbow( int &numberOfColors )
{
  numberOfColors = 129;

  int i = 0;
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0833295,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.166659,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.249989,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.333333,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.416663,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.499992,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.583322,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.666667,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.749996,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.833326,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.916655,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.916655);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.833326);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.749996);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.666651);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.583322);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.499992);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.416663);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.333318);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.249989);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.166659);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0833295);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0833295,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.166659,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.249989,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.333333,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.416663,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.499992,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.583322,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.666667,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.749996,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.833326,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.916655,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.956863,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.913725,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.870588,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.827451,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.784314,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.741176,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.698039,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.654902,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.611765,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.568627,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.525475,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.482353,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.428748,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.375158,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.321569,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.267964,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.214374,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.160784,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.107179,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0535897,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getStandardWindows( int &numberOfColors )
{
  numberOfColors = 16;

  int i = 0;
  myColors[i++] = Typ::getColor( Typ::COL_BLACK        );
  myColors[i++] = Typ::getColor( Typ::COL_DARK_RED     );
  myColors[i++] = Typ::getColor( Typ::COL_DARK_GREEN   );
  myColors[i++] = Typ::getColor( Typ::COL_DARK_YELLOW  );
  myColors[i++] = Typ::getColor( Typ::COL_DARK_BLUE    );
  myColors[i++] = Typ::getColor( Typ::COL_DARK_MAGENTA );
  myColors[i++] = Typ::getColor( Typ::COL_DARK_CYAN    );
  myColors[i++] = Typ::getColor( Typ::COL_LIGHT_GRAY   );
  myColors[i++] = Typ::getColor( Typ::COL_GRAY    );
  myColors[i++] = Typ::getColor( Typ::COL_RED     );
  myColors[i++] = Typ::getColor( Typ::COL_GREEN   );
  myColors[i++] = Typ::getColor( Typ::COL_YELLOW  );
  myColors[i++] = Typ::getColor( Typ::COL_BLUE    );
  myColors[i++] = Typ::getColor( Typ::COL_MAGENTA );
  myColors[i++] = Typ::getColor( Typ::COL_CYAN    );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE   );

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getPrimaryColors( int &numberOfColors )
{
  numberOfColors = 8;

  int i = 0;
  myColors[i++] = Typ::getColor( Typ::COL_BLACK   );
  myColors[i++] = Typ::getColor( Typ::COL_RED     );
  myColors[i++] = Typ::getColor( Typ::COL_GREEN   );
  myColors[i++] = Typ::getColor( Typ::COL_BLUE    );
  myColors[i++] = Typ::getColor( Typ::COL_YELLOW  );
  myColors[i++] = Typ::getColor( Typ::COL_CYAN    );
  myColors[i++] = Typ::getColor( Typ::COL_MAGENTA );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE   );

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getRollingRamps( int &numberOfColors )
{
  numberOfColors = 33;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.205875,0.205875,0.955871);
  myColors[i++] = Typ::FloatColor(0.411765,0.411765,0.911757);
  myColors[i++] = Typ::FloatColor(0.617639,0.617639,0.867643);
  myColors[i++] = Typ::FloatColor(0.823529,0.823529,0.823529);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.205875,0.955871,0.955871);
  myColors[i++] = Typ::FloatColor(0.411765,0.911757,0.911757);
  myColors[i++] = Typ::FloatColor(0.617639,0.867643,0.867643);
  myColors[i++] = Typ::FloatColor(0.823529,0.823529,0.823529);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.205875,0.955871,0.205875);
  myColors[i++] = Typ::FloatColor(0.411765,0.911757,0.411765);
  myColors[i++] = Typ::FloatColor(0.617639,0.867643,0.617639);
  myColors[i++] = Typ::FloatColor(0.823529,0.823529,0.823529);
  myColors[i++] = Typ::FloatColor(1.0,0.737255,0.0);
  myColors[i++] = Typ::FloatColor(0.955871,0.758816,0.205875);
  myColors[i++] = Typ::FloatColor(0.911757,0.780392,0.411765);
  myColors[i++] = Typ::FloatColor(0.867643,0.801953,0.617639);
  myColors[i++] = Typ::FloatColor(0.823529,0.823529,0.823529);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.955871,0.205875,0.205875);
  myColors[i++] = Typ::FloatColor(0.911757,0.411765,0.411765);
  myColors[i++] = Typ::FloatColor(0.867643,0.617639,0.617639);
  myColors[i++] = Typ::FloatColor(0.823529,0.823529,0.823529);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.955871,0.955871,0.205875);
  myColors[i++] = Typ::FloatColor(0.911757,0.911757,0.411765);
  myColors[i++] = Typ::FloatColor(0.867643,0.867643,0.617639);
  myColors[i++] = Typ::FloatColor(0.823529,0.823529,0.823529);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.499992,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.772549,1.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getCrazyZebra( int &numberOfColors )
{
  numberOfColors = 25;

  int i=0;

  myColors[i++] = Typ::getColor( Typ::COL_CYAN     );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_GREEN    );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_RED      );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_DARK_RED );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_DARK_RED );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_MAGENTA  );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_MAGENTA  );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_DARK_GREEN );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE      );
  myColors[i++] = Typ::getColor( Typ::COL_DARK_GREEN );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_YELLOW   );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_YELLOW   );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_BLUE     );
  myColors[i++] = Typ::getColor( Typ::COL_WHITE    );
  myColors[i++] = Typ::getColor( Typ::COL_BLUE     );

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getPerturbation( int &numberOfColors )
{
  numberOfColors = 64;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0624857,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.124987,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.187488,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.249989,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.31249,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.37499,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.437491,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.499992,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.562493,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.624994,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.687495,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.749996,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.812497,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.874998,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.937499,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.928557);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.85713);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.785702);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.714275);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.642847);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.57142);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.499992);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.428565);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.357137);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.28571);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.214282);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.142855);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0714275);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.933333,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.866667,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.8,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.733333,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.666651,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.6,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.533318,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.466651,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.399985,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.333318,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.266651,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.199985,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.133318,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0666514,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.998947,0.0,0.0666667);
  myColors[i++] = Typ::FloatColor(0.997894,0.0,0.133333);
  myColors[i++] = Typ::FloatColor(0.996857,0.0,0.2);
  myColors[i++] = Typ::FloatColor(0.995804,0.0,0.266667);
  myColors[i++] = Typ::FloatColor(0.994766,0.0,0.333333);
  myColors[i++] = Typ::FloatColor(0.993713,0.0,0.4);
  myColors[i++] = Typ::FloatColor(0.992676,0.0,0.466667);
  myColors[i++] = Typ::FloatColor(0.991623,0.0,0.533333);
  myColors[i++] = Typ::FloatColor(0.990585,0.0,0.6);
  myColors[i++] = Typ::FloatColor(0.989532,0.0,0.666667);
  myColors[i++] = Typ::FloatColor(0.988495,0.0,0.733333);
  myColors[i++] = Typ::FloatColor(0.987442,0.0,0.8);
  myColors[i++] = Typ::FloatColor(0.986404,0.0,0.866667);
  myColors[i++] = Typ::FloatColor(0.985351,0.0,0.933333);
  myColors[i++] = Typ::FloatColor(0.984314,0.0,1.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBandedRainbow( int &numberOfColors )
{
  numberOfColors = 21;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.0250095,0.0250095,0.530892);
  myColors[i++] = Typ::FloatColor(0.0495308,0.275944,0.9552);
  myColors[i++] = Typ::FloatColor(0.0309758,0.340703,0.657618);
  myColors[i++] = Typ::FloatColor(0.0495308,0.728786,0.9552);
  myColors[i++] = Typ::FloatColor(0.0274662,0.57586,0.583062);
  myColors[i++] = Typ::FloatColor(0.433448,0.973297,0.838331);
  myColors[i++] = Typ::FloatColor(0.0253605,0.538338,0.278233);
  myColors[i++] = Typ::FloatColor(0.0495308,0.9552,0.275944);
  myColors[i++] = Typ::FloatColor(0.0366064,0.776883,0.0366064);
  myColors[i++] = Typ::FloatColor(0.275944,0.9552,0.0495308);
  myColors[i++] = Typ::FloatColor(0.317281,0.612894,0.0288701);
  myColors[i++] = Typ::FloatColor(0.728786,0.9552,0.0495308);
  myColors[i++] = Typ::FloatColor(0.9552,0.9552,0.0495308);
  myColors[i++] = Typ::FloatColor(0.9552,0.728786,0.0495308);
  myColors[i++] = Typ::FloatColor(0.9552,0.502358,0.0495308);
  myColors[i++] = Typ::FloatColor(0.9552,0.275944,0.0495308);
  myColors[i++] = Typ::FloatColor(0.583062,0.0274662,0.0274662);
  myColors[i++] = Typ::FloatColor(0.9552,0.0495308,0.275944);
  myColors[i++] = Typ::FloatColor(0.73962,0.0348363,0.383627);
  myColors[i++] = Typ::FloatColor(0.9552,0.0495308,0.728786);
  myColors[i++] = Typ::FloatColor(0.978531,0.619806,0.982071);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBlueGreyRed( int &numberOfColors )
{
  numberOfColors = 21;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.11078,0.11078,0.985779);
  myColors[i++] = Typ::FloatColor(0.221561,0.221561,0.971557);
  myColors[i++] = Typ::FloatColor(0.332341,0.332341,0.957351);
  myColors[i++] = Typ::FloatColor(0.443137,0.443137,0.94313);
  myColors[i++] = Typ::FloatColor(0.553918,0.553918,0.928908);
  myColors[i++] = Typ::FloatColor(0.664698,0.664698,0.914702);
  myColors[i++] = Typ::FloatColor(0.775479,0.775479,0.900481);
  myColors[i++] = Typ::FloatColor(0.886275,0.886275,0.886275);
  myColors[i++] = Typ::FloatColor(0.94313,0.94313,0.94313);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.94313,0.94313,0.94313);
  myColors[i++] = Typ::FloatColor(0.886275,0.886275,0.886275);
  myColors[i++] = Typ::FloatColor(0.900481,0.775479,0.775479);
  myColors[i++] = Typ::FloatColor(0.914702,0.664698,0.664698);
  myColors[i++] = Typ::FloatColor(0.928908,0.553918,0.553918);
  myColors[i++] = Typ::FloatColor(0.94313,0.443137,0.443137);
  myColors[i++] = Typ::FloatColor(0.957351,0.332341,0.332341);
  myColors[i++] = Typ::FloatColor(0.971557,0.221561,0.221561);
  myColors[i++] = Typ::FloatColor(0.985779,0.11078,0.11078);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBlueSqueeze( int &numberOfColors )
{
  numberOfColors = 129;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0833295,0.916655);
  myColors[i++] = Typ::FloatColor(0.0,0.166659,0.833326);
  myColors[i++] = Typ::FloatColor(0.0,0.249989,0.749996);
  myColors[i++] = Typ::FloatColor(0.0,0.333333,0.666651);
  myColors[i++] = Typ::FloatColor(0.0,0.416663,0.583322);
  myColors[i++] = Typ::FloatColor(0.0,0.499992,0.499992);
  myColors[i++] = Typ::FloatColor(0.0,0.583322,0.416663);
  myColors[i++] = Typ::FloatColor(0.0,0.666667,0.333318);
  myColors[i++] = Typ::FloatColor(0.0,0.749996,0.249989);
  myColors[i++] = Typ::FloatColor(0.0,0.833326,0.166659);
  myColors[i++] = Typ::FloatColor(0.0,0.916655,0.0833295);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0833295,1.0,0.0248264);
  myColors[i++] = Typ::FloatColor(0.166659,1.0,0.0496681);
  myColors[i++] = Typ::FloatColor(0.249989,1.0,0.0745098);
  myColors[i++] = Typ::FloatColor(0.333333,1.0,0.0993362);
  myColors[i++] = Typ::FloatColor(0.416663,1.0,0.124178);
  myColors[i++] = Typ::FloatColor(0.499992,1.0,0.14902);
  myColors[i++] = Typ::FloatColor(0.583322,1.0,0.173846);
  myColors[i++] = Typ::FloatColor(0.666667,1.0,0.198688);
  myColors[i++] = Typ::FloatColor(0.749996,1.0,0.223529);
  myColors[i++] = Typ::FloatColor(0.833326,1.0,0.248356);
  myColors[i++] = Typ::FloatColor(0.916655,1.0,0.273198);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.967971,0.273198);
  myColors[i++] = Typ::FloatColor(1.0,0.935943,0.248356);
  myColors[i++] = Typ::FloatColor(1.0,0.903914,0.223529);
  myColors[i++] = Typ::FloatColor(1.0,0.871885,0.198688);
  myColors[i++] = Typ::FloatColor(1.0,0.839857,0.173846);
  myColors[i++] = Typ::FloatColor(1.0,0.807843,0.14902);
  myColors[i++] = Typ::FloatColor(1.0,0.775814,0.124178);
  myColors[i++] = Typ::FloatColor(1.0,0.743786,0.0993362);
  myColors[i++] = Typ::FloatColor(1.0,0.711757,0.0745098);
  myColors[i++] = Typ::FloatColor(1.0,0.679728,0.0496681);
  myColors[i++] = Typ::FloatColor(1.0,0.6477,0.0248264);
  myColors[i++] = Typ::FloatColor(1.0,0.615686,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.56437,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.513069,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.461753,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.410452,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.359136,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.307836,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.256535,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.205219,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.153918,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.102602,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0513008,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0833295);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.166659);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.249989);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.333333);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.416663);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.499992);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.583322);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.666667);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.749996);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.833326);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.916655);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.95816,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.916335,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.87451,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.83267,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.790845,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.74902,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.707179,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.665354,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.623529,0.0,1.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getHighlightedExtremes( int &numberOfColors )
{
  numberOfColors = 25;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.0364233,0.906645,0.0364233);
  myColors[i++] = Typ::FloatColor(0.107225,0.107225,0.88719);
  myColors[i++] = Typ::FloatColor(0.171099,0.171099,0.899809);
  myColors[i++] = Typ::FloatColor(0.239338,0.239338,0.908064);
  myColors[i++] = Typ::FloatColor(0.307591,0.307591,0.916304);
  myColors[i++] = Typ::FloatColor(0.37583,0.37583,0.924559);
  myColors[i++] = Typ::FloatColor(0.444083,0.444083,0.932799);
  myColors[i++] = Typ::FloatColor(0.512322,0.512322,0.941054);
  myColors[i++] = Typ::FloatColor(0.580575,0.580575,0.949294);
  myColors[i++] = Typ::FloatColor(0.648814,0.648814,0.957549);
  myColors[i++] = Typ::FloatColor(0.917922,0.917922,0.917922);
  myColors[i++] = Typ::FloatColor(0.917922,0.917922,0.917922);
  myColors[i++] = Typ::FloatColor(0.917922,0.917922,0.917922);
  myColors[i++] = Typ::FloatColor(0.917922,0.917922,0.917922);
  myColors[i++] = Typ::FloatColor(0.917922,0.917922,0.917922);
  myColors[i++] = Typ::FloatColor(0.957549,0.648814,0.648814);
  myColors[i++] = Typ::FloatColor(0.949294,0.580575,0.580575);
  myColors[i++] = Typ::FloatColor(0.941054,0.512322,0.512322);
  myColors[i++] = Typ::FloatColor(0.932799,0.444083,0.444083);
  myColors[i++] = Typ::FloatColor(0.924559,0.37583,0.37583);
  myColors[i++] = Typ::FloatColor(0.916304,0.307591,0.307591);
  myColors[i++] = Typ::FloatColor(0.908064,0.239338,0.239338);
  myColors[i++] = Typ::FloatColor(0.899809,0.171099,0.171099);
  myColors[i++] = Typ::FloatColor(0.88719,0.107225,0.107225);
  myColors[i++] = Typ::FloatColor(0.9505,0.9505,0.0198367);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getIlluminatedExtremes( int &numberOfColors )
{
  numberOfColors = 65;

  int i=0;

  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.909087,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.818173,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.72726,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.636362,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.545449,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.454536,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.363622,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.272725,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.181811,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.090898,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0833295,0.0833295);
  myColors[i++] = Typ::FloatColor(1.0,0.166659,0.166659);
  myColors[i++] = Typ::FloatColor(1.0,0.249989,0.249989);
  myColors[i++] = Typ::FloatColor(1.0,0.333333,0.333333);
  myColors[i++] = Typ::FloatColor(1.0,0.416663,0.416663);
  myColors[i++] = Typ::FloatColor(1.0,0.499992,0.499992);
  myColors[i++] = Typ::FloatColor(1.0,0.583322,0.583322);
  myColors[i++] = Typ::FloatColor(1.0,0.666667,0.666667);
  myColors[i++] = Typ::FloatColor(1.0,0.749996,0.749996);
  myColors[i++] = Typ::FloatColor(1.0,0.833326,0.833326);
  myColors[i++] = Typ::FloatColor(1.0,0.916655,0.916655);
  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.944442,0.944442,0.944442);
  myColors[i++] = Typ::FloatColor(0.888884,0.888884,0.888884);
  myColors[i++] = Typ::FloatColor(0.833326,0.833326,0.833326);
  myColors[i++] = Typ::FloatColor(0.777768,0.777768,0.777768);
  myColors[i++] = Typ::FloatColor(0.72221,0.72221,0.72221);
  myColors[i++] = Typ::FloatColor(0.666651,0.666651,0.666651);
  myColors[i++] = Typ::FloatColor(0.611109,0.611109,0.611109);
  myColors[i++] = Typ::FloatColor(0.55555,0.55555,0.55555);
  myColors[i++] = Typ::FloatColor(0.499992,0.499992,0.499992);
  myColors[i++] = Typ::FloatColor(0.444434,0.444434,0.444434);
  myColors[i++] = Typ::FloatColor(0.388876,0.388876,0.388876);
  myColors[i++] = Typ::FloatColor(0.333318,0.333318,0.333318);
  myColors[i++] = Typ::FloatColor(0.277775,0.277775,0.277775);
  myColors[i++] = Typ::FloatColor(0.222217,0.222217,0.222217);
  myColors[i++] = Typ::FloatColor(0.166659,0.166659,0.166659);
  myColors[i++] = Typ::FloatColor(0.111101,0.111101,0.111101);
  myColors[i++] = Typ::FloatColor(0.0555428,0.0555428,0.0555428);
  myColors[i++] = Typ::FloatColor(0.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.041825,0.041825,0.0833295);
  myColors[i++] = Typ::FloatColor(0.08365,0.08365,0.166659);
  myColors[i++] = Typ::FloatColor(0.12549,0.12549,0.249989);
  myColors[i++] = Typ::FloatColor(0.167315,0.167315,0.333333);
  myColors[i++] = Typ::FloatColor(0.20914,0.20914,0.416663);
  myColors[i++] = Typ::FloatColor(0.25098,0.25098,0.499992);
  myColors[i++] = Typ::FloatColor(0.292805,0.292805,0.583322);
  myColors[i++] = Typ::FloatColor(0.33463,0.33463,0.666667);
  myColors[i++] = Typ::FloatColor(0.376471,0.376471,0.749996);
  myColors[i++] = Typ::FloatColor(0.418296,0.418296,0.833326);
  myColors[i++] = Typ::FloatColor(0.460121,0.460121,0.916655);
  myColors[i++] = Typ::FloatColor(0.501961,0.501961,1.0);
  myColors[i++] = Typ::FloatColor(0.547234,0.456321,1.0);
  myColors[i++] = Typ::FloatColor(0.592508,0.410681,1.0);
  myColors[i++] = Typ::FloatColor(0.637781,0.365057,1.0);
  myColors[i++] = Typ::FloatColor(0.683055,0.319417,1.0);
  myColors[i++] = Typ::FloatColor(0.728328,0.273793,1.0);
  myColors[i++] = Typ::FloatColor(0.773617,0.228153,1.0);
  myColors[i++] = Typ::FloatColor(0.818891,0.182528,1.0);
  myColors[i++] = Typ::FloatColor(0.864164,0.136889,1.0);
  myColors[i++] = Typ::FloatColor(0.909438,0.0912642,1.0);
  myColors[i++] = Typ::FloatColor(0.954711,0.0456245,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getPurpleHaze( int &numberOfColors )
{
  numberOfColors = 65;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.380392,0.380392,0.380392);
  myColors[i++] = Typ::FloatColor(0.466667,0.466667,0.466667);
  myColors[i++] = Typ::FloatColor(0.552941,0.552941,0.552941);
  myColors[i++] = Typ::FloatColor(0.639216,0.639216,0.639216);
  myColors[i++] = Typ::FloatColor(0.72549,0.72549,0.72549);
  myColors[i++] = Typ::FloatColor(0.815686,0.537255,0.729412);
  myColors[i++] = Typ::FloatColor(0.905882,0.352941,0.733333);
  myColors[i++] = Typ::FloatColor(1.0,0.168627,0.741176);
  myColors[i++] = Typ::FloatColor(0.92549,0.14902,0.721569);
  myColors[i++] = Typ::FloatColor(0.854902,0.133333,0.705882);
  myColors[i++] = Typ::FloatColor(0.780392,0.117647,0.690196);
  myColors[i++] = Typ::FloatColor(0.709804,0.0980392,0.670588);
  myColors[i++] = Typ::FloatColor(0.635294,0.0823529,0.654902);
  myColors[i++] = Typ::FloatColor(0.564706,0.0666667,0.639216);
  myColors[i++] = Typ::FloatColor(0.490196,0.0470588,0.623529);
  myColors[i++] = Typ::FloatColor(0.419608,0.0313726,0.607843);
  myColors[i++] = Typ::FloatColor(0.345098,0.0156863,0.592157);
  myColors[i++] = Typ::FloatColor(0.27451,0.0,0.576471);
  myColors[i++] = Typ::FloatColor(0.219608,0.0,0.658824);
  myColors[i++] = Typ::FloatColor(0.164706,0.0,0.745098);
  myColors[i++] = Typ::FloatColor(0.109804,0.0,0.827451);
  myColors[i++] = Typ::FloatColor(0.054902,0.0,0.913725);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0941176,0.121569,1.0);
  myColors[i++] = Typ::FloatColor(0.192157,0.247059,1.0);
  myColors[i++] = Typ::FloatColor(0.286275,0.372549,1.0);
  myColors[i++] = Typ::FloatColor(0.384314,0.498039,1.0);
  myColors[i++] = Typ::FloatColor(0.482353,0.623529,1.0);
  myColors[i++] = Typ::FloatColor(0.576471,0.74902,1.0);
  myColors[i++] = Typ::FloatColor(0.67451,0.87451,1.0);
  myColors[i++] = Typ::FloatColor(0.772549,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.513726,0.0);
  myColors[i++] = Typ::FloatColor(0.0235294,0.576471,0.0156863);
  myColors[i++] = Typ::FloatColor(0.0470588,0.639216,0.0352941);
  myColors[i++] = Typ::FloatColor(0.0705882,0.701961,0.054902);
  myColors[i++] = Typ::FloatColor(0.0941176,0.764706,0.0745098);
  myColors[i++] = Typ::FloatColor(0.117647,0.827451,0.0941176);
  myColors[i++] = Typ::FloatColor(0.141176,0.890196,0.113725);
  myColors[i++] = Typ::FloatColor(0.168627,0.952941,0.133333);
  myColors[i++] = Typ::FloatColor(0.2,1.0,0.156863);
  myColors[i++] = Typ::FloatColor(0.4,1.0,0.117647);
  myColors[i++] = Typ::FloatColor(0.54902,0.984314,0.0862745);
  myColors[i++] = Typ::FloatColor(0.698039,0.972549,0.0588235);
  myColors[i++] = Typ::FloatColor(0.847059,0.960784,0.027451);
  myColors[i++] = Typ::FloatColor(1.0,0.94902,0.0);
  myColors[i++] = Typ::FloatColor(0.988235,0.878431,0.0);
  myColors[i++] = Typ::FloatColor(0.976471,0.811765,0.0);
  myColors[i++] = Typ::FloatColor(0.964706,0.745098,0.0);
  myColors[i++] = Typ::FloatColor(0.952941,0.67451,0.0);
  myColors[i++] = Typ::FloatColor(0.941176,0.607843,0.0);
  myColors[i++] = Typ::FloatColor(0.929412,0.541176,0.0);
  myColors[i++] = Typ::FloatColor(0.921569,0.47451,0.0);
  myColors[i++] = Typ::FloatColor(0.847059,0.313726,0.0);
  myColors[i++] = Typ::FloatColor(0.772549,0.156863,0.0);
  myColors[i++] = Typ::FloatColor(0.698039,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.756863,0.027451,0.027451);
  myColors[i++] = Typ::FloatColor(0.815686,0.054902,0.054902);
  myColors[i++] = Typ::FloatColor(0.878431,0.0823529,0.0823529);
  myColors[i++] = Typ::FloatColor(0.937255,0.109804,0.109804);
  myColors[i++] = Typ::FloatColor(1.0,0.137255,0.137255);
  myColors[i++] = Typ::FloatColor(1.0,0.501961,0.592157);
  myColors[i++] = Typ::FloatColor(1.0,0.592157,0.611765);
  myColors[i++] = Typ::FloatColor(1.0,0.682353,0.635294);
  myColors[i++] = Typ::FloatColor(1.0,0.772549,0.658824);
  myColors[i++] = Typ::FloatColor(1.0,0.862745,0.682353);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getRainbowMix( int &numberOfColors )
{
  numberOfColors = 21;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.74902,0.215686,0.215686);
  myColors[i++] = Typ::FloatColor(0.847059,0.156863,0.156863);
  myColors[i++] = Typ::FloatColor(1.0,0.499992,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.749996,0.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.913725,1.0,0.647059);
  myColors[i++] = Typ::FloatColor(0.486275,1.0,0.231373);
  myColors[i++] = Typ::FloatColor(0.717647,0.92549,0.0784314);
  myColors[i++] = Typ::FloatColor(0.0,0.901961,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.643137,0.164706);
  myColors[i++] = Typ::FloatColor(0.00392157,1.0,0.588235);
  myColors[i++] = Typ::FloatColor(0.00392157,0.988235,1.0);
  myColors[i++] = Typ::FloatColor(0.00392157,0.776471,1.0);
  myColors[i++] = Typ::FloatColor(0.129412,0.690196,0.87451);
  myColors[i++] = Typ::FloatColor(0.0,0.499992,1.0);
  myColors[i++] = Typ::FloatColor(0.760784,0.8,0.917647);
  myColors[i++] = Typ::FloatColor(0.298039,0.509804,0.705882);
  myColors[i++] = Typ::FloatColor(0.270588,0.168627,0.568627);
  myColors[i++] = Typ::FloatColor(0.686275,0.686275,0.686275);
  myColors[i++] = Typ::FloatColor(0.749996,0.0,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,1.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getIPGMap( int &numberOfColors )
{
  numberOfColors = 21;

  int i=0;

  myColors[i++] = Typ::FloatColor( 1.00000, 1.00000, 1.00000 );
  myColors[i++] = Typ::FloatColor( 0.803922, 1.00000, 1.00000 );
  myColors[i++] = Typ::FloatColor( 0.00000, 1.00000, 1.00000 );
  myColors[i++] = Typ::FloatColor( 0.00000, 0.725490, 1.00000 );
  myColors[i++] = Typ::FloatColor( 0.00000, 0.423529, 1.00000 );
  myColors[i++] = Typ::FloatColor( 0.756863, 1.00000, 0.00000 );
  myColors[i++] = Typ::FloatColor( 0.725490, 1.00000, 0.529412 );
  myColors[i++] = Typ::FloatColor( 0.513726, 1.00000, 0.274510 );
  myColors[i++] = Typ::FloatColor( 0.00000, 1.00000, 0.00000 );
  myColors[i++] = Typ::FloatColor( 0.00000, 0.862745, 0.258824 );
  myColors[i++] = Typ::FloatColor( 1.00000, 1.00000, 0.454902 );
  myColors[i++] = Typ::FloatColor( 1.00000, 1.00000, 0.301961 );
  myColors[i++] = Typ::FloatColor( 1.00000, 0.941176, 0.00000 );
  myColors[i++] = Typ::FloatColor( 0.968627, 0.878431, 0.501961 );
  myColors[i++] = Typ::FloatColor( 0.819608, 0.713726, 0.364706 );
  myColors[i++] = Typ::FloatColor( 0.847059, 0.619608, 0.168627 );
  myColors[i++] = Typ::FloatColor( 0.741176, 0.560784, 0.137255 );
  myColors[i++] = Typ::FloatColor( 1.00000, 0.756863, 0.803922 );
  myColors[i++] = Typ::FloatColor( 1.00000, 0.545098, 0.576471 );
  myColors[i++] = Typ::FloatColor( 1.00000, 0.00000, 0.529412 );
  myColors[i++] = Typ::FloatColor( 1.00000, 0.00000, 0.00000 );

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBlueYellowRed( int &numberOfColors )
{
  numberOfColors = 31;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0666667,0.0666667,0.933333);
  myColors[i++] = Typ::FloatColor(0.133333,0.133333,0.866667);
  myColors[i++] = Typ::FloatColor(0.2,0.2,0.8);
  myColors[i++] = Typ::FloatColor(0.266667,0.266667,0.733333);
  myColors[i++] = Typ::FloatColor(0.333333,0.333333,0.666667);
  myColors[i++] = Typ::FloatColor(0.4,0.4,0.6);
  myColors[i++] = Typ::FloatColor(0.466667,0.466667,0.533333);
  myColors[i++] = Typ::FloatColor(0.533333,0.533333,0.466667);
  myColors[i++] = Typ::FloatColor(0.6,0.6,0.4);
  myColors[i++] = Typ::FloatColor(0.666667,0.666667,0.333333);
  myColors[i++] = Typ::FloatColor(0.733333,0.733333,0.266667);
  myColors[i++] = Typ::FloatColor(0.8,0.8,0.2);
  myColors[i++] = Typ::FloatColor(0.866667,0.866667,0.133333);
  myColors[i++] = Typ::FloatColor(0.933333,0.933333,0.0666667);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.933333,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.866667,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.8,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.733333,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.666667,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.6,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.533333,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.466667,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.4,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.333333,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.266667,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.2,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.133333,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0666667,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getSemblanceSpectrum( int & numberOfColors )
{
  numberOfColors = 211;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.0276493,0.0276493,0.0276493);
  myColors[i++] = Typ::FloatColor(0.0336919,0.0336919,0.0540627);
  myColors[i++] = Typ::FloatColor(0.0397345,0.0397345,0.0804913);
  myColors[i++] = Typ::FloatColor(0.0457771,0.0457771,0.10692);
  myColors[i++] = Typ::FloatColor(0.0518044,0.0518044,0.133349);
  myColors[i++] = Typ::FloatColor(0.057847,0.057847,0.159762);
  myColors[i++] = Typ::FloatColor(0.0638895,0.0638895,0.186191);
  myColors[i++] = Typ::FloatColor(0.0699321,0.0699321,0.212619);
  myColors[i++] = Typ::FloatColor(0.0759747,0.0759747,0.239048);
  myColors[i++] = Typ::FloatColor(0.0820172,0.0820172,0.265461);
  myColors[i++] = Typ::FloatColor(0.0880598,0.0880598,0.29189);
  myColors[i++] = Typ::FloatColor(0.0941024,0.0941024,0.318318);
  myColors[i++] = Typ::FloatColor(0.100145,0.100145,0.344747);
  myColors[i++] = Typ::FloatColor(0.106188,0.106188,0.37116);
  myColors[i++] = Typ::FloatColor(0.11223,0.11223,0.397589);
  myColors[i++] = Typ::FloatColor(0.118273,0.118273,0.424018);
  myColors[i++] = Typ::FloatColor(0.124315,0.124315,0.450446);
  myColors[i++] = Typ::FloatColor(0.130358,0.130358,0.47686);
  myColors[i++] = Typ::FloatColor(0.136385,0.136385,0.503288);
  myColors[i++] = Typ::FloatColor(0.142428,0.142428,0.529717);
  myColors[i++] = Typ::FloatColor(0.14847,0.14847,0.556146);
  myColors[i++] = Typ::FloatColor(0.154513,0.154513,0.582559);
  myColors[i++] = Typ::FloatColor(0.160555,0.160555,0.608988);
  myColors[i++] = Typ::FloatColor(0.166598,0.166598,0.635416);
  myColors[i++] = Typ::FloatColor(0.172641,0.172641,0.661845);
  myColors[i++] = Typ::FloatColor(0.178683,0.178683,0.688258);
  myColors[i++] = Typ::FloatColor(0.184726,0.184726,0.714687);
  myColors[i++] = Typ::FloatColor(0.190768,0.190768,0.741115);
  myColors[i++] = Typ::FloatColor(0.196811,0.196811,0.767544);
  myColors[i++] = Typ::FloatColor(0.202853,0.202853,0.793957);
  myColors[i++] = Typ::FloatColor(0.196597,0.217716,0.768017);
  myColors[i++] = Typ::FloatColor(0.190356,0.232593,0.742061);
  myColors[i++] = Typ::FloatColor(0.1841,0.247471,0.716106);
  myColors[i++] = Typ::FloatColor(0.177859,0.262333,0.69015);
  myColors[i++] = Typ::FloatColor(0.171603,0.277211,0.66421);
  myColors[i++] = Typ::FloatColor(0.165362,0.292073,0.638254);
  myColors[i++] = Typ::FloatColor(0.159121,0.30695,0.612299);
  myColors[i++] = Typ::FloatColor(0.152865,0.321828,0.586343);
  myColors[i++] = Typ::FloatColor(0.146624,0.33669,0.560403);
  myColors[i++] = Typ::FloatColor(0.140368,0.351568,0.534447);
  myColors[i++] = Typ::FloatColor(0.134127,0.366445,0.508492);
  myColors[i++] = Typ::FloatColor(0.127871,0.381308,0.482551);
  myColors[i++] = Typ::FloatColor(0.12163,0.396185,0.456596);
  myColors[i++] = Typ::FloatColor(0.115373,0.411048,0.43064);
  myColors[i++] = Typ::FloatColor(0.114702,0.431495,0.410254);
  myColors[i++] = Typ::FloatColor(0.119158,0.457084,0.39501);
  myColors[i++] = Typ::FloatColor(0.123629,0.482658,0.379767);
  myColors[i++] = Typ::FloatColor(0.128084,0.508232,0.364523);
  myColors[i++] = Typ::FloatColor(0.13254,0.533822,0.349279);
  myColors[i++] = Typ::FloatColor(0.137011,0.559396,0.334051);
  myColors[i++] = Typ::FloatColor(0.141466,0.584985,0.318807);
  myColors[i++] = Typ::FloatColor(0.145922,0.610559,0.303563);
  myColors[i++] = Typ::FloatColor(0.150393,0.636133,0.288319);
  myColors[i++] = Typ::FloatColor(0.154849,0.661723,0.273075);
  myColors[i++] = Typ::FloatColor(0.159304,0.687297,0.257832);
  myColors[i++] = Typ::FloatColor(0.163775,0.712886,0.242588);
  myColors[i++] = Typ::FloatColor(0.168231,0.73846,0.227344);
  myColors[i++] = Typ::FloatColor(0.172686,0.764035,0.2121);
  myColors[i++] = Typ::FloatColor(0.177157,0.789624,0.196857);
  myColors[i++] = Typ::FloatColor(0.181613,0.815198,0.181613);
  myColors[i++] = Typ::FloatColor(0.180926,0.815885,0.203418);
  myColors[i++] = Typ::FloatColor(0.180255,0.816571,0.225208);
  myColors[i++] = Typ::FloatColor(0.179568,0.817243,0.247013);
  myColors[i++] = Typ::FloatColor(0.178882,0.817929,0.268818);
  myColors[i++] = Typ::FloatColor(0.17821,0.818616,0.290623);
  myColors[i++] = Typ::FloatColor(0.177523,0.819287,0.312413);
  myColors[i++] = Typ::FloatColor(0.176837,0.819974,0.334218);
  myColors[i++] = Typ::FloatColor(0.176165,0.820661,0.356023);
  myColors[i++] = Typ::FloatColor(0.175479,0.821332,0.377829);
  myColors[i++] = Typ::FloatColor(0.174792,0.822019,0.399619);
  myColors[i++] = Typ::FloatColor(0.174121,0.82269,0.421424);
  myColors[i++] = Typ::FloatColor(0.173434,0.823377,0.443229);
  myColors[i++] = Typ::FloatColor(0.172747,0.824063,0.465019);
  myColors[i++] = Typ::FloatColor(0.172076,0.824735,0.486824);
  myColors[i++] = Typ::FloatColor(0.171389,0.825422,0.508629);
  myColors[i++] = Typ::FloatColor(0.170703,0.826108,0.530434);
  myColors[i++] = Typ::FloatColor(0.170031,0.82678,0.552224);
  myColors[i++] = Typ::FloatColor(0.169345,0.827466,0.574029);
  myColors[i++] = Typ::FloatColor(0.168658,0.828153,0.595834);
  myColors[i++] = Typ::FloatColor(0.167987,0.828824,0.617639);
  myColors[i++] = Typ::FloatColor(0.1673,0.829511,0.639429);
  myColors[i++] = Typ::FloatColor(0.166613,0.830198,0.661234);
  myColors[i++] = Typ::FloatColor(0.165942,0.830869,0.68304);
  myColors[i++] = Typ::FloatColor(0.165255,0.831556,0.704845);
  myColors[i++] = Typ::FloatColor(0.164569,0.832242,0.726635);
  myColors[i++] = Typ::FloatColor(0.163897,0.832914,0.74844);
  myColors[i++] = Typ::FloatColor(0.16321,0.8336,0.770245);
  myColors[i++] = Typ::FloatColor(0.162524,0.834287,0.79205);
  myColors[i++] = Typ::FloatColor(0.161852,0.834958,0.81384);
  myColors[i++] = Typ::FloatColor(0.161166,0.835645,0.835645);
  myColors[i++] = Typ::FloatColor(0.186358,0.842649,0.818418);
  myColors[i++] = Typ::FloatColor(0.213718,0.847517,0.799023);
  myColors[i++] = Typ::FloatColor(0.241062,0.852369,0.779614);
  myColors[i++] = Typ::FloatColor(0.268406,0.857221,0.760204);
  myColors[i++] = Typ::FloatColor(0.29575,0.862089,0.740764);
  myColors[i++] = Typ::FloatColor(0.323095,0.866941,0.721325);
  myColors[i++] = Typ::FloatColor(0.350439,0.871794,0.701854);
  myColors[i++] = Typ::FloatColor(0.377798,0.876661,0.682368);
  myColors[i++] = Typ::FloatColor(0.405142,0.881514,0.662852);
  myColors[i++] = Typ::FloatColor(0.432486,0.886366,0.643305);
  myColors[i++] = Typ::FloatColor(0.459831,0.891218,0.623728);
  myColors[i++] = Typ::FloatColor(0.48719,0.896086,0.60412);
  myColors[i++] = Typ::FloatColor(0.514534,0.900938,0.584466);
  myColors[i++] = Typ::FloatColor(0.541878,0.905791,0.564752);
  myColors[i++] = Typ::FloatColor(0.565454,0.906615,0.541222);
  myColors[i++] = Typ::FloatColor(0.585428,0.903639,0.514122);
  myColors[i++] = Typ::FloatColor(0.605341,0.900679,0.487022);
  myColors[i++] = Typ::FloatColor(0.625208,0.897704,0.459937);
  myColors[i++] = Typ::FloatColor(0.64506,0.894713,0.432837);
  myColors[i++] = Typ::FloatColor(0.664866,0.891737,0.405753);
  myColors[i++] = Typ::FloatColor(0.684657,0.888762,0.378668);
  myColors[i++] = Typ::FloatColor(0.704417,0.885786,0.351583);
  myColors[i++] = Typ::FloatColor(0.724147,0.882795,0.324498);
  myColors[i++] = Typ::FloatColor(0.743877,0.87982,0.297414);
  myColors[i++] = Typ::FloatColor(0.763577,0.876829,0.270329);
  myColors[i++] = Typ::FloatColor(0.783261,0.873854,0.243244);
  myColors[i++] = Typ::FloatColor(0.802945,0.870863,0.216159);
  myColors[i++] = Typ::FloatColor(0.822614,0.867872,0.189075);
  myColors[i++] = Typ::FloatColor(0.842268,0.864897,0.16199);
  myColors[i++] = Typ::FloatColor(0.859602,0.859602,0.137209);
  myColors[i++] = Typ::FloatColor(0.860487,0.851911,0.136431);
  myColors[i++] = Typ::FloatColor(0.861372,0.844205,0.135653);
  myColors[i++] = Typ::FloatColor(0.862257,0.836515,0.134874);
  myColors[i++] = Typ::FloatColor(0.863142,0.828824,0.134096);
  myColors[i++] = Typ::FloatColor(0.864027,0.821118,0.133318);
  myColors[i++] = Typ::FloatColor(0.864912,0.813428,0.13254);
  myColors[i++] = Typ::FloatColor(0.865797,0.805722,0.131762);
  myColors[i++] = Typ::FloatColor(0.866682,0.798032,0.130983);
  myColors[i++] = Typ::FloatColor(0.867567,0.790341,0.130205);
  myColors[i++] = Typ::FloatColor(0.868452,0.782635,0.129427);
  myColors[i++] = Typ::FloatColor(0.869337,0.774945,0.128649);
  myColors[i++] = Typ::FloatColor(0.870222,0.767239,0.127871);
  myColors[i++] = Typ::FloatColor(0.871107,0.759548,0.127092);
  myColors[i++] = Typ::FloatColor(0.871977,0.751858,0.126314);
  myColors[i++] = Typ::FloatColor(0.872862,0.744152,0.125536);
  myColors[i++] = Typ::FloatColor(0.873747,0.736461,0.124758);
  myColors[i++] = Typ::FloatColor(0.874632,0.728756,0.12398);
  myColors[i++] = Typ::FloatColor(0.875517,0.721065,0.123201);
  myColors[i++] = Typ::FloatColor(0.876402,0.713375,0.122423);
  myColors[i++] = Typ::FloatColor(0.877287,0.705669,0.121645);
  myColors[i++] = Typ::FloatColor(0.878172,0.697978,0.120851);
  myColors[i++] = Typ::FloatColor(0.879057,0.690272,0.120073);
  myColors[i++] = Typ::FloatColor(0.879942,0.682582,0.119295);
  myColors[i++] = Typ::FloatColor(0.880827,0.674891,0.118517);
  myColors[i++] = Typ::FloatColor(0.881712,0.667185,0.117739);
  myColors[i++] = Typ::FloatColor(0.882597,0.659495,0.11696);
  myColors[i++] = Typ::FloatColor(0.883482,0.651789,0.116182);
  myColors[i++] = Typ::FloatColor(0.884367,0.644099,0.115404);
  myColors[i++] = Typ::FloatColor(0.885252,0.636408,0.114626);
  myColors[i++] = Typ::FloatColor(0.886137,0.628702,0.113848);
  myColors[i++] = Typ::FloatColor(0.886961,0.610712,0.113024);
  myColors[i++] = Typ::FloatColor(0.8878,0.592706,0.112184);
  myColors[i++] = Typ::FloatColor(0.88864,0.574716,0.111345);
  myColors[i++] = Typ::FloatColor(0.889464,0.556725,0.110521);
  myColors[i++] = Typ::FloatColor(0.890303,0.53872,0.109682);
  myColors[i++] = Typ::FloatColor(0.891142,0.520729,0.108843);
  myColors[i++] = Typ::FloatColor(0.891966,0.502739,0.108019);
  myColors[i++] = Typ::FloatColor(0.892805,0.484733,0.107179);
  myColors[i++] = Typ::FloatColor(0.893645,0.466743,0.10634);
  myColors[i++] = Typ::FloatColor(0.894469,0.448753,0.105516);
  myColors[i++] = Typ::FloatColor(0.895308,0.430747,0.104677);
  myColors[i++] = Typ::FloatColor(0.896147,0.412757,0.103838);
  myColors[i++] = Typ::FloatColor(0.896971,0.394751,0.103014);
  myColors[i++] = Typ::FloatColor(0.89781,0.376761,0.102174);
  myColors[i++] = Typ::FloatColor(0.89865,0.35877,0.101335);
  myColors[i++] = Typ::FloatColor(0.899474,0.340764,0.100511);
  myColors[i++] = Typ::FloatColor(0.900313,0.322774,0.0996719);
  myColors[i++] = Typ::FloatColor(0.901152,0.304784,0.0988327);
  myColors[i++] = Typ::FloatColor(0.901976,0.286778,0.0980087);
  myColors[i++] = Typ::FloatColor(0.902815,0.268788,0.0971695);
  myColors[i++] = Typ::FloatColor(0.903655,0.250782,0.0963302);
  myColors[i++] = Typ::FloatColor(0.904479,0.232792,0.0955062);
  myColors[i++] = Typ::FloatColor(0.905318,0.214801,0.094667);
  myColors[i++] = Typ::FloatColor(0.906157,0.196796,0.0938277);
  myColors[i++] = Typ::FloatColor(0.906981,0.178805,0.0930037);
  myColors[i++] = Typ::FloatColor(0.90782,0.160815,0.0921645);
  myColors[i++] = Typ::FloatColor(0.90866,0.142809,0.0913252);
  myColors[i++] = Typ::FloatColor(0.909483,0.124819,0.0905013);
  myColors[i++] = Typ::FloatColor(0.910323,0.106828,0.089662);
  myColors[i++] = Typ::FloatColor(0.911162,0.0888228,0.0888228);
  myColors[i++] = Typ::FloatColor(0.912337,0.0876478,0.12575);
  myColors[i++] = Typ::FloatColor(0.913512,0.0864729,0.162676);
  myColors[i++] = Typ::FloatColor(0.914687,0.0852979,0.199603);
  myColors[i++] = Typ::FloatColor(0.915846,0.0841382,0.23653);
  myColors[i++] = Typ::FloatColor(0.917021,0.0829633,0.273457);
  myColors[i++] = Typ::FloatColor(0.918196,0.0817884,0.310384);
  myColors[i++] = Typ::FloatColor(0.919371,0.0806134,0.347311);
  myColors[i++] = Typ::FloatColor(0.920546,0.0794385,0.384237);
  myColors[i++] = Typ::FloatColor(0.921721,0.0782635,0.421164);
  myColors[i++] = Typ::FloatColor(0.922896,0.0770886,0.458091);
  myColors[i++] = Typ::FloatColor(0.924071,0.0759136,0.495018);
  myColors[i++] = Typ::FloatColor(0.925246,0.0747387,0.531945);
  myColors[i++] = Typ::FloatColor(0.926421,0.0735637,0.568872);
  myColors[i++] = Typ::FloatColor(0.927581,0.0724041,0.605798);
  myColors[i++] = Typ::FloatColor(0.928756,0.0712291,0.642725);
  myColors[i++] = Typ::FloatColor(0.929931,0.0700542,0.679667);
  myColors[i++] = Typ::FloatColor(0.931105,0.0688792,0.716594);
  myColors[i++] = Typ::FloatColor(0.93228,0.0677043,0.753521);
  myColors[i++] = Typ::FloatColor(0.933455,0.0665293,0.790448);
  myColors[i++] = Typ::FloatColor(0.93463,0.0653544,0.827375);
  myColors[i++] = Typ::FloatColor(0.935805,0.0641794,0.864302);
  myColors[i++] = Typ::FloatColor(0.93698,0.0630045,0.901228);
  myColors[i++] = Typ::FloatColor(0.938155,0.0618296,0.938155);
  myColors[i++] = Typ::FloatColor(0.9449,0.178119,0.9449);
  myColors[i++] = Typ::FloatColor(0.951644,0.294408,0.951644);
  myColors[i++] = Typ::FloatColor(0.958404,0.410697,0.958404);
  myColors[i++] = Typ::FloatColor(0.965148,0.526986,0.965148);
  myColors[i++] = Typ::FloatColor(0.971893,0.643275,0.971893);
  myColors[i++] = Typ::FloatColor(0.978653,0.759564,0.978653);
  myColors[i++] = Typ::FloatColor(0.985397,0.875853,0.985397);
  myColors[i++] = Typ::FloatColor(0.992157,0.992157,0.992157);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getSickTiger( int &numberOfColors )
{
  numberOfColors = 65;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.027451,0.0235294,0.0235294);
  myColors[i++] = Typ::FloatColor(0.0509804,0.0509804,0.0509804);
  myColors[i++] = Typ::FloatColor(0.0784314,0.0745098,0.0745098);
  myColors[i++] = Typ::FloatColor(0.101961,0.101961,0.0980392);
  myColors[i++] = Typ::FloatColor(0.129412,0.12549,0.12549);
  myColors[i++] = Typ::FloatColor(0.152941,0.152941,0.14902);
  myColors[i++] = Typ::FloatColor(0.180392,0.176471,0.172549);
  myColors[i++] = Typ::FloatColor(0.203922,0.203922,0.2);
  myColors[i++] = Typ::FloatColor(0.231373,0.227451,0.223529);
  myColors[i++] = Typ::FloatColor(0.254902,0.254902,0.247059);
  myColors[i++] = Typ::FloatColor(0.282353,0.278431,0.27451);
  myColors[i++] = Typ::FloatColor(0.309804,0.305882,0.298039);
  myColors[i++] = Typ::FloatColor(0.333333,0.329412,0.321569);
  myColors[i++] = Typ::FloatColor(0.360784,0.356863,0.34902);
  myColors[i++] = Typ::FloatColor(0.384314,0.380392,0.372549);
  myColors[i++] = Typ::FloatColor(0.411765,0.407843,0.396078);
  myColors[i++] = Typ::FloatColor(0.435294,0.431373,0.423529);
  myColors[i++] = Typ::FloatColor(0.462745,0.458824,0.447059);
  myColors[i++] = Typ::FloatColor(0.486275,0.482353,0.470588);
  myColors[i++] = Typ::FloatColor(0.513726,0.509804,0.498039);
  myColors[i++] = Typ::FloatColor(0.537255,0.533333,0.521569);
  myColors[i++] = Typ::FloatColor(0.564706,0.556863,0.54902);
  myColors[i++] = Typ::FloatColor(0.588235,0.584314,0.572549);
  myColors[i++] = Typ::FloatColor(0.615686,0.607843,0.6);
  myColors[i++] = Typ::FloatColor(0.639216,0.635294,0.623529);
  myColors[i++] = Typ::FloatColor(0.662745,0.658824,0.65098);
  myColors[i++] = Typ::FloatColor(0.690196,0.686275,0.67451);
  myColors[i++] = Typ::FloatColor(0.713726,0.709804,0.701961);
  myColors[i++] = Typ::FloatColor(0.741176,0.733333,0.72549);
  myColors[i++] = Typ::FloatColor(0.764706,0.760784,0.74902);
  myColors[i++] = Typ::FloatColor(0.792157,0.784314,0.776471);
  myColors[i++] = Typ::FloatColor(0.815686,0.811765,0.8);
  myColors[i++] = Typ::FloatColor(0.839216,0.835294,0.827451);
  myColors[i++] = Typ::FloatColor(0.866667,0.862745,0.85098);
  myColors[i++] = Typ::FloatColor(0.890196,0.886275,0.878431);
  myColors[i++] = Typ::FloatColor(0.917647,0.913725,0.901961);
  myColors[i++] = Typ::FloatColor(0.941176,0.937255,0.929412);
  myColors[i++] = Typ::FloatColor(0.898039,0.917647,0.878431);
  myColors[i++] = Typ::FloatColor(0.854902,0.898039,0.827451);
  myColors[i++] = Typ::FloatColor(0.815686,0.882353,0.780392);
  myColors[i++] = Typ::FloatColor(0.772549,0.862745,0.729412);
  myColors[i++] = Typ::FloatColor(0.733333,0.847059,0.682353);
  myColors[i++] = Typ::FloatColor(0.72549,0.807843,0.631373);
  myColors[i++] = Typ::FloatColor(0.721569,0.768627,0.580392);
  myColors[i++] = Typ::FloatColor(0.717647,0.729412,0.529412);
  myColors[i++] = Typ::FloatColor(0.713726,0.690196,0.482353);
  myColors[i++] = Typ::FloatColor(0.705882,0.65098,0.431373);
  myColors[i++] = Typ::FloatColor(0.701961,0.611765,0.380392);
  myColors[i++] = Typ::FloatColor(0.698039,0.572549,0.333333);
  myColors[i++] = Typ::FloatColor(0.694118,0.533333,0.282353);
  myColors[i++] = Typ::FloatColor(0.690196,0.498039,0.235294);
  myColors[i++] = Typ::FloatColor(0.694118,0.466667,0.235294);
  myColors[i++] = Typ::FloatColor(0.694118,0.439216,0.231373);
  myColors[i++] = Typ::FloatColor(0.698039,0.415686,0.231373);
  myColors[i++] = Typ::FloatColor(0.698039,0.396078,0.227451);
  myColors[i++] = Typ::FloatColor(0.701961,0.376471,0.227451);
  myColors[i++] = Typ::FloatColor(0.705882,0.356863,0.227451);
  myColors[i++] = Typ::FloatColor(0.705882,0.337255,0.227451);
  myColors[i++] = Typ::FloatColor(0.709804,0.321569,0.227451);
  myColors[i++] = Typ::FloatColor(0.713726,0.301961,0.227451);
  myColors[i++] = Typ::FloatColor(0.713726,0.282353,0.227451);
  myColors[i++] = Typ::FloatColor(0.717647,0.262745,0.227451);
  myColors[i++] = Typ::FloatColor(0.721569,0.243137,0.227451);
  myColors[i++] = Typ::FloatColor(0.72549,0.227451,0.227451);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getStep145Ampd( int &numberOfColors )
{
  numberOfColors = 145;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.0,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.0,0.0,0.501961);
  myColors[i++] = Typ::FloatColor(0.0431373,0.0431373,0.545098);
  myColors[i++] = Typ::FloatColor(0.0901961,0.0901961,0.592157);
  myColors[i++] = Typ::FloatColor(0.133333,0.133333,0.635294);
  myColors[i++] = Typ::FloatColor(0.180392,0.180392,0.682353);
  myColors[i++] = Typ::FloatColor(0.227451,0.227451,0.72549);
  myColors[i++] = Typ::FloatColor(0.270588,0.270588,0.772549);
  myColors[i++] = Typ::FloatColor(0.317647,0.317647,0.815686);
  myColors[i++] = Typ::FloatColor(0.364706,0.364706,0.862745);
  myColors[i++] = Typ::FloatColor(0.407843,0.407843,0.905882);
  myColors[i++] = Typ::FloatColor(0.454902,0.454902,0.952941);
  myColors[i++] = Typ::FloatColor(0.501961,0.501961,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.501961,0.0);
  myColors[i++] = Typ::FloatColor(0.0431373,0.545098,0.0431373);
  myColors[i++] = Typ::FloatColor(0.0901961,0.592157,0.0901961);
  myColors[i++] = Typ::FloatColor(0.133333,0.635294,0.133333);
  myColors[i++] = Typ::FloatColor(0.180392,0.682353,0.180392);
  myColors[i++] = Typ::FloatColor(0.227451,0.72549,0.227451);
  myColors[i++] = Typ::FloatColor(0.270588,0.772549,0.270588);
  myColors[i++] = Typ::FloatColor(0.317647,0.815686,0.317647);
  myColors[i++] = Typ::FloatColor(0.364706,0.862745,0.364706);
  myColors[i++] = Typ::FloatColor(0.407843,0.905882,0.407843);
  myColors[i++] = Typ::FloatColor(0.454902,0.952941,0.454902);
  myColors[i++] = Typ::FloatColor(0.501961,1.0,0.501961);
  myColors[i++] = Typ::FloatColor(0.501961,0.258824,0.0);
  myColors[i++] = Typ::FloatColor(0.545098,0.32549,0.0431373);
  myColors[i++] = Typ::FloatColor(0.592157,0.392157,0.0901961);
  myColors[i++] = Typ::FloatColor(0.635294,0.458824,0.133333);
  myColors[i++] = Typ::FloatColor(0.682353,0.52549,0.180392);
  myColors[i++] = Typ::FloatColor(0.72549,0.592157,0.227451);
  myColors[i++] = Typ::FloatColor(0.772549,0.662745,0.270588);
  myColors[i++] = Typ::FloatColor(0.815686,0.729412,0.317647);
  myColors[i++] = Typ::FloatColor(0.862745,0.796078,0.364706);
  myColors[i++] = Typ::FloatColor(0.905882,0.862745,0.407843);
  myColors[i++] = Typ::FloatColor(0.952941,0.929412,0.454902);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.501961);
  myColors[i++] = Typ::FloatColor(0.501961,0.0,0.501961);
  myColors[i++] = Typ::FloatColor(0.545098,0.0431373,0.545098);
  myColors[i++] = Typ::FloatColor(0.592157,0.0901961,0.592157);
  myColors[i++] = Typ::FloatColor(0.635294,0.133333,0.635294);
  myColors[i++] = Typ::FloatColor(0.682353,0.180392,0.682353);
  myColors[i++] = Typ::FloatColor(0.72549,0.227451,0.72549);
  myColors[i++] = Typ::FloatColor(0.772549,0.270588,0.772549);
  myColors[i++] = Typ::FloatColor(0.815686,0.317647,0.815686);
  myColors[i++] = Typ::FloatColor(0.862745,0.364706,0.862745);
  myColors[i++] = Typ::FloatColor(0.905882,0.407843,0.905882);
  myColors[i++] = Typ::FloatColor(0.952941,0.454902,0.952941);
  myColors[i++] = Typ::FloatColor(1.0,0.501961,1.0);
  myColors[i++] = Typ::FloatColor(1.0,0.501961,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.545098,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.592157,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.635294,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.682353,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.72549,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.772549,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.815686,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.862745,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.905882,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.952941,0.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.243137,0.0,0.0);
  myColors[i++] = Typ::FloatColor(0.309804,0.0313726,0.0313726);
  myColors[i++] = Typ::FloatColor(0.380392,0.0666667,0.0666667);
  myColors[i++] = Typ::FloatColor(0.447059,0.101961,0.101961);
  myColors[i++] = Typ::FloatColor(0.517647,0.137255,0.137255);
  myColors[i++] = Typ::FloatColor(0.584314,0.172549,0.172549);
  myColors[i++] = Typ::FloatColor(0.654902,0.203922,0.203922);
  myColors[i++] = Typ::FloatColor(0.721569,0.239216,0.239216);
  myColors[i++] = Typ::FloatColor(0.792157,0.27451,0.27451);
  myColors[i++] = Typ::FloatColor(0.858824,0.309804,0.309804);
  myColors[i++] = Typ::FloatColor(0.929412,0.345098,0.345098);
  myColors[i++] = Typ::FloatColor(1.0,0.380392,0.380392);
  myColors[i++] = Typ::FloatColor(0.0,0.501961,0.243137);
  myColors[i++] = Typ::FloatColor(0.0431373,0.545098,0.286275);
  myColors[i++] = Typ::FloatColor(0.0901961,0.592157,0.333333);
  myColors[i++] = Typ::FloatColor(0.133333,0.635294,0.380392);
  myColors[i++] = Typ::FloatColor(0.180392,0.682353,0.427451);
  myColors[i++] = Typ::FloatColor(0.227451,0.72549,0.47451);
  myColors[i++] = Typ::FloatColor(0.270588,0.772549,0.521569);
  myColors[i++] = Typ::FloatColor(0.317647,0.815686,0.568627);
  myColors[i++] = Typ::FloatColor(0.364706,0.862745,0.615686);
  myColors[i++] = Typ::FloatColor(0.407843,0.905882,0.662745);
  myColors[i++] = Typ::FloatColor(0.454902,0.952941,0.709804);
  myColors[i++] = Typ::FloatColor(0.501961,1.0,0.756863);
  myColors[i++] = Typ::FloatColor(0.243137,0.0,0.243137);
  myColors[i++] = Typ::FloatColor(0.309804,0.0666667,0.298039);
  myColors[i++] = Typ::FloatColor(0.380392,0.133333,0.356863);
  myColors[i++] = Typ::FloatColor(0.447059,0.2,0.415686);
  myColors[i++] = Typ::FloatColor(0.517647,0.266667,0.470588);
  myColors[i++] = Typ::FloatColor(0.584314,0.333333,0.529412);
  myColors[i++] = Typ::FloatColor(0.654902,0.403922,0.588235);
  myColors[i++] = Typ::FloatColor(0.721569,0.470588,0.647059);
  myColors[i++] = Typ::FloatColor(0.792157,0.537255,0.701961);
  myColors[i++] = Typ::FloatColor(0.858824,0.603922,0.760784);
  myColors[i++] = Typ::FloatColor(0.929412,0.670588,0.819608);
  myColors[i++] = Typ::FloatColor(1.0,0.741176,0.878431);
  myColors[i++] = Typ::FloatColor(0.0,0.243137,0.501961);
  myColors[i++] = Typ::FloatColor(0.0,0.266667,0.545098);
  myColors[i++] = Typ::FloatColor(0.0,0.290196,0.592157);
  myColors[i++] = Typ::FloatColor(0.0,0.313726,0.635294);
  myColors[i++] = Typ::FloatColor(0.0,0.337255,0.682353);
  myColors[i++] = Typ::FloatColor(0.0,0.360784,0.72549);
  myColors[i++] = Typ::FloatColor(0.0,0.384314,0.772549);
  myColors[i++] = Typ::FloatColor(0.0,0.407843,0.815686);
  myColors[i++] = Typ::FloatColor(0.0,0.431373,0.862745);
  myColors[i++] = Typ::FloatColor(0.0,0.454902,0.905882);
  myColors[i++] = Typ::FloatColor(0.0,0.478431,0.952941);
  myColors[i++] = Typ::FloatColor(0.0,0.501961,1.0);
  myColors[i++] = Typ::FloatColor(0.501961,0.258824,0.0);
  myColors[i++] = Typ::FloatColor(0.545098,0.32549,0.027451);
  myColors[i++] = Typ::FloatColor(0.592157,0.392157,0.054902);
  myColors[i++] = Typ::FloatColor(0.635294,0.458824,0.0823529);
  myColors[i++] = Typ::FloatColor(0.682353,0.52549,0.113725);
  myColors[i++] = Typ::FloatColor(0.72549,0.592157,0.141176);
  myColors[i++] = Typ::FloatColor(0.772549,0.662745,0.168627);
  myColors[i++] = Typ::FloatColor(0.815686,0.729412,0.196078);
  myColors[i++] = Typ::FloatColor(0.862745,0.796078,0.227451);
  myColors[i++] = Typ::FloatColor(0.905882,0.862745,0.254902);
  myColors[i++] = Typ::FloatColor(0.952941,0.929412,0.282353);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.313726);
  myColors[i++] = Typ::FloatColor(0.501961,0.0,0.34902);
  myColors[i++] = Typ::FloatColor(0.545098,0.054902,0.407843);
  myColors[i++] = Typ::FloatColor(0.592157,0.113725,0.466667);
  myColors[i++] = Typ::FloatColor(0.635294,0.172549,0.52549);
  myColors[i++] = Typ::FloatColor(0.682353,0.227451,0.584314);
  myColors[i++] = Typ::FloatColor(0.72549,0.286275,0.643137);
  myColors[i++] = Typ::FloatColor(0.772549,0.345098,0.701961);
  myColors[i++] = Typ::FloatColor(0.815686,0.403922,0.760784);
  myColors[i++] = Typ::FloatColor(0.862745,0.458824,0.819608);
  myColors[i++] = Typ::FloatColor(0.905882,0.517647,0.878431);
  myColors[i++] = Typ::FloatColor(0.952941,0.576471,0.937255);
  myColors[i++] = Typ::FloatColor(1.0,0.635294,1.0);
  myColors[i++] = Typ::FloatColor(0.756863,0.121569,0.121569);
  myColors[i++] = Typ::FloatColor(0.780392,0.168627,0.168627);
  myColors[i++] = Typ::FloatColor(0.803922,0.219608,0.219608);
  myColors[i++] = Typ::FloatColor(0.827451,0.270588,0.270588);
  myColors[i++] = Typ::FloatColor(0.85098,0.317647,0.317647);
  myColors[i++] = Typ::FloatColor(0.87451,0.368627,0.368627);
  myColors[i++] = Typ::FloatColor(0.901961,0.419608,0.419608);
  myColors[i++] = Typ::FloatColor(0.92549,0.466667,0.466667);
  myColors[i++] = Typ::FloatColor(0.94902,0.517647,0.517647);
  myColors[i++] = Typ::FloatColor(0.972549,0.568627,0.568627);
  myColors[i++] = Typ::FloatColor(1.0,0.619608,0.619608);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getWhiteAnchoredRainbow( int &numberOfColors )
{
  numberOfColors = 31;

  int i=0;

  myColors[i++] = Typ::FloatColor(1.0,1.0,1.0);
  myColors[i++] = Typ::FloatColor(0.776471,0.423529,0.941176);
  myColors[i++] = Typ::FloatColor(0.619608,0.337255,0.952941);
  myColors[i++] = Typ::FloatColor(0.466667,0.254902,0.964706);
  myColors[i++] = Typ::FloatColor(0.309804,0.168627,0.976471);
  myColors[i++] = Typ::FloatColor(0.152941,0.0823529,0.988235);
  myColors[i++] = Typ::FloatColor(0.0,0.0,1.0);
  myColors[i++] = Typ::FloatColor(0.0,0.164706,0.831373);
  myColors[i++] = Typ::FloatColor(0.0,0.333333,0.666667);
  myColors[i++] = Typ::FloatColor(0.0,0.498039,0.498039);
  myColors[i++] = Typ::FloatColor(0.0,0.666667,0.333333);
  myColors[i++] = Typ::FloatColor(0.0,0.831373,0.164706);
  myColors[i++] = Typ::FloatColor(0.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.2,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.4,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.6,1.0,0.0);
  myColors[i++] = Typ::FloatColor(0.8,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,1.0,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.941176,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.882353,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.823529,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.764706,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.705882,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.647059,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.552941,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.458824,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.368627,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.27451,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.184314,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0901961,0.0);
  myColors[i++] = Typ::FloatColor(1.0,0.0,0.0);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getAcquisitionFoldOfCover( int &numberOfColors )
{
  numberOfColors = 11;

  int i=0;

  myColors[i++] = Typ::FloatColor(0.811337,0.165499,0.165499);
  myColors[i++] = Typ::FloatColor(0.811337,0.488426,0.165499);
  myColors[i++] = Typ::FloatColor(0.816785,0.720867,0.179095);
  myColors[i++] = Typ::FloatColor(0.823957,0.823957,0.168078);
  myColors[i++] = Typ::FloatColor(0.945464,0.945464,0.0545205);
  myColors[i++] = Typ::FloatColor(0.0710613,0.928923,0.0710613);
  myColors[i++] = Typ::FloatColor(0.0874495,0.576516,0.0874495);
  myColors[i++] = Typ::FloatColor(0.392935,0.924498,0.924498);
  myColors[i++] = Typ::FloatColor(0.0900893,0.363363,0.909895);
  myColors[i++] = Typ::FloatColor(0.0837415,0.0837415,0.410529);
  myColors[i++] = Typ::FloatColor(0.811337,0.165499,0.811337);

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getFoldMap( int &numberOfColors )
{
	numberOfColors = 19;

  int i=0;

  myColors[i++] = Typ::FloatColor( 1.00000, 1.00000, 1.00000 );
  myColors[i++] = Typ::FloatColor( 1.00000, 0.000000, 0.000000 );
  myColors[i++] = Typ::FloatColor( 1.00000, 0.321569, 0.000000 );
  myColors[i++] = Typ::FloatColor( 1.00000, 0.647059, 0.000000 );
  myColors[i++] = Typ::FloatColor( 1.00000, 0.764706, 0.000000 );
  myColors[i++] = Typ::FloatColor( 1.00000, 0.882353, 0.000000 );
  myColors[i++] = Typ::FloatColor( 1.00000, 1.00000, 0.000000 );
  myColors[i++] = Typ::FloatColor( 0.882353, 0.721569, 0.0549020 );
  myColors[i++] = Typ::FloatColor( 0.764706, 0.443137, 0.109804 );
  myColors[i++] = Typ::FloatColor( 0.509804, 0.627451, 0.0705882 );
  myColors[i++] = Typ::FloatColor( 0.254902, 0.811765, 0.0352941 );
  myColors[i++] = Typ::FloatColor( 0.000000, 1.00000, 0.000000 );
  myColors[i++] = Typ::FloatColor( 0.000000, 0.831373, 0.164706 );
  myColors[i++] = Typ::FloatColor( 0.000000, 0.666667, 0.333333 );
  myColors[i++] = Typ::FloatColor( 0.000000, 0.498039, 0.498039 );
  myColors[i++] = Typ::FloatColor( 0.000000, 0.333333, 0.666667 );
  myColors[i++] = Typ::FloatColor( 0.000000, 0.164706, 0.831373 );
  myColors[i++] = Typ::FloatColor( 0.000000, 0.000000, 1.00000 );
  myColors[i++] = Typ::FloatColor( 0.000000, 0.000000, 0.501961 );

  assert( i == numberOfColors );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getHotBlack( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) ((i*2.0)/(float)factor),
			    (double) ((i*2.0)/(float)factor),
			    (double) ((i*2.0)/(float)factor) );
    myColors[(i+1)+half] =
      Typ::FloatColor( 1.0, (double) (1.0-((i+1)*2.0)/(float)factor), 0.0 );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-1] =
      Typ::FloatColor( 1.0, 0.0, 0.0 );

  // Add the middle color which you don't get from the above algorithm.
  myColors[half] = Typ::FloatColor(1.0,1.0,1.0);

  return myColors;
}


const Typ::ColorCreateInfo * TypColormapDefinitions::getBlackWhite( int &numberOfColors )
{
  if ( numberOfColors < 2 ) numberOfColors = 2;
  if ( numberOfColors > Typ::MAXIMUM_NUMBER_OF_COLORS ) {
    numberOfColors = Typ::MAXIMUM_NUMBER_OF_COLORS;
  }
  for( int i=0; i<numberOfColors; i++ ){
    myColors[i] = Typ::FloatColor( (double) ((float)i/(float)(numberOfColors-1)) );
  }

  return myColors;
}


const Typ::ColorCreateInfo * TypColormapDefinitions::getBlackWhiteBlack( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) ((i*2.0)/(float)factor),
			    (double) ((i*2.0)/(float)factor),
			    (double) ((i*2.0)/(float)factor) );
    myColors[i+half] =
      Typ::FloatColor( (double) (1.0-(i*2.0)/(float)factor),
		  (double) (1.0-(i*2.0)/(float)factor),
		  (double) (1.0-(i*2.0)/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( (double) (1.0-(half*2.0)/(float)factor),
		  (double) (1.0-(half*2.0)/(float)factor),
		  (double) (1.0-(half*2.0)/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(0.0,0.0,0.0);

  return myColors;
}


const Typ::ColorCreateInfo * TypColormapDefinitions::getWhiteBlack( int &numberOfColors )
{
  if ( numberOfColors < 2 ) numberOfColors = 2;
  if ( numberOfColors > Typ::MAXIMUM_NUMBER_OF_COLORS ) {
    numberOfColors = Typ::MAXIMUM_NUMBER_OF_COLORS;
  }
  float fdenom = (float) (numberOfColors-1);
  for( int i=0; i<numberOfColors; i++ ){
    myColors[i] = Typ::FloatColor( (double) ( 1.0f - (float)i/fdenom) );
  }

  return myColors;
}


const Typ::ColorCreateInfo * TypColormapDefinitions::getWhiteBlackWhite( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) (1.0-(i*2.0)/(float)factor),
			    (double) (1.0-(i*2.0)/(float)factor),
			    (double) (1.0-(i*2.0)/(float)factor) );
    myColors[i+half] =
      Typ::FloatColor( (double) ((i*2.0)/(float)factor),
		  (double) ((i*2.0)/(float)factor),
		  (double) ((i*2.0)/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( (double) ((half*2.0)/(float)factor),
		  (double) ((half*2.0)/(float)factor),
		  (double) ((half*2.0)/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(1.0,1.0,1.0);

  return myColors;
}


const Typ::ColorCreateInfo * TypColormapDefinitions::getPureRedBlueGreen( int &numberOfColors )
{
  // If the number of colors is less than 9, which is the minimum for the full
// algorithm, compute them more manually here.
  if( numberOfColors < 9 ) {
    if( numberOfColors < 3 ) numberOfColors = 3;
    myColors[0] = Typ::FloatColor( 1.0, 0.0, 0.0 );
    myColors[numberOfColors-1] = Typ::FloatColor(0.0, 1.0, 0.0 );
    myColors[numberOfColors/2] = Typ::FloatColor(0.0, 0.0, 1.0 );
    if( numberOfColors > 3 ) {
      if( numberOfColors < 6 ) 
  myColors[1] = Typ::FloatColor(1.0, 0.0, 1.0 );
      else
  myColors[1] = Typ::FloatColor(1.0, 0.0, 0.5 );
      if( numberOfColors > 4 ) {
	if( numberOfColors < 7 ) 
    myColors[numberOfColors-2] = Typ::FloatColor(0.0, 1.0, 1.0 );
	else
    myColors[numberOfColors-2] = Typ::FloatColor(0.0, 1.0, 0.5 );
	if( numberOfColors > 5 ) {
    myColors[2] = Typ::FloatColor(1.0, 0.0, 1.0 );
	  if( numberOfColors > 6 ) {
      myColors[numberOfColors-3] = Typ::FloatColor(0.0, 1.0, 1.0 );
      if( numberOfColors == 8 ) myColors[3] = Typ::FloatColor(0.5, 0.0, 1.0 );
	  }
	}
      }
    }

    // Else use the full algorithm.
  } else {
  // Make numberOfColors a multiple of 4 for the four color ramp sections.
    numberOfColors = myMultipleOf( 4, numberOfColors );

  // Generate the four color ramp sections.
    for( int i=0; i<numberOfColors/4; i++ ){
      myColors[i] =
  Typ::FloatColor( 1.0, 0.0, (double)((i*4.0)/(float)numberOfColors) );
      myColors[i+numberOfColors/4] =
  Typ::FloatColor( (double) (1.0-(i*4.0)/(float)numberOfColors), 0.0, 1.0 );
      myColors[i+numberOfColors/2] =
  Typ::FloatColor( 0.0, (double) ((i*4.0)/(float)numberOfColors), 1.0 );
      myColors[i+3*numberOfColors/4] =
  Typ::FloatColor( 0.0, 1.0, (double) (1.0-(i*4.0)/(float)numberOfColors) );
    }
  // Add the last color which you don't get from the above algorithm.
    myColors[numberOfColors++] = Typ::FloatColor(0.0,1.0,0.0);
  }

  return myColors;
}


const Typ::ColorCreateInfo * TypColormapDefinitions::getMuddyRedBlueGreen( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) (1.0-i/(float)factor),
			    (double) (i/(float)factor),
			    (double) ((i*2.0)/(float)factor) );
    myColors[i+half] =
      Typ::FloatColor( (double) (0.5-i/(float)factor),
		  (double) (0.5+i/(float)factor),
		  (double) (1-(i*2.0)/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( (double) (0.5-half/(float)factor),
		  (double) (0.5+half/(float)factor),
		  (double) (1-(half*2.0)/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor( 0.0, 1.0, 0.0 );

  return myColors;
}


const Typ::ColorCreateInfo * TypColormapDefinitions::getPureGreenRedBlue( int &numberOfColors )
{
  // If the number of colors is less than 9, which is the minimum for the full
// algorithm, compute them more manually here.
  if( numberOfColors < 9 ) {
    if( numberOfColors < 3 ) numberOfColors = 3;
    myColors[0] = Typ::FloatColor( 0.0, 1.0, 0.0 );
    myColors[numberOfColors-1] = Typ::FloatColor(0.0, 0.0, 1.0 );
    myColors[numberOfColors/2] = Typ::FloatColor(1.0, 0.0, 0.0 );
    if( numberOfColors > 3 ) {
      if( numberOfColors < 6 ) 
  myColors[1] = Typ::FloatColor(1.0, 1.0, 0.0 );
      else
  myColors[1] = Typ::FloatColor(0.5, 1.0, 0.0 );
      if( numberOfColors > 4 ) {
	if( numberOfColors < 7 ) 
    myColors[numberOfColors-2] = Typ::FloatColor(1.0, 0.0, 1.0 );
	else
    myColors[numberOfColors-2] = Typ::FloatColor(0.5, 0.0, 1.0 );
	if( numberOfColors > 5 ) {
    myColors[2] = Typ::FloatColor(1.0, 1.0, 0.0 );
	  if( numberOfColors > 6 ) {
      myColors[numberOfColors-3] = Typ::FloatColor(1.0, 0.0, 1.0 );
      if( numberOfColors == 8 ) myColors[3] = Typ::FloatColor(1.0, 0.5, 0.0 );
	  }
	}
      }
    }

    // Else use the full algorithm.
  } else {
  // Make numberOfColors a multiple of 4 for the four color ramp sections.
    numberOfColors = myMultipleOf( 4, numberOfColors );

  // Generate the four color ramp sections.
    for( int i=0; i<numberOfColors/4; i++ ){
      myColors[i] =
  Typ::FloatColor( (double) ((i*4.0)/(float)numberOfColors), 1.0, 0.0 );
      myColors[i+numberOfColors/4] =
  Typ::FloatColor( 1.0, (double) (1.0-(i*4.0)/(float)numberOfColors), 0.0 );
      myColors[i+numberOfColors/2] =
  Typ::FloatColor( 1.0, 0.0, (double) ((i*4.0)/(float)numberOfColors) );
      myColors[i+3*numberOfColors/4] =
  Typ::FloatColor( (double) (1.0-(i*4.0)/(float)numberOfColors), 0.0, 1.0 );
    }
    // Add the last color which you don't get from the above algorithm.
    myColors[numberOfColors++] = Typ::FloatColor(0.0,0.0,1.0);
  }

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getMuddyGreenRedBlue( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) ((i*2.0)/(float)factor),
			    (double) (1.0-i/(float)factor),
			    (double) (i/(float)factor) );
    myColors[i+half] =
      Typ::FloatColor( (double) (1-(i*2.0)/(float)factor),
		  (double) (0.5-i/(float)factor),
		  (double) (0.5+i/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( (double) (1-(half*2.0)/(float)factor),
		  (double) (0.5-half/(float)factor),
		  (double) (0.5+half/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor( 0.0, 0.0, 1.0 );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getPureBlueGreenRed( int &numberOfColors )
{
  // If the number of colors is less than 9, which is the minimum for the full
// algorithm, compute them more manually here.
  if( numberOfColors < 9 ) {
    if( numberOfColors < 3 ) numberOfColors = 3;
    myColors[0] = Typ::FloatColor( 0.0, 0.0, 1.0 );
    myColors[numberOfColors-1] = Typ::FloatColor(1.0, 0.0, 0.0 );
    myColors[numberOfColors/2] = Typ::FloatColor(0.0, 1.0, 0.0 );
    if( numberOfColors > 3 ) {
      if( numberOfColors < 6 ) 
  myColors[1] = Typ::FloatColor(0.0, 1.0, 1.0 );
      else
  myColors[1] = Typ::FloatColor(0.0, 0.5, 1.0 );
      if( numberOfColors > 4 ) {
	if( numberOfColors < 7 ) 
    myColors[numberOfColors-2] = Typ::FloatColor(1.0, 1.0, 0.0 );
	else
    myColors[numberOfColors-2] = Typ::FloatColor(1.0, 0.5, 0.0 );
	if( numberOfColors > 5 ) {
    myColors[2] = Typ::FloatColor(0.0, 1.0, 1.0 );
	  if( numberOfColors > 6 ) {
      myColors[numberOfColors-3] = Typ::FloatColor(1.0, 1.0, 0.0 );
      if( numberOfColors == 8 ) myColors[3] = Typ::FloatColor(0.0, 1.0, 0.5 );
	  }
	}
      }
    }

    // Else use the full algorithm.
  } else {
  // Make numberOfColors a multiple of 4 for the four color ramp sections.
    numberOfColors = myMultipleOf( 4, numberOfColors );

    // Generate the four color ramp sections.
    for( int i=0; i<numberOfColors/4; i++ ){
      myColors[i] =
  Typ::FloatColor( 0.0, (double) ((i*4.0)/(float)numberOfColors), 1.0 );
      myColors[i+numberOfColors/4] =
  Typ::FloatColor( 0.0, 1.0, (double) (1.0-(i*4.0)/(float)numberOfColors) );
      myColors[i+numberOfColors/2] =
  Typ::FloatColor( (double) ((i*4.0)/(float)numberOfColors), 1.0, 0.0 );
      myColors[i+3*numberOfColors/4] =
  Typ::FloatColor( 1.0, (double) (1.0-(i*4.0)/(float)numberOfColors), 0.0 );
    }
    // Add the last color which you don't get from the above algorithm.
    myColors[numberOfColors++] = Typ::FloatColor( 1.0, 0.0, 0.0 );
  }

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getMuddyBlueGreenRed( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) (i/(float)factor),
			    (double) ((i*2.0)/(float)factor),
			    (double) (1.0-i/(float)factor) );
    myColors[i+half] =
      Typ::FloatColor( (double) (0.5+i/(float)factor),
		  (double) (1.0-(i*2.0)/(float)factor), 
		  (double) (0.5-i/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( (double) (0.5+half/(float)factor),
		  (double) (1.0-(half*2.0)/(float)factor), 
		  (double) (0.5-half/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor( 1.0, 0.0, 0.0 );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBlueWhiteRed( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) ((i*2.0)/(float)factor),
			    (double) ((i*2.0)/(float)factor),
			    1.0 );
    myColors[i+half] =
      Typ::FloatColor( 1.0,
		  (double) (1.0-(i*2.0)/(float)factor),
		  (double) (1.0-(i*2.0)/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( 1.0,
		  (double) (1.0-(half*2.0)/(float)factor),
		  (double) (1.0-(half*2.0)/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(1.0,0.0,0.0);

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBlueWhiteYellow( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) ((i*2.0)/(float)factor),
			    (double) ((i*2.0)/(float)factor),
			    1.0 );
    myColors[i+half] =
      Typ::FloatColor( 1.0,
		  1.0,
		  (double) (1.0-(i*2.0)/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( 1.0,
		  1.0,
		  (double) (1.0-(half*2.0)/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(1.0,1.0,0.0);

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getGreenWhiteRed( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) ((i*2.0)/(float)factor),
			    1.0,
			    (double) ((i*2.0)/(float)factor) );
    myColors[i+half] =
      Typ::FloatColor( 1.0,
		  (double) (1.0-(i*2.0)/(float)factor),
		  (double) (1.0-(i*2.0)/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( 1.0,
		  (double) (1.0-(half*2.0)/(float)factor),
		  (double) (1.0-(half*2.0)/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(1.0,0.0,0.0);

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getBlueWhiteGreen( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) ((i*2.0)/(float)factor),
			    (double) ((i*2.0)/(float)factor),
			    1.0 );
    myColors[i+half] =
      Typ::FloatColor( (double) (1.0-(i*2.0)/(float)factor),
		  1.0,
		  (double) (1.0-(i*2.0)/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( (double) (1.0-(half*2.0)/(float)factor),
		  1.0,
		  (double) (1.0-(half*2.0)/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(0.0,1.0,0.0);

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getCyanWhiteMagenta( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] =
      Typ::FloatColor( (double) ((i*2.0)/(float)factor), 1.0, 1.0 );
    myColors[i+half] =
      Typ::FloatColor( 1.0, (double) (1.0-(i*2.0)/(float)factor), 1.0 );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( 1.0, (double) (1.0-(half*2.0)/(float)factor), 1.0 );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(1.0,0.0,1.0);

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getYellowWhiteMagenta( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] =
      Typ::FloatColor( 1.0, 1.0, (double) ((i*2.0)/(float)factor) );
    myColors[i+half] =
      Typ::FloatColor( 1.0, (double) (1.0-(i*2.0)/(float)factor), 1.0 );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( 1.0, (double) (1.0-(half*2.0)/(float)factor), 1.0 );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(1.0,0.0,1.0);

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getCyanWhiteYellow( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] =
      Typ::FloatColor( (double) ((i*2.0)/(float)factor), 1.0, 1.0 );
    myColors[i+half] =
      Typ::FloatColor( 1.0, 1.0, (double) (1.0-(i*2.0)/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( 1.0, 1.0, (double) (1.0-(half*2.0)/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(1.0,1.0,0.0);

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getCyanMagentaYellow( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) ((i*2.0)/(float)factor),
			    (double)(1.0-(i*2.0)/(float)factor),
			    1.0 );
    myColors[i+half] =
      Typ::FloatColor( 1.0,
		  (double) ((i*2.0)/(float)factor),
		  (double) (1.0-(i*2.0)/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( 1.0,
		  (double) ((half*2.0)/(float)factor),
		  (double) (1.0-(half*2.0)/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(1.0,1.0,0.0);

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getMagentaYellowCyan( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( 1.0,
			    (double)((i*2.0)/(float)factor),
			    (double) (1.0-(i*2.0)/(float)factor) );
    myColors[i+half] =
      Typ::FloatColor( (double) (1.0-(i*2.0)/(float)factor),
		  1.0,
		  (double) ((i*2.0)/(float)factor) );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( (double) (1.0-(half*2.0)/(float)factor),
		  1.0,
		  (double) ((half*2.0)/(float)factor) );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(0.0,1.0,1.0);

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getYellowCyanMagenta( int &numberOfColors )
{
  if( numberOfColors < 3 ) numberOfColors = 3;
  int half = numberOfColors / 2;
  if( numberOfColors % 2 == 0 ) --half;
  int factor = numberOfColors-1;

  // Generate the two color ramp sections.
  for( int i=0; i<half; i++ ){
    myColors[i] = Typ::FloatColor( (double) (1.0-(i*2.0)/(float)factor),
			    1.0,
			    (double) ((i*2.0)/(float)factor) );
    myColors[i+half] =
      Typ::FloatColor( (double) ((i*2.0)/(float)factor),
		  (double) (1.0-(i*2.0)/(float)factor),
		  1.0 );
  }
  // If numberOfColors is even, add another value at the end.
  if( numberOfColors % 2 == 0 ) myColors[numberOfColors-2] =
      Typ::FloatColor( (double) ((half*2.0)/(float)factor),
		  (double) (1.0-(half*2.0)/(float)factor),
		  1.0 );

  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors-1] = Typ::FloatColor(1.0,0.0,1.0);

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getPureBlueGreenRedMagenta( int &numberOfColors )
{
  // Make numberOfColors a multiple of 5 for the five color ramp sections.
  numberOfColors = myMultipleOf( 5, numberOfColors );

  // Generate the five color ramp sections.
  for( int i=0; i<numberOfColors/5; i++ ){
    myColors[i] =
      Typ::FloatColor( 0.0, (double) ((i*5.0)/(float)numberOfColors), 1.0 );
    myColors[i+numberOfColors/5] =
      Typ::FloatColor( 0.0, 1.0, (double) (1.0-(i*5.0)/(float)numberOfColors) );
    myColors[i+2*numberOfColors/5] =
      Typ::FloatColor( (double) ((i*5.0)/(float)numberOfColors), 1.0, 0.0 );
    myColors[i+3*numberOfColors/5] =
      Typ::FloatColor( 1.0, (double) (1.0-(i*5.0)/(float)numberOfColors), 0.0 );
    myColors[i+4*numberOfColors/5] = 
      Typ::FloatColor( 1.0, 0.0, (double) ((i*5.0)/(float)numberOfColors) );
  }
  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors++] = Typ::FloatColor( 1.0, 0.0, 1.0 );

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getDivan( int & numberOfColors )
{
  numberOfColors -= 1;
  // Make numberOfColors odd
  numberOfColors = myMultipleOf( 2, numberOfColors );
  numberOfColors += 1;
  int ncd2 = numberOfColors /2;
  numberOfColors += 1;
  double del = 1.0 / ( ncd2 + 1);
  double* ra = new double[numberOfColors];
  double* ba = new double[numberOfColors];
  double r = 1.0;
  double b = 1.0;
  double g = del;
  int i;
  for ( i = 0; i <= ncd2; ++i ) {
      ra[i] = 0.0;
      ra[(numberOfColors-i)-1] = r;
      ba[i] = b;
      ba[(numberOfColors-i)-1] = 0.0;
      r -= del;
      b -= del;
  }
  for (  i = 0; i < numberOfColors; ++i ) {
    r = ra[i];
    b = ba[i];
    r = (r < 0.0) ? 0.0 : (r > 1.0) ? 1.0 : r;
    g = (g < 0.0) ? 0.0 : (g > 1.0) ? 1.0 : g;
    b = (b < 0.0) ? 0.0 : (b > 1.0) ? 1.0 : b;
    myColors[i] = Typ::FloatColor( r, g, b );
      if ( i < ncd2 ) {
          g += del;
      } else {
          g -= del;
      }
  }
  delete ra;
  delete ba;

  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getSingaporeShades( int &numberOfColors )
{
  // Colors: Singapore request 28Jul06
  float mult = 1 ; mult /= 65535 ;
  struct { int myRed ; int myGreen ; int myBlue ; } rgbValuesStruct[] = {
    { 50739 , 63955 , 64214 },// blue
    { 36451 , 62708 , 62940 },
    { 12947 , 60844 , 59070 },
    {  5240 , 45381 , 58762 },
    {  4192 , 31477 , 47009 },
    { 23086 , 61748 , 23086 },// green
    {  4644 , 52079 , 24793 },
    {  3658 , 41018 , 17720 },
    {  3452 , 38714 ,  3452 },
    {  2630 , 29495 ,  2630 },
    { 58762 , 58762 ,  5240 },// yellow
    { 59812 , 60474 ,  8799 },
    { 60309 , 52152 ,  6956 },
    { 46548 , 40042 ,  4151 },
    { 37988 , 33161 , 10703 },
    { 58762 ,  5240 , 58762 },// red
    { 58762 ,  5240 ,  5240 }
  };
  int ncols = (sizeof(rgbValuesStruct) / sizeof(rgbValuesStruct[0]));
  struct { int myFirst ; int myLast ; } intervalsStruct[] = {
    {  0 ,  4 },
    {  5 ,  9 },
    { 10 , 14 },
    { 15 , 16 } 
  };
  int nintervals = (sizeof(intervalsStruct) / sizeof(intervalsStruct[0]));

  // Adjust the number of colors.
  if ( numberOfColors > Typ::STANDARD_NUMBER_OF_COLORS ) {
    numberOfColors = Typ::STANDARD_NUMBER_OF_COLORS;
  }
  int numberOfInterpolatedColors = int(0.5f+float(numberOfColors-ncols)/float(ncols-nintervals));
  if ( numberOfInterpolatedColors < 0 ) numberOfInterpolatedColors = 0;
  numberOfColors = ncols + numberOfInterpolatedColors * (ncols-nintervals);
  if ( numberOfColors > Typ::STANDARD_NUMBER_OF_COLORS ) {
    numberOfInterpolatedColors -= 1;
  }
  
  // Store the colors.
  numberOfColors = 0;
  for ( int n=0 ; n < nintervals ; ++n ) {
    int i;
    for ( i=intervalsStruct[n].myFirst ; i < intervalsStruct[n].myLast ; ++i ) {
      float r = (mult*rgbValuesStruct[i+1].myRed   - mult*rgbValuesStruct[i].myRed  ) / (numberOfInterpolatedColors+1) ;
      float g = (mult*rgbValuesStruct[i+1].myGreen - mult*rgbValuesStruct[i].myGreen) / (numberOfInterpolatedColors+1) ;
      float b = (mult*rgbValuesStruct[i+1].myBlue  - mult*rgbValuesStruct[i].myBlue ) / (numberOfInterpolatedColors+1) ;
      for ( int j=0 ; j <= numberOfInterpolatedColors ; ++j ) {
        myColors[numberOfColors++] = Typ::FloatColor( mult*rgbValuesStruct[i].myRed   + j * r ,
                                                   mult*rgbValuesStruct[i].myGreen + j * g ,
                                                   mult*rgbValuesStruct[i].myBlue  + j * b );
      }
    }
    myColors[numberOfColors++] = Typ::FloatColor( mult*rgbValuesStruct[i].myRed   ,
                                             mult*rgbValuesStruct[i].myGreen ,
                                             mult*rgbValuesStruct[i].myBlue  );
  }
  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getChicRainbow( int &numberOfColors )
{
  // Steve Campbell / Andrew Claw request: 20 november 2006.
  float mult = 1; mult /= 100 ;
  struct { int myRank; int myRed ; int myGreen ; int myBlue ; } rgbValuesStruct[] = {
    { 1  , 93  , 0   , 0   },
    { 8  , 54  , 53  , 0   },
    { 16 , 100 , 53  , 0   },
    { 24 , 100 , 82  , 11  },
    { 32 , 100 , 100 , 100 },
    { 40 , 20  , 73  , 27  },
    { 48 , 0   , 47  , 53  },
    { 56 , 22  , 36  , 64  },
    { 64 , 60  , 40  , 60  }
  };
  int ncols = (sizeof(rgbValuesStruct) / sizeof(rgbValuesStruct[0]));

  // Adjust the number of colors.
  if ( numberOfColors > Typ::STANDARD_NUMBER_OF_COLORS ) {
    numberOfColors = Typ::STANDARD_NUMBER_OF_COLORS;
  }
  int numberOfInterpolatedColors = int(0.5f+float(numberOfColors-ncols)/float(ncols-1));
  numberOfColors = ncols + (ncols-1) * numberOfInterpolatedColors;
  if ( numberOfColors > Typ::STANDARD_NUMBER_OF_COLORS ) {
    numberOfInterpolatedColors -= 1;
  }
  
  // Store the colors.
  int i;
  numberOfColors = 0;
  for ( i=0 ; i < (ncols-1) ; ++i ) {
    float r = (mult*rgbValuesStruct[i+1].myRed   - mult*rgbValuesStruct[i].myRed  ) / (numberOfInterpolatedColors+1) ;
    float g = (mult*rgbValuesStruct[i+1].myGreen - mult*rgbValuesStruct[i].myGreen) / (numberOfInterpolatedColors+1) ;
    float b = (mult*rgbValuesStruct[i+1].myBlue  - mult*rgbValuesStruct[i].myBlue ) / (numberOfInterpolatedColors+1) ;
    for ( int j=0 ; j <= numberOfInterpolatedColors ; ++j ) {
      myColors[numberOfColors++] = Typ::FloatColor( mult*rgbValuesStruct[i].myRed   + j * r ,
                                               mult*rgbValuesStruct[i].myGreen + j * g ,
                                               mult*rgbValuesStruct[i].myBlue  + j * b );
    }
  }
  myColors[numberOfColors++] = Typ::FloatColor( mult*rgbValuesStruct[i].myRed   ,
                                           mult*rgbValuesStruct[i].myGreen ,
                                           mult*rgbValuesStruct[i].myBlue  );
  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getPureEMSpectrum( int &numberOfColors )
{
  // Make numberOfColors a multiple of 5 for the five color ramp sections.
  numberOfColors = myMultipleOf( 5, numberOfColors );

  // Generate the five color ramp sections.
  for( int i=0; i<numberOfColors/5; i++ ){
    myColors[i] =
      Typ::FloatColor( 1.0, (double) ((i*5.0)/(float)numberOfColors), 0.0 );
    myColors[i+numberOfColors/5] =
      Typ::FloatColor( (double) (1.0-(i*5.0)/(float)numberOfColors), 1.0, 0.0 );
    myColors[i+2*numberOfColors/5] =
      Typ::FloatColor( 0.0, 1.0, (double) ((i*5.0)/(float)numberOfColors) );
    myColors[i+3*numberOfColors/5] =
      Typ::FloatColor( 0.0, (double) (1.0-(i*5.0)/(float)numberOfColors), 1.0 );
    myColors[i+4*numberOfColors/5] = 
      Typ::FloatColor( (double) ((i*5.0)/(float)numberOfColors), 0.0, 1.0 );
  }
  // Add the last color which you don't get from the above algorithm.
  myColors[numberOfColors++] = Typ::FloatColor( 1.0, 0.0, 1.0 );

  return myColors;
}

int
TypColormapDefinitions::myMultipleOf( int factor, int numberOfColors,
			   bool adjustmentMargin )
{
  if( adjustmentMargin ){
    if( numberOfColors > Typ::MAXIMUM_NUMBER_OF_COLORS - factor ){
      numberOfColors = Typ::MAXIMUM_NUMBER_OF_COLORS - factor;
    }
  }else{
    if( numberOfColors > Typ::MAXIMUM_NUMBER_OF_COLORS ){
      numberOfColors = Typ::MAXIMUM_NUMBER_OF_COLORS;
    }
  }

  if( numberOfColors < factor*2 ) numberOfColors = factor*2;

  if( numberOfColors % factor ) numberOfColors = factor*(numberOfColors/factor);
 
  return numberOfColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getVoxelGeo( int & i )
{
  i = 0;
  myColors[i++] = Typ::FloatColor(  0.0, 0.0, 0.0);
  myColors[i++] = Typ::FloatColor(  0.0, 0.0, 0.0);
  myColors[i++] = Typ::FloatColor(  0.00198511, 0.00198511, 0.00198511);
  myColors[i++] = Typ::FloatColor(  0.0205955, 0.0205955, 0.0205955);
  myColors[i++] = Typ::FloatColor(  0.042928, 0.042928, 0.042928);
  myColors[i++] = Typ::FloatColor(  0.0503722, 0.0503722, 0.0503722);
  myColors[i++] = Typ::FloatColor(  0.0652605, 0.0652605, 0.0652605);
  myColors[i++] = Typ::FloatColor(  0.0801489, 0.0801489, 0.0801489);
  myColors[i++] = Typ::FloatColor(  0.087593, 0.087593, 0.087593);
  myColors[i++] = Typ::FloatColor(  0.106203, 0.106203, 0.106203);
  myColors[i++] = Typ::FloatColor(  0.11737, 0.11737, 0.11737);
  myColors[i++] = Typ::FloatColor(  0.124814, 0.124814, 0.124814);
  myColors[i++] = Typ::FloatColor(  0.132258, 0.132258, 0.132258);
  myColors[i++] = Typ::FloatColor(  0.154591, 0.154591, 0.154591);
  myColors[i++] = Typ::FloatColor(  0.180645, 0.180645, 0.180645);
  myColors[i++] = Typ::FloatColor(  0.191811, 0.191811, 0.191811);
  myColors[i++] = Typ::FloatColor(  0.202978, 0.202978, 0.202978);
  myColors[i++] = Typ::FloatColor(  0.214144, 0.214144, 0.214144);
  myColors[i++] = Typ::FloatColor(  0.22531, 0.22531, 0.22531);
  myColors[i++] = Typ::FloatColor(  0.236476, 0.236476, 0.236476);
  myColors[i++] = Typ::FloatColor(  0.258809, 0.258809, 0.258809);
  myColors[i++] = Typ::FloatColor(  0.273697, 0.273697, 0.273697);
  myColors[i++] = Typ::FloatColor(  0.284864, 0.284864, 0.284864);
  myColors[i++] = Typ::FloatColor(  0.29603, 0.29603, 0.29603);
  myColors[i++] = Typ::FloatColor(  0.307196, 0.307196, 0.307196);
  myColors[i++] = Typ::FloatColor(  0.329529, 0.329529, 0.329529);
  myColors[i++] = Typ::FloatColor(  0.344417, 0.344417, 0.344417);
  myColors[i++] = Typ::FloatColor(  0.359305, 0.359305, 0.359305);
  myColors[i++] = Typ::FloatColor(  0.381638, 0.381638, 0.381638);
  myColors[i++] = Typ::FloatColor(  0.392804, 0.392804, 0.392804);
  myColors[i++] = Typ::FloatColor(  0.422581, 0.422581, 0.422581);
  myColors[i++] = Typ::FloatColor(  0.433747, 0.433747, 0.433747);
  myColors[i++] = Typ::FloatColor(  0.448635, 0.448635, 0.448635);
  myColors[i++] = Typ::FloatColor(  0.463524, 0.463524, 0.463524);
  myColors[i++] = Typ::FloatColor(  0.478412, 0.478412, 0.478412);
  myColors[i++] = Typ::FloatColor(  0.489578, 0.489578, 0.489578);
  myColors[i++] = Typ::FloatColor(  0.4933, 0.4933, 0.4933);
  myColors[i++] = Typ::FloatColor(  0.508189, 0.508189, 0.508189);
  myColors[i++] = Typ::FloatColor(  0.526799, 0.526799, 0.526799);
  myColors[i++] = Typ::FloatColor(  0.549132, 0.549132, 0.549132);
  myColors[i++] = Typ::FloatColor(  0.567742, 0.567742, 0.567742);
  myColors[i++] = Typ::FloatColor(  0.578908, 0.578908, 0.578908);
  myColors[i++] = Typ::FloatColor(  0.601241, 0.601241, 0.601241);
  myColors[i++] = Typ::FloatColor(  0.601241, 0.601241, 0.601241);
  myColors[i++] = Typ::FloatColor(  0.638462, 0.638462, 0.638462);
  myColors[i++] = Typ::FloatColor(  0.645906, 0.645906, 0.645906);
  myColors[i++] = Typ::FloatColor(  0.668238, 0.668238, 0.668238);
  myColors[i++] = Typ::FloatColor(  0.686849, 0.686849, 0.686849);
  myColors[i++] = Typ::FloatColor(  0.701737, 0.701737, 0.701737);
  myColors[i++] = Typ::FloatColor(  0.720347, 0.720347, 0.720347);
  myColors[i++] = Typ::FloatColor(  0.746402, 0.746402, 0.746402);
  myColors[i++] = Typ::FloatColor(  0.765012, 0.765012, 0.765012);
  myColors[i++] = Typ::FloatColor(  0.791067, 0.791067, 0.791067);
  myColors[i++] = Typ::FloatColor(  0.809677, 0.809677, 0.809677);
  myColors[i++] = Typ::FloatColor(  0.824566, 0.824566, 0.824566);
  myColors[i++] = Typ::FloatColor(  0.846898, 0.846898, 0.846898);
  myColors[i++] = Typ::FloatColor(  0.861787, 0.861787, 0.861787);
  myColors[i++] = Typ::FloatColor(  0.880397, 0.880397, 0.880397);
  myColors[i++] = Typ::FloatColor(  0.895285, 0.895285, 0.895285);
  myColors[i++] = Typ::FloatColor(  0.906452, 0.906452, 0.906452);
  myColors[i++] = Typ::FloatColor(  0.936228, 0.936228, 0.936228);
  myColors[i++] = Typ::FloatColor(  0.962283, 0.962283, 0.962283);
  myColors[i++] = Typ::FloatColor(  1.0, 0.995782, 0.962283);
  myColors[i++] = Typ::FloatColor(  1.0, 0.995782, 0.954839);
  myColors[i++] = Typ::FloatColor(  1.0, 0.988337, 0.928784);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.895285);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.880397);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.865509);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.83201);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.794789);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.794789);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.765012);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.746402);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.705459);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.686849);
  myColors[i++] = Typ::FloatColor(  1.0, 0.99206, 0.668238);
  myColors[i++] = Typ::FloatColor(  1.0, 0.988337, 0.634739);
  myColors[i++] = Typ::FloatColor(  1.0, 0.988337, 0.601241);
  myColors[i++] = Typ::FloatColor(  1.0, 0.984615, 0.567742);
  myColors[i++] = Typ::FloatColor(  1.0, 0.980893, 0.534243);
  myColors[i++] = Typ::FloatColor(  1.0, 0.980893, 0.500744);
  myColors[i++] = Typ::FloatColor(  1.0, 0.977171, 0.463524);
  myColors[i++] = Typ::FloatColor(  1.0, 0.973449, 0.444913);
  myColors[i++] = Typ::FloatColor(  1.0, 0.969727, 0.40397);
  myColors[i++] = Typ::FloatColor(  1.0, 0.966005, 0.348139);
  myColors[i++] = Typ::FloatColor(  1.0, 0.958561, 0.307196);
  myColors[i++] = Typ::FloatColor(  1.0, 0.954839, 0.281141);
  myColors[i++] = Typ::FloatColor(  1.0, 0.951117, 0.258809);
  myColors[i++] = Typ::FloatColor(  1.0, 0.943672, 0.232754);
  myColors[i++] = Typ::FloatColor(  1.0, 0.936228, 0.195533);
  myColors[i++] = Typ::FloatColor(  1.0, 0.925062, 0.184367);
  myColors[i++] = Typ::FloatColor(  1.0, 0.917618, 0.173201);
  myColors[i++] = Typ::FloatColor(  1.0, 0.891563, 0.147146);
  myColors[i++] = Typ::FloatColor(  1.0, 0.880397, 0.124814);
  myColors[i++] = Typ::FloatColor(  1.0, 0.865509, 0.109926);
  myColors[i++] = Typ::FloatColor(   1.0, 0.839454, 0.0950372);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.820844, 0.0727047);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.805955, 0.0578164);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.779901, 0.042928);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.750124, 0.042928);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.705459, 0.0205955);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.657072, 0.0205955);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.627295, 0.00942928);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.575186, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.560298, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.508189, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.4933, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.467246, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.426303, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.396526, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.344417, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.299752, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.269975, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.236476, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.22531, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.210422, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.173201, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.162035, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.150868, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.132258, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.11737, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.083871, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.0615385, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.039206, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.0205955, 0.0);
  myColors[i++] = Typ::FloatColor(   1.0, 0.0, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.0, 0.0);
  myColors[i++] = Typ::FloatColor(	 1.0, 0.0, 0.0);
  assert( i == 128 ); // numberOfColors = 128;
  return myColors;
}

/*static*/ const Typ::ColorCreateInfo *TypColormapDefinitions::getSmallVortex(int & numberOfColors)
{
	// 
	numberOfColors = 32;
	
	int i = 0;    
	
  myColors[i++] = Typ::FloatColor( 1,1,0 );
    myColors[i++] = Typ::FloatColor( 1,0,0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.207843,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.419608,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.631373,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.843137,0.0 );
    myColors[i++] = Typ::FloatColor( 0.0,0.392157,0.0 );
    myColors[i++] = Typ::FloatColor( 0.14902,0.541176,0.14902 );
    myColors[i++] = Typ::FloatColor( 0.298039,0.690196,0.298039 );
    myColors[i++] = Typ::FloatColor( 0.447059,0.839216,0.447059 );
    myColors[i++] = Typ::FloatColor( 0.596078,0.984314,0.596078 );
    myColors[i++] = Typ::FloatColor( 0.0,0.0,0.501961 );
    myColors[i++] = Typ::FloatColor( 0.0901961,0.152941,0.533333 );
    myColors[i++] = Typ::FloatColor( 0.184314,0.309804,0.564706 );
    myColors[i++] = Typ::FloatColor( 0.278431,0.462745,0.596078 );
    myColors[i++] = Typ::FloatColor( 0.372549,0.619608,0.627451 );
    myColors[i++] = Typ::FloatColor( 0.870588,0.721569,0.529412 );
    myColors[i++] = Typ::FloatColor( 0.905882,0.764706,0.588235 );
    myColors[i++] = Typ::FloatColor( 0.937255,0.807843,0.65098 );
    myColors[i++] = Typ::FloatColor( 0.968627,0.85098,0.709804 );
    myColors[i++] = Typ::FloatColor( 1.0,0.894118,0.768627 );
    myColors[i++] = Typ::FloatColor( 0.764706,0.776471,0.776471 );
    myColors[i++] = Typ::FloatColor( 0.698039,0.72549,0.72549 );
    myColors[i++] = Typ::FloatColor( 0.635294,0.67451,0.67451 );
    myColors[i++] = Typ::FloatColor( 0.568627,0.619608,0.619608 );
    myColors[i++] = Typ::FloatColor( 0.505882,0.568627,0.568627 );
    myColors[i++] = Typ::FloatColor( 0.443137,0.517647,0.517647 );
    myColors[i++] = Typ::FloatColor( 0.376471,0.466667,0.466667 );
    myColors[i++] = Typ::FloatColor( 0.313726,0.411765,0.411765 );
    myColors[i++] = Typ::FloatColor( 0.247059,0.360784,0.360784 );
    myColors[i++] = Typ::FloatColor( 0.184314,0.309804,0.309804 );
    myColors[i++] = Typ::FloatColor( 0,0,0 );
	
	
	assert( i == numberOfColors );
	
	return myColors;
	
}
/*static*/ const Typ::ColorCreateInfo * TypColormapDefinitions::getBigVortex(int & numberOfColors)
{
	// 
	numberOfColors = 128;
	
	int i = 0;     
	    
  myColors[i++] = Typ::FloatColor( 1,1,0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.756863,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.513726,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.270588,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.027451,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.0431373,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.0941176,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.145098,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.2,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.25098,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.301961,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.352941,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.403922,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.454902,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.505882,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.556863,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.607843,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.662745,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.713726,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.764706,0.0 );
    myColors[i++] = Typ::FloatColor( 1.0,0.815686,0.0 );
    myColors[i++] = Typ::FloatColor( 0.894118,0.796078,0.0 );
    myColors[i++] = Typ::FloatColor( 0.65098,0.686275,0.0 );
    myColors[i++] = Typ::FloatColor( 0.407843,0.576471,0.0 );
    myColors[i++] = Typ::FloatColor( 0.164706,0.466667,0.0 );
    myColors[i++] = Typ::FloatColor( 0.0117647,0.403922,0.0117647 );
    myColors[i++] = Typ::FloatColor( 0.0470588,0.439216,0.0470588 );
    myColors[i++] = Typ::FloatColor( 0.0823529,0.47451,0.0823529 );
    myColors[i++] = Typ::FloatColor( 0.117647,0.513726,0.117647 );
    myColors[i++] = Typ::FloatColor( 0.156863,0.54902,0.156863 );
    myColors[i++] = Typ::FloatColor( 0.192157,0.584314,0.192157 );
    myColors[i++] = Typ::FloatColor( 0.227451,0.619608,0.227451 );
    myColors[i++] = Typ::FloatColor( 0.262745,0.654902,0.262745 );
    myColors[i++] = Typ::FloatColor( 0.301961,0.694118,0.301961 );
    myColors[i++] = Typ::FloatColor( 0.337255,0.729412,0.337255 );
    myColors[i++] = Typ::FloatColor( 0.372549,0.764706,0.372549 );
    myColors[i++] = Typ::FloatColor( 0.411765,0.8,0.411765 );
    myColors[i++] = Typ::FloatColor( 0.447059,0.835294,0.447059 );
    myColors[i++] = Typ::FloatColor( 0.482353,0.87451,0.482353 );
    myColors[i++] = Typ::FloatColor( 0.517647,0.909804,0.517647 );
    myColors[i++] = Typ::FloatColor( 0.556863,0.945098,0.556863 );
    myColors[i++] = Typ::FloatColor( 0.592157,0.980392,0.592157 );
    myColors[i++] = Typ::FloatColor( 0.470588,0.776471,0.576471 );
    myColors[i++] = Typ::FloatColor( 0.32549,0.537255,0.552941 );
    myColors[i++] = Typ::FloatColor( 0.176471,0.294118,0.529412 );
    myColors[i++] = Typ::FloatColor( 0.0313726,0.054902,0.505882 );
    myColors[i++] = Typ::FloatColor( 0.0156863,0.027451,0.505882 );
    myColors[i++] = Typ::FloatColor( 0.0392157,0.0627451,0.513726 );
    myColors[i++] = Typ::FloatColor( 0.0627451,0.101961,0.521569 );
    myColors[i++] = Typ::FloatColor( 0.0823529,0.141176,0.529412 );
    myColors[i++] = Typ::FloatColor( 0.105882,0.176471,0.537255 );
    myColors[i++] = Typ::FloatColor( 0.129412,0.215686,0.545098 );
    myColors[i++] = Typ::FloatColor( 0.152941,0.254902,0.552941 );
    myColors[i++] = Typ::FloatColor( 0.176471,0.290196,0.560784 );
    myColors[i++] = Typ::FloatColor( 0.196078,0.329412,0.568627 );
    myColors[i++] = Typ::FloatColor( 0.219608,0.368627,0.576471 );
    myColors[i++] = Typ::FloatColor( 0.243137,0.403922,0.584314 );
    myColors[i++] = Typ::FloatColor( 0.266667,0.443137,0.592157 );
    myColors[i++] = Typ::FloatColor( 0.286275,0.482353,0.6 );
    myColors[i++] = Typ::FloatColor( 0.309804,0.517647,0.607843 );
    myColors[i++] = Typ::FloatColor( 0.333333,0.556863,0.615686 );
    myColors[i++] = Typ::FloatColor( 0.356863,0.592157,0.623529 );
    myColors[i++] = Typ::FloatColor( 0.411765,0.627451,0.619608 );
    myColors[i++] = Typ::FloatColor( 0.533333,0.65098,0.596078 );
    myColors[i++] = Typ::FloatColor( 0.654902,0.678431,0.572549 );
    myColors[i++] = Typ::FloatColor( 0.776471,0.701961,0.54902 );
    myColors[i++] = Typ::FloatColor( 0.87451,0.72549,0.533333 );
    myColors[i++] = Typ::FloatColor( 0.882353,0.733333,0.545098 );
    myColors[i++] = Typ::FloatColor( 0.890196,0.745098,0.560784 );
    myColors[i++] = Typ::FloatColor( 0.898039,0.756863,0.576471 );
    myColors[i++] = Typ::FloatColor( 0.905882,0.764706,0.592157 );
    myColors[i++] = Typ::FloatColor( 0.913725,0.776471,0.603922 );
    myColors[i++] = Typ::FloatColor( 0.921569,0.788235,0.619608 );
    myColors[i++] = Typ::FloatColor( 0.929412,0.8,0.635294 );
    myColors[i++] = Typ::FloatColor( 0.937255,0.807843,0.65098 );
    myColors[i++] = Typ::FloatColor( 0.945098,0.819608,0.662745 );
    myColors[i++] = Typ::FloatColor( 0.952941,0.831373,0.678431 );
    myColors[i++] = Typ::FloatColor( 0.960784,0.839216,0.694118 );
    myColors[i++] = Typ::FloatColor( 0.968627,0.85098,0.705882 );
    myColors[i++] = Typ::FloatColor( 0.976471,0.862745,0.721569 );
    myColors[i++] = Typ::FloatColor( 0.984314,0.870588,0.737255 );
    myColors[i++] = Typ::FloatColor( 0.992157,0.882353,0.752941 );
    myColors[i++] = Typ::FloatColor( 1.0,0.894118,0.764706 );
    myColors[i++] = Typ::FloatColor( 0.956863,0.87451,0.772549 );
    myColors[i++] = Typ::FloatColor( 0.901961,0.843137,0.772549 );
    myColors[i++] = Typ::FloatColor( 0.843137,0.815686,0.772549 );
    myColors[i++] = Typ::FloatColor( 0.784314,0.788235,0.776471 );
    myColors[i++] = Typ::FloatColor( 0.752941,0.768627,0.768627 );
    myColors[i++] = Typ::FloatColor( 0.737255,0.756863,0.756863 );
    myColors[i++] = Typ::FloatColor( 0.721569,0.745098,0.745098 );
    myColors[i++] = Typ::FloatColor( 0.705882,0.729412,0.729412 );
    myColors[i++] = Typ::FloatColor( 0.690196,0.717647,0.717647 );
    myColors[i++] = Typ::FloatColor( 0.67451,0.705882,0.705882 );
    myColors[i++] = Typ::FloatColor( 0.658824,0.694118,0.694118 );
    myColors[i++] = Typ::FloatColor( 0.643137,0.678431,0.678431 );
    myColors[i++] = Typ::FloatColor( 0.627451,0.666667,0.666667 );
    myColors[i++] = Typ::FloatColor( 0.611765,0.654902,0.654902 );
    myColors[i++] = Typ::FloatColor( 0.596078,0.643137,0.643137 );
    myColors[i++] = Typ::FloatColor( 0.580392,0.631373,0.631373 );
    myColors[i++] = Typ::FloatColor( 0.564706,0.615686,0.615686 );
    myColors[i++] = Typ::FloatColor( 0.54902,0.603922,0.603922 );
    myColors[i++] = Typ::FloatColor( 0.533333,0.592157,0.592157 );
    myColors[i++] = Typ::FloatColor( 0.517647,0.580392,0.580392 );
    myColors[i++] = Typ::FloatColor( 0.501961,0.564706,0.564706 );
    myColors[i++] = Typ::FloatColor( 0.486275,0.552941,0.552941 );
    myColors[i++] = Typ::FloatColor( 0.470588,0.541176,0.541176 );
    myColors[i++] = Typ::FloatColor( 0.454902,0.529412,0.529412 );
    myColors[i++] = Typ::FloatColor( 0.439216,0.517647,0.517647 );
    myColors[i++] = Typ::FloatColor( 0.423529,0.501961,0.501961 );
    myColors[i++] = Typ::FloatColor( 0.407843,0.490196,0.490196 );
    myColors[i++] = Typ::FloatColor( 0.392157,0.478431,0.478431 );
    myColors[i++] = Typ::FloatColor( 0.376471,0.466667,0.466667 );
    myColors[i++] = Typ::FloatColor( 0.360784,0.45098,0.45098 );
    myColors[i++] = Typ::FloatColor( 0.345098,0.439216,0.439216 );
    myColors[i++] = Typ::FloatColor( 0.329412,0.427451,0.427451 );
    myColors[i++] = Typ::FloatColor( 0.313726,0.415686,0.415686 );
    myColors[i++] = Typ::FloatColor( 0.298039,0.403922,0.403922 );
    myColors[i++] = Typ::FloatColor( 0.282353,0.388235,0.388235 );
    myColors[i++] = Typ::FloatColor( 0.266667,0.376471,0.376471 );
    myColors[i++] = Typ::FloatColor( 0.25098,0.364706,0.364706 );
    myColors[i++] = Typ::FloatColor( 0.235294,0.352941,0.352941 );
    myColors[i++] = Typ::FloatColor( 0.219608,0.337255,0.337255 );
    myColors[i++] = Typ::FloatColor( 0.203922,0.32549,0.32549 );
    myColors[i++] = Typ::FloatColor( 0.188235,0.313726,0.313726 );
    myColors[i++] = Typ::FloatColor( 0.156863,0.262745,0.262745 );
    myColors[i++] = Typ::FloatColor( 0.109804,0.184314,0.184314 );
    myColors[i++] = Typ::FloatColor( 0.0666667,0.109804,0.109804 );
    myColors[i++] = Typ::FloatColor( 0.0196078,0.0352941,0.0352941 );
		
	assert( i == numberOfColors );
	
	return myColors;

}

/*static*/ const Typ::ColorCreateInfo * TypColormapDefinitions::getLandmark(int & numberOfColors)
{
  numberOfColors = 52;

  int i=0;

  myColors[i++] = Typ::FloatColor( 0.686204, 0.0575037, 0.0575037 );
  myColors[i++] = Typ::FloatColor( 0.694472, 0.0959955, 0.0881723 );
  myColors[i++] = Typ::FloatColor( 0.698788, 0.130679, 0.115007 );
  myColors[i++] = Typ::FloatColor( 0.706996, 0.165390, 0.141842 );
  myColors[i++] = Typ::FloatColor( 0.711371, 0.200044, 0.172511 );
  myColors[i++] = Typ::FloatColor( 0.715686, 0.238761, 0.199346 );
  myColors[i++] = Typ::FloatColor( 0.723895, 0.273582, 0.226181 );
  myColors[i++] = Typ::FloatColor( 0.728270, 0.308349, 0.256850 );
  myColors[i++] = Typ::FloatColor( 0.733759, 0.342412, 0.282512 );
  myColors[i++] = Typ::FloatColor( 0.741413, 0.381819, 0.309901 );
  myColors[i++] = Typ::FloatColor( 0.745206, 0.417162, 0.341151 );
  myColors[i++] = Typ::FloatColor( 0.752858, 0.452612, 0.368544 );
  myColors[i++] = Typ::FloatColor( 0.756654, 0.488091, 0.395898 );
  myColors[i++] = Typ::FloatColor( 0.760438, 0.527543, 0.427158 );
  myColors[i++] = Typ::FloatColor( 0.768083, 0.563085, 0.454556 );
  myColors[i++] = Typ::FloatColor( 0.771869, 0.598705, 0.481920 );
  myColors[i++] = Typ::FloatColor( 0.775640, 0.634322, 0.513193 );
  myColors[i++] = Typ::FloatColor( 0.783274, 0.674072, 0.540602 );
  myColors[i++] = Typ::FloatColor( 0.787046, 0.709967, 0.567981 );
  myColors[i++] = Typ::FloatColor( 0.794657, 0.745820, 0.599307 );
  myColors[i++] = Typ::FloatColor( 0.798415, 0.782061, 0.626699 );
  myColors[i++] = Typ::FloatColor( 0.801088, 0.821482, 0.654252 );
  myColors[i++] = Typ::FloatColor( 0.807474, 0.856154, 0.685773 );
  myColors[i++] = Typ::FloatColor( 0.810185, 0.890903, 0.713324 );
  myColors[i++] = Typ::FloatColor( 0.813159, 0.925746, 0.740781 );
  myColors[i++] = Typ::FloatColor( 0.993017, 0.992798, 0.992798 );
  myColors[i++] = Typ::FloatColor( 0.861320, 0.996001, 0.996001 );
  myColors[i++] = Typ::FloatColor( 0.826814, 0.952632, 0.952632 );
  myColors[i++] = Typ::FloatColor( 0.791670, 0.913795, 0.913795 );
  myColors[i++] = Typ::FloatColor( 0.756320, 0.875163, 0.875163 );
  myColors[i++] = Typ::FloatColor( 0.720870, 0.836632, 0.836632 );
  myColors[i++] = Typ::FloatColor( 0.685332, 0.794294, 0.794294 );
  myColors[i++] = Typ::FloatColor( 0.649786, 0.755859, 0.755859 );
  myColors[i++] = Typ::FloatColor( 0.614218, 0.717446, 0.717446 );
  myColors[i++] = Typ::FloatColor( 0.578634, 0.679049, 0.679049 );
  myColors[i++] = Typ::FloatColor( 0.546946, 0.640649, 0.640649 );
  myColors[i++] = Typ::FloatColor( 0.511297, 0.598423, 0.598423 );
  myColors[i++] = Typ::FloatColor( 0.475684, 0.560054, 0.560054 );
  myColors[i++] = Typ::FloatColor( 0.440861, 0.520896, 0.520896 );
  myColors[i++] = Typ::FloatColor( 0.406359, 0.481417, 0.481417 );
  myColors[i++] = Typ::FloatColor( 0.371857, 0.441938, 0.441938 );
  myColors[i++] = Typ::FloatColor( 0.337355, 0.398565, 0.398565 );
  myColors[i++] = Typ::FloatColor( 0.302853, 0.359086, 0.359086 );
  myColors[i++] = Typ::FloatColor( 0.272184, 0.319667, 0.319667 );
  myColors[i++] = Typ::FloatColor( 0.237682, 0.280188, 0.280188 );
  myColors[i++] = Typ::FloatColor( 0.203180, 0.240708, 0.240708 );
  myColors[i++] = Typ::FloatColor( 0.168677, 0.197336, 0.197336 );
  myColors[i++] = Typ::FloatColor( 0.134175, 0.157856, 0.157856 );
  myColors[i++] = Typ::FloatColor( 0.0996730, 0.118377, 0.118377 );
  myColors[i++] = Typ::FloatColor( 0.0651708, 0.0788981, 0.0788981 );
  myColors[i++] = Typ::FloatColor( 0.0306686, 0.0394190, 0.0394190 );
  myColors[i++] = Typ::FloatColor( 0.000000, 0.000000, 0.000000 );

  assert( i == numberOfColors );

  return myColors;
}



Typ::FloatColor TypColormapDefinitions::toFloatColor( int r16, int g16, int b16, int scaling )
{
  float r = r16 ; r /= scaling ;
  float g = g16 ; g /= scaling ;
  float b = b16 ; b /= scaling ;
  return Typ::FloatColor(r,g,b);
}



const Typ::ColorCreateInfo* TypColormapDefinitions::getRedWblk( int  & i )
{
  i=0;
  myColors[i]   = toFloatColor(59641, 25432,  9224);
  myColors[++i] = toFloatColor(59128, 29276, 12812);
  myColors[++i] = toFloatColor(58360, 36771, 20051);
  myColors[++i] = toFloatColor(57847, 40358, 23638);
  myColors[++i] = toFloatColor(57335, 44202, 27226);
  myColors[++i] = toFloatColor(57078, 47789, 31069);
  myColors[++i] = toFloatColor(56566, 51441, 34721);
  myColors[++i] = toFloatColor(56310, 54772, 38308);
  myColors[++i] = toFloatColor(55797, 58360, 41896);
  myColors[++i] = toFloatColor(58360, 60666, 47021);
  myColors[++i] = toFloatColor(60922, 63228, 51697);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(59641, 61178, 63228);
  myColors[++i] = toFloatColor(52466, 57078, 60666);
  myColors[++i] = toFloatColor(45227, 51441, 58360);
  myColors[++i] = toFloatColor(40102, 45996, 51953);
  myColors[++i] = toFloatColor(35233, 40358, 45227);
  myColors[++i] = toFloatColor(30301, 34977, 38821);
  myColors[++i] = toFloatColor(25176, 29276, 32351);
  myColors[++i] = toFloatColor(20051, 23894, 25944);
  myColors[++i] = toFloatColor(15118, 18257, 19282);
  myColors[++i] = toFloatColor( 9993, 12299, 12812);
  myColors[++i] = toFloatColor( 4868,  6149,  6406);
  myColors[++i] = toFloatColor(    0,     0,     0);
  ++i ; // should be 24
  return myColors;
}


const Typ::ColorCreateInfo* TypColormapDefinitions::getAngle45Dip60( int & i )
{
  i=0;
  myColors[i]   = toFloatColor(    0,     0, 65535);
  myColors[++i] = toFloatColor( 8456, 14606, 65535);
  myColors[++i] = toFloatColor(16720, 29532, 65535);
  myColors[++i] = toFloatColor(25176, 44202, 65535);
  myColors[++i] = toFloatColor(33440, 58872, 65535);
  myColors[++i] = toFloatColor(65535,     0,     0);
  myColors[++i] = toFloatColor(65535, 11787, 11787);
  myColors[++i] = toFloatColor(65535, 23638, 23894);
  myColors[++i] = toFloatColor(65535, 35233, 35746);
  myColors[++i] = toFloatColor(65535, 47277, 47789);
  myColors[++i] = toFloatColor(    0, 47277,     0);
  myColors[++i] = toFloatColor(11787, 51697,  8456);
  myColors[++i] = toFloatColor(23894, 56310, 16976);
  myColors[++i] = toFloatColor(35746, 60922, 25432);
  myColors[++i] = toFloatColor(47789, 65535, 33952);
  myColors[++i] = toFloatColor(65535, 51185, 16976);
  myColors[++i] = toFloatColor(65535, 54772,     0);
  myColors[++i] = toFloatColor(65535, 58360,  9993);
  myColors[++i] = toFloatColor(65535, 61947, 20051);
  myColors[++i] = toFloatColor(65535, 65535, 30301);
  myColors[++i] = toFloatColor(30813,     0,     0);
  myColors[++i] = toFloatColor(36258,     0,     0);
  myColors[++i] = toFloatColor(41640, 11274,  9224);
  myColors[++i] = toFloatColor(47021, 22613, 18770);
  myColors[++i] = toFloatColor(52466, 33952, 28251);
  myColors[++i] = toFloatColor(49903,     0, 64766);
  myColors[++i] = toFloatColor(53747, 10762, 65022);
  myColors[++i] = toFloatColor(57591, 21588, 65022);
  myColors[++i] = toFloatColor(61691, 32351, 65278);
  myColors[++i] = toFloatColor(65535, 43177, 65278);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  myColors[++i] = toFloatColor(65535, 65535, 65535);
  ++i ; // should be nCol = 45;
  assert( i == 45 );
  return myColors;
}



const Typ::ColorCreateInfo* TypColormapDefinitions::getBandedRGV( int & i ) // Banded Red Green Violet
{
  i=0;
  myColors[i]   = toFloatColor( 52, 7, 80, 255);
  myColors[++i] = toFloatColor( 52, 7, 80, 255);
  myColors[++i] = toFloatColor( 52, 7, 80, 255);
  myColors[++i] = toFloatColor( 61, 9, 97, 255);
  myColors[++i] = toFloatColor( 72, 11, 118, 255);
  myColors[++i] = toFloatColor( 95, 15, 164, 255);
  myColors[++i] = toFloatColor(104, 17, 185, 255);
  myColors[++i] = toFloatColor(110, 19, 201, 255);
  myColors[++i] = toFloatColor(112, 20, 212, 255);
  myColors[++i] = toFloatColor(111, 20, 215, 255);
  myColors[++i] = toFloatColor( 97, 19, 201, 255);
  myColors[++i] = toFloatColor( 86, 17, 184, 255);
  myColors[++i] = toFloatColor( 73, 15, 164, 255);
  myColors[++i] = toFloatColor( 49, 11, 117, 255);
  myColors[++i] = toFloatColor( 49, 11, 117, 255);
  myColors[++i] = toFloatColor( 31, 7, 80, 255);
  myColors[++i] = toFloatColor( 25, 6, 70, 255);
  myColors[++i] = toFloatColor( 23, 6, 66, 255);
  myColors[++i] = toFloatColor( 23, 6, 70, 255);
  myColors[++i] = toFloatColor( 25, 7, 80, 255);
  myColors[++i] = toFloatColor( 33, 11, 118, 255);
  myColors[++i] = toFloatColor( 37, 13, 141, 255);
  myColors[++i] = toFloatColor( 41, 15, 164, 255);
  myColors[++i] = toFloatColor( 43, 17, 185, 255);
  myColors[++i] = toFloatColor( 44, 19, 201, 255);
  myColors[++i] = toFloatColor( 40, 20, 215, 255);
  myColors[++i] = toFloatColor( 35, 20, 211, 255);
  myColors[++i] = toFloatColor( 30, 19, 201, 255);
  myColors[++i] = toFloatColor( 25, 17, 184, 255);
  myColors[++i] = toFloatColor( 19, 15, 164, 255);
  myColors[++i] = toFloatColor( 11, 12, 118, 255);
  myColors[++i] = toFloatColor( 9, 11, 97, 255);
  myColors[++i] = toFloatColor( 7, 10, 80, 255);
  myColors[++i] = toFloatColor( 6, 10, 70, 255);
  myColors[++i] = toFloatColor( 6, 11, 66, 255);
  myColors[++i] = toFloatColor( 7, 16, 80, 255);
  myColors[++i] = toFloatColor( 11, 27, 117, 255);
  myColors[++i] = toFloatColor( 11, 27, 117, 255);
  myColors[++i] = toFloatColor( 13, 35, 141, 255);
  myColors[++i] = toFloatColor( 15, 43, 164, 255);
  myColors[++i] = toFloatColor( 19, 60, 201, 255);
  myColors[++i] = toFloatColor( 20, 67, 211, 255);
  myColors[++i] = toFloatColor( 20, 71, 215, 255);
  myColors[++i] = toFloatColor( 20, 74, 212, 255);
  myColors[++i] = toFloatColor( 19, 73, 201, 255);
  myColors[++i] = toFloatColor( 15, 65, 164, 255);
  myColors[++i] = toFloatColor( 13, 58, 141, 255);
  myColors[++i] = toFloatColor( 11, 51, 118, 255);
  myColors[++i] = toFloatColor( 7, 37, 80, 255);
  myColors[++i] = toFloatColor( 7, 37, 80, 255);
  myColors[++i] = toFloatColor( 6, 33, 66, 255);
  myColors[++i] = toFloatColor( 6, 36, 70, 255);
  myColors[++i] = toFloatColor( 7, 42, 80, 255);
  myColors[++i] = toFloatColor( 9, 53, 97, 255);
  myColors[++i] = toFloatColor( 11, 66, 117, 255);
  myColors[++i] = toFloatColor( 15, 97, 164, 255);
  myColors[++i] = toFloatColor( 17, 113, 184, 255);
  myColors[++i] = toFloatColor( 19, 126, 201, 255);
  myColors[++i] = toFloatColor( 20, 136, 211, 255);
  myColors[++i] = toFloatColor( 20, 142, 215, 255);
  myColors[++i] = toFloatColor( 19, 140, 201, 255);
  myColors[++i] = toFloatColor( 17, 131, 185, 255);
  myColors[++i] = toFloatColor( 15, 119, 164, 255);
  myColors[++i] = toFloatColor( 13, 105, 141, 255);
  myColors[++i] = toFloatColor( 11, 89, 118, 255);
  myColors[++i] = toFloatColor( 7, 64, 80, 255);
  myColors[++i] = toFloatColor( 6, 57, 70, 255);
  myColors[++i] = toFloatColor( 6, 55, 66, 255);
  myColors[++i] = toFloatColor( 6, 59, 70, 255);
  myColors[++i] = toFloatColor( 7, 69, 80, 255);
  myColors[++i] = toFloatColor( 11, 105, 117, 255);
  myColors[++i] = toFloatColor( 15, 152, 164, 255);
  myColors[++i] = toFloatColor( 15, 152, 164, 255);
  myColors[++i] = toFloatColor( 17, 174, 184, 255);
  myColors[++i] = toFloatColor( 19, 193, 201, 255);
  myColors[++i] = toFloatColor( 20, 214, 215, 255);
  myColors[++i] = toFloatColor( 20, 212, 210, 255);
  myColors[++i] = toFloatColor( 19, 201, 196, 255);
  myColors[++i] = toFloatColor( 17, 185, 177, 255);
  myColors[++i] = toFloatColor( 15, 164, 154, 255);
  myColors[++i] = toFloatColor( 11, 118, 107, 255);
  myColors[++i] = toFloatColor( 9, 97, 86, 255);
  myColors[++i] = toFloatColor( 7, 80, 70, 255);
  myColors[++i] = toFloatColor( 6, 66, 56, 255);
  myColors[++i] = toFloatColor( 6, 66, 56, 255);
  myColors[++i] = toFloatColor( 7, 80, 65, 255);
  myColors[++i] = toFloatColor( 9, 97, 76, 255);
  myColors[++i] = toFloatColor( 11, 117, 91, 255);
  myColors[++i] = toFloatColor( 13, 141, 107, 255);
  myColors[++i] = toFloatColor( 15, 164, 121, 255);
  myColors[++i] = toFloatColor( 19, 201, 142, 255);
  myColors[++i] = toFloatColor( 20, 211, 147, 255);
  myColors[++i] = toFloatColor( 20, 215, 146, 255);
  myColors[++i] = toFloatColor( 20, 212, 140, 255);
  myColors[++i] = toFloatColor( 19, 201, 129, 255);
  myColors[++i] = toFloatColor( 15, 164, 100, 255);
  myColors[++i] = toFloatColor( 13, 141, 83, 255);
  myColors[++i] = toFloatColor( 11, 118, 68, 255);
  myColors[++i] = toFloatColor( 9, 97, 54, 255);
  myColors[++i] = toFloatColor( 7, 80, 44, 255);
  myColors[++i] = toFloatColor( 6, 66, 34, 255);
  myColors[++i] = toFloatColor( 6, 70, 34, 255);
  myColors[++i] = toFloatColor( 7, 80, 38, 255);
  myColors[++i] = toFloatColor( 9, 97, 44, 255);
  myColors[++i] = toFloatColor( 11, 117, 52, 255);
  myColors[++i] = toFloatColor( 15, 164, 67, 255);
  myColors[++i] = toFloatColor( 19, 201, 76, 255);
  myColors[++i] = toFloatColor( 19, 201, 76, 255);
  myColors[++i] = toFloatColor( 19, 201, 76, 255);
  myColors[++i] = toFloatColor( 20, 211, 77, 255);
  myColors[++i] = toFloatColor( 20, 212, 70, 255);
  myColors[++i] = toFloatColor( 19, 201, 63, 255);
  myColors[++i] = toFloatColor( 17, 185, 55, 255);
  myColors[++i] = toFloatColor( 15, 164, 46, 255);
  myColors[++i] = toFloatColor( 13, 141, 37, 255);
  myColors[++i] = toFloatColor( 9, 97, 22, 255);
  myColors[++i] = toFloatColor( 7, 80, 17, 255);
  myColors[++i] = toFloatColor( 6, 70, 13, 255);
  myColors[++i] = toFloatColor( 6, 66, 12, 255);
  myColors[++i] = toFloatColor( 6, 70, 11, 255);
  myColors[++i] = toFloatColor( 9, 97, 12, 255);
  myColors[++i] = toFloatColor( 11, 117, 13, 255);
  myColors[++i] = toFloatColor( 13, 141, 14, 255);
  myColors[++i] = toFloatColor( 17, 164, 15, 255);
  myColors[++i] = toFloatColor( 22, 184, 17, 255);
  myColors[++i] = toFloatColor( 32, 211, 20, 255);
  myColors[++i] = toFloatColor( 36, 215, 20, 255);
  myColors[++i] = toFloatColor( 39, 212, 20, 255);
  myColors[++i] = toFloatColor( 41, 201, 19, 255);
  myColors[++i] = toFloatColor( 40, 185, 17, 255);
  myColors[++i] = toFloatColor( 35, 141, 13, 255);
  myColors[++i] = toFloatColor( 27, 97, 9, 255);
  myColors[++i] = toFloatColor( 27, 97, 9, 255);
  myColors[++i] = toFloatColor( 24, 80, 7, 255);
  myColors[++i] = toFloatColor( 22, 70, 6, 255);
  myColors[++i] = toFloatColor( 24, 70, 6, 255);
  myColors[++i] = toFloatColor( 29, 80, 7, 255);
  myColors[++i] = toFloatColor( 37, 97, 9, 255);
  myColors[++i] = toFloatColor( 47, 117, 11, 255);
  myColors[++i] = toFloatColor( 59, 141, 13, 255);
  myColors[++i] = toFloatColor( 83, 184, 17, 255);
  myColors[++i] = toFloatColor( 94, 201, 19, 255);
  myColors[++i] = toFloatColor(102, 211, 20, 255);
  myColors[++i] = toFloatColor(109, 212, 20, 255);
  myColors[++i] = toFloatColor(109, 212, 20, 255);
  myColors[++i] = toFloatColor(101, 185, 17, 255);
  myColors[++i] = toFloatColor( 93, 164, 15, 255);
  myColors[++i] = toFloatColor( 82, 141, 13, 255);
  myColors[++i] = toFloatColor( 70, 118, 11, 255);
  myColors[++i] = toFloatColor( 60, 97, 9, 255);
  myColors[++i] = toFloatColor( 45, 70, 6, 255);
  myColors[++i] = toFloatColor( 44, 66, 6, 255);
  myColors[++i] = toFloatColor( 47, 70, 6, 255);
  myColors[++i] = toFloatColor( 56, 80, 7, 255);
  myColors[++i] = toFloatColor( 69, 97, 9, 255);
  myColors[++i] = toFloatColor(105, 141, 13, 255);
  myColors[++i] = toFloatColor(125, 164, 15, 255);
  myColors[++i] = toFloatColor(144, 184, 17, 255);
  myColors[++i] = toFloatColor(160, 201, 19, 255);
  myColors[++i] = toFloatColor(172, 211, 20, 255);
  myColors[++i] = toFloatColor(179, 212, 20, 255);
  myColors[++i] = toFloatColor(174, 201, 19, 255);
  myColors[++i] = toFloatColor(163, 185, 17, 255);
  myColors[++i] = toFloatColor(147, 164, 15, 255);
  myColors[++i] = toFloatColor(128, 141, 13, 255);
  myColors[++i] = toFloatColor( 92, 97, 9, 255);
  myColors[++i] = toFloatColor( 68, 70, 6, 255);
  myColors[++i] = toFloatColor( 68, 70, 6, 255);
  myColors[++i] = toFloatColor( 66, 66, 6, 255);
  myColors[++i] = toFloatColor( 70, 69, 6, 255);
  myColors[++i] = toFloatColor( 97, 92, 9, 255);
  myColors[++i] = toFloatColor(117, 110, 11, 255);
  myColors[++i] = toFloatColor(141, 129, 13, 255);
  myColors[++i] = toFloatColor(164, 148, 15, 255);
  myColors[++i] = toFloatColor(184, 164, 17, 255);
  myColors[++i] = toFloatColor(211, 181, 20, 255);
  myColors[++i] = toFloatColor(215, 180, 20, 255);
  myColors[++i] = toFloatColor(212, 174, 20, 255);
  myColors[++i] = toFloatColor(185, 146, 17, 255);
  myColors[++i] = toFloatColor(185, 146, 17, 255);
  myColors[++i] = toFloatColor(141, 106, 13, 255);
  myColors[++i] = toFloatColor(118, 87, 11, 255);
  myColors[++i] = toFloatColor( 97, 70, 9, 255);
  myColors[++i] = toFloatColor( 80, 57, 7, 255);
  myColors[++i] = toFloatColor( 70, 48, 6, 255);
  myColors[++i] = toFloatColor( 70, 46, 6, 255);
  myColors[++i] = toFloatColor( 80, 51, 7, 255);
  myColors[++i] = toFloatColor( 97, 60, 9, 255);
  myColors[++i] = toFloatColor(117, 71, 11, 255);
  myColors[++i] = toFloatColor(141, 83, 13, 255);
  myColors[++i] = toFloatColor(184, 103, 17, 255);
  myColors[++i] = toFloatColor(201, 109, 19, 255);
  myColors[++i] = toFloatColor(211, 111, 20, 255);
  myColors[++i] = toFloatColor(215, 109, 20, 255);
  myColors[++i] = toFloatColor(212, 104, 20, 255);
  myColors[++i] = toFloatColor(185, 85, 17, 255);
  myColors[++i] = toFloatColor(164, 72, 15, 255);
  myColors[++i] = toFloatColor(141, 60, 13, 255);
  myColors[++i] = toFloatColor(118, 48, 11, 255);
  myColors[++i] = toFloatColor( 97, 38, 9, 255);
  myColors[++i] = toFloatColor( 70, 25, 6, 255);
  myColors[++i] = toFloatColor( 70, 22, 6, 255);
  myColors[++i] = toFloatColor( 70, 22, 6, 255);
  myColors[++i] = toFloatColor( 80, 25, 7, 255);
  myColors[++i] = toFloatColor( 97, 28, 9, 255);
  myColors[++i] = toFloatColor(141, 36, 13, 255);
  myColors[++i] = toFloatColor(164, 40, 15, 255);
  myColors[++i] = toFloatColor(184, 42, 17, 255);
  myColors[++i] = toFloatColor(201, 42, 19, 255);
  myColors[++i] = toFloatColor(211, 41, 20, 255);
  myColors[++i] = toFloatColor(212, 34, 20, 255);
  myColors[++i] = toFloatColor(201, 29, 19, 255);
  myColors[++i] = toFloatColor(185, 23, 17, 255);
  myColors[++i] = toFloatColor(164, 18, 15, 255);
  ++i ; // nCol = 214;
  return myColors;
}

const Typ::ColorCreateInfo *
TypColormapDefinitions::getSeismicRedBlue(int& j)
{
  Typ::ColorCreateInfo myColor[256];
  int i=0;
  myColor[i++] = Typ::FloatColor( 0.866697 , 0.000000 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.866697 , 0.000000 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.866697 , 0.000000 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.000000 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.925490 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.917586 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.909789 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.901991 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.894087 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.886290 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.878386 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.870588 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.862699 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.850996 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.839185 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.827497 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.819593 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.803891 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.788190 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.772488 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.756893 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.745098 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.733288 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.721599 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.713695 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.705898 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.697993 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.690196 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.682399 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.674495 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.666697 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.658793 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.650996 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.643091 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.635294 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.627497 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.619593 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.600000 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.580392 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.560800 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.545098 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.537285 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.529397 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.521599 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.513695 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.501991 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.490196 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.478386 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.470588 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.462699 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.454887 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.447089 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.439185 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.431388 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.423499 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.415686 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.407797 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.388190 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.368597 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.348989 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 0.333288 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.984298 , 0.329397 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.968597 , 0.329397 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.952895 , 0.325490 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.941192 , 0.325490 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.925490 , 0.321599 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.909789 , 0.321599 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.894087 , 0.317586 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.882399 , 0.317586 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.866697 , 0.313695 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.850996 , 0.313695 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.835294 , 0.309789 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.823499 , 0.309789 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.807797 , 0.305898 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.792187 , 0.305898 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.776486 , 0.301991 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.764691 , 0.301991 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.748989 , 0.297993 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.733288 , 0.297993 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.717586 , 0.294087 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.705898 , 0.294087 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.690196 , 0.290196 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.674495 , 0.290196 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.658793 , 0.286290 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.647089 , 0.286290 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.635294 , 0.282399 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.623499 , 0.282399 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.611795 , 0.278386 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.603891 , 0.278386 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.588190 , 0.274495 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.572488 , 0.274495 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.556893 , 0.270588 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.545098 , 0.270588 ,0.000000 );
  myColor[i++] = Typ::FloatColor( 0.548989 , 0.286290 ,0.023499 );
  myColor[i++] = Typ::FloatColor( 0.552895 , 0.301991 ,0.047089 );
  myColor[i++] = Typ::FloatColor( 0.556893 , 0.317586 ,0.070588 );
  myColor[i++] = Typ::FloatColor( 0.560800 , 0.329397 ,0.090196 );
  myColor[i++] = Typ::FloatColor( 0.568597 , 0.345098 ,0.113695 );
  myColor[i++] = Typ::FloatColor( 0.576486 , 0.360800 ,0.137285 );
  myColor[i++] = Typ::FloatColor( 0.584298 , 0.376486 ,0.160800 );
  myColor[i++] = Typ::FloatColor( 0.588190 , 0.388190 ,0.184298 );
  myColor[i++] = Typ::FloatColor( 0.596094 , 0.403891 ,0.207797 );
  myColor[i++] = Typ::FloatColor( 0.603891 , 0.419593 ,0.231388 );
  myColor[i++] = Typ::FloatColor( 0.611795 , 0.435294 ,0.254887 );
  myColor[i++] = Typ::FloatColor( 0.619593 , 0.447089 ,0.274495 );
  myColor[i++] = Typ::FloatColor( 0.627497 , 0.458793 ,0.294087 );
  myColor[i++] = Typ::FloatColor( 0.631388 , 0.470588 ,0.309789 );
  myColor[i++] = Typ::FloatColor( 0.635294 , 0.482399 ,0.325490 );
  myColor[i++] = Typ::FloatColor( 0.639185 , 0.490196 ,0.341192 );
  myColor[i++] = Typ::FloatColor( 0.647089 , 0.505898 ,0.364691 );
  myColor[i++] = Typ::FloatColor( 0.654887 , 0.521599 ,0.388190 );
  myColor[i++] = Typ::FloatColor( 0.662699 , 0.537285 ,0.411795 );
  myColor[i++] = Typ::FloatColor( 0.670588 , 0.548989 ,0.431388 );
  myColor[i++] = Typ::FloatColor( 0.678386 , 0.564691 ,0.454887 );
  myColor[i++] = Typ::FloatColor( 0.686290 , 0.580392 ,0.478386 );
  myColor[i++] = Typ::FloatColor( 0.713695 , 0.615686 ,0.521599 );
  myColor[i++] = Typ::FloatColor( 0.737285 , 0.647089 ,0.560800 );
  myColor[i++] = Typ::FloatColor( 0.760800 , 0.678386 ,0.600000 );
  myColor[i++] = Typ::FloatColor( 0.784298 , 0.709789 ,0.639185 );
  myColor[i++] = Typ::FloatColor( 0.807797 , 0.745098 ,0.682399 );
  myColor[i++] = Typ::FloatColor( 0.831388 , 0.776486 ,0.721599 );
  myColor[i++] = Typ::FloatColor( 0.858793 , 0.807797 ,0.760800 );
  myColor[i++] = Typ::FloatColor( 0.882399 , 0.839185 ,0.800000 );
  myColor[i++] = Typ::FloatColor( 0.905898 , 0.874495 ,0.843091 );
  myColor[i++] = Typ::FloatColor( 0.929397 , 0.905898 ,0.882399 );
  myColor[i++] = Typ::FloatColor( 0.952895 , 0.937285 ,0.921599 );
  myColor[i++] = Typ::FloatColor( 0.976486 , 0.968597 ,0.960800 );
  myColor[i++] = Typ::FloatColor( 1.000000 , 1.000000 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.984298 , 0.984298 ,0.988190 );
  myColor[i++] = Typ::FloatColor( 0.972488 , 0.972488 ,0.980392 );
  myColor[i++] = Typ::FloatColor( 0.960800 , 0.960800 ,0.972488 );
  myColor[i++] = Typ::FloatColor( 0.948989 , 0.948989 ,0.964691 );
  myColor[i++] = Typ::FloatColor( 0.937285 , 0.937285 ,0.952895 );
  myColor[i++] = Typ::FloatColor( 0.925490 , 0.925490 ,0.945098 );
  myColor[i++] = Typ::FloatColor( 0.913695 , 0.913695 ,0.937285 );
  myColor[i++] = Typ::FloatColor( 0.901991 , 0.901991 ,0.929397 );
  myColor[i++] = Typ::FloatColor( 0.886290 , 0.886290 ,0.917586 );
  myColor[i++] = Typ::FloatColor( 0.874495 , 0.874495 ,0.909789 );
  myColor[i++] = Typ::FloatColor( 0.862699 , 0.862699 ,0.901991 );
  myColor[i++] = Typ::FloatColor( 0.850996 , 0.850996 ,0.894087 );
  myColor[i++] = Typ::FloatColor( 0.839185 , 0.839185 ,0.882399 );
  myColor[i++] = Typ::FloatColor( 0.827497 , 0.827497 ,0.874495 );
  myColor[i++] = Typ::FloatColor( 0.815686 , 0.815686 ,0.866697 );
  myColor[i++] = Typ::FloatColor( 0.803891 , 0.803891 ,0.858793 );
  myColor[i++] = Typ::FloatColor( 0.788190 , 0.788190 ,0.847089 );
  myColor[i++] = Typ::FloatColor( 0.776486 , 0.776486 ,0.839185 );
  myColor[i++] = Typ::FloatColor( 0.764691 , 0.764691 ,0.831388 );
  myColor[i++] = Typ::FloatColor( 0.752895 , 0.752895 ,0.823499 );
  myColor[i++] = Typ::FloatColor( 0.741192 , 0.741192 ,0.811795 );
  myColor[i++] = Typ::FloatColor( 0.729397 , 0.729397 ,0.803891 );
  myColor[i++] = Typ::FloatColor( 0.717586 , 0.717586 ,0.796094 );
  myColor[i++] = Typ::FloatColor( 0.705898 , 0.705898 ,0.788190 );
  myColor[i++] = Typ::FloatColor( 0.682399 , 0.682399 ,0.784298 );
  myColor[i++] = Typ::FloatColor( 0.662699 , 0.658793 ,0.780392 );
  myColor[i++] = Typ::FloatColor( 0.639185 , 0.635294 ,0.780392 );
  myColor[i++] = Typ::FloatColor( 0.615686 , 0.615686 ,0.776486 );
  myColor[i++] = Typ::FloatColor( 0.592187 , 0.592187 ,0.772488 );
  myColor[i++] = Typ::FloatColor( 0.568597 , 0.568597 ,0.772488 );
  myColor[i++] = Typ::FloatColor( 0.548989 , 0.545098 ,0.768597 );
  myColor[i++] = Typ::FloatColor( 0.525490 , 0.521599 ,0.764691 );
  myColor[i++] = Typ::FloatColor( 0.501991 , 0.497993 ,0.764691 );
  myColor[i++] = Typ::FloatColor( 0.478386 , 0.474495 ,0.760800 );
  myColor[i++] = Typ::FloatColor( 0.454887 , 0.450996 ,0.756893 );
  myColor[i++] = Typ::FloatColor( 0.435294 , 0.431388 ,0.756893 );
  myColor[i++] = Typ::FloatColor( 0.411795 , 0.407797 ,0.752895 );
  myColor[i++] = Typ::FloatColor( 0.388190 , 0.384298 ,0.748989 );
  myColor[i++] = Typ::FloatColor( 0.364691 , 0.360800 ,0.748989 );
  myColor[i++] = Typ::FloatColor( 0.341192 , 0.337285 ,0.745098 );
  myColor[i++] = Typ::FloatColor( 0.321599 , 0.313695 ,0.741192 );
  myColor[i++] = Typ::FloatColor( 0.297993 , 0.290196 ,0.741192 );
  myColor[i++] = Typ::FloatColor( 0.274495 , 0.266697 ,0.737285 );
  myColor[i++] = Typ::FloatColor( 0.250996 , 0.247059 ,0.733288 );
  myColor[i++] = Typ::FloatColor( 0.227497 , 0.223499 ,0.733288 );
  myColor[i++] = Typ::FloatColor( 0.207797 , 0.200000 ,0.729397 );
  myColor[i++] = Typ::FloatColor( 0.184298 , 0.176486 ,0.725490 );
  myColor[i++] = Typ::FloatColor( 0.160800 , 0.152895 ,0.725490 );
  myColor[i++] = Typ::FloatColor( 0.137285 , 0.129397 ,0.721599 );
  myColor[i++] = Typ::FloatColor( 0.113695 , 0.105898 ,0.717586 );
  myColor[i++] = Typ::FloatColor( 0.094087 , 0.086290 ,0.717586 );
  myColor[i++] = Typ::FloatColor( 0.086290 , 0.078386 ,0.741192 );
  myColor[i++] = Typ::FloatColor( 0.078386 , 0.074495 ,0.764691 );
  myColor[i++] = Typ::FloatColor( 0.066697 , 0.062669 ,0.792187 );
  myColor[i++] = Typ::FloatColor( 0.058793 , 0.054887 ,0.819593 );
  myColor[i++] = Typ::FloatColor( 0.050996 , 0.047089 ,0.847089 );
  myColor[i++] = Typ::FloatColor( 0.043091 , 0.039185 ,0.870588 );
  myColor[i++] = Typ::FloatColor( 0.031388 , 0.031388 ,0.897993 );
  myColor[i++] = Typ::FloatColor( 0.023499 , 0.023499 ,0.925490 );
  myColor[i++] = Typ::FloatColor( 0.015686 , 0.015686 ,0.952895 );
  myColor[i++] = Typ::FloatColor( 0.007797 , 0.007797 ,0.976486 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.023499 ,0.980392 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.039185 ,0.980392 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.050996 ,0.980392 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.066697 ,0.980392 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.082399 ,0.984298 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.094087 ,0.984298 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.109789 ,0.984298 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.125490 ,0.984298 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.137285 ,0.984298 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.152895 ,0.988190 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.168597 ,0.988190 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.180392 ,0.988190 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.196094 ,0.988190 );
  myColor[i++] = Typ::FloatColor( 0.003861 , 0.207797 ,0.988190 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.223499 ,0.992187 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.239185 ,0.992187 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.250996 ,0.992187 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.266697 ,0.992187 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.282399 ,0.996094 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.294087 ,0.996094 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.309789 ,0.996094 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.325490 ,0.996094 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.337285 ,0.996094 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.352895 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.368597 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.380392 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.396094 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.407797 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.423499 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.439185 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.454887 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.470588 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.486290 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.501991 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.517586 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.529397 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.545098 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.560800 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.576486 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.592187 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.607797 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.623499 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.639185 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.650996 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.666697 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.682399 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.697993 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.713695 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.729397 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.745098 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.760800 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.772488 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.788190 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.803891 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.819593 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.835294 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.850996 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.866697 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.882399 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.894087 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.909789 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.925490 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.941192 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.000000 , 0.956893 ,1.000000 );
  myColor[i++] = Typ::FloatColor( 0.427497 , 0.000000 ,0.713695 );
  myColor[i++] = Typ::FloatColor( 0.427497 , 0.000000 ,0.713695 );
  myColor[i++] = Typ::FloatColor( 0.427497 , 0.000000 ,0.713695 );
  // i = 256
  const Typ::ColorCreateInfo *temp_color=interpolateColors(myColor,i,Typ::MAXIMUM_NUMBER_OF_COLORS);
  for (int k=0;k<Typ::MAXIMUM_NUMBER_OF_COLORS; k++)
    {
      myColors[k]=temp_color[k];
    }
  j=Typ::MAXIMUM_NUMBER_OF_COLORS;
  return myColors;

}

// from CRW-15348 comments include reference to Isochron42.txt from which the data below has been taken
const Typ::ColorCreateInfo * TypColormapDefinitions::getGeoVel( int& numberOfColors , int zeroColor )
{
  float mult = 1 ; mult /= 100 ;

  struct 
  { 
    int myRed; 
    int myGreen; 
    int myBlue; 
  } rgbValuesStruct[] = 
  {
    {107, 0, 0},
    {120, 0, 0},
    {137, 5, 0},
    {154, 10, 0},
    {171, 15, 0},
    {188, 20, 0},
    {205, 25, 0},
    {222, 30, 0},
    {239, 35, 0},
    {255, 40, 0},
    {255, 76, 0},
    {255, 112, 0},
    {255, 148, 0},
    {255, 184, 0},
    {255, 220, 0},
    {255, 255, 0},
    {168, 255, 0},
    {81, 255, 0},
    {60, 235, 0},
    {40, 215, 0},
    {20, 195, 0},
    {1, 183, 28},
    {2, 192, 56},
    {4, 201, 85},
    {5, 210, 113},
    {6, 219, 142},
    {8, 228, 170},
    {9, 237, 199},
    {10, 246, 227},
    {12, 255, 255},
    {10, 227, 255},
    {9, 199, 255},
    {7, 170, 255},
    {6, 142, 255},
    {4, 113, 255},
    {3, 85, 255},
    {1, 56, 255},
    {0, 28, 255},
    {26, 21, 238},
    {52, 14, 220},
    {78, 7, 202},
    {104, 0, 184}
  };
  int ncols = (sizeof(rgbValuesStruct) / sizeof(rgbValuesStruct[0]));

  numberOfColors = 0;
  for ( int i=0 ; i < ncols ; ++i ) {
    myColors[numberOfColors++] = Typ::FloatColor( (double)rgbValuesStruct[i].myRed   / 255.0 ,
                                               (double)rgbValuesStruct[i].myGreen / 255.0 ,
                                               (double)rgbValuesStruct[i].myBlue  / 255.0 );
  }
  if ( 0 <= zeroColor && zeroColor < ncols ) {
    myColors[ zeroColor ] = Typ::FloatColor( 1.0 , 1.0 , 1.0 ) ;
  }
  return myColors;
}


const Typ::ColorCreateInfo * TypColormapDefinitions::getBP_Aberdeen(int & numberOfColors)
{
	// ;
	numberOfColors = 65;
	
	int i = 0;     
    myColors[i]   = toFloatColor(238,  0,   0, 255 );
    myColors[++i] = toFloatColor(220,	19,	0,	255 );
    myColors[++i] = toFloatColor(203,	38,	0,	255 );
    myColors[++i] = toFloatColor(186,	57,	0,	255 );
    myColors[++i] = toFloatColor(169,	76,	0,	255 );
    myColors[++i] = toFloatColor(152,	95,	0,	255 );
    myColors[++i] = toFloatColor(134,	114,	0,	255 );
    myColors[++i] = toFloatColor(117,	133,	0,	255 );
    myColors[++i] = toFloatColor(137,	133,	0,	255 );
    myColors[++i] = toFloatColor(157,	133,	0,	255 );
    myColors[++i] = toFloatColor(177,	133,	0,	255 );
    myColors[++i] = toFloatColor(196,	133,	0,	255 );
    myColors[++i] = toFloatColor(216,	133,	0,	255 );
    myColors[++i] = toFloatColor(236,	133,	0,	255 );
    myColors[++i] = toFloatColor(255,	133,	0,	255 );
    myColors[++i] = toFloatColor(255,	127,	0,	255 );
    myColors[++i] = toFloatColor(255,	135,	0,	255 );
    myColors[++i] = toFloatColor(255,	144,	0,	255 );
    myColors[++i] = toFloatColor(255,	153,	0,	255 );
    myColors[++i] = toFloatColor(255,	161,	0,	255	);
    myColors[++i] = toFloatColor(245,	170,	0,	255	);
    myColors[++i] = toFloatColor(255,	179,	0,	255	);
    myColors[++i] = toFloatColor(255,	186,	0,	255	);
    myColors[++i] = toFloatColor(255,	193,	0,	255	);
    myColors[++i] = toFloatColor(255,	201,	27,	255	);
    myColors[++i] = toFloatColor(255,	208,	55,	255	);
    myColors[++i] = toFloatColor(255,	215,	82,	255	);
    myColors[++i] = toFloatColor(255,	223,	110,	255	);
    myColors[++i] = toFloatColor(255,	230,	139,	255	);
    myColors[++i] = toFloatColor(248,	236,	168,	255	);
    myColors[++i] = toFloatColor(255,	241,	197,	255	);
    myColors[++i] = toFloatColor(255,	247,	226,	255	);
    myColors[++i] = toFloatColor(255,	253,	255,	255	);
    myColors[++i] = toFloatColor(231,	249,	226,	255	);
    myColors[++i] = toFloatColor(206,	245,	197,	255	);
    myColors[++i] = toFloatColor(181,	235,	167,	255	);
    myColors[++i] = toFloatColor(157,	226,	138,	255	);
    myColors[++i] = toFloatColor(132,	216,	96,	255	);
    myColors[++i] = toFloatColor(107,	206,	54,	255	);
    myColors[++i] = toFloatColor(90,	196,	12,	255	);
    myColors[++i] = toFloatColor(74,	186,	56,	255	);
    myColors[++i] = toFloatColor(49,	176,	65,	255	);
    myColors[++i] = toFloatColor(24,	168,	74,	255	);
    myColors[++i] = toFloatColor(0,	159,	83,	255	);
    myColors[++i] = toFloatColor(0,	151,	92,	255	);
    myColors[++i] = toFloatColor(0,	143,	100,	255	);
    myColors[++i] = toFloatColor(0,	134,	108,	255	);
    myColors[++i] = toFloatColor(0,	126,	117,	255	);
    myColors[++i] = toFloatColor(0,	117,	125,	255	);
    myColors[++i] = toFloatColor(0,	109,	134,	255	);
    myColors[++i] = toFloatColor(0,	101,	143,	255	);
    myColors[++i] = toFloatColor(0,	92,	152,	255	);
    myColors[++i] = toFloatColor(0,	84,	161,	255	);
    myColors[++i] = toFloatColor(0,	86,	171,	255	);
    myColors[++i] = toFloatColor(13,	87,	167,	255	);
    myColors[++i] = toFloatColor(27,	89,	163,	255	);
    myColors[++i] = toFloatColor(41,	91,	162,	255	);
    myColors[++i] = toFloatColor(54,	93,	161,	255	);
    myColors[++i] = toFloatColor(68,	94,	159,	255	);
    myColors[++i] = toFloatColor(82,	95,	158,	255	);
    myColors[++i] = toFloatColor(96,	97,	157,	255	);
    myColors[++i] = toFloatColor(109,	98,	155,	255	);
    myColors[++i] = toFloatColor(123,	99,	153,	255	);
    myColors[++i] = toFloatColor(137,	101,	153,255	);
    myColors[++i] = toFloatColor(151,	102,	153,	255	);

	assert( ++i == numberOfColors );

	return myColors;
}

/*static*/ const Typ::ColorCreateInfo * TypColormapDefinitions::getAngle4(int & numberOfColors)
{
	// 
	numberOfColors = 45;
	
	int i = 0;     
    myColors[i]   = toFloatColor(0, 0, 255, 255);
    myColors[++i] = toFloatColor(25, 63, 255, 255);
    myColors[++i] = toFloatColor(51, 127, 255, 255);
    myColors[++i] = toFloatColor(76 ,191, 255 ,255);
    myColors[++i] = toFloatColor(102, 255, 255, 255);
    myColors[++i] = toFloatColor(255, 0, 0, 255);
    myColors[++i] = toFloatColor(255, 51, 51, 255);
    myColors[++i] = toFloatColor(255, 102, 102, 255);
    myColors[++i] = toFloatColor(255, 153, 153, 255);
    myColors[++i] = toFloatColor(255, 204, 204, 255);
    myColors[++i] = toFloatColor(0, 153, 0, 255);
    myColors[++i] = toFloatColor(38, 178, 38, 255);
    myColors[++i] = toFloatColor(76, 204, 76, 255);
    myColors[++i] = toFloatColor(114, 229, 114, 255);
    myColors[++i] = toFloatColor(153, 255, 153 ,255);
    myColors[++i] = toFloatColor(255, 153, 0, 255);
    myColors[++i] = toFloatColor(255, 178, 38, 255);
    myColors[++i] = toFloatColor(255, 204, 76, 255);
    myColors[++i] = toFloatColor(255, 229, 114, 255);
    myColors[++i] = toFloatColor(255, 255, 153 ,255);
    myColors[++i] = toFloatColor(130, 17, 17, 255);
    myColors[++i] = toFloatColor(147, 56, 55, 255);
    myColors[++i] = toFloatColor(164, 95, 93, 255);
    myColors[++i] = toFloatColor(181, 134, 131, 255);
    myColors[++i] = toFloatColor(198, 174, 170, 255);
    myColors[++i] = toFloatColor(200, 0, 210, 255);
    myColors[++i] = toFloatColor(210, 45, 217, 255);
    myColors[++i] = toFloatColor(220, 90, 225, 255);
    myColors[++i] = toFloatColor(230, 135, 232, 255);
    myColors[++i] = toFloatColor(240, 180, 240, 255);
    myColors[++i] = toFloatColor(102, 102, 102, 255);
    myColors[++i] = toFloatColor(140, 140, 140, 255);
    myColors[++i] = toFloatColor(178, 178, 178, 255);
    myColors[++i] = toFloatColor(216, 216, 216, 255);
    myColors[++i] = toFloatColor(255, 255, 255, 255);
    myColors[++i] = toFloatColor(102, 102, 0, 255);
    myColors[++i] = toFloatColor(127, 127, 0, 255);
    myColors[++i] = toFloatColor(153, 153, 0, 255);
    myColors[++i] = toFloatColor(178, 178, 0, 255);
    myColors[++i] = toFloatColor(204 ,204, 0, 255);
    myColors[++i] = toFloatColor(0, 102, 102, 255);
    myColors[++i] = toFloatColor(0, 127, 127, 255);
    myColors[++i] = toFloatColor(0, 153, 153, 255);
    myColors[++i] = toFloatColor(0 ,178, 178, 255);
    myColors[++i] = toFloatColor(0, 204, 204, 255);	

	assert( ++i == numberOfColors );

	return myColors;
}

/*static*/ const Typ::ColorCreateInfo * TypColormapDefinitions::getAngle3(int & numberOfColors)
{
	// 
	numberOfColors = 12;
	
	int i = 0; 
    myColors[i] =   toFloatColor(11796, 34733,     0);
    myColors[++i] = toFloatColor(65535,  8519, 51772);
    myColors[++i] = toFloatColor(61602, 57015,     0);
    myColors[++i] = toFloatColor(64224, 65535, 25558);
    myColors[++i] = toFloatColor(32112, 42597, 51117);
    myColors[++i] = toFloatColor(60947, 41942, 41287);
    myColors[++i] = toFloatColor(65535, 65535, 65535);
    myColors[++i] = toFloatColor(26869, 19660, 17039);
    myColors[++i] = toFloatColor(47840, 26214, 13107);
    myColors[++i] = toFloatColor(2621,     0 ,    0);
    myColors[++i] = toFloatColor(7864, 40631, 44563);
    myColors[++i] = toFloatColor(6553, 21626, 65535 );  

	assert( ++i == numberOfColors );

	return myColors;
}

const Typ::ColorCreateInfo * TypColormapDefinitions::getBWGreyScale65(int & numberOfColors)
{
  numberOfColors = 65;
	
  int i = 0; 
  myColors[i]   = toFloatColor( 0, 0, 0 );
  myColors[++i] = toFloatColor( 1023, 1023, 1023 );
  myColors[++i] = toFloatColor( 2047, 2047, 2047 );
  myColors[++i] = toFloatColor( 3071, 3071, 3071 );
  myColors[++i] = toFloatColor( 4095, 4095, 4095 );
  myColors[++i] = toFloatColor( 5119, 5119, 5119 );
  myColors[++i] = toFloatColor( 6143, 6143, 6143 );
  myColors[++i] = toFloatColor( 7167, 7167, 7167 );
  myColors[++i] = toFloatColor( 8191, 8191, 8191 );
  myColors[++i] = toFloatColor( 9215, 9215, 9215 );
  myColors[++i] = toFloatColor( 10239, 10239, 10239 );
  myColors[++i] = toFloatColor( 11263, 11263, 11263 );
  myColors[++i] = toFloatColor( 12287, 12287, 12287 );
  myColors[++i] = toFloatColor( 13311, 13311, 13311 );
  myColors[++i] = toFloatColor( 14335, 14335, 14335 );
  myColors[++i] = toFloatColor( 15359, 15359, 15359 );
  myColors[++i] = toFloatColor( 16383, 16383, 16383 );
  myColors[++i] = toFloatColor( 17407, 17407, 17407 );
  myColors[++i] = toFloatColor( 18431, 18431, 18431 );
  myColors[++i] = toFloatColor( 19455, 19455, 19455 );
  myColors[++i] = toFloatColor( 20479, 20479, 20479 );
  myColors[++i] = toFloatColor( 21503, 21503, 21503 );
  myColors[++i] = toFloatColor( 22527, 22527, 22527 );
  myColors[++i] = toFloatColor( 23551, 23551, 23551 );
  myColors[++i] = toFloatColor( 24575, 24575, 24575 );
  myColors[++i] = toFloatColor( 25599, 25599, 25599 );
  myColors[++i] = toFloatColor( 26623, 26623, 26623 );
  myColors[++i] = toFloatColor( 27647, 27647, 27647 );
  myColors[++i] = toFloatColor( 28671, 28671, 28671 );
  myColors[++i] = toFloatColor( 29695, 29695, 29695 );
  myColors[++i] = toFloatColor( 30719, 30719, 30719 );
  myColors[++i] = toFloatColor( 31743, 31743, 31743 );
  myColors[++i] = toFloatColor( 32767, 32767, 32767 );
  myColors[++i] = toFloatColor( 33791, 33791, 33791 );
  myColors[++i] = toFloatColor( 34815, 34815, 34815 );
  myColors[++i] = toFloatColor( 35839, 35839, 35839 );
  myColors[++i] = toFloatColor( 36863, 36863, 36863 );
  myColors[++i] = toFloatColor( 37887, 37887, 37887 );
  myColors[++i] = toFloatColor( 38911, 38911, 38911 );
  myColors[++i] = toFloatColor( 39935, 39935, 39935 );
  myColors[++i] = toFloatColor( 40959, 40959, 40959 );
  myColors[++i] = toFloatColor( 41983, 41983, 41983 );
  myColors[++i] = toFloatColor( 43007, 43007, 43007 );
  myColors[++i] = toFloatColor( 44031, 44031, 44031 );
  myColors[++i] = toFloatColor( 45055, 45055, 45055 );
  myColors[++i] = toFloatColor( 46079, 46079, 46079 );
  myColors[++i] = toFloatColor( 47103, 47103, 47103 );
  myColors[++i] = toFloatColor( 48127, 48127, 48127 );
  myColors[++i] = toFloatColor( 49151, 49151, 49151 );
  myColors[++i] = toFloatColor( 50175, 50175, 50175 );
  myColors[++i] = toFloatColor( 51199, 51199, 51199 );
  myColors[++i] = toFloatColor( 52223, 52223, 52223 );
  myColors[++i] = toFloatColor( 53247, 53247, 53247 );
  myColors[++i] = toFloatColor( 54271, 54271, 54271 );
  myColors[++i] = toFloatColor( 55295, 55295, 55295 );
  myColors[++i] = toFloatColor( 56319, 56319, 56319 );
  myColors[++i] = toFloatColor( 57343, 57343, 57343 );
  myColors[++i] = toFloatColor( 58367, 58367, 58367 );
  myColors[++i] = toFloatColor( 59391, 59391, 59391 );
  myColors[++i] = toFloatColor( 60415, 60415, 60415 );
  myColors[++i] = toFloatColor( 61439, 61439, 61439 );
  myColors[++i] = toFloatColor( 62463, 62463, 62463 );
  myColors[++i] = toFloatColor( 63487, 63487, 63487 );
  myColors[++i] = toFloatColor( 64511, 64511, 64511 );
  myColors[++i] = toFloatColor( 65535, 65535, 65535 );

  assert( ++i == numberOfColors );
  return myColors;
}



/*static*/ const Typ::ColorCreateInfo *TypColormapDefinitions::getBpRms(int & numberOfColors)
{
	// 
	numberOfColors = 32;
	
	int i = 0;
   myColors[i++] = toFloatColor(	64250	,	65535	,	65535	);
   myColors[i++] = toFloatColor(	64250	,	11051	,	2570	);
   myColors[i++] = toFloatColor(	64250	,	17219	,	3084	);
   myColors[i++] = toFloatColor(	64250	,	23130	,	3598	);
   myColors[i++] = toFloatColor(	64250	,	29298	,	4112	);
   myColors[i++] = toFloatColor(	64250	,	35209	,	4626	);
   myColors[i++] = toFloatColor(	64250	,	41377	,	5140	);
   myColors[i++] = toFloatColor(	64250	,	47545	,	5654	);
   myColors[i++] = toFloatColor(	64250	,	53456	,	6168	);
   myColors[i++] = toFloatColor(	64250	,	59624	,	6682	);
   myColors[i++] = toFloatColor(	64250	,	65535	,	7196	);
   myColors[i++] = toFloatColor(	61680	,	64507	,	7710	);
   myColors[i++] = toFloatColor(	58853	,	63222	,	8224	);
   myColors[i++] = toFloatColor(	56026	,	61937	,	8738	);
   myColors[i++] = toFloatColor(	53199	,	60652	,	9252	);
   myColors[i++] = toFloatColor(	50629	,	59367	,	9766	);
   myColors[i++] = toFloatColor(	47802	,	58082	,	10280	);
   myColors[i++] = toFloatColor(	44975	,	56797	,	11051	);
   myColors[i++] = toFloatColor(	42405	,	55512	,	11565	);
   myColors[i++] = toFloatColor(	39578	,	54484	,	12079	);
   myColors[i++] = toFloatColor(	36751	,	53199	,	12593	);
   myColors[i++] = toFloatColor(	33924	,	51914	,	13107	);
   myColors[i++] = toFloatColor(	31354	,	48830	,	18247	);
   myColors[i++] = toFloatColor(	28527	,	45746	,	23644	);
   myColors[i++] = toFloatColor(	25700	,	42662	,	28784	);
   myColors[i++] = toFloatColor(	22873	,	39835	,	34181	);
   myColors[i++] = toFloatColor(	20303	,	36751	,	39321	);
   myColors[i++] = toFloatColor(	17476	,	33667	,	44718	);
   myColors[i++] = toFloatColor(	14649	,	30583	,	49858	);
   myColors[i++] = toFloatColor(	12079	,	27756	,	55255	);
   myColors[i++] = toFloatColor(	9252	,	24672	,	60395	);
   myColors[i++] = toFloatColor(	6425	,	21588	,	65535	);
	
	assert( i == numberOfColors );
	
	return myColors;
	
}



/*static*/ const Typ::ColorCreateInfo *TypColormapDefinitions::getBpNormalisedRms( int & numberOfColors )
{
  // 
  numberOfColors = 32;
  
  int i = 0;
  myColors[i++] = toFloatColor(	27499	,	15677	,	19532	);
  myColors[i++] = toFloatColor(	30069	,	15677	,	28270	);
  myColors[i++] = toFloatColor(	28270	,	8995	,	40092	);
  myColors[i++] = toFloatColor(	25443	,	2570	,	48573	);
  myColors[i++] = toFloatColor(	0	,	1799	,	51143	);
  myColors[i++] = toFloatColor(	0	,	514	,	55255	);
  myColors[i++] = toFloatColor(	0	,	1285	,	59624	);
  myColors[i++] = toFloatColor(	0	,	0	,	65535	);
  myColors[i++] = toFloatColor(	0	,	24158	,	0	);
  myColors[i++] = toFloatColor(	3084	,	32125	,	0	);
  myColors[i++] = toFloatColor(	6425	,	37265	,	0	);
  myColors[i++] = toFloatColor(	8995	,	41377	,	0	);
  myColors[i++] = toFloatColor(	13107	,	44718	,	1285	);
  myColors[i++] = toFloatColor(	19018	,	48573	,	1799	);
  myColors[i++] = toFloatColor(	24929	,	51914	,	3855	);
  myColors[i++] = toFloatColor(	32639	,	58339	,	4369	);
  myColors[i++] = toFloatColor(	52428	,	65535	,	6425	);
  myColors[i++] = toFloatColor(	54484	,	64250	,	7196	);
  myColors[i++] = toFloatColor(	59624	,	61166	,	5140	);
  myColors[i++] = toFloatColor(	60395	,	55769	,	0	);
  myColors[i++] = toFloatColor(	61680	,	48573	,	0	);
  myColors[i++] = toFloatColor(	62965	,	44718	,	0	);
  myColors[i++] = toFloatColor(	65535	,	40606	,	0	);
  myColors[i++] = toFloatColor(	65535	,	26214	,	0	);
  myColors[i++] = toFloatColor(	65535	,	28270	,	0	);
  myColors[i++] = toFloatColor(	65535	,	28784	,	0	);
  myColors[i++] = toFloatColor(	65535	,	514	,	514	);
  myColors[i++] = toFloatColor(	65535	,	7196	,	17733	);
  myColors[i++] = toFloatColor(	65535	,	16191	,	29555	);
  myColors[i++] = toFloatColor(	65535	,	34181	,	43947	);
  myColors[i++] = toFloatColor(	65535	,	50629	,	55769	);
  myColors[i++] = toFloatColor(	65535	,	65535	,	65535	);
  
  assert( i == numberOfColors );
  
  return myColors;
}



/*static*/ const Typ::ColorCreateInfo *TypColormapDefinitions::getBpRmsRatio(int & numberOfColors )
{
  // 
  numberOfColors = 35;

  int i = 0 ;
  myColors[i++] = toFloatColor(	253	,	255	,	255	,	255	);
  myColors[i++] = toFloatColor(	184	,	89	,	253	,	255	);
  myColors[i++] = toFloatColor(	138	,	67	,	254	,	255	);
  myColors[i++] = toFloatColor(	92	,	44	,	254	,	255	);
  myColors[i++] = toFloatColor(	46	,	22	,	255	,	255	);
  myColors[i++] = toFloatColor(	0	,	0	,	255	,	255	);
  myColors[i++] = toFloatColor(	0	,	19	,	214	,	255	);
  myColors[i++] = toFloatColor(	0	,	39	,	172	,	255	);
  myColors[i++] = toFloatColor(	0	,	58	,	130	,	255	);
  myColors[i++] = toFloatColor(	0	,	78	,	88	,	255	);
  myColors[i++] = toFloatColor(	0	,	98	,	46	,	255	);
  myColors[i++] = toFloatColor(	0	,	117	,	5	,	255	);
  myColors[i++] = toFloatColor(	44	,	141	,	49	,	255	);
  myColors[i++] = toFloatColor(	88	,	164	,	93	,	255	);
  myColors[i++] = toFloatColor(	132	,	188	,	137	,	255	);
  myColors[i++] = toFloatColor(	176	,	211	,	181	,	255	);
  myColors[i++] = toFloatColor(	220	,	235	,	225	,	255	);
  myColors[i++] = toFloatColor(	255	,	255	,	161	,	255	);
  myColors[i++] = toFloatColor(	232	,	238	,	235	,	255	);
  myColors[i++] = toFloatColor(	210	,	215	,	215	,	255	);
  myColors[i++] = toFloatColor(	187	,	193	,	194	,	255	);
  myColors[i++] = toFloatColor(	165	,	170	,	174	,	255	);
  myColors[i++] = toFloatColor(	142	,	147	,	153	,	255	);
  myColors[i++] = toFloatColor(	120	,	125	,	133	,	255	);
  myColors[i++] = toFloatColor(	142	,	104	,	110	,	255	);
  myColors[i++] = toFloatColor(	164	,	83	,	88	,	255	);
  myColors[i++] = toFloatColor(	186	,	62	,	66	,	255	);
  myColors[i++] = toFloatColor(	209	,	41	,	44	,	255	);
  myColors[i++] = toFloatColor(	231	,	20	,	22	,	255	);
  myColors[i++] = toFloatColor(	253	,	0	,	0	,	255	);
  myColors[i++] = toFloatColor(	202	,	0	,	0	,	255	);
  myColors[i++] = toFloatColor(	152	,	0	,	0	,	255	);
  myColors[i++] = toFloatColor(	101	,	0	,	0	,	255	);
  myColors[i++] = toFloatColor(	50	,	0	,	0	,	255	);
  myColors[i++] = toFloatColor(	0	,	0	,	0	,	255	);
  
  assert( i == numberOfColors );
  return myColors;
}


//===============================================================================================
//===============================================================================================
//===============================================================================================
// ****    ACCESS TO THE COLORMAPS
//===============================================================================================
//===============================================================================================
//===============================================================================================


Typ::ColorCreateInfo TypColormapDefinitions::myColors            [ Typ::MAXIMUM_NUMBER_OF_COLORS ];
Typ::ColorCreateInfo TypColormapDefinitions::myInterpolatedColors[ Typ::MAXIMUM_NUMBER_OF_COLORS ];
Typ::ColormapInfo   TypColormapDefinitions::myColormapInfos[] = {
  /***** COL_TYPE_FIXED_COLOR *****/ // Interval was never defined for the 'COL_TYPE_FIXED_COLOR'
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_SEGCOLORMAP            , TypColormapDefinitions::getSEGColormap            , "SEG Colormap"              , "SEGColormap"            ,  64 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_SEGFUCHSIABANDS        , TypColormapDefinitions::getSEGFuchsiaBands        , "SEG Fuchsia Bands"         , "SEGFuchsiaBands"        ,  64 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BGRCONTRASTBANDS       , TypColormapDefinitions::getBGRContrastBands       , "Banded BGR 1"              , "BandedBGR1"             , 101 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BGRCONTRASTBANDS2      , TypColormapDefinitions::getBGRContrastBands2      , "Banded BGR 2"              , "BandedBGR2"             , 101 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BANDEDRAINBOW          , TypColormapDefinitions::getBandedRainbow          , "Banded Rainbow"            , "BandedRainbow"          ,  21 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_WHITEANCHOREDRAINBOW   , TypColormapDefinitions::getWhiteAnchoredRainbow   , "White-Anchored Rainbow"    , "WhiteAnchoredRainbow"   ,  31 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_RAINBOXMIX             , TypColormapDefinitions::getRainbowMix             , "Rainbow Mix"               , "RainbowMix"             ,  21 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_IPGMAP                 , TypColormapDefinitions::getIPGMap                 , "IPG Map"                   , "IPGMap"                 ,  21 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_ILLUMINATEDEXTREMES    , TypColormapDefinitions::getIlluminatedExtremes    , "Illuminated Extremes"      , "IlluminatedExtremes"    ,  65 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_HIGHLIGHTEDEXTREMES    , TypColormapDefinitions::getHighlightedExtremes    , "Highlighted Extremes"      , "HighlightedExtremes"    ,  25 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_LANDMARK               , TypColormapDefinitions::getLandmark               , "Landmark"                  , "Landmark"               ,  52 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_ROLLINGRAMPS           , TypColormapDefinitions::getRollingRamps           , "Rolling Ramps"             , "RollingRamps"           ,  33 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_CRAZYZEBRA             , TypColormapDefinitions::getCrazyZebra             , "Crazy Zebra"               , "CrazyZebra"             ,  25 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BLUERAINBOW            , TypColormapDefinitions::getBlueRainbow            , "Blue Shift"                , "BlueShift"              , 129 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BLUESQUEEZE            , TypColormapDefinitions::getBlueSqueeze            , "Blue Squeeze"              , "BlueSqueeze"            , 129 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BANDEDTIEDYE           , TypColormapDefinitions::getBandedTieDye           , "Banded Tie Dye"            , "BandedTieDye"           , 101 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_PURPLEHAZE             , TypColormapDefinitions::getPurpleHaze             , "Purple Haze"               , "PurpleHaze"             ,  65 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BLUEGREYRED            , TypColormapDefinitions::getBlueGreyRed            , "Blue Grey Red"             , "BlueGreyRed"            ,  21 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BLUEYELLOWRED          , TypColormapDefinitions::getBlueYellowRed          , "Blue Yellow Red"           , "BlueYellowRed"          ,  31 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_SMALLTIGER             , TypColormapDefinitions::getSmallTiger             , "Small Tiger"               , "SmallTiger"             ,  21 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BIGTIGER               , TypColormapDefinitions::getBigTiger               , "Big Tiger"                 , "BigTiger"               ,  65 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_SICKTIGER              , TypColormapDefinitions::getSickTiger              , "Sick Tiger"                , "SickTiger"              ,  65 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_PERTURBATION           , TypColormapDefinitions::getPerturbation           , "Perturbation"              , "Perturbation"           ,  64 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_PRIMARYCOLORS          , TypColormapDefinitions::getPrimaryColors          , "Primary Colors"            , "PrimaryColors"          ,   8 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_STEP145AMPD            , TypColormapDefinitions::getStep145Ampd            , "Step145Ampd"               , "Step145Ampd"            , 145 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_SEMBLANCESPECTRUM      , TypColormapDefinitions::getSemblanceSpectrum      , "Semblance Spectrum"        , "SemblanceSpectrum"      , 211 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_ACQUISITIONFOLDOFCOVER , TypColormapDefinitions::getAcquisitionFoldOfCover , "Acquisition Fold of Cover" , "AcquisitionFoldOfCover" ,  11 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_FOLDMAP                , TypColormapDefinitions::getFoldMap                , "Fold Map"                  , "FoldMap"                ,  19 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_VOXELGEO               , TypColormapDefinitions::getVoxelGeo               , "VoxelGeo"                  , "VoxelGeo"               , 128 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_SMALLVORTEX            , TypColormapDefinitions::getSmallVortex            , "Small Vortex"              , "SmallVortex"            ,  32 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BIGVORTEX              , TypColormapDefinitions::getBigVortex              , "Large Vortex"              , "LargeVortex"            , 128 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_GEOVEL                 , TypColormapDefinitions::getGeoVel                 , "Geo Vel"                   , "GeoVel"                 ,  42 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_REDWBLK                , TypColormapDefinitions::getRedWblk                , "RedWblk"                   , "RedWblk"                ,  24 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_ANGLE45DIP60           , TypColormapDefinitions::getAngle45Dip60           , "Angle45Dip60"              , "Angle45Dip60"           ,  45 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BANDEDRGV              , TypColormapDefinitions::getBandedRGV              , "Banded RGV"                , "BandedRGV"              , 214 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BP_ABERDEEN            , TypColormapDefinitions::getBP_Aberdeen            , "BP Aberdeen"               , "BPAberdeen"             ,  65 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_ANGLE3                 , TypColormapDefinitions::getAngle3                 , "Angle 3"                   , "Angle3"                 ,  12 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_ANGLE4                 , TypColormapDefinitions::getAngle4                 , "Angle 4"                   , "Angle4"                 ,  45 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_STANDARD_WINDOWS       , TypColormapDefinitions::getStandardWindows        , "Standard Windows"          , "StandardWindows"        ,  16 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_GRAYSCALE_65           , TypColormapDefinitions::getBWGreyScale65          , "Black->White 65"           , "BlackWhite65"           ,  65 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_SEISMICREDBLUE         , TypColormapDefinitions::getSeismicRedBlue         , "Seismic Red Blue"          , "SeismicRedBlue"         , 216 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BP_RMS                 , TypColormapDefinitions::getBpRms                  , "BP RMS"                    , "BPRMS"                  ,  32 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BP_NORMALISED_RMS      , TypColormapDefinitions::getBpNormalisedRms        , "BP Normalised RMS"         , "BPNormalisedRMS"        ,  32 , 0 },
  { Typ::COL_TYPE_FIXED_COLOR      , Typ::COLORMAP_BP_RMS_RATIO           , TypColormapDefinitions::getBpRmsRatio             , "BP RMS Ratio"              , "BPRMSRatio"             ,  35 , 0 },
  /***** COL_TYPE_MONITOR_FRIENDLY *****/
  { Typ::COL_TYPE_MONITOR_FRIENDLY , Typ::COLORMAP_PUREBLUEGREENRED  , TypColormapDefinitions::getPureBlueGreenRed  , "Pure Blue->Green->Red"  , "PureBlueGreenRed" , 3 , 4 },
  { Typ::COL_TYPE_MONITOR_FRIENDLY , Typ::COLORMAP_PUREGREENREDBLUE  , TypColormapDefinitions::getPureGreenRedBlue  , "Pure Green->Red->Blue"  , "PureGreenRedBlue" , 3 , 4 },
  { Typ::COL_TYPE_MONITOR_FRIENDLY , Typ::COLORMAP_PUREREDBLUEGREEN  , TypColormapDefinitions::getPureRedBlueGreen  , "Pure Red->Blue->Green"  , "PureRedBlueGreen" , 3 , 4 },
  { Typ::COL_TYPE_MONITOR_FRIENDLY , Typ::COLORMAP_MUDDYBLUEGREENRED , TypColormapDefinitions::getMuddyBlueGreenRed , "Muddy Blue->Green->Red" , "PureBlueGreenRed" , 3 , 2 },
  { Typ::COL_TYPE_MONITOR_FRIENDLY , Typ::COLORMAP_MUDDYGREENREDBLUE , TypColormapDefinitions::getMuddyGreenRedBlue , "Muddy Green->Red->Blue" , "PureGreenRedBlue" , 3 , 2 },
  { Typ::COL_TYPE_MONITOR_FRIENDLY , Typ::COLORMAP_MUDDYREDBLUEGREEN , TypColormapDefinitions::getMuddyRedBlueGreen , "Muddy Red->Blue->Green" , "PureRedBlueGreen" , 3 , 2 },
  /***** COL_TYPE_FULL_SPECTRUM *****/
  { Typ::COL_TYPE_FULL_SPECTRUM    , Typ::COLORMAP_PUREEMSPECTRUM          , TypColormapDefinitions::getPureEMSpectrum          , "Visible Region of the EM Spectrum"        , "VisibleRegionOfTheEMSpectrum" , 11 , 5 },
  { Typ::COL_TYPE_FULL_SPECTRUM    , Typ::COLORMAP_PUREBLUEGREENREDMAGENTA , TypColormapDefinitions::getPureBlueGreenRedMagenta , "Blue, Cyan, Green, Yellow, Red, Magenta"  , "BlueCyanYellowRedMagenta"     , 11 , 5 },
  /***** COL_TYPE_PLOTTER_FRIENDLY *****/
  { Typ::COL_TYPE_PLOTTER_FRIENDLY , Typ::COLORMAP_CYANMAGENTAYELLOW , TypColormapDefinitions::getCyanMagentaYellow , "Cyan->Magenta->Yellow" , "CyanMagentaYellow" , 3 , 2 },
  { Typ::COL_TYPE_PLOTTER_FRIENDLY , Typ::COLORMAP_MAGENTAYELLOWCYAN , TypColormapDefinitions::getMagentaYellowCyan , "Magenta->Yellow->Cyan" , "MagentaYellowCyan" , 3 , 2 },
  { Typ::COL_TYPE_PLOTTER_FRIENDLY , Typ::COLORMAP_YELLOWCYANMAGENTA , TypColormapDefinitions::getYellowCyanMagenta , "Yellow->Cyan->Magenta" , "YellowCyanMagenta" , 3 , 2 },
  /***** COL_TYPE_GREY_SCALE *****/
  { Typ::COL_TYPE_GREY_SCALE       , Typ::COLORMAP_BLACKWHITE      , TypColormapDefinitions::getBlackWhite      , "Black->White"        , "BlackWhite"      ,  2 , 1 },
  { Typ::COL_TYPE_GREY_SCALE       , Typ::COLORMAP_BLACKWHITEBLACK , TypColormapDefinitions::getBlackWhiteBlack , "Black->White->Black" , "BlackWhiteBlack" ,  3 , 2 },
  { Typ::COL_TYPE_GREY_SCALE       , Typ::COLORMAP_WHITEBLACK      , TypColormapDefinitions::getWhiteBlack      , "White->Black"        , "WhiteBlack"      ,  2 , 1 },
  { Typ::COL_TYPE_GREY_SCALE       , Typ::COLORMAP_WHITEBLACKWHITE , TypColormapDefinitions::getWhiteBlackWhite , "White->Black->White" , "WhiteBlackWhite" ,  3 , 2 },
  /***** COL_TYPE_WHITE_CENTERED *****/
  { Typ::COL_TYPE_WHITE_CENTERED   , Typ::COLORMAP_BLUEWHITERED       , TypColormapDefinitions::getBlueWhiteRed       , "Blue White Red"       , "BlueWhiteRed"       , 3 , 2 },
  { Typ::COL_TYPE_WHITE_CENTERED   , Typ::COLORMAP_BLUEWHITEYELLOW    , TypColormapDefinitions::getBlueWhiteYellow    , "Blue White Yellow"    , "BlueWhiteYellow"    , 3 , 2 },
  { Typ::COL_TYPE_WHITE_CENTERED   , Typ::COLORMAP_GREENWHITERED      , TypColormapDefinitions::getGreenWhiteRed      , "Green White Red"      , "GreenWhiteRed"      , 3 , 2 },
  { Typ::COL_TYPE_WHITE_CENTERED   , Typ::COLORMAP_BLUEWHITEGREEN     , TypColormapDefinitions::getBlueWhiteGreen     , "Blue White Green"     , "BlueWhiteGreen"     , 3 , 2 },
  { Typ::COL_TYPE_WHITE_CENTERED   , Typ::COLORMAP_CYANWHITEMAGENTA   , TypColormapDefinitions::getCyanWhiteMagenta   , "Cyan White Magenta"   , "CyanWhiteMagenta"   , 3 , 2 },
  { Typ::COL_TYPE_WHITE_CENTERED   , Typ::COLORMAP_YELLOWWHITEMAGENTA , TypColormapDefinitions::getYellowWhiteMagenta , "Yellow White Magenta" , "YellowWhiteMagenta" , 3 , 2 },
  { Typ::COL_TYPE_WHITE_CENTERED   , Typ::COLORMAP_CYANWHITEYELLOW    , TypColormapDefinitions::getCyanWhiteYellow    , "Cyan White Yellow"    , "CyanWhiteYellow"    , 3 , 2 },
  /***** COL_TYPE_MISCELLANEOUS *****/
  { Typ::COL_TYPE_MISCELLANEOUS    , Typ::COLORMAP_HOTBLACK         , TypColormapDefinitions::getHotBlack        , "Hotblack"         , "Hotblack"        ,  3 , 2 },
  { Typ::COL_TYPE_MISCELLANEOUS    , Typ::COLORMAP_DIVAN            , TypColormapDefinitions::getDivan           , "Divan"            , "Divan"           ,  6 , 2 }, // guess work
  { Typ::COL_TYPE_MISCELLANEOUS    , Typ::COLORMAP_SINGAPORESHADES  , TypColormapDefinitions::getSingaporeShades , "Singapore shades" , "Singaporeshades" , 17 , 2 },
  { Typ::COL_TYPE_MISCELLANEOUS    , Typ::COLORMAP_CHICRAINBOW      , TypColormapDefinitions::getChicRainbow     , "Chic Rainbow"     , "ChicRainbow"     ,  9 , 2 }
};
int TypColormapDefinitions::myNumberOfColorInfo = sizeof(TypColormapDefinitions::myColormapInfos) / sizeof(TypColormapDefinitions::myColormapInfos[0]);


/** Get a colormap information */
const Typ::ColormapInfo & TypColormapDefinitions::getColormapInfo( int colormapId , bool & isPresent )
{
  for ( int i=0 ; i < myNumberOfColorInfo ; ++i ) {
    if ( colormapId == myColormapInfos[i].myColormapId ) {
      isPresent = true ;
      return myColormapInfos[i] ;
    }
  }
  isPresent = false ;
  MscDg::error( "TypColormapDefinitions" , "getColormapInfo()" , "Can't find colormap %d" , colormapId );
  return myColormapInfos[0] ;
}



/** from Color Id to Gui name */
const char * TypColormapDefinitions::getGuiNameFromColormapId( Typ::ColormapId colormapId )
{
  bool isPresent = false ;
  const Typ::ColormapInfo  & colormapInfo = TypColormapDefinitions::getColormapInfo( colormapId , isPresent );
  return ( isPresent ? colormapInfo.myGuiName : "undefined" );
}



/** from Gui name to Color name id */
Typ::ColormapId TypColormapDefinitions::getColormapIdFromGuiName( const MscString & name )
{
  Typ::ColormapId colormapId =  Typ::COLORMAP_UNDEFINED ;
  for ( int i=0 ; i < myNumberOfColorInfo ; ++i ) {
    if ( name == myColormapInfos[i].myGuiName ) {
      return myColormapInfos[i].myColormapId ;
    }
  }
  return Typ::COLORMAP_UNDEFINED ;
}



/** usually used for the 'fixed' number values 
 *  If 'numberOfColors' is not null, it used the Typild-in number of colors 'TypildInNumberOfColors'
 *  else it uses the provided 'numberOfColors' and returns the interpolated colors */
const Typ::ColorCreateInfo * TypColormapDefinitions::getColorsFromColormapId( Typ::ColormapId colormapId , int & numberOfColors ,
                                                                           int & TypildInNumberOfColors , int & increment )
{
  int i=0 ;
  const Typ::ColorCreateInfo * TypildInColors = 0 ;

  // number of colours
  int numberFromFunction = 0 ;
  if ( numberOfColors > Typ::MAXIMUM_NUMBER_OF_COLORS ) {
    numberOfColors = Typ::MAXIMUM_NUMBER_OF_COLORS;
  }
  // "Fixed colours"
  bool isFixedColor = false ;
  if ( Typ::getColorTypeFromColormapId(colormapId) == Typ::COL_TYPE_FIXED_COLOR ) {
    isFixedColor = true ;
  }
  // "Variable"
  else {
    if ( numberOfColors < 2 ) { numberOfColors = 2 ; }
    numberFromFunction = numberOfColors ;
    isFixedColor = false ;
  }


  // find it
  for ( i=0 ; i < myNumberOfColorInfo ; ++i ) {
    if ( colormapId == myColormapInfos[i].myColormapId ) {
      TypildInColors         = myColormapInfos[i].myColorFunction( numberFromFunction );
      increment             = myColormapInfos[i].myIncrement ;
      TypildInNumberOfColors = myColormapInfos[i].myPreferedNumber ;
      break;
    }
  }

  // undefined
  if ( TypildInColors == 0 ) {
    numberOfColors        = 0 ;
    TypildInNumberOfColors = 0 ;
    return TypildInColors ;
  }


  // "Fixed colours" 
  if ( isFixedColor == true ) {
    // should be the same
    if ( numberFromFunction != TypildInNumberOfColors ) {
      std::cerr << "TypColormapDefinitions::getColorsFromColorName Name " << colormapId << " mismatch "
     << numberFromFunction << " " << TypildInNumberOfColors << std::endl ;
    }
    // interpolate "Fixed colours" 
    if ( numberOfColors > 0 && numberOfColors < numberFromFunction ) {
      return interpolateColors( TypildInColors , numberFromFunction , numberOfColors );
    }
  }
  // return the Typild-in colors
  numberOfColors = numberFromFunction ; // should be same as 'TypildInNumberOfColors'
  return TypildInColors;
}



const Typ::ColorCreateInfo * TypColormapDefinitions::interpolateColors( const Typ::ColorCreateInfo * TypildInColors , int numberOfTypildInColors , int numberOfColors )
{
  // copy the first and last
  myInterpolatedColors[0] = TypildInColors[0];
  myInterpolatedColors[numberOfColors-1] = TypildInColors[numberOfTypildInColors-1];
  // interpolated in-between
  for ( int i=1 ; i < (numberOfColors-1) ; ++i ) {
    float index = (i*numberOfTypildInColors) / (1.0f*numberOfColors) ;
    // previous
    int prev  = (int)index;
    int next  = prev+1 ;
    // value is found
    if ( prev == (1.0*index) ) {
      myInterpolatedColors[i] = TypildInColors[prev];
    }
    // interpolate
    else {
      float toPrev   = (index - prev);
      float toNext   = (next - index);
      Typ::ColorCreateInfo prevColor = TypildInColors[prev];
      Typ::ColorCreateInfo nextColor = TypildInColors[next];
      float red      = toNext * prevColor.red()   + toPrev * nextColor.red()   ;
      float green    = toNext * prevColor.green() + toPrev * nextColor.green() ;
      float blue     = toNext * prevColor.blue()  + toPrev * nextColor.blue()  ;
      float alpha    = toNext * prevColor.alpha() + toPrev * nextColor.alpha() ;
      myInterpolatedColors[i] = Typ::ColorCreateInfo( Typ::ColorCreateInfo::checkFloat(red)   ,
                                                    Typ::ColorCreateInfo::checkFloat(green) ,
                                                    Typ::ColorCreateInfo::checkFloat(blue)  ,
                                                    Typ::ColorCreateInfo::checkFloat(alpha) );
    }
  }
  // return the interpolated colors
  return myInterpolatedColors;
}


//===============================================================================================
//===============================================================================================
//===============================================================================================
// INTERNAL    INTERNAL    INTERNAL    INTERNAL    INTERNAL    INTERNAL  INTERNAL    INTERNAL      END END END
//===============================================================================================
//===============================================================================================
//===============================================================================================




//===============================================================================================
//===============================================================================================
//===============================================================================================
// ****    IDENTIFY (static)   
//===============================================================================================
//===============================================================================================
//===============================================================================================




const Typ::ColormapInfo & Typ::getColormapInfo( int colormapId , bool & isPresent )
{
  return TypColormapDefinitions::getColormapInfo( colormapId , isPresent );
}



Typ::ColorType Typ::getColorTypeFromColormapId( int colormapId )
{
  Typ::ColorType colorType = Typ::COL_TYPE_UNDEFINED ;
  // *** Undefined *** //
  if ( colormapId < Typ::COLORMAP_FIRST || Typ::COLORMAP_LAST < colormapId ) {
    colorType = Typ::COL_TYPE_UNDEFINED ;
  }

  // *** Fixed Size *** //
  else if ( colormapId <= Typ::COLORMAP_FIXED_LAST ) { // Fixed Size
    colorType = Typ::COL_TYPE_FIXED_COLOR ;
  }

  // *** Variable Size *** //
  else if ( colormapId <= Typ::COLORMAP_MONITOR_LAST ) { // Monitor Friendly
    colorType = Typ::COL_TYPE_MONITOR_FRIENDLY ;
  }
  else if ( colormapId <= Typ::COLORMAP_SPECTRUM_LAST ) { // Full Spectrum
    colorType = Typ::COL_TYPE_FULL_SPECTRUM ;
  }
  else if ( colormapId <= Typ::COLORMAP_PLOTTER_LAST ) { // Plotter Friendly
    colorType = Typ::COL_TYPE_PLOTTER_FRIENDLY ;
  }
  else if ( colormapId <= Typ::COLORMAP_GREY_LAST ) { // Grey Scale
    colorType = Typ::COL_TYPE_GREY_SCALE ;
  }
  else if ( colormapId <= Typ::COLORMAP_WHITE_LAST ) { // White Centered
    colorType = Typ::COL_TYPE_WHITE_CENTERED ;
  }
  else if ( colormapId <= Typ::COLORMAP_MISCELLANEOUS_LAST ) { // Miscellaneous
    colorType = Typ::COL_TYPE_MISCELLANEOUS ;
  }
  return colorType ;  
}





//===============================================================================================
//===============================================================================================
//===============================================================================================
// ****    COLORMAP CLASS   (TypColormap)   Storage of colors
//===============================================================================================
//===============================================================================================
//===============================================================================================



const char * TypColormap::CLASS_NAME = "TypColormap" ;

TypColormap::TypColormap()
{
}


TypColormap::~TypColormap()
{
}


/** Utilities for the colormap
 *  limitNumber : limit the number of colors
 *  reverse     : change the order of the colors in the palette 
 *  inverse     : turn each color into its complementary color 
 *  saturation  : color intensity of the colormap
 *  brightness  : brightness intensity of the colormap
 */


bool TypColormap::generate( const std::shared_ptr< TypColormapPM > & colormapPM )
{
  static const char * METHOD_NAME = "generate()" ;
  bool isOk = false ;
  int numberOfColors = colormapPM->getInt( TypColormapPM::ID_NUMBER_OF_COLORS );
  MscDg::trace( CLASS_NAME , METHOD_NAME , "number of colors is %d" , numberOfColors );

  // information
  int colormapId = colormapPM->getInt(TypColormapPM::ID_MAP_IDENTIFICATION) ;
  const Typ::ColormapInfo & colormapInfo = Typ::getColormapInfo( colormapId , isOk );
  if ( isOk == false ) { return false; }

  // for the variable size, check the minimum
  if ( Typ::COLORMAP_VARIABLE_FIRST <= colormapId && colormapId <= Typ::COLORMAP_VARIABLE_LAST ) {
    numberOfColors = colormapPM->getInt( TypColormapPM::ID_NUMBER_OF_COLORS );
    // check the minimum
    if ( numberOfColors < colormapInfo.myPreferedNumber ) { 
      numberOfColors = colormapInfo.myPreferedNumber ;
    }
    if ( numberOfColors > Typ::MAXIMUM_NUMBER_OF_COLORS ) {
      numberOfColors = Typ::MAXIMUM_NUMBER_OF_COLORS;
    }
  }

  // get the colors
  const Typ::ColorCreateInfo * colors = colormapInfo.myColorFunction( numberOfColors );
  setColors( colors , numberOfColors );

  // for fixed size maps, see if the number has to be reduced
  if ( Typ::COLORMAP_FIXED_FIRST <= colormapId && colormapId <= Typ::COLORMAP_FIXED_LAST ) {
    if ( colormapPM->getBool( TypColormapPM::ID_REDUCE_NUMBER ) == true ) {
      numberOfColors = colormapPM->getInt( TypColormapPM::ID_NUMBER_OF_COLORS );
    }
    // check the maximum 
    if ( numberOfColors > colormapInfo.myPreferedNumber ) {
      numberOfColors = colormapInfo.myPreferedNumber ;
    }
    if ( numberOfColors > Typ::MAXIMUM_NUMBER_OF_COLORS ) {
      numberOfColors = Typ::MAXIMUM_NUMBER_OF_COLORS;
    }
    // check the maximum . reduce number if needed
    sample( numberOfColors );
  } 

  // initialize
  colormapPM->setInt( TypColormapPM::ID_NUMBER_OF_COLORS , getNumberOfColors() );
  colormapPM->setIsReversed(false);
  colormapPM->setIsComplementary(false);

  return true;
}


/// MODIFY


bool TypColormap::reverse()
{
  std::vector< Typ::ColorCreateInfo > colors ;
  std::vector< Typ::ColorCreateInfo >::const_reverse_iterator iter ;
  for ( iter=myColors.rbegin() ; iter != myColors.rend() ; ++iter ) {
    colors.push_back( *iter );
  }
  return setColors( colors );
}


bool TypColormap::complementary()
{
  std::vector< Typ::ColorCreateInfo > colors ;
  std::vector< Typ::ColorCreateInfo >::const_iterator iter ;
  for ( iter=myColors.begin() ; iter != myColors.end() ; ++iter ) {
    Typ::ColorCreateInfo color(*iter);
    color.complementary();
    colors.push_back( color );
  }
  return setColors( colors ); 
}


bool TypColormap::sample( int number )
{
  static const char * METHOD_NAME = "sample()" ;
  int initialNumber = getNumberOfColors();
  MscDg::trace( CLASS_NAME , METHOD_NAME , "number is %d -> %d" , initialNumber , number );
 
  // minimum number of colors
  if ( number < 3 ) { number = 3 ; }

  // too many colors
  if ( initialNumber > number ) {
    std::vector< Typ::ColorCreateInfo > colors ;
    // sample them
    float ratio = float(initialNumber) / float(number);
    for ( int i=0 ; i < number ; ++i ) {
      int initialInt = int( i * ratio + 0.5f);
      if ( initialInt >= initialNumber ) { initialInt = (initialNumber - 1); }
      colors.push_back( myColors[initialInt] );
    }
    // store them
    return setColors( colors ); 
  }
  else {
    return false ;
  }
}


bool TypColormap::interpolate( int rank1 , int rank2 )
{
  int first  = (rank1 < rank2) ? rank1 : rank2 ;
  int last   = (rank1 > rank2) ? rank1 : rank2 ;
  float span = (last - first);
  int number = myColors.size();
  if ( first < 0 || last < 0 || first >= number || last >= number || span <= 1.0f ) { return false ; }
  
  myIsGenerated = false ;
  Typ::ColorCreateInfo c1 = myColors[first];
  Typ::ColorCreateInfo c2 = myColors[last ];

  for ( int i=(first+1) ; i <= (last-1) ; ++i ) {
    myColors[i] = Typ::ColorCreateInfo ( (int)(c1.myRed   + (i-first)*(c2.myRed   - c1.myRed  )/span),
                                       (int)(c1.myGreen + (i-first)*(c2.myGreen - c1.myGreen)/span),
                                       (int)(c1.myBlue  + (i-first)*(c2.myBlue  - c1.myBlue )/span),
                                       (int)(c1.myAlpha + (i-first)*(c2.myAlpha - c1.myAlpha)/span));
  }
  //if ( sendSignal == true ) { addSignal( TypColormapPM::ID_SET_COLORS ); }
  return true ;  
}



/// SATURATION


float TypColormap::getSaturation() const
{
  float sum = 0.0f ;
  std::vector< Typ::ColorCreateInfo >::const_iterator iter ;
  for ( iter=myColors.begin() ; iter != myColors.end() ; ++iter ) {
    sum += iter->getSaturation();
  }
  if ( myColors.empty() == false ) { sum /= myColors.size(); }
  return sum ;
}



int TypColormap::getSaturationPercent() const
{
  return int(100 * getSaturation());
}



bool TypColormap::setSaturationPercent( int percent )
{
  // no change
  int oldPercent = getSaturationPercent();
  if ( oldPercent == percent ) { return false ; }  

  // ratio
  float ratio = 1.0f ;
  std::vector< Typ::ColorCreateInfo >::iterator iter ;
  for ( iter=myColors.begin() ; iter != myColors.end() ; ++iter ) {  
    float oldValue = iter->getSaturation();
    float newValue = ratio * oldValue ;
    iter->setSaturation( newValue );
  }

  return true;
}

/// BRIGHTNESS


float TypColormap::getBrightness() const
{
  float sum    = 0.0f ;
  std::vector< Typ::ColorCreateInfo >::const_iterator iter ;
  for ( iter=myColors.begin() ; iter != myColors.end() ; ++iter ) {
    sum += iter->getBrightness();
  }
  if ( myColors.empty() == false ) { sum /= myColors.size(); }
  return sum ;
}


int  TypColormap::getBrightnessPercent() const
{
  return int(100 * getBrightness());
}


bool TypColormap::setBrightnessPercent( int percent )
{
  // no change
  int oldPercent = getBrightnessPercent();
  if ( oldPercent == percent ) { return false ; }  

  // ratio
  float ratio = 1.0f ;
  std::vector< Typ::ColorCreateInfo >::iterator iter ;
  for ( iter=myColors.begin() ; iter != myColors.end() ; ++iter ) {  
    float oldValue = iter->getBrightness();
    float newValue = ratio * oldValue ;
    iter->setBrightness( newValue );
  }

  return true;
}

/// STORE 


bool TypColormap::getColor( int rank , Typ::ColorCreateInfo & color ) const
{
  if ( 0 <= rank && rank < myColors.size() ) {
    color = myColors[rank];
    return true ;
  }
  else {
    return false ;
  }  
}



bool TypColormap::setColors( const Typ::ColorCreateInfo * colorArray , int numberOfColors )
{
  std::vector< Typ::ColorCreateInfo > colors ;
  for ( int i=0 ; i < numberOfColors ; ++i ) {
    colors.push_back( colorArray[i] );
  }
  return setColors( colors );
}



bool TypColormap::setColors( const std::vector< Typ::ColorCreateInfo > & colors )
{
  if ( myColors != colors ) {
    myColors = colors;
    return true ;
  }
  else {
    return false;
  }
}




//===============================================================================================
//===============================================================================================
//===============================================================================================
// ****    COLORMAP PARAMETER  CLASS   (TypColormapPM)
//===============================================================================================
//===============================================================================================
//===============================================================================================



TypColormapPM::Callback TypColormapPM::myCallback = 0 ;
/** colormap : it reflects the definition of "Typ::ColormapType" */

static Typ::ValuesStruct ColormapTypeVALUES[] = {
  { Typ::CLM_SEMBLANCE         , "CLM_SEMBLANCE"         , "Semblance"                , 0 , -1 },
  { Typ::CLM_SEISMIC_STACK     , "CLM_SEISMIC_STACK"     , "Seismic (stacks)"         , 0 , -1 },
  { Typ::CLM_SEISMIC_GATHER    , "CLM_SEISMIC_GATHER"    , "Seismic (gather)"         , 0 , -1 },
  { Typ::CLM_SEISMIC_OVERLAY   , "CLM_SEISMIC_OVERLAY"   , "Seismic (overlay)"        , 0 , -1 },
  { Typ::CLM_VELOCITY_TABLE    , "CLM_VELOCITY_TABLE"    , "Velocity"                 , 0 , -1 },
  { Typ::CLM_MAP_VELOCITY      , "CLM_MAP_VELOCITY"      , "Map"                      , 0 , -1 }
};



static MscDataItem::CreateInfo GenericColormapBP[] = {
  /*0*/  { TypColormapPM::ID_START_FLAG          , "<Colormap>"       , MscDataItem::DT_START_FLAG , 0 , 0 , 0 , 0 , 0 } ,
  //    definition of the colormap by using existing parameters
  /*1*/  { TypColormapPM::ID_MAP_IDENTIFICATION  , "ColormapId"       , MscDataItem::DT_INT_Colormap , Typ::COLORMAP_DIVAN ,  0 , 0 , 0 , 0 } ,
  /*2*/  { TypColormapPM::ID_NUMBER_OF_COLORS    , "NumberOfColors"   , MscDataItem::DT_INT       , 31 , 0 , 0 , 0 , 0 } ,
  /*3*/  { TypColormapPM::ID_REDUCE_NUMBER       , "ReduceNumber"     , MscDataItem::DT_BOOL      , (int)false , 0 , 0 , 0 , 0 } ,
  //    intensity
  /*4*/  { TypColormapPM::ID_LEVEL_COLOR_MODIFY  , "ColorModify"      , MscDataItem::DT_BOOL      , (int)false , 0 , 0 , 0 , 0 } ,
  /*5*/  { TypColormapPM::ID_LEVEL_COLOR_VALUE   , "ColorValue"       , MscDataItem::DT_INT       , 0 , 0 , 0 , 0 , 0 } ,
  /*6*/  { TypColormapPM::ID_LEVEL_BRIGHT_MODIFY , "BrightnessModify" , MscDataItem::DT_BOOL      , (int)false , 0 , 0 , 0 , 0 } ,
  /*7*/  { TypColormapPM::ID_LEVEL_BRIGHT_VALUE  , "BrightnessVslue"  , MscDataItem::DT_INT       , 0 , 0 , 0 , 0 , 0 } ,
  /*8*/  { TypColormapPM::ID_REVERSE_MAP         , "ReverseMap"       , MscDataItem::DT_BOOL      , (int)false , 0 , 0 , 0 , 0 } ,
  /*9*/  { TypColormapPM::ID_COMPLEMENTARY_MAP   , "ComplementaryMap" , MscDataItem::DT_BOOL      , (int)false , 0 , 0 , 0 , 0 } ,
  //    storage of the colormap in a file
  /*10*/ { TypColormapPM::ID_STORAGE_FILENAME    , "FileName"         , MscDataItem::DT_STRING    , 0 , 0 , 0 , 0 , 0 } ,
  // end
  /*11*/ { TypColormapPM::ID_END_FLAG            , "</Colormap>"      , MscDataItem::DT_END_FLAG  , 0 , 0 , 0 , 0 , 0 }
};


const char * TypColormapPM::CLASS_NAME = "TypColormapPM"   ;


// Typild-in colormaps
MscDataItem::CreateInfo * TypColormapPM::defaultColormapPM( Typ::ColormapType type )
{
  static const char * METHOD_NAME = "CustomizeColormapPM()" ;
  switch ( type ) {
  case Typ::CLM_SEMBLANCE         : // see: "vsSemblancePM::myInitialize()"
    GenericColormapBP[0].myFlag   = "<Colormap::Semblance>" ;
    GenericColormapBP[0].myComment= 0 ;
    GenericColormapBP[1].myInt    = Typ::COLORMAP_SINGAPORESHADES  ; // Typ::COLORMAP_DIVAN
    GenericColormapBP[2].myInt    = 31 ; // 11 ;
    break ;
  case Typ::CLM_SEISMIC_STACK     : // see: "vxSeismicDisplayPM::setColorPaletteNoSignal()"
    GenericColormapBP[0].myFlag   = "<Colormap::SeismicStack>" ;
    GenericColormapBP[0].myComment= 0 ;
    GenericColormapBP[1].myInt    = Typ::COLORMAP_BIGTIGER ;
    GenericColormapBP[2].myInt    = 65 ;
    break ;
  case Typ::CLM_SEISMIC_GATHER    : // see: "vxSeismicDisplayPM::setColorPaletteNoSignal()"
    GenericColormapBP[0].myFlag   = "<Colormap::SeismicGather>" ;
    GenericColormapBP[0].myComment= 0 ;
    GenericColormapBP[1].myInt    = Typ::COLORMAP_BIGTIGER  ;
    GenericColormapBP[2].myInt    = 65 ;
    break ;
  case Typ::CLM_SEISMIC_OVERLAY   : // see: "pcPanelLayers::pcPanelLayers(()"
    GenericColormapBP[0].myFlag   = "<Colormap::SeismicOverlay>" ;
    GenericColormapBP[0].myComment= 0 ;
    GenericColormapBP[1].myInt    = Typ::COLORMAP_BLACKWHITEBLACK ;
    GenericColormapBP[2].myInt    = 64 ;
    break ;
  case Typ::CLM_VELOCITY_TABLE    : // see: "vsVelocityTablePM::myInitialize()"
    GenericColormapBP[0].myFlag   = "<Colormap::VelocityTable>" ;
    GenericColormapBP[0].myComment= 0 ;
    GenericColormapBP[1].myInt    = Typ::COLORMAP_MUDDYBLUEGREENRED ;
    GenericColormapBP[2].myInt    = 15 ;
    break ;
  case Typ::CLM_MAP_VELOCITY      : // see: "pcParameterModel::pcParameterModel(()"
    GenericColormapBP[0].myFlag   = "<Colormap::MapVelocity>" ;
    GenericColormapBP[0].myComment= 0 ;
    GenericColormapBP[1].myInt    = Typ::COLORMAP_MUDDYBLUEGREENRED  ;
    GenericColormapBP[2].myInt    = 15 ;
    break ;
  }
  return GenericColormapBP ;
}



TypColormapPM::TypColormapPM( Typ::ColormapType type )
  : MscDataTeam( CT_TypColormapPM ,
                  sizeof(GenericColormapBP) / sizeof(GenericColormapBP[0]) ,
                  TypColormapPM::defaultColormapPM(type) ,
                  0 , 0 , type , 0 )
{
  myIsGenerated     = false ;
  myIsReversed      = false ;
  myIsComplementary = false ;
  generateColormap( false ); // create the colormap
}


void TypColormapPM::resetToDefault()
{
  TypColormapPM colormap( (Typ::ColormapType)getSubClass() );
  copyValuesFromModel( colormap , true );
}


void TypColormapPM::copyValuesFromModel( const TypColormapPM & colormapPM , bool sendSignal )
{
  static const char * METHOD_NAME = "copyValuesFromModel()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "IsGenerated %d" , colormapPM.myIsGenerated );

  saveSignals( true );
  copy( colormapPM );
  myColors          = colormapPM.myColors          ;
  myIsGenerated     = colormapPM.myIsGenerated     ;
  myIsReversed      = colormapPM.myIsReversed      ;
  myIsComplementary = colormapPM.myIsComplementary ;
  addSignal( TypColormapPM::ID_SET_COLORS );
  if ( sendSignal == false ) { discartSignals(); }
  saveSignals( false ); 
}



void TypColormapPM::generateColormap( bool modifyOnly )
{
  static const char * METHOD_NAME = "generateColormap()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME );
  MscDg::check( CLASS_NAME , METHOD_NAME , (myCallback != 0) , "'TypColormapPM::myCallback' is not defined" );
  myCallback( this , (modifyOnly ? TypColormapPM::RQT_MODIFY : TypColormapPM::RQT_CREATE) );
}



bool TypColormapPM::getColor( int rank , Typ::ColorCreateInfo & color ) const
{
  if ( 0 <= rank && rank < myColors.size() ) {
    color = myColors[rank];
    return true ;
  }
  else {
    return false ;
  }
}


bool TypColormapPM::interpolate( int rank1 , int rank2 , bool sendSignal )
{
  int first  = (rank1 < rank2) ? rank1 : rank2 ;
  int last   = (rank1 > rank2) ? rank1 : rank2 ;
  float span = (last - first);
  int number = myColors.size();
  if ( first < 0 || last < 0 || first >= number || last >= number || span <= 1.0f ) { return false ; }
  
  myIsGenerated = false ;
  Typ::ColorCreateInfo c1 = myColors[first];
  Typ::ColorCreateInfo c2 = myColors[last ];

  for ( int i=(first+1) ; i <= (last-1) ; ++i ) {
    myColors[i] = Typ::ColorCreateInfo ( (int)(c1.myRed   + (i-first)*(c2.myRed   - c1.myRed  )/span),
                                       (int)(c1.myGreen + (i-first)*(c2.myGreen - c1.myGreen)/span),
                                       (int)(c1.myBlue  + (i-first)*(c2.myBlue  - c1.myBlue )/span),
                                       (int)(c1.myAlpha + (i-first)*(c2.myAlpha - c1.myAlpha)/span));
  }
  if ( sendSignal == true ) { addSignal( TypColormapPM::ID_SET_COLORS ); }
  return true ;
}


bool TypColormapPM::setColors( const std::vector< Typ::ColorCreateInfo > & c , bool isGenerated , bool sendSignal )
{
  static const char * METHOD_NAME = "setColors()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Size %ld  Generated %d SendSignal %d" , c.size() , isGenerated , sendSignal );
  
  saveSignals( true );
  myIsGenerated = isGenerated ;
  myColors = c ;
  if ( sendSignal == true ) { addSignal( TypColormapPM::ID_SET_COLORS ); }
  return true ;
}



bool TypColormapPM::setColor( int rank , const Typ::ColorCreateInfo & color , bool sendSignal )
{
  if ( 0 <= rank && rank < myColors.size() ) { // &&  myColors[rank] != color ) { 
    myIsGenerated  = false ;
    myColors[rank] = color ;
    if ( sendSignal == true ) { addSignal( TypColormapPM::ID_SET_COLORS ); }
    return true ;
  }
  else {
    return false ;
  }
}



int TypColormapPM::getMapIdentification( bool & isFixed , bool & isVariable )
{
  int mapId  = getInt( TypColormapPM::ID_MAP_IDENTIFICATION );
  isFixed    = false ;
  isVariable = false ;
  if ( Typ::COLORMAP_FIXED_FIRST <= mapId && mapId <= Typ::COLORMAP_FIXED_LAST ) {
    isFixed = true ;
  }
  else if ( Typ::COLORMAP_VARIABLE_FIRST <= mapId && mapId <= Typ::COLORMAP_VARIABLE_LAST ) {
    isVariable = true ;
  } 
  return mapId ;
}



MscString TypColormapPM::getDescription( bool & isFixed , bool & isVariable )
{
  isFixed     = false ;
  isVariable  = false ;
  MscString tmp , str ;
  if ( myIsGenerated == true ) {
    str.printf( "Colormap is generated with:\n" );
    // map
    int mapId = getMapIdentification( isFixed , isVariable );
    MscString colormapName = Typ::getValue( MscDataItem::DT_INT_Colormap , mapId ).myLabel ;
    tmp.printf( "    %s colormap '%s'" , isFixed ? "Fixed size" : "Variable size" , colormapName.c_str() );
    str += tmp  ;
    // number of colors
    int numberOfColors = getInt(TypColormapPM::ID_NUMBER_OF_COLORS);
    if ( isVariable == true ) {
      tmp.printf( " with %d colors." , numberOfColors );
    }
    else if ( isFixed == true ) {
      if ( getBool(TypColormapPM::ID_REDUCE_NUMBER) == true ) {
        tmp.printf( " sampled to %d colors." , numberOfColors );
      }
      else {
        tmp.printf( " with maximum %d colors." , numberOfColors );
      }
    }
    str += tmp  ;
    str += "\n    " ;
    // modifiers
    if ( getBool(TypColormapPM::ID_REVERSE_MAP) == true ) { str += "reversed   "; }
    if ( getBool(TypColormapPM::ID_COMPLEMENTARY_MAP) == true ) { str += "complementary   "; }
  }
  else {
    str.printf( "Colormap is specific." );
  }
  return str ;
}


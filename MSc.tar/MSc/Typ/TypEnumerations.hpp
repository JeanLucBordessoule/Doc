#ifndef TYP_ENUMERATIONS_HPP
#define TYP_ENUMERATIONS_HPP

#include <vector>

#include "MscDataHolder.hpp"
#include "MscString.hpp"
#include "TypStructure.hpp"


/** In 'MscDataItem::DataType', most useful enumerations are defined.
 *  The application can add other enumerations.
 *
 *  In the below the data holder type is a value enumerated in 'MscDataItem::DataType'
 *  such as 'DT_INT_LineStyle'.
 *  All the values pertaining to this enumeraion are specified in 'Typ::ValuesStruct'.
 * **/


namespace Typ
{
  /** get the array of values (the size of the array is provided) */
  const Typ::ValuesStruct   * getValues( MscDataItem::DataType dataHolderType , int & numberOfValues , bool &isPresent );
  const Typ::ValuesStruct   * getValues( MscDataItem::DataType dataHolderType , int & numberOfValues );
  std::vector< Typ::ValuesStruct > getValues( MscDataItem::DataType dataHolderType , int firstId , int lastId );

  /** find out if a value exists (value or the flag) */
  bool                   hasValue ( MscDataItem::DataType dataHolderType , int );
  bool                   hasValue ( MscDataItem::DataType dataHolderType , const MscString & );

  /** for a specific value , get the flags (used when writing) , or
   *  get the array of values corresponding to the flag (used when reading) */
  const Typ::ValuesStruct   & getValue ( MscDataItem::DataType dataHolderType , int , bool &isPresent );
  const Typ::ValuesStruct   & getValue ( MscDataItem::DataType dataHolderType , int );
  const Typ::ValuesStruct   & getValue ( MscDataItem::DataType dataHolderType , const MscString & , bool &isPresent );
  const Typ::ValuesStruct   & getValue ( MscDataItem::DataType dataHolderType , const MscString & );

  /** font identification to show to the user */
  MscString                getFontLabel( int fontFamily , int fontSize , int fontSlant , int fontWeight );
};




namespace Typ {

// Pre-defined.

enum ColormapId {
  // *** UNDEFINED
  COLORMAP_UNDEFINED            = 1 ,
  // *** FIXED_COLOR
  // first column
  COLORMAP_SEGCOLORMAP          = 10 ,
  COLORMAP_SEGFUCHSIABANDS      ,
  COLORMAP_BGRCONTRASTBANDS     ,
  COLORMAP_BGRCONTRASTBANDS2    ,
  COLORMAP_BANDEDRAINBOW        ,
  COLORMAP_WHITEANCHOREDRAINBOW ,
  COLORMAP_RAINBOXMIX           ,
  COLORMAP_ILLUMINATEDEXTREMES  ,
  COLORMAP_HIGHLIGHTEDEXTREMES  ,
  COLORMAP_LANDMARK             ,
  COLORMAP_IPGMAP               ,
  // second column
  COLORMAP_ROLLINGRAMPS         = 30 ,
  COLORMAP_CRAZYZEBRA           ,
  COLORMAP_BLUERAINBOW          ,
  COLORMAP_BLUESQUEEZE          ,
  COLORMAP_BANDEDTIEDYE         ,
  COLORMAP_PURPLEHAZE           ,
  COLORMAP_BLUEGREYRED          ,
  COLORMAP_BLUEYELLOWRED        ,
  COLORMAP_VOXELGEO             ,
  COLORMAP_SMALLVORTEX          ,
  COLORMAP_GEOVEL               ,
  // third column
  COLORMAP_SMALLTIGER           = 50 ,
  COLORMAP_BIGTIGER             ,
  COLORMAP_SICKTIGER            ,
  COLORMAP_PERTURBATION         ,
  COLORMAP_PRIMARYCOLORS        ,
  COLORMAP_BP_ABERDEEN          ,
  COLORMAP_SEMBLANCESPECTRUM    ,
  COLORMAP_ACQUISITIONFOLDOFCOVER ,
  COLORMAP_FOLDMAP              ,
  COLORMAP_BIGVORTEX            ,
  COLORMAP_REDWBLK              ,
  // fourth column
  COLORMAP_BANDEDRGV            = 70 ,
  //
  COLORMAP_GRAYSCALE_65         ,
  COLORMAP_STANDARD_WINDOWS     ,
  COLORMAP_SEISMICREDBLUE       ,
  //
  COLORMAP_STEP145AMPD          ,
  COLORMAP_ANGLE45DIP60         ,
  COLORMAP_ANGLE3               ,
  COLORMAP_ANGLE4               ,
  COLORMAP_BP_RMS               ,
  COLORMAP_BP_NORMALISED_RMS    ,
  COLORMAP_BP_RMS_RATIO         ,
  // *** first last fixed
  COLORMAP_FIXED_FIRST          = COLORMAP_SEGCOLORMAP  ,
  COLORMAP_FIXED_LAST           = COLORMAP_BP_RMS_RATIO ,

  // *** MONITOR_FRIENDLY
  COLORMAP_PUREBLUEGREENRED     = 101 ,
  COLORMAP_PUREGREENREDBLUE     ,
  COLORMAP_PUREREDBLUEGREEN     ,
  COLORMAP_MUDDYBLUEGREENRED    ,
  COLORMAP_MUDDYGREENREDBLUE    ,
  COLORMAP_MUDDYREDBLUEGREEN    ,
  // first last
  COLORMAP_MONITOR_FIRST        = COLORMAP_PUREBLUEGREENRED  ,
  COLORMAP_MONITOR_LAST         = COLORMAP_MUDDYREDBLUEGREEN ,

  // *** SPECTRUM
  COLORMAP_PUREEMSPECTRUM       = 201,
  COLORMAP_PUREBLUEGREENREDMAGENTA ,
  // first last
  COLORMAP_SPECTRUM_FIRST       = COLORMAP_PUREEMSPECTRUM          ,
  COLORMAP_SPECTRUM_LAST        = COLORMAP_PUREBLUEGREENREDMAGENTA ,

  // *** PLOTTER_FRIENDLY
  COLORMAP_CYANMAGENTAYELLOW    = 301,
  COLORMAP_MAGENTAYELLOWCYAN    ,
  COLORMAP_YELLOWCYANMAGENTA    ,
  // first last
  COLORMAP_PLOTTER_FIRST        = COLORMAP_CYANMAGENTAYELLOW ,
  COLORMAP_PLOTTER_LAST         = COLORMAP_YELLOWCYANMAGENTA ,

  // *** GREY_SCALE
  COLORMAP_BLACKWHITE           = 401,
  COLORMAP_BLACKWHITEBLACK      ,
  COLORMAP_WHITEBLACK           ,
  COLORMAP_WHITEBLACKWHITE      ,
  // first last
  COLORMAP_GREY_FIRST           = COLORMAP_BLACKWHITE      ,
  COLORMAP_GREY_LAST            = COLORMAP_WHITEBLACKWHITE ,

  // *** WHITE_CENTERED
  COLORMAP_BLUEWHITERED         = 501,
  COLORMAP_BLUEWHITEYELLOW      ,
  COLORMAP_GREENWHITERED        ,
  COLORMAP_BLUEWHITEGREEN       ,
  COLORMAP_CYANWHITEMAGENTA     ,
  COLORMAP_YELLOWWHITEMAGENTA   ,
  COLORMAP_CYANWHITEYELLOW      ,
  // first last
  COLORMAP_WHITE_FIRST          = COLORMAP_BLUEWHITERED    ,
  COLORMAP_WHITE_LAST           = COLORMAP_CYANWHITEYELLOW ,

  // *** COL_TYPE_MISCELLANEOUS
  COLORMAP_HOTBLACK             = 601,
  COLORMAP_DIVAN                ,
  COLORMAP_SINGAPORESHADES      ,
  COLORMAP_CHICRAINBOW          ,
  // first last
  COLORMAP_MISCELLANEOUS_FIRST  = COLORMAP_HOTBLACK     ,
  COLORMAP_MISCELLANEOUS_LAST   = COLORMAP_CHICRAINBOW  ,

  // *** first last variable
  COLORMAP_VARIABLE_FIRST       = COLORMAP_MONITOR_FIRST      ,
  COLORMAP_VARIABLE_LAST        = COLORMAP_MISCELLANEOUS_LAST ,
  // *** first last colormap
  COLORMAP_FIRST                = COLORMAP_FIXED_FIRST        ,
  COLORMAP_LAST                 = COLORMAP_VARIABLE_LAST
};

/** ====================================================
 *  DRAWING PARAMETERS, lines, font, text, array (e.g.: seismic image)
 *  ================================================= */

/** Line attriTypte types **/

enum LineStyle {
  LS_SOLID       = 0 ,
  LS_EMPTY       ,
  LS_DASH        ,
  LS_DOT         ,
  LS_DASHDOT     ,
  LS_DASHDOTDOT  ,
  LS_PATTERN
};

enum LineEndCap {
  LEC_DEFAULT = 0 ,
    LEC_ROUND   ,
    LEC_SQUARE  ,
    LEC_FLAT
};

enum LineJoin {
  LJ_DEFAULT  = 0 ,
    LJ_ROUND    ,
    LJ_BEVEL    ,
    LJ_MITER
};

enum DimUnit {
  DU_PIXEL    = 0 ,
    DU_POINT    ,
    DU_SCALED_POINT
};

enum MarkerStyle {
  MS_EMPTY   = 0 ,
    MS_DOT     ,
    MS_PLUS    ,
    MS_STAR    ,
    MS_CIRCLE  ,
    MS_CROSS   ,
    MS_SQUARE  ,
    MS_PATTERN
};

enum  {
  MZ_DEFAULT    = 4 , // default size of the marker
  MAX_FONT_NAME = 32  // font
};

/** Attribute types **/

enum FillStyle {
  FS_SOLID        = 0,
    FS_EMPTY        ,
    FS_HORIZONTAL   ,
    FS_VERTICAL     ,
    FS_FDIAGONAL    ,
    FS_BDIAGONAL    ,
    FS_CROSS        ,
    FS_DIAGCROSS    ,
    FS_PATTERN      ,
    FS_CUSTOM_BRUSH
};

/** Font attriTypte types **/

enum FontWeight {
  WT_DEFAULT    = 0,
    WT_THIN       ,
    WT_EXTRALIGHT ,
    WT_LIGHT      ,
    WT_NORMAL     ,
    WT_MEDIUM     ,
    WT_SEMIBOLD   ,
    WT_BOLD       ,
    WT_EXTRABOLD  ,
    WT_HEAVY
};

enum FontSize {
  SZ_8  =  8 ,
  SZ_10 = 10 ,
  SZ_11 = 11 ,
  SZ_12 = 12 ,
  SZ_14 = 14 ,
  SZ_16 = 16 ,
  SZ_18 = 18 ,
  SZ_20 = 20 ,
  SZ_24 = 24 ,
  SZ_28 = 28 ,
  SZ_32 = 32 ,
  SZ_36 = 36 ,
  SZ_40 = 40 ,
  SZ_44 = 44 ,
  SZ_48 = 48
};

enum FontSlant {
  SL_NORMAL  = 0 ,
    SL_ITALIC  ,
    SL_OBLIQUE = SL_ITALIC
};

enum FontAttribute {
  FA_NORMAL      = 0,
    FA_UNDERLINE ,
    FA_STRIKEOUT ,
    FA_UNDERLINE_STRIKEOUT
};

enum FontFamily {
  FM_DEFAULT      = 0,
    FM_ROMAN      ,
    FM_SWISS      ,
    FM_MODERN     ,
    FM_SCRIPT     ,
    FM_DECORATIVE ,
    FM_SERIF      = FM_ROMAN  ,
    FM_SANS_SERIF = FM_SWISS  ,
    FM_MONOSPACED = FM_MODERN
};

enum FontTechnology {
  FT_EMPTY      = 0 ,
    FT_NATIVE   = 1 ,
    FT_TRUETYPE	= 2 ,
    FT_OLF      = 4 ,
    FT_SCALABLE	= 2 , /* FT_TRUETYPE */
    FT_DEFAULT	= 7   /* FT_NATIVE | FT_TRUETYPE | FT_OLF */
};

enum FontSizeMode {
  FSM_DEFAULT    = 0 ,				 // Driver default
    FSM_HEIGHT     = 1 ,				 // Height of M
    FSM_DEPTH      = 2 ,				 // Depth of g
    FSM_DESCENT    = 2 ,				 // WIN32 analog
    FSM_HEIGHT_GAP = 4 ,			 // Gap above symbols for accent etc
    FSM_INTERNALLEADING = 4,      // WIN32 analog
    FSM_ASCENT     = FSM_HEIGHT | FSM_HEIGHT_GAP, // Height of A with accent
    FSM_EMHEIGHT   = FSM_HEIGHT | FSM_DEPTH, // Height of Mg (also em height)
    // It is ascent + descent + internal leading // Maximum character height
    FSM_MAXHEIGHT  = FSM_HEIGHT | FSM_DEPTH | FSM_HEIGHT_GAP
};

/** Alignment, Order of graphics layers **/

enum Alignment {
  // Vertical
  AL_V_TOP      = 1  ,
  AL_V_CENTER   = 3  ,
  AL_V_BOTTOM   = 2  ,
  AL_V_BASELINE = 16 ,
  // Horizontal
  AL_H_LEFT     = 4  ,
  AL_H_CENTER   = 12 ,
  AL_H_RIGHT    = 8  ,
  //
  AL_H_ALIGNMENT = 12 ,
  AL_V_ALIGNMENT = 3  //  Baseline alignment not included here
};

enum PointTag {
  PT_ILLEGAL   = 0 ,
    PT_REGULAR   ,
    PT_BEZIER    ,
    PT_OPEN_END  ,
    PT_CLOSE_END
};

enum Order {
  ORD_BESIDE    = 0 ,
    ORD_ABOVE     ,
    ORD_BELOW     ,
    ORD_ABOVE_ONE ,
    ORD_BELOW_ONE ,
    ORD_FRONT     ,
    ORD_BACK
};

/** Float array drawing (Float Array such as seismic image: trace is vertical) **/

enum TraceType {
  TR_NORMAL   = 0,
  TR_KILLED   ,
  TR_REVERSED ,
  TR_GAP
};

enum SampleUnits {
  SU_TIME         = 0,
  SU_DEPTH_FEET   ,
  SU_DEPTH_METERS
};

enum SeismicInterpolationType {
  SIT_STEP       = 0 ,
  SIT_LINEAR     = 1 ,
  SIT_QUADRATIC  = 2
};

enum SeismicClipType {
  SCT_NOCLIP    = 0 ,
  SCT_FILL      = 1 ,
  SCT_WIGGLE    = 2
};

enum SeismicPlotType {
  SPT_WIGGLE               = 1,
  SPT_POSITIVE_FILL        = 2,
  SPT_NEGATIVE_FILL        = 4,
  SPT_COLOR                = 8,
  SPT_LOBE                 = 16,
  SPT_DENSITY              = 64,
  SPT_INTERPOLATED_DENSITY = 128,
  //
  SPT_POSITIVE_FILL_AND_WIGGLE   = SPT_POSITIVE_FILL | SPT_WIGGLE        ,
  SPT_NEGATIVE_FILL_AND_WIGGLE   = SPT_NEGATIVE_FILL | SPT_WIGGLE        ,
  SPT_POSITIVE_AND_NEGATIVE_FILL = SPT_POSITIVE_FILL | SPT_NEGATIVE_FILL ,
  SPT_POSITIVE_COLOR_FILL        = SPT_POSITIVE_FILL | SPT_COLOR         ,
  SPT_NEGATIVE_COLOR_FILL        = SPT_NEGATIVE_FILL | SPT_COLOR         ,
  SPT_DENSITY_AND_WIGGLE         = SPT_DENSITY       | SPT_WIGGLE        ,
  SPT_DENSITY_AND_POSITIVE_FILL  = SPT_DENSITY       | SPT_POSITIVE_FILL ,
  SPT_DENSITY_AND_NEGATIVE_FILL  = SPT_DENSITY       | SPT_NEGATIVE_FILL ,
  SPT_COLOR_FILL                 = SPT_POSITIVE_FILL | SPT_NEGATIVE_FILL | SPT_COLOR,
  SPT_LOBE_FILL                  = SPT_POSITIVE_FILL | SPT_NEGATIVE_FILL | SPT_COLOR | SPT_LOBE
};

enum SeismicNormMode {
  // values
  SNM_DATA_TYPE     = 0 ,
  SNM_TRACE_MAXIMUM = 1 ,
  SNM_TRACE_AVERAGE = 2 ,
  SNM_TRACE_RMS     = 3 ,
  SNM_LIMITS        = 4 ,
  // default
  SNM_DEFAULT       = SNM_LIMITS
};


/** ====================================================
 *  PRINTING OPTIONS (for instance, in Qt)
 *  ================================================= */

enum ImageOutput {
  IMG_O_FILE    ,
  IMG_O_PRINTER
};

enum ImageDepth {
  IMG_D_1  = 1  ,
  IMG_D_8  = 8  ,
  IMG_D_16 = 16 ,
  IMG_D_24 = 24 ,
  IMG_D_32 = 32
};

enum ImageFormat {
  IMG_F_BMP	 , // Windows Bitmap
  IMG_F_GIF  , // Graphic Interchange Format (optional)
  IMG_F_JPG  , // Joint Photographic Experts Group
  IMG_F_JPEG , // Joint Photographic Experts Group
  IMG_F_MNG  , // Multiple-image Network Graphics
  IMG_F_PNG  , // Portable Network Graphics
  IMG_F_PBM	 , // Portable Bitmap
  IMG_F_PGM	 , // Portable Graymap
  IMG_F_PPM	 , // Portable Pixmap
  IMG_F_TIF  , // Tagged Image File Format
  IMG_F_TIFF , // Tagged Image File Format
  IMG_F_XBM	 , // X11 Bitmap
  IMG_F_XPM	 , // X11 Pixmap
  IMG_F_SVG	 , // Scalable Vector Graphics
  IMG_F_TGA	 , // Targa Image Format
  // printer
  IMG_F_PDF	 , // Acrobat reader
  IMG_F_PS     // PostScript
};

enum ImageScaling {
  IMG_S_FIT      ,
  IMG_S_ORIGINAL
};

enum PrinterColorMode {
  PRT_CM_COLOR     = 1 ,
  PRT_CM_GRAYSCALE = 0
};

enum PrinterOrientation {
  PRT_OR_PORTRAIT  = 0 ,
  PRT_OR_LANDSCAPE = 1
};

enum PrinterResolution {
  PRT_PM_SCREEN_RESOLUTION = 0 ,
  PRT_PM_HIGH_RESOLUTION   = 2
};



/**
** Graphics types
*/

  enum DisplayType {
    // one location
    DISPLAY_SINGLE            ,
    // fan (lines starting at the same point)
    DISPLAY_FAN_OF_FIELD      ,
    DISPLAY_FAN_OF_LINE       ,
    DISPLAY_FAN_OF_SELECTED   ,
    DISPLAY_FAN_OF_NEIGHBOURS ,
    // locations on a line
    DISPLAY_LINE
  };


  enum OriginType {
    ORIGIN_ALL        ,
    ORIGIN_SELECTED   ,
    ORIGIN_LINE       ,
    ORIGIN_NEIGHBOURS ,
    ORIGIN_SINGLE
  };


  /** PINUP MODE : adding labels on the screen. */

  enum PinUpMode {
    PIN_NO    = 1 ,
    PIN_SCRAP ,
    PIN_EDIT
  };


  /** DRAWING . what to draw in a 'vsDrawingLayer' . It uses the colors of the lines */

  // **** TO BE DISCARTED **** //
  /** Drawing type : what to draw in a 'vsDrawingLayer' */
  enum DrawingMethod {
    DMT_BACKGROUND      = 0 , // vertical line at the back
    // semblance
    DMT_SMB_COLORPOSTS  ,
    DMT_SMB_CMB         ,
    DMT_SMB_CENTRAL_CMB ,
    // fan
    DMT_FAN_ALL         ,
    DMT_FAN_ENVELOPPE   ,
    DMT_FAN_AVERAGE     ,
    // velocity graph
    DMT_VEL_LINE        , // current velocity line
    DMT_VEL_PICKS         // current velocity line
  };

  /** LINE (VELOCITY) */

  /** line and points drawer */
  enum LineAspectType {
    // background . can also draw a vertical  line (e.g.: FOC, Eta graph)
    LAT_BACKGROUND         = 0 , LAT_FIRST = LAT_BACKGROUND ,
    // map  [ vqSmallBrushPM::ConstructorOptions ]
    LAT_MAP_DATA_LINE      ,
    LAT_MAP_VELOCITY_LINE  ,
    LAT_MAP_THICK_LINE     ,
    LAT_MAP_THIN_LINE      ,
    LAT_MAP_LOCATIONS      ,
    LAT_MAP_SELECTED       ,
    LAT_MAP_CONTOUR_LINE   ,
    LAT_MAP_CONTOUR_STRING ,
    // velocity graph
    LAT_VEL_LINE           , // current velocity line
    LAT_FAN_ALL            ,
    LAT_FAN_ENVELOPPE      ,
    LAT_FAN_AVERAGE        ,
    // velocity table
    LAT_TAB_FUNCTION       , // vsVelocityFunctionsDoc::mySetFunctionsAttribute => vxVelocityFunctionsPM
    LAT_TAB_INVERSION      , // vsVelocityFunctionsDoc::myUpdateInversionShapes
    // semblance
    LAT_SMB_CMB            , // cmb
    LAT_SMB_CENTRAL_CMB    , // central cmb
    LAT_SMB_COLORPOSTS     , // colorpost
    LAT_SMB_SURFACE        , // surface getLeftAxisPositionMarker
    LAT_SMB_AUTOVEL_DIM    , // autovel (dim auto) myDimAutoVelScene
    LAT_SMB_AUTOVEL_SINGLE , // mySingleAutoVelScene
    LAT_SMB_AUTOVEL_TRIAL  , // myTrialScene
    LAT_SMB_INTERVAL       , // myIntervalVelocityScene
    LAT_SMB_BOX            , // myCursorLayer
    // vsSembPicksPM
    LAT_SMB_OPERATIONS     , // =  0 , // label informing about the current operations (added 30 october 2012)
    LAT_SMB_MULTIPLES      , // =  1 ,
    LAT_SMB_GUIDE_FUNCTION , // =  2 ,
    LAT_SMB_BACK           , // =  3 ,
    LAT_SMB_FRONT          , // =  4 ,
    LAT_SMB_NEXT           , // =  5 ,
    LAT_SMB_PREVIOUS       , // =  6 ,
    LAT_SMB_MAIN           , // =  7 ,
    LAT_SMB_TRIAL          , // =  8 ,
    LAT_SMB_HORIZON        , // =  9 ,
    LAT_SMB_RADIUS         , // = 10 ,
    LAT_SMB_INTERVAL_VEL   , // = 11 ,
    LAT_SMB_RADIUS_AVG     , // = 12 ,
    LAT_SMB_LAST_FUNCTION  , // = 13 ,
    //-------------------------------------
    // GATHER RELATED
    //-------------------------------------
    LAT_GTH_TIME_TICKS                    ,
    // vsNmoHyperbolaDoc
    LAT_GTH_TRANSPARENT                   ,
    LAT_GTH_SECOND                        ,
    LAT_GTH_SECOND_INVERSION              ,
    LAT_GTH_SECOND_NEAR_INVERSION         ,
    LAT_GTH_FOURTH                        ,
    LAT_GTH_FOURTH_IGNORED                ,
    LAT_GTH_FOURTH_INVERSION              ,
    LAT_GTH_FOURTH_INVERSION_IGNORED      ,
    LAT_GTH_FOURTH_NEAR_INVERSION         ,
    LAT_GTH_FOURTH_NEAR_INVERSION_IGNORED ,
    // vsMute
    LAT_MUTE_NEW              ,
    LAT_MUTE_INTERPOLATED     ,
    LAT_MUTE_AUTOMUTE         ,
    LAT_MUTE_CURRENT_LOCATION ,
    LAT_MUTE_ANY_LOCATION     ,
    // vsNmoAllGathersDocCollector : all gathers frame
    LAT_GTH_FRAME_ONLY   ,
    LAT_GTH_FRAME_FILLED ,
    LAT_GTH_SURFACE      ,
    //-------------------------------------
    // STACK RELATED
    //-------------------------------------
    // stack . mini-stack
    LAT_STK_ANALYSIS       , // getAnalysisColor
    LAT_STK_FUNCTION       , // getPicksColor (function)
    LAT_STK_PICKS          , // getPicksColor (picks)
    LAT_STK_BETWEEN        , // getBtwColor
    LAT_STK_PREVIOUS       , // getPreColor
    LAT_STK_CURRENT        , // getCurColor
    LAT_STK_PST            , // getPstColor
    // shapes
    LAT_STK_RUBBERBAND     , // rubber band to draw horizons
    LAT_STK_BOX            , // selection box in the stack
    LAT_SBS_HIGHLIGHT      , // highlighted frame in the mini-atack
    // composite
    LAT_CMP_PICKS          ,
    // mini-stack
    LAT_SBS_MN_CURRENT     , // pick on the line
    LAT_SBS_MN_PREVIOUS    , // adjacent pick
    LAT_SBS_MN_NEXT        ,
    LAT_SBS_MN_BACK        ,
    LAT_SBS_MN_FRONT       ,
    LAT_SBS_GF_CURRENT     , // guide function
    LAT_SBS_GF_PREVIOUS    ,
    LAT_SBS_GF_NEXT        ,
    LAT_SBS_GF_BACK        ,
    LAT_SBS_GF_FRONT       ,
    // cursor
    LAT_CURSOR_CROSS       ,
    LAT_CURSOR_LINE        ,
    // hub
    LAT_HRZ_STATIC         ,
    LAT_HUB_LINK           , LAT_LAST = LAT_HUB_LINK ,

    // TO BE REMOVED ....
    // common
    //LAT_VERTICAL_LINE     , // vertical line at the back
    LAT_CMB                ,
    LAT_CENTRAL_CMB        ,
    LAT_SEMBLANCE          ,
    // specific to the
    LAT_SINGLE_LINE        ,
    LAT_FAN_OF_FIELD       ,
    LAT_FAN_OF_LINE        ,
    LAT_FAN_OF_SELECTED    ,
    LAT_FAN_OF_NEIGHBOURS  ,
    LAT_LINE
  };

  /** VELOCITY SLICE */

  /** velocity table (##layer##) used by 'TypVelocityTablePM' */
  enum VelocityAspectType {
    VAT_UNDEFINED         ,
    //
    VAT_VELOCITY_TABLE    , VAT_FIRST = VAT_VELOCITY_TABLE ,
    VAT_MAP               ,
    VAT_VERACITY          , VAT_LAST  = VAT_VERACITY
  };

  /** what field to consider */
  enum VelocityField {
    VFD_CURRENT ,
    VFD_TRIAL   ,
    VFD_GUIDE   ,
    VFD_MUTE
  };

  /** what locations */
  enum VelocityLocations {
    VLC_CURRENT ,
    VLC_LINE    ,
    VLC_AREA    ,
    VLC_FIELD
  };

  /** how to display */
  enum VelocityDisplay {
    VDP_CURRENT       ,
    VDP_LEFT          ,
    VDP_RIGHT         ,
    VDP_PREVIOUS      ,
    VDP_NEXT          ,
    VDP_FAN           ,
    VDP_FAN_AVERAGE   ,
    VDP_FAN_ENVELOPPE ,
    VDP_LINE
  };

  /** component of the pick */
  enum VelocityData {
    VELPOINT_VEL = 0 ,
    VELPOINT_INT     ,
    VELPOINT_FOC     ,
    VELPOINT_ETA_AN  ,
    VELPOINT_ETA_SH
  };

  /** HORIZON */

  /** horizon (##layer##) used by 'TypHorizonLayerPM' */
  enum HorizonAspectType { // (layer)
    HAT_UNDEFINED ,
    //
    HAT_NORMAL , HAT_FIRST  = HAT_NORMAL ,
    HAT_STATIC , HAT_LAST   = HAT_STATIC
  };

  /** SEMBLANCE */

  /** semblance (##layer##) used by 'TypSemblanceLayersPM' */
  enum SemblanceAspectType {
    SAT_UNDEFINED ,
    //
    SAT_SEMBLANCE , SAT_FIRST = SAT_SEMBLANCE ,
    SAT_OVERLAY   , SAT_LAST  = SAT_OVERLAY
  };

  enum SemblanceOriginType {
    SOT_CURRENT ,
    SOT_RESTACK
  };

  enum SemblanceDisplayType {
    SDT_RECTANGLE ,
    SDT_CONTOUR   ,
    SDT_WIGGLE    ,
    SDT_OVERLAY
  };

  /** OVERLAY */

  /** overlay (##layer##) used by 'TypOverlayLayersPM' */
  enum OverlayAspectType {
    OAT_UNDEFINED       ,
    //
    OAT_SEMBLANCE       , OAT_FIRST = OAT_SEMBLANCE ,
    OAT_SEMBLANCE_GRAY  ,
    OAT_SEISMIC_STACK   ,
    OAT_SEISMIC_GATHER  ,
    OAT_SEISMIC_OVERLAY ,
    OAT_VELOCITY_TABLE  , OAT_LAST  = OAT_VELOCITY_TABLE
  };

  enum OverlayOriginType {
    OOT_STACK     ,
    OOT_GATHER    ,
    OOT_SEMBLANCE ,
    OOT_VELOCITY
  };




/** ====================================================
 *  APPLICATION OPTIONS: set of parameters that applies to the application.
 *  ================================================= */

enum FontType {
  //
  FNT_TITLE        = 0 ,
  FNT_SECTION_TITLE    ,
  FNT_VERTICAL_MAJOR   ,
  FNT_VERTICAL_MINOR   ,
  FNT_HORIZONTAL_MAJOR ,
  FNT_HORIZONTAL_MINOR ,
  FNT_TIMESLICE_INLINE_MAJOR    ,
  FNT_TIMESLICE_CROSSLINE_MINOR ,
  //
  FNT_CONTOUR_LINE     ,
  FNT_HORIZON          ,
  //
  FNT_LAST  = FNT_HORIZON ,
  FNT_FIRST = FNT_TITLE
};

enum AxisType {
  //
  AXI_VERTICAL_TIME   = 0 ,
  AXI_HORIZONTAL_VELOCITY ,
  AXI_HORIZONTAL_SIGNAL   ,
  //
  AXI_FIRST = AXI_VERTICAL_TIME  ,
  AXI_LAST  = AXI_HORIZONTAL_SIGNAL
};

enum CursorType {
  CRS_UNDEFINED = 0 ,
  CRS_NONE      ,
  CRS_ANY       ,
  CRS_WEST_EAST
};

enum SoundMode {
  SND_BEEP   = 0 ,
  SND_VISUAL
};

enum DeleteMode {
  DEL_DRAG     = 0 ,
  DEL_REGION   ,
  DEL_FUNCTION
};

}; // namespace



#endif


#ifndef TYP_OPTIONS_PM_HPP
#define TYP_OPTIONS_PM_HPP

// C++
#include <fstream>
#include <list>
#include <vector>

#include "MscDataHolder.hpp"
#include "MscString.hpp"

#include "TypEnumerations.hpp"
#include "TypColorsPM.hpp"


class TypImagePM : public MscDataTeam {

public:

  // id of the flags 
  enum {
    ID_START_FLAG           ,
    // output
    ID_OUTPUT               ,
    ID_FILE_DIRECTORY       ,
    ID_USE_DEFAULT_FILENAME ,
    ID_FILE_NAME            ,
    ID_PRINTER_NAME         ,
    // image
    ID_FORMAT               ,
    ID_IMAGE_DEPTH          ,
    ID_SCALING              ,
    ID_COMPRESSION          ,
    // printer
    ID_RESOLUTION           ,
    ID_ORIENTATION          ,
    ID_COLOR_MODE           ,
    // end
    ID_END_FLAG
  };

  TypImagePM();

  /** used in the tooltip */
  static const char * getComment( int dataId );

  /** name used to save in a file 
   * see source code in "vqImagePMEDForm::mySaveOutputImageFn" for the checks */
  MscString  getFullPathName( const char * tmpName = 0 );

  /** value suitable for QImage */
  MscString  getFormatString();

  /** identify the values */
  static const Typ::ValuesStruct * getValuesStructFromLabel( const MscString & label );

  void saveSignals( void );
  void sendSignals( void );

//-------------------------------------
// Attributes Get & Set
//-------------------------------------
  int  getDisplayType( void ) const;
  void setDisplayType( int disp );
  
  int  getTargetType( void ) const;
  void setTargetType( int target );

  const MscString& getOutputDirPath( void ) const;
  void  setOutputDirPath( const MscString& path );

  int  getImageCompressionValue( void ) const;
  void setImageCompressionValue( int comp );

  int  getColorDepthType( void ) const;
  void setColorDepthType( int depth );

  const MscString& getOutputFileName( void ) const;
  void  setOutputFileName( const MscString& file );

  int  getUseDefaultFileName( void ) const;
  void setUseDefaultFileName( int ans );

  bool getIncludeLayerName() const;
  void setIncludeLayerName( bool use );

  int getImageFormatType( void ) const;
  void setImageFormatType( int type );

  const MscString& getPrinterName( void ) const;
  void setPrinterName( const MscString& name );

  int getPrinterOrientation( void ) const;
  void setPrinterOrientation( int type );

  int getPrinterResolution( void ) const;
  void setPrinterResolution( int type );

  int getPrinterScale( void ) const;
  void setPrinterScale( int type );
  
  void setDataList( const std::list<MscString>& dlist );

//-------------------------------------
// Indirect Send()
//-------------------------------------

  const std::list<MscString>& retreiveDataList( const MscString& type );
  int getUniqueIDForRow( int row );
  bool updateDataView( const MscString& type, int uniqueid );
  
  // OSTREAM 
  friend std::ostream &operator<<( std::ostream &, TypImagePM & );
  friend std::istream &operator>>( std::istream &, TypImagePM & );

private:
 
  void mySendSignal( bool realSignal=true );

  // Attributes
  bool mySendSignalOut;

  std::list<MscString> myDataList;
  std::vector<int> myUniqueIDList;
  MscString myOutputDir;
  MscString myOutputFile;
  int myImageCompression;
  int myColorDepth;
  int myUseDefaultFileName;
  bool myIncludeLayerName;
  int myDisplayType;
  int myTargetType;
  int myImageFormatType;
  int myPrinterOrientation;
  int myPrinterResolution;
  int myPrinterScale;
  MscString myPrinterName;

};



/** ======================
  * Parameter Model Types
  * ====================== */



/** "TypPmType" is used by the application */
namespace TypPmType {


/** ----------------------------
** Type of the parameter models
  ** ------------------------ **/

  enum Enum {
    // Justt make sure. (size used to allocate array)
    // Yes, there are unused places Typt I don't mind (30 characters ...)
    PM_FIRST                       = 0 ,
      // Horizon
      PM_HORIZON                     ,
      // vsModuleLinkerId::VELOCITY_TABLE
      PM_VELOCITY_TABLE              ,
      // vsModuleLinkerId::VELOCITY_GRAPH
      PM_VELOCITY_GRAPH              ,
      // vsModuleLinkerId::MAP
      PM_MAP                         ,
      PM_VERACITY                    ,
      // vsModuleLinkerId::SEMBLANCE
      PM_SEMBLANCE                   ,
      PM_RADIUS                      ,
      PM_AVERAGE                     ,
      // vsModuleLinkerId::PANEL
      PM_PANEL                       ,
      PM_PANEL_SEISMIC_DISPLAY       ,
      PM_PANEL_SEISMIC_PROCESS       ,
      // vsModuleLinkerId::PANEL_LINE (Side By Side)
      PM_SBS_SEISMIC_DISPLAY         ,
      PM_SBS_SEISMIC_PROCESS         ,
      // vsModuleLinkerId::COMPOSITE_STACK
      PM_COMPOSITE_SEISMIC_DISPLAY   ,
      PM_COMPOSITE_SEISMIC_PROCESS   ,
      // vsModuleLinkerId::RESTACK
      PM_RESTACK                     ,
      PM_RESTACK_SEISMIC_DISPLAY     ,
      PM_RESTACK_SEISMIC_PROCESS     ,
      // vsModuleLinkerId::GATHER & vsModuleLinkerId::GATHER_LINE
      PM_GATHER                      ,
      PM_GATHER_VX_NMO               ,
      // vsModuleLinkerId::GATHER
      PM_GATHER_SEISMIC_DISPLAY      ,
      PM_GATHER_SEISMIC_PROCESS      ,
      // vsModuleLinkerId::GATHER_LINE
      PM_GATHER_LINE                 ,
      PM_GATHER_LINE_VX_NMO          ,
      PM_GATHER_LINE_SEISMIC_DISPLAY ,
      PM_GATHER_LINE_SEISMIC_PROCESS ,
      // DIMENSION OF THE ARRAY (can be seen as undefined value)
      PM_DIMENSION
  };

}





/*************************************************************************
 ** storage of the options
*************************************************************************/



/**--------------
* TypOptionsPM
*--------------*/

class TypOptionsPM : public MscDataTeam {

public :
  static const char * CLASS_NAME ;
  /** Flags for 'MscDataTeam' read/write
   * values to save in , to access from */
  enum {
    ID_START_FLAG             ,
    // aspect
    ID_RESOLUTION_FONT        , // float
    ID_RESOLUTION_PIXMAP      , // float
    ID_BANNER                 , // bool
    // options
    ID_WATER_BOTTOM_ON        , // bool
    ID_WATER_BOTTOM_VALUE     , // float
    ID_ALLOW_INVERSION        , // bool
    ID_DELETE_MODE            , // DT_INT_DeleteMode
    ID_TOLERANCE_DELETE       , // int
    ID_TOLERANCE_MOVE         , // int
    ID_CURSOR_MODE            , // DT_INT_CursorMode
    ID_SET_TO_SILENCE         , // bool
    ID_PINUP_MODE             , // DT_INT_PinUpMode
    ID_CURSOR_MESSAGE_ON      , // bool
    ID_CURSOR_MESSAGE_ENABLED , // bool
    ID_NUMBER_OF_SEMBLANCE    , // int  : odd number from 1 to 21.
    ID_NUMBER_OF_GATHER       , // int  : odd number from 1 to 21.
    ID_STEP_INCREMENT         , // int  : 1 to ...
    ID_CHANGE_VEL_ORIENTATION , // bool
    // end
    ID_END_FLAG
  };

  TypOptionsPM();
};


/**--------------
* TypMinMaxPM
*--------------*/


class TypMinMaxPM : public MscDataTeam {

public :
  static const char * CLASS_NAME ;
  /** Min Max Types */
  enum Type {
    MM_VELOCITY , MM_FIRST = MM_VELOCITY ,
    MM_INTERVAL ,
    MM_FOC      ,
    MM_ETA      , MM_LAST  = MM_ETA
  };
  /** Flags for 'MscDataTeam' read/write
   * values to save in , to access from */
  enum {
    ID_START_FLAG ,
    ID_MIN_VALUE  ,
    ID_MAX_VALUE  ,
    ID_UNIT       ,
    // end
    ID_END_FLAG
  };

  TypMinMaxPM( Type );

};





/*************************************************************************
 ** storage of the graphics parameters
*************************************************************************/




/**--------------
* TypFontPM
*--------------*/


class TypFontPM : public MscDataTeam {

public :
  static const char * CLASS_NAME ;
  /** Flags for 'MscDataTeam' read/write
   * values to save in , to access from */
  enum {
    ID_START_FLAG ,
    // font
    ID_SIZE       , // DT_INT_FontSize
    ID_WEIGHT     , // DT_INT_FontWeight
    ID_SLANT      , // DT_INT_FontSlant
    ID_FAMILY     , // DT_INT_FontFamily
    // line
    ID_LINE_COLOR , // DT_INT_Color
    ID_LINE_STYLE , // DT_INT_LineStyle
    ID_LINE_WIDTH , // DT_INT
    ID_FILL_COLOR , // DT_INT_Color
    ID_FILL_STYLE , // DT_INT_FillStyle
    // end
    ID_END_FLAG
  };

  TypFontPM( Typ::FontType );

  /** reset to default */
  void resetToDefault();

  /** get the label */
  MscString getFontLabel() ;

};


/**--------------
* TypAxisPM
*--------------*/


class TypAxisPM : public MscDataTeam {

public :
  static const char * CLASS_NAME ;
  /** Flags for 'MscDataTeam' read/write
   * values to save in , to access from */
  enum {
    ID_START_FLAG   ,
    ID_MAJOR_LABELS , // bool
    ID_MINOR_LABELS , // bool
    ID_TIMING_LINES , // bool
    ID_USER_DEFINED , // bool
    ID_USER_MINOR   , // float
    ID_USER_MAJOR   , // float
    ID_TIME_SHIFT   , // float
    // end
    ID_END_FLAG
  };

  TypAxisPM( Typ::AxisType );

  /** reset to default */
  void resetToDefault();
};



/**--------------
 * TypLinePM
 *--------------*/


class TypLinePM : public MscDataTeam {

public :
  static const char * CLASS_NAME ;
  /** Flags for 'MscDataTeam' read/write.
   * values to save in , to access from .
   * See in 'derivedDataAccess' how they are been accessed */
  enum {
    ID_START_FLAG   ,
    ID_IS_VISIBLE   , // BOOL
    // line
    ID_LINE_WIDTH   , // INT
    ID_LINE_COLOR   , // DT_INT_Color
    ID_LINE_STYLE   , // DT_INT_LineStyle
    ID_FILL_COLOR   , // DT_INT_Color
    ID_FILL_STYLE   , // DT_INT_FillStyle
    // marker
    ID_MARKER_WIDTH , // INT
    ID_MARKER_STYLE , // DT_INT_MarkerStyle
    // end
    ID_END_FLAG
  };

  /** Datatypes */
  enum DataType {
    DATA_SINGLE_VELOCITY ,
    // VelPoint
    DATA_POINT_VEL    ,
    DATA_POINT_INT    ,
    DATA_POINT_ETA_AN ,
    DATA_POINT_ETA_SH ,
    DATA_POINT_FOC    ,
    // Others
    DATA_RMS_VEL ,
    DATA_RMS_INT ,
    DATA_MUTE    ,
    // CMB
    DATA_CMB     ,
    DATA_CENTRAL_CMB
    // ID
  };

  /** Customize */
  typedef struct {
    Typ::LineAspectType myDataType    ;
    bool                myIsVisible   ;
    int                 myLineWidth   ;
    Typ::ColorId        myLineColor   ;
    Typ::LineStyle      myLineStyle   ;
    Typ::ColorId        myFillColor   ;
    Typ::FillStyle      myFillStyle   ;
    int                 myMarkerWidth ;
    Typ::MarkerStyle    myMarkerStyle ;
    const char        * myStartFlag   ;
    int                 myEpitome     ;
    const char        * myComment     ;
  } Customize ;

  /** constructor */
  TypLinePM( Typ::LineAspectType typeOfData );

  /** reset to default */
  void resetToDefault();

  /** according to the option, a specic type of data is requied */
  static bool isRmsFunctionRequired( int );
  static bool isVelPointFunctionRequired( int );

  /** get the label */
  MscString getLineLabel() ;

};


/**--------------
* TypSemblancePM
*--------------*/

class TypSemblancePM : public MscDataTeam {

public :
  static const char * CLASS_NAME ;
  /** Flags for 'MscDataTeam' read/write */
  enum {
    ID_START_FLAG          ,
    /** Line parameters */
    ID_CMB_LINE_PM         , // DT_INT_LineAspectType
    ID_CMB_CENTRAL_LINE_PM , // DT_INT_LineAspectType
    /** parameters for colormap */
    ID_COLORMAP            , // DT_INT_ColormapType
    // end
    ID_END_FLAG
  };

  TypSemblancePM( Typ::SemblanceAspectType );

  /** access to specific members */
  TypColormapPM & getColormapPM() { return myColormapPM; }

private :

  /** parameter */
  TypColormapPM myColormapPM ;
};



/**--------------
* TypOverlayPM
*--------------*/

class TypOverlayPM : public MscDataTeam {

public :
  static const char * CLASS_NAME ;
  /** Flags for 'MscDataTeam' read/write */
  enum {
    ID_START_FLAG           ,
    /** parameters for 'vsSeismicVisual': how to show an overlay */
    ID_BIAS                 , // getZeroLineOffset
    ID_CLIP_FACTOR          , // DT_INT_SeismicClipType
    ID_COLOR_INTERPOLATION  , // DT_INT_SeismicInterpolationType
    ID_FOREGROUND_COLOR     , // DT_INT_Color
    ID_PLOT_TYPE            , // DT_INT_SeismicPlotType
    ID_WIGGLE_INTERPOLATION , // DT_INT_SeismicInterpolationType
    ID_SWING                ,
    ID_NORM_MIN             ,
    ID_NORM_MAX             ,
    ID_REVERSE_AMPLITUDE    , //
    /** parameters for 'vsSeismicVisual': colormap */
    ID_COLORMAP             , // DT_INT_ColormapType
    // end
    ID_END_FLAG
  };

  TypOverlayPM( Typ::OverlayAspectType ,
               const char *startFlag = 0 , const char *endFlag = 0 , int userId = 0 );

  /** access to specific members */
  TypColormapPM & getColormapPM();

private :

  /** parameter */
  std::shared_ptr< TypColormapPM > myColormapPM ;
};





/*************************************************************************
 ** all the parameter models
*************************************************************************/




class TypAppPM : public MscDataTeam {

public :
  static const char * CLASS_NAME ;

  /** signal sent if a child has changed */
  // Signal2< MscDataTeam * , set<int> * > ChildChange ;

  /** Flags for 'MscDataTeam' read/write.
   * values to save in , to access from .
   * See in 'derivedDataAccess' how they are been accessed */
  enum {
    ID_START_FLAG ,
    ID_END_FLAG
  };

  /** singleton */

  static std::shared_ptr<TypAppPM>  instance();
  static void              assignInstance ( TypAppPM * pm );
  static void              releaseInstance( TypAppPM * pm );

  /** constructor / destructor */

  TypAppPM( bool doConnectChildren );
  TypAppPM( const TypAppPM & );
  const   TypAppPM & operator= ( const TypAppPM & );
  ~TypAppPM();

  /** read / write */

  bool write( const MscString & name="" , bool showErrorMessage=false , bool showWaitCursor=false );
  bool read ( const MscString & name="" , bool showErrorMessage=false , bool showWaitCursor=false );

  /** user defined and options parameters */

  float                    getFontPercentage();
  const std::shared_ptr< TypOptionsPM > & getOptionsPM() const { return myOptionsPM ; }
  std::shared_ptr< TypMinMaxPM >    getMinMaxPM( int userId );
  std::shared_ptr< TypImagePM >     getImagePM();

  /** graphics resource values */

  std::shared_ptr< TypFontPM >      getFontPM     ( int userId );
  std::shared_ptr< TypAxisPM >      getAxisPM     ( int userId );
  std::shared_ptr< TypLinePM >      getLinePM     ( int userId );
  std::shared_ptr< TypColormapPM >  getColormapPM ( int userId );

  std::shared_ptr< TypSemblancePM > getSemblancePM( int userId );
  std::shared_ptr< TypOverlayPM >   getOverlayPM  ( int userId );

  /** parameter models of a given class */

  std::vector< std::shared_ptr< MscDataTeam > > getDataHolder( MscDataTeam::ClassType );

  /** connect children so a message is sent */

  void  connectChildren();

private :

  /** not implemented */
  TypAppPM();

  /** send message */
  void  changedHolderSet( MscDataTeam * dh , std::set<int> * cg );

  /** parameter models */
  static std::shared_ptr< TypAppPM > myInstance  ;
  std::shared_ptr< TypOptionsPM >    myOptionsPM ;
};




#endif


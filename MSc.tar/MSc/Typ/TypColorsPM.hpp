#ifndef TYP_COLORS_HPP
#define TYP_COLORS_HPP


#include "MscDataHolder.hpp"
#include "TypStructure.hpp"
#include "TypEnumerations.hpp"


/** ***********************************************************
 *  Identification of the colors and declaration of structures.
 *  ********************************************************* */


namespace Typ {


  //********************//  
  // BASE COLORS        //
  //********************//
 

  /** Values of the colour . 0-255 . Alpha is the transparency . 255 is opaque */
  class FloatColor ;
  class ColorCreateInfo {
  public :
    static const char * CLASS_NAME ;
    ColorCreateInfo( int r=0 , int g=0 , int b=0 , int a=255 );
    ColorCreateInfo( const ColorCreateInfo & c ) { *this = c; }
    bool operator== ( const ColorCreateInfo & c ) const ;
    bool operator!= ( const ColorCreateInfo & c ) const { return (*this == c) ? false : true; }
    const ColorCreateInfo & operator= ( const ColorCreateInfo & );
    ColorCreateInfo( const FloatColor & c )  { *this = c; }
    const ColorCreateInfo & operator= ( const FloatColor & );
    // trim value so it's in range
    static int checkFloat( float );
    // get values (same as QColor): range 0 <=> 255
    int   red  () const { return myRed   ; }
    int   green() const { return myGreen ; }
    int   blue () const { return myBlue  ; }
    int   alpha() const { return myAlpha ; }
    void  complementary() { myRed=(255-myRed); myGreen=(255-myGreen); myBlue=(255-myBlue); }
    float getSaturation() const ; 
    float getBrightness() const ;
    bool  setSaturation( float ) ;
    bool  setBrightness( float ) ;
    // values (not protected at the moment)
    int   myRed   ;
    int   myGreen ;
    int   myBlue  ;
    int   myAlpha ;
  private :
    /** check the value. trim it if possible */
    //int checkFloat( float value );
  } ;
  
  /** Values of the colour . 0.0f <-> 1.0f . Alpha is the transparency . 1.0f is opaque */
  class FloatColor {
  public :
    static const char * CLASS_NAME ;
    FloatColor( float r=0.0f , float g=0.0f , float b=0.0f , float a=1.0f );
    FloatColor( const FloatColor & c ) { *this = c; }
    const FloatColor & operator= ( const FloatColor & c );
    FloatColor( const ColorCreateInfo & c )  { *this = c; }
    const FloatColor & operator= ( const ColorCreateInfo & );
    // get values (same as graphic's "cgRgbColor"): between 0.0f <=> 1.0f
    float red  () const { return myRed   ; }
    float green() const { return myGreen ; }
    float blue () const { return myBlue  ; }
    float alpha() const { return myAlpha ; }
    // values (not protected at the moment) values
    float myRed   ;
    float myGreen ;
    float myBlue  ;
    float myAlpha ;
  private :
    /** check the value. trim it if possible */
    float myCheck( float value );
  } ;



  /** Return the color definition */
  const ColorCreateInfo & getColor( int colorId );



  //************************************************//  
  // COLORMAPS                                      //
  //************************************************//
  
  /** Classify the colormaps in groups . It's own a colormap is generated */
  enum ColorType { 
    COL_TYPE_UNDEFINED        ,
    COL_TYPE_FIXED_COLOR      ,
    COL_TYPE_MONITOR_FRIENDLY ,
    COL_TYPE_FULL_SPECTRUM    ,
    COL_TYPE_PLOTTER_FRIENDLY ,
    COL_TYPE_GREY_SCALE       ,
    COL_TYPE_WHITE_CENTERED   ,
    COL_TYPE_MISCELLANEOUS 
  };  


  /** Define the numbers of colors */
  enum{ STANDARD_NUMBER_OF_COLORS = 128 ,
        MAXIMUM_NUMBER_OF_COLORS  = 216 };

  /** it identifies the colormaps according to the use*/

  enum ColormapType {
    CLM_SEMBLANCE     = 0 , CLM_FIRST = CLM_SEMBLANCE ,
    CLM_SEISMIC_STACK     ,
    CLM_SEISMIC_GATHER    ,
    CLM_SEISMIC_OVERLAY   ,
    CLM_VELOCITY_TABLE    ,
    CLM_MAP_VELOCITY      , CLM_LAST = CLM_MAP_VELOCITY
  };


  /** =======================================**
   ** COLORMAP MANAGEMENT DEFINED            **
   ** INTERNALLY IN "TypColormapDefinitions" **
   ** =======================================*/

  /** callback */
  typedef const ColorCreateInfo * (*ColormapFunction)( int & );
  
  /** Information about a colour */
  struct ColormapInfo {
    Typ::ColorType          myColorType      ;
    Typ::ColormapId         myColormapId     ;
    Typ::ColormapFunction   myColorFunction  ; // callback function to get the values
    const char            * myGuiName        ; // character string for the gui item
    const char            * myStorageName    ; // storage of the name in a file (parameter model file)
    int                     myPreferedNumber ; // minimum number of colors or Typilt-in number of colors ("Fixed Map")
    int                     myIncrement      ;
  };

  /** Get a colormap information */
  const ColormapInfo & getColormapInfo( int colormapId , bool & isPresent );
  ColorType            getColorTypeFromColormapId( int colormapId );
};




//==============================================================
//==============================================================
// COLORMAPS    
//==============================================================
//==============================================================


class TypColormapPM : public MscDataTeam {

public :
  static const char * CLASS_NAME ;

  /** Request id */
  enum RequestId { RQT_CREATE , RQT_MODIFY };
  typedef void (*Callback)( TypColormapPM * , int );

  /** default values */
  static MscDataItem::CreateInfo * defaultColormapPM( Typ::ColormapType type );

  /** Flags for 'MscDataTeam' read/write */
  enum {
    ID_START_FLAG           ,
    /*** definition of the colormap by using existing parameters ***/
    ID_MAP_IDENTIFICATION   , // identification number of a pre-defined map : ==> 100 : fixed size after: variable size
    ID_NUMBER_OF_COLORS     , // int    :  number of colors in the map
    ID_REDUCE_NUMBER        , // bool   :
    // intensity
    ID_LEVEL_COLOR_MODIFY   , // bool   :
    ID_LEVEL_COLOR_VALUE    , // int    :
    ID_LEVEL_BRIGHT_MODIFY  , // bool   :
    ID_LEVEL_BRIGHT_VALUE   , // int    :
    // reverse & complementary
    ID_REVERSE_MAP          , // bool   :
    ID_COMPLEMENTARY_MAP    , // bool   :
    // colors changed
    ID_SET_COLORS           , // used to send a signal
    /*** storage of the colormap in a file ***/
    ID_STORAGE_FILENAME     , // string :
    // end
    ID_END_FLAG 
  };

  /** constructor */ 
  TypColormapPM( Typ::ColormapType = Typ::CLM_SEMBLANCE );

  /** reset to default */
  void    resetToDefault();

  /** copy from existing */
  void    copyValuesFromModel( const TypColormapPM & , bool sendSignal );

  /** need to provide the callback to generate the colormap */
  static void setCallback( Callback cb ) { myCallback = cb ; }

  /** access to the values . Might be created (initialized) . USED BY "vsBaseLayers" */
  const std::vector< Typ::ColorCreateInfo > & getColors() const { return myColors ; }
  bool    getColor( int rank , Typ::ColorCreateInfo & ) const ;

  /** generate color map from the parameters */
  void    generateColormap( bool modifyOnly );

  /** set the color map . it checks it's the same or not as the generated one */
  bool    interpolate( int rank1 , int rank2 ,  bool sendSignal );
  bool    setColors( const std::vector< Typ::ColorCreateInfo > & c , bool isGenerated , bool sendSignal );
  bool    setColor( int rank , const Typ::ColorCreateInfo & , bool sendSignal );

  /** get the state, e.g.: string describing the state of the color map */
  int     getMapIdentification( bool & isFixed , bool & isVariable );
  MscString getDescription( bool & isFixed , bool & isVariable );
  bool    getIsReversed() const { return myIsReversed ; }
  void    setIsReversed( bool b ) { myIsReversed = b ; }
  bool    getIsComplementary() const { return myIsComplementary ; }
  void    setIsComplementary(  bool b ) { myIsComplementary = b; }

private :

  static Callback              myCallback        ;
  std::vector< Typ::ColorCreateInfo > myColors    ;
  bool                         myIsGenerated     ;
  bool                         myIsReversed      ;
  bool                         myIsComplementary ;

};


//==============================================================
//==============================================================
// STORAGE OF COLORS   . I uses information from "TypColormapPM"
// to create the set of colors.
//==============================================================
//==============================================================

 

class TypColormap {
public :
  static const char * CLASS_NAME ;
  TypColormap();
  ~TypColormap();
  
  /** Utilities for the colormap
   *  limitNumber : limit the number of colors
   *  reverse     : change the order of the colors in the palette 
   *  inverse     : turn each color into its complementary color 
   *  saturation  : color intensity of the colormap
   *  brightness  : brightness intensity of the colormap
   */
  
  bool                 generate( const std::shared_ptr< TypColormapPM > & );
  
  bool                 reverse();
  bool                 complementary();
  bool                 sample( int );
  bool                 interpolate( int rank1 , int rank2 );

  float                getSaturation       () const ; // float between 0.0 and 1.0f
  int                  getSaturationPercent() const ; // int between 0 and 100
  bool                 setSaturationPercent( int );

  float                getBrightness       () const ; // float between 0.0 and 1.0f
  int                  getBrightnessPercent() const ; // int between 0 and 100
  bool                 setBrightnessPercent( int );


  /** get / set the colors */
  const std::vector< Typ::ColorCreateInfo > & getColors() const { return myColors ; }
  bool                 getColor( int rank , Typ::ColorCreateInfo & ) const ;
  bool                 setColors( const Typ::ColorCreateInfo * , int numberOfColors );
  bool                 setColors( const std::vector< Typ::ColorCreateInfo > & );
  bool                 getColors( std::vector< Typ::ColorCreateInfo > & colors ) const { colors = myColors ; return (colors.empty()==false); }
  int                  getNumberOfColors() const { return myColors.size(); }

private :
  std::vector< Typ::ColorCreateInfo > myColors      ;
  bool                              myIsGenerated ;
  std::shared_ptr< TypColormapPM >   myColormapPM  ;
};


#endif

#ifndef TYP_STRUCTURE_HPP
#define TYP_STRUCTURE_HPP


namespace Typ {


/** ====================================================
 *  COLOURS .
 *  ================================================= */

enum ColorId {
  COL_ALPHA        = 255 , // Default Alpha (opaque)
  COL_UNDEFINED    = -1 ,
  // default standard colours.
  COL_BLACK        =  0 , //   0   0   0  -> Qt::black
  COL_DARK_RED     =  1 , // 128   0   0  -> Qt::darkRed
  COL_DARK_GREEN   =  2 , //   0 128   0  -> Qt::darkGreen
  COL_DARK_YELLOW  =  3 , // 128 128   0  -> Qt::darkYellow
  COL_DARK_BLUE    =  4 , //   0   0 128  -> Qt::darkBlue
  COL_DARK_MAGENTA =  5 , // 128   0 128  -> Qt::darkMagenta
  COL_DARK_CYAN    =  6 , //   0 128 128  -> Qt::darkCyan
  COL_LIGHT_GRAY   =  7 , // 192 192 192  -> Qt::lightGray
  COL_GRAY         =  8 , // 128 128 128  -> Qt::gray
  COL_RED          =  9 , // 255   0   0  -> Qt::red
  COL_GREEN        = 10 , //   0 255   0  -> Qt::green
  COL_YELLOW       = 11 , // 255 255   0  -> Qt::yellow
  COL_BLUE         = 12 , //   0   0 255  -> Qt::blue
  COL_MAGENTA      = 13 , // 255   0 255  -> Qt::magenta
  COL_CYAN         = 14 , //   0 255 255  -> Qt::cyan
  COL_WHITE        = 15 , // 255 255 255  -> Qt::white
  // others
  COL_FRAME        = 16 , // 212 208 200
  COL_DARK_GRAY    = 17 , //  96  96  96
  COL_ORANGE       = 18 , // 255 170   0
  COL_FIRST        = COL_BLACK        ,
  COL_LAST         = COL_ORANGE       ,
  // aliases
  COL_MAROON       = COL_DARK_RED     ,
  COL_OLIVE        = COL_DARK_YELLOW  ,
  COL_NAVY         = COL_DARK_BLUE    ,
  COL_PURPLE       = COL_DARK_MAGENTA ,
  COL_TEAL         = COL_DARK_CYAN    ,
  COL_SILVER       = COL_LIGHT_GRAY   ,
  COL_LIME         = COL_GREEN        ,
  COL_FUCHSIA      = COL_MAGENTA      ,
  COL_AQUA         = COL_CYAN         ,
  // 26 user-defined colours.
  COL_USER_01      = (COL_LAST + 1) ,
  COL_USER_02 , COL_USER_03 , COL_USER_04 , COL_USER_05 , COL_USER_06 ,
  COL_USER_07 , COL_USER_08 , COL_USER_09 , COL_USER_10 , COL_USER_11 ,
  COL_USER_12 , COL_USER_13 , COL_USER_14 , COL_USER_15 , COL_USER_16 ,
  COL_USER_17 , COL_USER_18 , COL_USER_19 , COL_USER_20 , COL_USER_21 ,
  COL_USER_22 , COL_USER_23 , COL_USER_24 , COL_USER_25 , COL_USER_26 ,
  COL_FIRST_USER_COLOR = COL_USER_01 ,
  COL_LAST_USER_COLOR  = COL_USER_26
} ;


  /** Values (for the combo box and to save the combobox option) */
  typedef struct {
    int          myValue   ; // value used by the programme, such as option, resource or parameter.
    const char * myFlag    ; // corresponding name in the parameter file rather than a magic value.
    const char * myLabel   ; // label shown in the GUI (e.g.:combobox).
    const char * myPixmap  ; // pixmap in the GUI (e.g.:combobox).
    /*ColorId*/ int myColorId ; // colour id (Typ::ColorId) shown in the combobox (Typ::COL_UNDEFINED=-1 for nothing)
  } ValuesStruct ;

};


#endif


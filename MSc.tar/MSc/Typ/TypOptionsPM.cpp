#include "TypOptionsPM.hpp"

#include "MscUtl.hpp"


//-------------------------------------
// See the previous version: ""
//-------------------------------------
/*
  int  myTargetType;         // DT_INT_ImageOutput // Typ:: FILE // *** GUI ID_OUTPUT 
  //MscString myOutputDir;       // DT_STRING // "" 
  MscString myOutputFile;      // DT_STRING // "" // *** GUI ID_FILE_NAME
  MscString myPrinterName;     // DT_STRING // ""
  bool myUseDefaultFileName; // DT_BOOL // true // *** GUI ID_FILE_CHECKBOX 

  int  myImageFormatType;    // DT_INT_ImageFormat  // Typ:: PNG // GUI *** ID_FILE_FORMAT_COMBOBOX
  int  myColorDepth;         // DT_INT_ImagePrinterColorMode // 8  // GUI *** ID_FILE_DEPTH_COMBOBOX 
  int  myImageCompression;   // DT_INT  // 30    // *** GUI ID_FILE_COMPR_VALUE
  int  myPrinterOrientation; // DT_INT_PrinterOrientation // 0 // GUI *** ID_PRT_ORIENT_COMBOBOX
  int  myPrinterResolution;  // DT_INT_PrinterResolution // 0 // GUI *** ID_PRT_RESOLUTION_COMBOBOX
  int  myPrinterScale;       // DT_INT_ImageScaling // GUI *** ID_PRT_SCALING_COMBOBOX
*/


static MscDataItem::CreateInfo TypImagePmBP[] = {
  { TypImagePM::ID_START_FLAG         , "<Image>"       , MscDataItem::DT_START_FLAG      , 0 , 0 , 0 , 0 ,
    "Images and Printer parameters" } , 
  // image output
  { TypImagePM::ID_OUTPUT , "TargetType" , MscDataItem::DT_INT_ImageOutput , Typ::IMG_O_FILE , 0 , 0 , 0 ,
    "the output (file or printer) of the images" },
  { TypImagePM::ID_USE_DEFAULT_FILENAME , "UseDefaultFileName" , MscDataItem::DT_BOOL , (int)true , 0 , 0 , 0 ,
    "rather than using the defined name, use " },
  { TypImagePM::ID_FILE_DIRECTORY , "FileDirectory" , MscDataItem::DT_STRING , 0 , 0 , 0 , 0 ,
    "directory to save the images files in" },
  { TypImagePM::ID_FILE_NAME , "FileName" , MscDataItem::DT_STRING , 0 , 0 , 0 , 0 ,
    "name of the file (without the directory)" },
  // printer output
  { TypImagePM::ID_PRINTER_NAME , "PrinterName" , MscDataItem::DT_STRING , 0 , 0 , 0 , 0 ,
    "selected printer name"},
  // image properties
  { TypImagePM::ID_FORMAT , "ImageFormat" , MscDataItem::DT_INT_ImageFormat , Typ::IMG_F_PNG , 0 , 0 , 0 ,
    "Available Formats (25 July 2015)\n" 
    "are some of the belows (pds and ps available in the printer)\n"
    "\n"
    "bmp  Windows Bitmap\n"
    "gif  Graphic Interchange Format (optional)\n"
    "jpg  Joint Photographic Experts Group\n"
    "jpeg Joint Photographic Experts Group\n"
    "mng  Multiple-image Network Graphics\n"
    "png  Portable Network Graphics\n"
    "pbm  Portable Bitmap\n"
    "pgm  Portable Graymap\n"
    "ppm  Portable Pixmap\n"
    "tiff Tagged Image File Format\n"
    "xbm  X11 Bitmap\n"
    "xpm  X11 Pixmap\n"
    "svg  Scalable Vector Graphics\n"
    "tga Targa Image Format"
  },
  { TypImagePM::ID_IMAGE_DEPTH , "ImageDepth" , MscDataItem::DT_INT_ImageDepth , Typ::IMG_D_8 , 0 , 0 , 0 ,
    "the depth of the image.\n"
    "The image depth is the number of bits used to store a single pixel,\n"
    "also called bits per pixel (bpp).\n"
    "The supported depths are 1, 8, 16, 24 and 32." },
  { TypImagePM::ID_SCALING , "ImageScaling" , MscDataItem::DT_INT_ImageScaling , Typ::IMG_S_FIT , 0 , 0 , 0 ,
    "how to use the surface of the page" },
  { TypImagePM::ID_COMPRESSION , "Compression" , MscDataItem::DT_INT , 30 , 0 , 0 , 0 ,
    "algorithm for the storage of the image\n"
    "30 is the default. 0 is low and 100 is high compression" },
  // printer properties
  { TypImagePM::ID_RESOLUTION , "PrinterResolution" , MscDataItem::DT_INT_PrinterResolution , Typ::PRT_PM_SCREEN_RESOLUTION , 0 , 0 , 0 ,
    "Screen: use same resolution as the image's one (default)\nHigh resolution: use the best resolution of the printer" },
  { TypImagePM::ID_ORIENTATION , "PrinterOrientation" , MscDataItem::DT_INT_PrinterOrientation , Typ::PRT_OR_PORTRAIT , 0 , 0 , 0 ,
    "orientation of the image on the page" },
  { TypImagePM::ID_COLOR_MODE , "PrinterColorMode" , MscDataItem::DT_INT_PrinterColorMode , Typ::PRT_CM_COLOR , 0 , 0 , 0 ,
    "It's the depth: number of bits to store the color)\n"
    "Values are 1 (grayscale), 8 (color), "},
  // end
  { TypImagePM::ID_END_FLAG         , "</Image>"       , MscDataItem::DT_END_FLAG      , 0 , 0 , 0 , 0 , 0 }
};



TypImagePM::TypImagePM()
  : MscDataTeam( CT_TypImagePM , sizeof(TypImagePmBP) / sizeof(TypImagePmBP[0]) , TypImagePmBP )
  ,
    myDisplayType(0),
    myTargetType(0),
    myOutputDir(MscString()),
    myOutputFile(MscString()),
    myUseDefaultFileName(1), // Use default
    myIncludeLayerName( true ),
    myImageCompression(30), // range 0 - 100.
    myColorDepth(8), // 8 bit
    myImageFormatType(3), // 3=PNG for QT4. // See vcViewsUtl::supportedImageFormats
    myPrinterName(MscString()),
    myPrinterOrientation(0),
    myPrinterResolution(0),
    myPrinterScale(0),
    mySendSignalOut(true)
{
  // default storage directory
  MscString defaultStorage = MscUtl::homeDirectory() ;
  setString( TypImagePM::ID_FILE_DIRECTORY , defaultStorage );
}




// static method used to set the tooltip.
const char * TypImagePM::getComment( int dataId )
{
  for ( int i=0 ; i < sizeof(TypImagePmBP) / sizeof(TypImagePmBP[0]) ; ++i ) {
    if ( TypImagePmBP[i].myId == dataId ) {
      return TypImagePmBP[i].myComment ;
    }
  }
  return 0 ;
}


// get the full pathname for the save in a file.
// "tmpName" is when the name of the selected view is used
MscString TypImagePM::getFullPathName( const char * tmpName )
{
  // directory
  MscString directory = getString(TypImagePM::ID_FILE_DIRECTORY);
  directory.strip();
  MscUtl::removeEndSlash( directory );
  if ( MscUtl::directoryExists( directory , false ) == false ) { directory = MscUtl::homeDirectory() ; }
  // check file
  MscString fileName  = getString(TypImagePM::ID_FILE_NAME);
  if ( tmpName != 0 ) { fileName = tmpName ; }
  fileName.strip();
  // pathname
  MscString pathHame ;
  pathHame.printf( "%s/%s" , directory.c_str() , fileName.c_str() );  
  pathHame = MscUtl::removeSpaceCamelCase( pathHame );
  // add extension if needed
  MscString extension ;
  extension.printf( ".%s" , getFormatString().c_str() );
  MscUtl::addExtensionIfMissing( pathHame , extension.c_str() );
  // TO CHECK : REMOVE SPECIAL CHARACTERS
  //
  return pathHame;
}



MscString TypImagePM::getFormatString()
{
  return Typ::getValue( MscDataItem::DT_INT_ImageFormat , getInt(TypImagePM::ID_FORMAT) ).myLabel ;
}


const Typ::ValuesStruct * TypImagePM::getValuesStructFromLabel( const MscString & label )
{
  int numberOfValues = 0 ;
  const Typ::ValuesStruct * values = Typ::getValues( MscDataItem::DT_INT_ImageFormat , numberOfValues );
  for ( int i=0 ; i < numberOfValues ; ++i ) {
    if ( label == values[i].myLabel ) {
      return & values[i] ;
    }
  }
  return 0 ;
}



//-------------------------------------
// Signals 
//-------------------------------------
void TypImagePM::saveSignals()
{
   mySendSignalOut = false;
}



void TypImagePM::sendSignals()
{
   mySendSignalOut = true;
   mySendSignal();
}



void TypImagePM::mySendSignal( bool realSignal )
{
  if( mySendSignalOut && realSignal ){
     // TODO  // TODO Send( *this, ParameterModelChanged );
  }
}


//-------------------------------------
// Attributes Get & Set
//-------------------------------------

const MscString& TypImagePM::getOutputDirPath( void ) const
{
  return myOutputDir;
}



void TypImagePM::setOutputDirPath( const MscString& path )
{
  if( myOutputDir != path ){
    myOutputDir = path;
    mySendSignal();
  }    
}


int TypImagePM::getImageCompressionValue( void ) const
{
  return myImageCompression;
}


void TypImagePM::setImageCompressionValue( int comp )
{ 
  if( myImageCompression != comp ){
    myImageCompression = comp;
    mySendSignal();
  }    
}


int TypImagePM::getColorDepthType( void ) const
{ 
   return myColorDepth;
}


void TypImagePM::setColorDepthType( int depth )
{
  if( myColorDepth != depth ){
    myColorDepth = depth;
    mySendSignal();
  }  
}


const MscString& TypImagePM::getOutputFileName( void ) const
{
  return myOutputFile;
}


void TypImagePM::setOutputFileName( const MscString& file )
{
  if( myOutputFile != file ){
    myOutputFile = file;
    mySendSignal();
  }   
} 


int TypImagePM::getUseDefaultFileName( void ) const
{
  return myUseDefaultFileName;
}


void TypImagePM::setUseDefaultFileName( int ans )
{
  if( myUseDefaultFileName != ans ){
    myUseDefaultFileName = ans;
    mySendSignal();
  }     
}

bool TypImagePM::getIncludeLayerName() const
{
  return myIncludeLayerName;
}

void TypImagePM::setIncludeLayerName( bool use )
{
  myIncludeLayerName = use;
}

int TypImagePM::getDisplayType( void ) const
{
  return myDisplayType;
}



void TypImagePM::setDisplayType( int disp )
{
  if( myDisplayType != disp ){
    myDisplayType = disp;
    mySendSignal();
  }    
}



int TypImagePM::getTargetType( void ) const
{
  return myTargetType;
}



void TypImagePM::setTargetType( int target )
{
  if( myTargetType != target ){
    myTargetType = target;
    mySendSignal();
  }    
}


int TypImagePM::getImageFormatType( void ) const
{
  return myImageFormatType;
}


void TypImagePM::setImageFormatType( int type )
{
  if( myImageFormatType != type ){
    myImageFormatType = type;
    mySendSignal();
  }   
}


void TypImagePM::setDataList( const std::list<MscString>& dlist )
{
  if( myDataList != dlist ){
    myDataList = dlist;
  }
}


void TypImagePM::setPrinterName( const MscString& name )
{
  if( myPrinterName != name ){
    myPrinterName = name;
    mySendSignal();
  } 
}


const MscString& TypImagePM::getPrinterName() const
{
  return myPrinterName;
}


void TypImagePM::setPrinterOrientation( int type )
{
  if( myPrinterOrientation != type ){
    myPrinterOrientation = type;
    mySendSignal();
  }    
}


int TypImagePM::getPrinterOrientation() const
{
  return myPrinterOrientation;
}


void TypImagePM::setPrinterResolution( int type )
{
  if( myPrinterResolution != type ){
    myPrinterResolution = type;
    mySendSignal();
  }    
}


int TypImagePM::getPrinterResolution( void ) const
{
  return myPrinterResolution;
}


void TypImagePM::setPrinterScale( int type )
{
  if( myPrinterScale != type ){
    myPrinterScale = type;
    mySendSignal();
  }   
}


int TypImagePM::getPrinterScale( void ) const
{
  return myPrinterScale;
}


//-------------------------------------
// Indirect // TODO Send()
//-------------------------------------

const std::list<MscString>& TypImagePM::retreiveDataList( const MscString& type )
{
  myDataList.clear();
  // TODO Send( *this, ImageRetrieveDataList, &myDataList, type );

// If we get a valid data list back, then try to get a list of unique ids.
// This will fix a Khoros problem where, if the same data name is present
// multiple times, only the first occurrence is plotted.  Other applications
// won't connect to this signal.

  myUniqueIDList.clear();
  // TODO Send( *this, ImageRetrieveUniqueIDs, &myUniqueIDList, type );
  
  return myDataList;
}

int
TypImagePM::getUniqueIDForRow( int row )
{
  if( myUniqueIDList.size() > 0 ) {
    return myUniqueIDList[row];
  } else {
    return -1;
  }
}

bool TypImagePM::updateDataView( const MscString& sname, int uniqueid )
{
  bool isDone = false;
  // If we have a valid unique id, then use it to update the data view.
  if( uniqueid != -1 ) {
    // TODO Send( *this, ImageUpdateUniqueIDView, uniqueid, &isDone );

// If not,just use the data name..
  } else {
    // TODO Send( *this, ImageUpdateDataView, sname, &isDone );
  }
    
  return isDone;
}


//-------------------------------------
// IOstream
//-------------------------------------

#if 0
static const char * START_FLAG = "startOfvqImagePM" ;
static const char * END_FLAG   = "endOfvqImagePM"   ;



std::ostream &
std::operator<<( std::ostream &stream, TypImagePM &model )
{  
  stream <<  START_FLAG << std::endl;

  stream << "myDisplayType " << model.myDisplayType << std::endl;
  stream << "myTargetType " << model.myTargetType << std::endl;
  stream << "myOutputDir " << model.myOutputDir << std::endl;
  stream << "myOutputFile " << model.myOutputFile << std::endl;
  stream << "myImageCompression " << model.myImageCompression << std::endl;
  stream << "myColorDepth " << model.myColorDepth << std::endl;
  stream << "myImageFormatType " << model.myImageFormatType << std::endl;
  stream << "myPrinterName " << model.myPrinterName << std::endl;
  stream << "myPrinterOrientation " << model.myPrinterOrientation << std::endl;
  stream << "myPrinterResolution " << model.myPrinterResolution << std::endl;
  stream << "myPrinterScale " << model.myPrinterScale << std::endl;
  stream << "myIncludeLayerName " << (model.myIncludeLayerName ? "true":"false") << std::endl;

  stream << END_FLAG << std::endl;

  return stream;
}


std::istream &
std::operator>>( std::istream &stream, TypImagePM &model )
{
  char c[128];
  stream >> c;
  MscString cc;
  bool done(false);

  do{
    cc = c;
    
    if ( cc == "myDisplayType" ) 
    {
      stream >> model.myDisplayType;
    }

    if ( cc == "myImageCompression" ) 
    {
      stream >> model.myImageCompression;
    }

    if ( cc == "myColorDepth" ) 
    {
      stream >> model.myColorDepth;
    }

    if ( cc == "myTargetType" ) 
    {
      stream >> model.myTargetType;
    }

    if ( cc == "myOutputDir" )
    {
		  char tmp[256]; 		
		  stream.get(tmp, 256);
		  model.myOutputDir = tmp;
  		// Discard the occurence of one prefix white space.
	  	if( model.myOutputDir.length() > 1){
		  	model.myOutputDir = model.myOutputDir.get(1, model.myOutputDir.length()-1);
  		}else{
	  		model.myOutputDir.erase();
		  }
    }

    if ( cc == "myOutputFile" )
    {
		  char tmp[256]; 		
		  stream.get(tmp, 256);
		  model.myOutputFile = tmp;
  		// Discard the occurence of one prefix white space.
	  	if( model.myOutputFile.length() > 1){
		  	model.myOutputFile = model.myOutputFile.get(1, model.myOutputFile.length()-1);
  		}else{
	  		model.myOutputFile.erase();
		  }
    }

    if ( cc == "myImageFormatType" ) 
    {
      stream >> model.myImageFormatType;
    }

    if ( cc == "myPrinterName" ) 
    {
		  char tmp[256]; 		
		  stream.get(tmp, 256);
		  model.myPrinterName = tmp;
  		// Discard the occurence of one prefix white space.
	  	if( model.myPrinterName.length() > 1){
		  	model.myPrinterName = model.myPrinterName.get(1, model.myPrinterName.length()-1);
  		}else{
	  		model.myPrinterName.erase();
		  }
    }

    if ( cc == "myPrinterOrientation" ) 
    {
      stream >> model.myPrinterOrientation;
    }

    if ( cc == "myPrinterResolution" ) 
    {
      stream >> model.myPrinterResolution;
    }

    if ( cc == "myPrinterScale" ) 
    {
      stream >> model.myPrinterScale;
    }

    if( cc == "myIncludeLayerName" ) {
      stream >> c;
      model.myIncludeLayerName = !strcmp(c,"true");
    }

    if ( cc == END_FLAG ) {
      done = true;
    }  
    
    if (!done)   stream >> c;

  }while( !stream.eof() && !done );
	
  return stream;
}
#endif



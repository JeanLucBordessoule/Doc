#ifndef GUI_DATA_DEFINITIONS_HPP
#define GUI_DATA_DEFINITIONS_HPP


/** Declarations of enumerations and structures .
 *  Enumerations are defined.
 *  Add an enumeration value and customize according to the needs of the application.
 *
 *  It define the base cmponents that are assembled to keep the user choices.
 *  Information can be stored in "DataItem" and a set of them "DataTeam".
 * */

#include <fstream>

#include "TypStructure.hpp"

class QColor     ;
class QColormap  ;
class QString    ;




/*! ===========================================================
 *  APPLICATION
 *  ======================================================== */

namespace Defs {
    enum NameType { APP_NAME , APP_ICON , APP_TOOLTIP };
    const char * getAppName( NameType = APP_NAME );
}



/*! ===========================================================
 *  COLORS . See: "GuiDataDefColors.cpp" for the definitions.
 * ========================================================== */

namespace Defs {

    class ColorComponents {
    public :
        ColorComponents( int r=0 , int g=0 , int b=0 , int a=Typ::COL_ALPHA ) { myRed=r ; myGreen=g ; myBlue=b ; myAlpha=a ; }
        int myRed   ;
        int myGreen ;
        int myBlue  ;
        int myAlpha ;
    }  ;

    /** the components of a color */
    const ColorComponents & getColorComponents( /*ColorId*/ int askedId , /*ColorId*/ int * foundId = nullptr );
    /** the QColor */
    const QColor          & getColor( /*ColorId*/ int askedId );
    /** user color is added to the existing one. up to 21 are stored */
    bool                    addUserColor( const QColor & , int * addedId = nullptr );
    bool                    addUserColor( int r , int g , int b , int a=Typ::COL_ALPHA , int * addedId = nullptr );
    bool                    hasUserColorsToSave() ;
    bool                    saveUserColors( std::ofstream * );
    bool                    readUserColors( std::ifstream * );
};



/*! ===========================================================
 *  COLORMAPS . See also: "GuiDataDefColors.cpp" .
 * ========================================================== */

namespace Defs {

    enum ColormapId {
        CMP_UNDEFINED = -1 ,
        // Example of colormaps
        CMP_PREDEFINED     ,
        CMP_BLACK_CENTERED
    };

    const QColormap       & getColormap( ColormapId );
};



/*! ===========================================================
 *  COMBO-BOX
 * ========================================================== */

/*! \class Definitions defines the enumerations for the data and provide the corresponding
 * values.
 * An obvious usage of it is the display of the values in a combo-box
 * */

namespace Defs {

   /** Values (for the combo box and to save the combobox option). See also: GuiComboBox */

    /** get the array of values (the size of the array is provided) */
    //const Typ::ValuesStruct * getValues( DataItem::DataType dataHolderType , int & numberOfValues , bool &isPresent );
    const Typ::ValuesStruct  * getValues( /*DataItem::DataType*/ int dataHolderType , int & numberOfValues );

    /** for a specific value , get the flags (used when writing) , or
     *  get the array of values corresponding to the flag (used when reading) */
    //const Typ::ValuesStruct  & getValue ( /*DataItem::DataType*/ int dataHolderType , int , bool &isPresent );
    const Typ::ValuesStruct  & getValue ( /*DataItem::DataType*/ int dataHolderType , int );
    const Typ::ValuesStruct  & getValue ( /*DataItem::DataType*/ int dataItemType   , const QString & );
};



/*! ===========================================================
 *  FORMS
 * ========================================================== */

/** Enumerations for the forms. Define them according to the application. */

namespace Defs {

    /** Values */
    enum FormId {
        FRM_MAIN_FORM = 0 ,
        // first and last.
        FRM_FIRST = FRM_MAIN_FORM ,
        FRM_LAST  = FRM_MAIN_FORM
    };
};

#if 0

/** Identify if it's a valid enumeration */

namespace Defs {

    bool getTypeIsEnum( int );

};
#endif

#endif

#include "GuiItem.hpp"

#include <iostream>

#include "MscDebug.hpp"

#include "GuiUtilities.hpp"
#include "GuiWidgets.hpp"
#include "GuiForms.hpp"

#include <QAction>
#include <QApplication>
#include <QCheckBox>
#include <QComboBox>
#include <QFrame>
#include <QGroupBox>
#include <QLabel>
#include <QLayout>
#include <QLineEdit>
#include <QListView>
#include <QListWidget>
#include <QMenu>
#include <QMessageBox>
#include <QPixmap>
#include <QPushButton>
#include <QKeyEvent>
#include <QSpinBox>
#include <QSplitter>
#include <QTableWidget>
#include <QTextEdit>
#include <QStackedWidget>
#include <QStatusBar>
#include <QTableWidget>
#include <QTabWidget>
#include <QTextEdit>
#include <QToolBar>
#include <QToolTip>




const char * GuiEvent::CLASS_NAME = "GuiEvent" ;
const char * GuiItem ::CLASS_NAME = "GuiItem"  ;
const char * GuiTeam ::CLASS_NAME = "GuiTeam"  ;




//-------------------------------------------------------------------------------------//
//                                      EVENT                                          //
//-------------------------------------------------------------------------------------//


GuiEvent::GuiEvent( GuiItem * s , GuiEvent::EventType t , int senderId )
{
  myInitialize( s , t , senderId );
}


GuiEvent::GuiEvent( int senderId )
{
  myInitialize( 0 , GuiEvent::ET_ACTIVATED , senderId );
}


typedef struct {
  GuiEvent::KeyType myKeyType   ;
  Qt::Key           myQtKey     ;
  int               myIsControl ; // -1: ignore * 0:false:must _not_ be on * 1:true:must be on
} KeyStorageStruct ;
static KeyStorageStruct MyKeys[]  = {
  // key
  { GuiEvent::KEY_F4     , Qt::Key_F4       , -1 } ,
  { GuiEvent::KEY_F5     , Qt::Key_F5       , -1 } ,
  { GuiEvent::KEY_DELETE , Qt::Key_Delete   , -1 } ,
  { GuiEvent::KEY_INSERT , Qt::Key_Insert   , -1 } ,
  // control
  { GuiEvent::KEY_CTRL_A , Qt::Key_A        , +1 } ,
  { GuiEvent::KEY_CTRL_C , Qt::Key_C        , +1 } ,
  { GuiEvent::KEY_CTRL_D , Qt::Key_D        , +1 } ,
  { GuiEvent::KEY_CTRL_X , Qt::Key_X        , +1 }
};
static const int NumberOfKeys = sizeof(MyKeys) / sizeof(MyKeys[0]) ;




GuiEvent::KeyType GuiEvent::getKeyType( QKeyEvent * e )
{
  GuiEvent::KeyType keyType = GuiEvent::KEY_UNDEFINED ;
  if ( e != 0 ) {
    int qtKey = e->key();
    for ( int i=0 ; i < NumberOfKeys ; ++i ) {
      if ( MyKeys[i].myQtKey == qtKey ) {
        bool foundIt = true ;
        // modifier
        if ( MyKeys[i].myIsControl != -1 ) {
          int ctrl = (e->modifiers() & Qt::ControlModifier) ? +1 : +0 ;
          foundIt = (MyKeys[i].myIsControl == ctrl);
        }
        if ( foundIt == true ) {
          keyType = MyKeys[i].myKeyType ;
          break;
        }
      }
    }
  }
  return keyType ;
}



GuiEvent::GuiEvent( GuiItem * s , const std::set< GuiEvent::KeyType > & keys , QKeyEvent * e , int senderId )
{
  myInitialize( s , GuiEvent::ET_UNDEFINED );
  // find
  GuiEvent::KeyType keyType = GuiEvent::getKeyType(e);
  // is registered
  if ( keyType != GuiEvent::KEY_UNDEFINED && keys.find(keyType) == keys.end() ) {
    keyType = GuiEvent::KEY_UNDEFINED ;
  }
  // event is considered
  if ( keyType != GuiEvent::KEY_UNDEFINED ) {
    myEventType = GuiEvent::ET_KEY ;
    myInt       = keyType ;
  }
}


void GuiEvent::myInitialize( GuiItem * guiItem , GuiEvent::EventType eventType , int senderId )
{
  // send by a gui item
  myGuiItem       = guiItem   ;
  myGuiItemId     = myGuiItem ? myGuiItem->getId() : senderId ;
  myEventType     = eventType ;
  // send from inside a menu
  myAction        = 0    ;
  myViewPopupMenu = 0    ;  
  // value
  myBool          = true ;
  myInt           = 0    ;
  myFloat         = 0    ;
  // location
  myRow           = 0    ;
  myColumn        = 0    ;
}


MscString GuiEvent::getMscString() const
{
  return MscString(myString.toStdString().c_str()) ;
}


//-------------------------------------------------------------------------------------//
//                                   Format Hints                                      //
//-------------------------------------------------------------------------------------//




// the one at the application level
GuiFormatHint GuiItem::myApplicationFormatHint ;




//-------------------------------------------------------------------------------------//
//                               SENDER OF AN EVENT                                    //
//-------------------------------------------------------------------------------------//



const int GuiItem::MAX_SHORT_INT      = 32767 ;
float     GuiItem::DEFAULT_POINT_SIZE = 13.0f ;



GuiItem::GuiItem(  GuiTeam & g , const char * n , QObject * o ,GuiItem::WidgetType t , int id )
  : myTeam(g) , myName(n) , myDerivedClass(o) , myWidgetType(t) , myId(id) , myFormatHint( g.getFormatHint() )
{
  myIsVisible     = true ;
  myDataId        = MscDataItem::ID_UNDEFINED ;
  myTeam.addGuiItem( this , myDataId );
  // point size might depend on the type of item (?)
  myPointSize     = GuiItem::DEFAULT_POINT_SIZE ;
  myMaxWidth      = GuiItem::MAX_SHORT_INT ;
  myMaxHeight     = GuiItem::MAX_SHORT_INT ;
  myToolTip       =  0   ;
  myRow           = -1   ;
  myColumn        = -1   ;
  myToolBarAction =  0   ;
  myMenuAction    =  0   ;
  MscDg::trace( CLASS_NAME , "GuiItem()" , "Type:%d  Id:%d  DataId:%d  IsVisible:%d" ,
               myWidgetType , myId , myDataId , myIsVisible );
}


GuiItem::~GuiItem()
{
  myFreeMemory() ;
  // remove from owner list
  myTeam.removeGuiItem( this );
}

void GuiItem::myFreeMemory()
{
  // TODO : free memory of owned items
}


// *static* function that returns
const char * GuiItem::objectName( QObject * o )
{
  QString name("null");
  if ( o == 0 ) {
      return "null";
  }
  else if ( o->objectName().isEmpty() == true ) {
      return "no_name";
  }
  else {
     return o->objectName().toLatin1().constData();
  }
}


void GuiItem::myInitializeFont( QWidget * w )
{
  static const char * METHOD_NAME = "myInitializeFont()" ;
  if ( w == 0 ) return ;
  
  // always possible to know it
  if ( myPointSize >  w->font().pointSizeF() ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "'%s' PointSize %g -> SizeFloat %g" ,
                 GuiItem::objectName(w) , myPointSize , w->font().pointSizeF() );
    myPointSize = GuiItem::DEFAULT_POINT_SIZE ; // w->font().setPointSizeF(); // **** TODO ... FIND WAYS TO IMPROVE THAT **** //
  }
  // let the parent decide
  // TODO: not present in 5.7 // if ( w->ownFont() == false ) return ;
  // change font
  if ( myFormatHint.myFontPercentage != 1.0f ) {
    QFont font( w->font() );
    font.setPointSizeF( myPointSize * myFormatHint.myFontPercentage );
    w->setFont( font );   
  }
}


void GuiItem::setFormatHint( const GuiFormatHint & fh )
{
  // pixmap
  if ( myFormatHint.myPixmapPercentage != fh.myPixmapPercentage ) {
    myFormatHint.myPixmapPercentage = fh.myPixmapPercentage ;
    updateIcon();
  }
  // font
  if ( myFormatHint.myFontPercentage != fh.myFontPercentage ) {
    myFormatHint.myFontPercentage = fh.myFontPercentage ;
    updateFont();
  }
}


void GuiItem::updateFont( QWidget * w  )
{
  static const char * METHOD_NAME = "updateFont()" ;
  if ( w == 0 ) { return ; }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "%s: widget '%s' PointSize %g Percentage %g" ,
               GuiUtl::getString(myName) , GuiItem::objectName(w) , myPointSize , myFormatHint.myFontPercentage );
  // own font !!
  if ( true ) { //  w->ownFont() == true ) {
    QFont font( w->font() );
    font.setPointSizeF( myPointSize * myFormatHint.myFontPercentage );
    w->setFont( font );
  }
  // min max
  if ( myMaxWidth  != GuiItem::MAX_SHORT_INT && myMaxWidth  != 0 ) { setMaxWidth ( myMaxWidth  , true ); }
  if ( myMaxHeight != GuiItem::MAX_SHORT_INT && myMaxHeight != 0 ) { setMaxHeight( myMaxHeight , true ); }
}


void GuiItem::updateFont()
{
  updateFont( isWidget() ? getWidget() : 0 );
}


bool GuiItem::changeFont( int bold , const char * family , int size )
{
  QWidget * w = isWidget() ? getWidget() : 0 ;
  if ( w == 0 ) return false ;
  QFont font( w->font() );
  if ( bold == 0 || bold == 1 ) {
    font.setBold( bold ? true : false );
  }
  if ( family != 0 ) {
    font.setFamily( family );
  }
  if ( size > 0 ) {
    // save the font size
    myPointSize = size ;
    // rescale it
    font.setPointSizeF( myPointSize * myFormatHint.myFontPercentage );
  }
  w->setFont( font );
  return true ;
}



void GuiItem::setIsVisible( bool isVisible )
{
  static const char * METHOD_NAME = "setIsVisible()" ;
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME , "Item %d '%s' myIsVisible %d => %d" ,
                           myId , getName() , myIsVisible , isVisible );
                           
  // test current state mismatch...
  if ( dbOn == true ) {
    bool itemIsVisible = isVisible ;
    if ( isWidget() == true ) { // "GuiActionGroup" is a "QMenu"
      itemIsVisible = getWidget()->isVisible(); // was "isShown()" ;
    }
    else if ( isAction() == true ) {
      itemIsVisible = getAction()->isVisible() ;
    }
    if ( myIsVisible != itemIsVisible ) {
      MscDg::error( CLASS_NAME , METHOD_NAME ,
                   "Item %d '%s' mismatch  IsShown %d  myIsVisible %d" ,
                   myId , getName() , itemIsVisible , myIsVisible );
    }
  }
  // apply ... Issue with some widget that are forced to be visible.. 
  if ( true || myIsVisible != isVisible ) {
    myIsVisible = isVisible ;
    if ( isWidget() == true ) {
      if ( myIsVisible == true ) {
        getWidget()->show();
        
      }
      else { getWidget()->hide(); }
      if ( myToolBarAction != 0 ) { myToolBarAction->setVisible( myIsVisible ); }
      if ( myMenuAction    != 0 ) { myMenuAction   ->setVisible( myIsVisible ); }
    }
    else if ( isAction() == true ) {
      getAction()->setVisible( myIsVisible );
    }
    else if ( isSeparator() == true ) {
      // getSeparator()->setVisible( myIsVisible );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME ,
                   "Item %d '%s' not widget or action" , myId , GuiUtl::getString(myName) );
    }
    // if in toolbar 
    if ( myToolBarAction != 0 && myToolBarAction->isVisible() == false ) {
      myToolBarAction->setVisible(isVisible);
    }
  }
}


bool GuiItem::getIsEnabled() const
{
  static const char * METHOD_NAME = "getIsEnabled()" ;
  if ( isWidget() == true ) {
   return getWidget()->isEnabled() ;
  }
  else if ( isAction() == true ) {
    return getAction()->isEnabled() ;
  }
  else if ( isSeparator() == true ) {
    return true;
  }
  else {
    MscDg::error( CLASS_NAME , METHOD_NAME ,
                 "Item %d '%s' not enabled" , GuiUtl::getString(myName) , myId );
    return false ;
  }
}

void GuiItem::setIsEnabled( bool isEnabled )
{
  if ( isWidget() == true ) {
    getWidget()->setEnabled( isEnabled ) ;
  }
  else if ( isAction() == true ) {
    getAction()->setEnabled( isEnabled ) ;
  }
  else if ( isLayout() == true ) {
    getLayout()->setEnabled( isEnabled ) ;
  }
}



bool GuiItem::getIsEditable() const
{
  int isEditable = -1 ;
  switch ( myWidgetType ) {
  case GuiItem::WT_COMBO_BOX :
    isEditable = (dynamic_cast<GuiComboBox*>(myDerivedClass)->getComboBox()->isEditable() == true) ? 1 : 0 ;
    break;
  default :
      ; // consider it to avoid warnings
  }
  if ( isEditable == -1 ) {
    MscDg::error( CLASS_NAME , "getIsEditable()" , "not defined for type:%d Id;%d" , myWidgetType , myId );
  }
  return (isEditable == 1);
}



void GuiItem::setIsEditable( bool isEditable )
{
  switch ( myWidgetType ) {
  case GuiItem::WT_COMBO_BOX :
    dynamic_cast<GuiComboBox*>(myDerivedClass)->getComboBox()->setEditable(isEditable);
    break;
  default :
      ; // consider it to avoid warnings
  }
}


void GuiItem::setFocusOnItem()
{
  getWidget()->setFocus();
}


bool GuiItem::isLayout() const
{
  switch ( myWidgetType ) {
  case GuiItem::WT_LAYOUT :
    return true ;
  default :
      ; // consider it to avoid warnings
  }
  return false ;
}


QLayout * GuiItem::getLayout() const
{
  QLayout * layout = 0 ;
  switch ( myWidgetType ) {
  case GuiItem::WT_LAYOUT : layout = dynamic_cast<GuiLayout *>(myDerivedClass)->getLayout() ; break ;
  default :
      ; // consider it to avoid warnings
  }
  if ( layout == 0 ) {
    MscDg::error( CLASS_NAME , "getLayout()" , "'%s':  Id:%d Type %d is not a layout" , getName() , myId , myWidgetType );
  }
  return layout ;
}


bool GuiItem::isAction() const
{
  switch ( myWidgetType ) {
  case GuiItem::WT_ACTION       :
    return true ;
  default :
      ; // consider it to avoid warnings
  }
  return false ;
}


QAction * GuiItem::getAction() const
{
  QAction * action = 0 ;
  switch ( myWidgetType ) {
  case GuiItem::WT_ACTION       : action = dynamic_cast<GuiAction     *>(myDerivedClass)->getAction()      ; break ;
  default :
      ; // consider it to avoid warnings
  }
  if ( action == 0 ) {
    MscDg::error( CLASS_NAME , "getAction()" , "Type %d is not an QAction" , myWidgetType );
  }
  return action ;
}


bool  GuiItem::isWidget() const
{
  switch ( myWidgetType ) {
  case GuiItem::WT_ACTION_GROUP   :
  case GuiItem::WT_CHECK_BOX      :
  case GuiItem::WT_COMBO_BOX      :
  case GuiItem::WT_FRAME          :
  case GuiItem::WT_GROUP_BOX      :
  case GuiItem::WT_LABEL          :
  case GuiItem::WT_LIST_BOX       :
  case GuiItem::WT_LINE_EDIT      :
  case GuiItem::WT_LIST_VIEW      :
  case GuiItem::WT_MOVIE_SLIDER   :
  case GuiItem::WT_MOVIE_SPINBOX  :
  case GuiItem::WT_PAGE_HOLDER    :
  case GuiItem::WT_POPUPMENU      :
  case GuiItem::WT_PUSH_BUTTON    :
  case GuiItem::WT_SLIDER         :
  case GuiItem::WT_SPIN_BOX       :
  case GuiItem::WT_SPLITTER       :
  case GuiItem::WT_STACKED_WIDGET :
  case GuiItem::WT_TABLE          :
  case GuiItem::WT_TAB_WIDGET     :
  case GuiItem::WT_TEXT_EDIT      :
  case GuiItem::WT_TOOLBAR        :
  case GuiItem::WT_VIEW_POPUPMENU :
  case GuiItem::WT_WIDGET         :
    return true ;
  default :
      ; // consider it to avoid warnings
  }
  return false ;
}

QWidget  * GuiItem::getWidget() const
{
  QWidget * widget = 0 ;
  // alphabetical order ...
  switch ( myWidgetType ) {
  case GuiItem::WT_ACTION_GROUP   : widget = dynamic_cast<GuiActionGroup   *>(myDerivedClass)->getMenu()       ; break ;
  case GuiItem::WT_CHECK_BOX      : widget = dynamic_cast<GuiCheckBox      *>(myDerivedClass)->getCheckBox()   ; break ;
  case GuiItem::WT_COMBO_BOX      : widget = dynamic_cast<GuiComboBox      *>(myDerivedClass)->getComboBox()   ; break ;
  case GuiItem::WT_FRAME          : widget = dynamic_cast<GuiFrame         *>(myDerivedClass)->getFrame()      ; break ;
  case GuiItem::WT_GROUP_BOX      : widget = dynamic_cast<GuiGroupBox      *>(myDerivedClass)->getGroupBox()   ; break ;// not "getWidget"
  case GuiItem::WT_LABEL          : widget = dynamic_cast<GuiLabel         *>(myDerivedClass)->getLabel()      ; break ;
  case GuiItem::WT_LIST_BOX       : widget = dynamic_cast<GuiListBox       *>(myDerivedClass)->getListBox()    ; break ;
  case GuiItem::WT_LINE_EDIT      : widget = dynamic_cast<GuiLineEdit      *>(myDerivedClass)->getLineEdit()   ; break ;
  case GuiItem::WT_LIST_VIEW      : widget = dynamic_cast<GuiListView      *>(myDerivedClass)->getListView()   ; break ;
  case GuiItem::WT_MOVIE_SLIDER   : widget = dynamic_cast<GuiMovieSlider   *>(myDerivedClass)->getSlider()     ; break ;
  case GuiItem::WT_MOVIE_SPINBOX  : widget = dynamic_cast<GuiMovieSpinBox  *>(myDerivedClass)->getSpinBox()    ; break ;
  case GuiItem::WT_PAGE_HOLDER    : widget = dynamic_cast<GuiPageHolder    *>(myDerivedClass)->getWidget()     ; break ;
  case GuiItem::WT_POPUPMENU      : widget = dynamic_cast<GuiPopupMenu     *>(myDerivedClass)->getPopupMenu()  ; break ;
  case GuiItem::WT_PUSH_BUTTON    : widget = dynamic_cast<GuiPushButton    *>(myDerivedClass)->getPushButton() ; break ;
  case GuiItem::WT_SLIDER         : widget = dynamic_cast<GuiSlider        *>(myDerivedClass)->getSlider()     ; break ;
  case GuiItem::WT_SPIN_BOX       : widget = dynamic_cast<GuiSpinBox       *>(myDerivedClass)->getSpinBox()    ; break ;
  case GuiItem::WT_SPLITTER       : widget = dynamic_cast<GuiSplitter      *>(myDerivedClass)->getSplitter()   ; break ;
  case GuiItem::WT_STACKED_WIDGET : widget = dynamic_cast<GuiStackedWidget *>(myDerivedClass)->getStackedWidget();break;
  case GuiItem::WT_TABLE          : widget = dynamic_cast<GuiTable         *>(myDerivedClass)->getTable()      ; break ;
  case GuiItem::WT_TAB_WIDGET     : widget = dynamic_cast<GuiTabWidget     *>(myDerivedClass)->getTabWidget()  ; break ;
  case GuiItem::WT_TEXT_EDIT      : widget = dynamic_cast<GuiTextEdit      *>(myDerivedClass)->getTextEdit()   ; break ;
  case GuiItem::WT_TOOLBAR        : widget = dynamic_cast<GuiToolBar       *>(myDerivedClass)->getToolBar()    ; break ;
  case GuiItem::WT_VIEW_POPUPMENU : widget = dynamic_cast<GuiViewPopupMenu *>(myDerivedClass)->getPopupMenu()  ; break ;
  case GuiItem::WT_WIDGET         : widget = dynamic_cast<GuiWidget        *>(myDerivedClass)->getWidget()     ; break ;
  default :
      ; // consider it to avoid warnings
  }
  if ( widget == 0 ) {
    MscDg::error( CLASS_NAME , "getWidget()" , "Type %d is not an QWidget" , myWidgetType );
  }
  return widget ;
}


bool GuiItem::isSeparator() const
{
  switch ( myWidgetType ) {
  case GuiItem::WT_SEPARATOR :
    return true;
  default :
      ; // consider it to avoid warnings
  }
  return false ;
}


GuiComboBox * GuiItem::getComboBox()
{
  static const char * METHOD_NAME = "getComboBox()";
  if ( myWidgetType != GuiItem::WT_COMBO_BOX || myDerivedClass == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Type %d is not a GuiComboBox" , myWidgetType );
    return 0;
  }
  if ( myDerivedClass == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "value is null" );
    return 0;
  }
  return dynamic_cast<GuiComboBox*>(myDerivedClass) ;
}



void GuiItem::setValues( const GuiItem::CreateInfo & createInfo )
{
  if ( 0 <= createInfo.myRed   && createInfo.myRed   <= 255 &&
       0 <= createInfo.myGreen && createInfo.myGreen <= 255 &&
       0 <= createInfo.myBlue  && createInfo.myBlue  <= 255  ) {
    setBackgroundColor( createInfo.myRed , createInfo.myGreen , createInfo.myBlue );
  }
  if ( createInfo.myColorName != 0 ) {
    setBackgroundColor( createInfo.myColorName );
  }
  setAlignmenT( createInfo.myAlignment );
  if ( createInfo.myAccelText != 0 ) {
    setAccelText( createInfo.myAccelText );
  }
  // size
  
  if ( createInfo.myMaxWidth != 0 && createInfo.myMaxWidth  <= GuiItem::MAX_SHORT_INT ) {
    myMaxWidth = createInfo.myMaxWidth ;
    setMaxWidth( createInfo.myMaxWidth );
  }
  if ( 0 < createInfo.myMaxHeight && createInfo.myMaxHeight <= GuiItem::MAX_SHORT_INT ) {
    myMaxHeight = createInfo.myMaxHeight ;
    setMaxHeight( createInfo.myMaxHeight );
  }
}


bool GuiItem::setBackgroundColor( int colorId /*values from: Typ::ColorId*/ , bool printMessage )
{
  if ( colorId < Typ::COL_FIRST || Typ::COL_LAST < colorId ) {
    MscDg::error( CLASS_NAME , "setBackgroundColor()" , "%d: color ids must be in range %d-%d" ,
                 colorId , Typ::COL_FIRST , Typ::COL_LAST );
    return false ;
  }
  const  Defs::ColorComponents & color = Defs::getColorComponents( colorId );
  return GuiItem::setBackgroundColor( color.myRed , color.myGreen , color.myBlue , printMessage );
}


bool GuiItem::setBackgroundColor( int red , int green , int blue , bool printMessage )
{
  static const char * METHOD_NAME = "setBackgroundColor()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Red %d  Green %d  Blue %d" , red , green , blue );
  // not considered (values to be ignored)
  if ( red < 0 || green < 0 || blue < 0 || 255 < red || 255 < green || 255 < blue ) {
    return false ;
  }
  if ( isWidget() == false ) {
    if ( printMessage == true ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Id %d: Not a widget" ,
                   myId );
    }
    return false ;
  } 
  QColor color(red,green,blue);
  if ( color.isValid() == false ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "R:%d g:%d b:%d . values must be in range 0-255" ,
                 red , green , blue );
    return false ;
  }
  // widget
  QWidget * widget = getWidget();
  QPalette palette;
  palette.setColor( widget->backgroundRole() , color );
  widget->setPalette( palette );
  return true ;
}



bool GuiItem::setBackgroundColor( const char * name , bool printMessage )
{
  if ( name == 0 ) { name = "white"; }
  QColor color(name);
  if ( isWidget() == false || color.isValid() == false ) {
    if ( printMessage == true ) {
      MscDg::error( CLASS_NAME , "setBackgroundColor()" , "Name:'%s' wrong value" , (name ? name : "") );
    }
    return false ;
  }
  QWidget * widget = getWidget();
  QPalette palette;
  palette.setColor( widget->backgroundRole() , color );
  widget->setPalette( palette );
  return true ;
}
 
 
 
void GuiItem::setMaxWidth( int width ,  bool usePercentage )
{
  if ( isWidget() == false || width == 0 ) { return ; }
  float percentage = usePercentage ? myFormatHint.myFontPercentage : 1.0f ;
  if ( 0 < width ) {
    getWidget()->setMaximumWidth( (int)(width * percentage + 0.5f) );
  }
  if ( width < -5 ) {
    int minWidth = -width ;
    minWidth = (int)(minWidth * percentage + 0.5f);
    if ( getWidget()->maximumWidth() < minWidth ) {
      getWidget()->setMaximumWidth( minWidth );
    }
    getWidget()->setMinimumWidth( minWidth );
  }
}



void GuiItem::setMaxHeight( int height , bool usePercentage )
{
  if ( isWidget() == false || height == 0 ) { return ; }
  float percentage = usePercentage ? myFormatHint.myFontPercentage : 1.0f ;
  if ( 0 < height ) {
    getWidget()->setMaximumHeight( (int)(height * percentage + 0.5f) ); 
  }
}




void GuiItem::setAlignmenT( GuiItem::AlignmentType a )
{
  if ( a == GuiItem::AT_UNDEFINED ) return ;
  Qt::Alignment alignment = Qt::AlignLeft;
  switch ( a ) {
  case GuiItem::AT_LEFT   : alignment = Qt::AlignLeft    ; break ;
  case GuiItem::AT_CENTER : alignment = Qt::AlignHCenter ; break ;
  case GuiItem::AT_RIGHT  : alignment = Qt::AlignRight   ; break ;
  default :
    MscDg::error( CLASS_NAME , "setAlignmenT()" , "undefined value %d" , a );
    return ;
  }
  switch ( myWidgetType ) {
  case GuiItem::WT_LABEL :
    dynamic_cast<GuiLabel*>(myDerivedClass)->getLabel()->setAlignment( alignment );
    break ;
  case GuiItem::WT_LINE_EDIT :
    dynamic_cast<GuiLineEdit*>(myDerivedClass)->getLineEdit()->setAlignment( alignment );
    break ;
  default :
      ; // consider it to avoid warnings
  }
}



void GuiItem::setAccelText( const char * c )
{
  if ( c == 0 ) return ;
  QKeySequence keySequence( c )  ;
  switch ( myWidgetType ) {
  case GuiItem::WT_ACTION :
    dynamic_cast<GuiAction*>(myDerivedClass)->getAction()->setShortcut( keySequence );
    break ;
  case GuiItem::WT_ACTION_GROUP :
    dynamic_cast<GuiActionGroup*>(myDerivedClass)->setAccelText( c );
    break ;
  case GuiItem::WT_CHECK_BOX :
    dynamic_cast<GuiCheckBox*>(myDerivedClass)->getCheckBox()->setShortcut( keySequence );
    break ;
  case GuiItem::WT_PUSH_BUTTON :
    dynamic_cast<GuiPushButton*>(myDerivedClass)->getPushButton()->setShortcut( keySequence );
    break ;
  default :
      ; // consider it to avoid warnings
  }
}



void GuiItem::setSizes( GuiItem::SizesCreateInfo * size , bool atCreation )
{
  MscDg::trace( CLASS_NAME , "setSizes()" , "Type:%d  Id:%d  Size %d" , myWidgetType , myId , size );
  GuiItem::setSizes( isWidget() ? getWidget() : 0 , size , atCreation );
}



void  GuiItem::setSizes( QWidget * widget , GuiItem::SizesCreateInfo * size , bool atCreation )
{
  if ( widget == 0 || size == 0 ) { return ; }
  MscDg::trace( CLASS_NAME , "setSizes()" , "Width: %d %d %d  Height %d %d %d" ,
               size->myMinWidth  , size->myWidth  , size->myMaxWidth , 
               size->myMinHeight , size->myHeight , size->myMaxHeight ); 
  int width  = widget->width() ;
  int height = widget->height();
  if ( size->myWidth     > 0 ) { width  = size->myWidth  ; }
  if ( size->myHeight    > 0 ) { height = size->myHeight ; }
  if ( atCreation == true ) {
    widget->resize( QSize(width , height).expandedTo( widget->minimumSizeHint() ) );
      }
  else {
    widget->resize( width , height );
  }
  if ( size->myMinWidth  > 0 ) { widget->setMinimumWidth  ( size->myMinWidth  ); }
  if ( size->myMaxWidth  > 0 ) { widget->setMaximumWidth  ( size->myMaxWidth  ); }
  if ( size->myMinHeight > 0 ) { widget->setMinimumHeight ( size->myMinHeight ); }
  if ( size->myMaxHeight > 0 ) { widget->setMaximumHeight ( size->myMaxHeight ); }
}


bool GuiItem::getBool() const
{
  switch ( myWidgetType ) {
  case GuiItem::WT_ACTION :
    {
      return dynamic_cast<GuiAction*>(myDerivedClass)->getAction()->isChecked();
    } break ;
  case GuiItem::WT_COMBO_BOX :
    {
      bool isOk ;
      int intValue = dynamic_cast<GuiComboBox*>(myDerivedClass)->getUserValue(-1,&isOk); // (-1): current item
      return (intValue != 0);
    } break ;
  case GuiItem::WT_CHECK_BOX :
    {
      return dynamic_cast<GuiCheckBox*>(myDerivedClass)->getCheckBox()->isChecked();
    } break ;
  case GuiItem::WT_GROUP_BOX :
    {
      return dynamic_cast<GuiGroupBox*>(myDerivedClass)->getGroupBox()->isChecked();
    } break ;
  default:
    {
      MscDg::error( CLASS_NAME , "getBool()" , "method not implemented for Type:%d Id:%d" ,
                   myWidgetType , myId );
    }
  }
  return false ;
}


bool GuiItem::setBool( bool value , bool forceMessage )
{
  bool isOk = true ;
  switch ( myWidgetType ) {
  case GuiItem::WT_ACTION :
    {
      dynamic_cast<GuiAction*>(myDerivedClass)->getAction()->setChecked( value );
    } break ;
  case GuiItem::WT_COMBO_BOX :
    {
      dynamic_cast<GuiComboBox*>(myDerivedClass)->setUserValue( value ? 1 : 0 );
    } break ;
  case GuiItem::WT_CHECK_BOX :
    {
      dynamic_cast<GuiCheckBox*>(myDerivedClass)->getCheckBox()->setChecked( value );
    } break ;
  case GuiItem::WT_GROUP_BOX :
    {
      dynamic_cast<GuiGroupBox*>(myDerivedClass)->getGroupBox()->setChecked( value );
    } break ;
  default:
    {
      isOk = false ;
      MscDg::error( CLASS_NAME , "setBool()" , "method not implemented for Type:%d Id:%d" ,
                   myWidgetType , myId );
    }
  }
  return isOk ;
}


int GuiItem::getInt(  bool *isOkPtr )
{
  int value = 0 ;
  bool isOk = true ;
  switch ( myWidgetType ) {
  case GuiItem::WT_COMBO_BOX :
    {
      value = dynamic_cast<GuiComboBox*>(myDerivedClass)->getUserValue(-1,&isOk); // (-1): current item
    } break ;
  case GuiItem::WT_LINE_EDIT :
    {
      value = dynamic_cast<GuiLineEdit*>(myDerivedClass)->getLineEdit()->text().toInt(&isOk);
    } break ;
  case GuiItem::WT_SLIDER :
    {
      value = dynamic_cast<GuiSlider*>(myDerivedClass)->getSlider()->value();
    } break ;
  case GuiItem::WT_SPIN_BOX :
    {
      value = dynamic_cast<GuiSpinBox*>(myDerivedClass)->getSpinBox()->value();
    } break ;
  case GuiItem::WT_STACKED_WIDGET :
    {
      value = dynamic_cast<GuiStackedWidget*>(myDerivedClass)->getUserValue(-1,&isOk); // (-1): current item
    } break ;
  case GuiItem::WT_TAB_WIDGET :
    {
      value = dynamic_cast<GuiTabWidget*>(myDerivedClass)->getUserValue(-1,&isOk); // (-1): current item
    } break ;
  default:
    MscDg::error( CLASS_NAME , "getInt()" , "method not implemented for Type:%d Id:%d" ,
                 myWidgetType , myId );
    isOk = false ;
  }
  if ( isOkPtr != 0 ) { *isOkPtr = isOk; }
  return value ;
}


bool GuiItem::getCheckedInt( int &value , const char * name , bool resetIfNeeded )
{
  static const char * METHOD_NAME = "setCheckedInt()" ;
  bool isOk = false ;
  switch ( myWidgetType ) {
  case GuiItem::WT_LINE_EDIT :
    {
      isOk = static_cast<GuiLineEdit*>(myDerivedClass)->getCheckedInt( value , name , resetIfNeeded );
    } break;
  default:
    MscDg::error( CLASS_NAME , METHOD_NAME , "method not implemented for Type:%d Id:%d" ,
                 myWidgetType , myId );
    isOk = false ;
  }
  return isOk ;
}


bool GuiItem::setInt( int value , bool forceMessage )
{
  static const char * METHOD_NAME = "setInt()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Type:%d Id:%d" , myWidgetType , myId );
  bool isOk = true ;
  switch ( myWidgetType ) {
  case GuiItem::WT_COMBO_BOX :
    {
      dynamic_cast<GuiComboBox*>(myDerivedClass)->setUserValue( value , forceMessage );
    } break ;
  case GuiItem::WT_LINE_EDIT :
    {
      QString text ;
      text.sprintf("%d",value);
      dynamic_cast<GuiLineEdit*>(myDerivedClass)->setUserValue( text , forceMessage );
    } break ;
  case GuiItem::WT_SLIDER :
    {
      dynamic_cast<GuiSlider*>(myDerivedClass)->setUserValue( value , forceMessage );
    } break ;
  case GuiItem::WT_SPIN_BOX :
    {
      dynamic_cast<GuiSpinBox*>(myDerivedClass)->setUserValue( value , forceMessage );
    } break ;
  case GuiItem::WT_STACKED_WIDGET :
    {
      dynamic_cast<GuiStackedWidget*>(myDerivedClass)->setUserValue( value , forceMessage );
    } break ;
  case GuiItem::WT_TAB_WIDGET :
    {
      dynamic_cast<GuiTabWidget*>(myDerivedClass)->setUserValue( value , forceMessage );
    } break ;
  default:
    {
      QString str ;
      str.sprintf( "%d" , value );
      isOk = setString( str ); 
    }
  }
  return isOk ;
}


float GuiItem::getFloat( bool *isOk )
{
  QString str = getString();
  GuiUtl::stripString(str);
  float value = 0.0f ;
  if ( str.isEmpty() == false ) {
    value = GuiUtl::toFloat(str);
    if ( isOk != 0 ) { *isOk = true ; }
  }
  else if ( isOk != 0 ) {
    *isOk = false ;
  }
  return value ;
}


bool GuiItem::setFloat( float value , bool forceMessage )
{
  static const char * METHOD_NAME = "setFloat()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Type:%d Id:%d" , myWidgetType , myId );
  QString str ;
  str.sprintf( "%f" , value );
  return setString( str );
}



double GuiItem::getDouble( bool *isOk )
{
  QString str = getString();
  GuiUtl::stripString(str); // remove the spaces at the beginning and the end
  double value = 0.0 ;
  if ( str.isEmpty() == false ) {
    value = GuiUtl::toDouble(str);
    if ( isOk != 0 ) { *isOk = true ; }
  }
  else if ( isOk != 0 ) {
    *isOk = false ;
  }
  return value ;
}



bool GuiItem::setDouble( double value , bool forceMessage )
{
  static const char * METHOD_NAME = "setDouble()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Type:%d Id:%d" , myWidgetType , myId );
  QString str ;
  str.sprintf( "%g" , value );
  return setString( str );
}


bool GuiItem::setString( const QString & t , bool forceMessage )
{
  bool isOk = true ;
  switch ( myWidgetType ) {
  case GuiItem::WT_ACTION :
    dynamic_cast<GuiAction*>(myDerivedClass)->getAction()->setText( t );
    // dynamic_cast<GuiAction*>(myDerivedClass)->getAction()->setMenuText( t );
    break;
  case GuiItem::WT_ACTION_GROUP :
    dynamic_cast<GuiActionGroup*>(myDerivedClass)->getMenu()->setTitle( t );
    break ;
  case GuiItem::WT_CHECK_BOX :
    dynamic_cast<GuiCheckBox*>(myDerivedClass)->getCheckBox()->setText( t );
    break ;
    // set the combo-box to the choice pertaining to this string
  case GuiItem::WT_COMBO_BOX :
    dynamic_cast<GuiComboBox*>(myDerivedClass)->setString( t , forceMessage );
    break ;
  case GuiItem::WT_GROUP_BOX :
    dynamic_cast<GuiGroupBox*>(myDerivedClass)->getGroupBox()->setTitle( t );
    break ;
  case GuiItem::WT_LABEL :
    dynamic_cast<GuiLabel*>(myDerivedClass)->getLabel()->setText( t );
    break ;
  case GuiItem::WT_LINE_EDIT :
    dynamic_cast<GuiLineEdit*>(myDerivedClass)->getLineEdit()->setText( t );
    break ;
  case GuiItem::WT_LIST_VIEW :
    // **TODO**  dynamic_cast<GuiListView*>(myDerivedClass)->getListView()->setText( t );
    break ;
  case GuiItem::WT_POPUPMENU :
    dynamic_cast<GuiPopupMenu*>(myDerivedClass)->getPopupMenu()->setTitle( t );
    break ;
  case GuiItem::WT_PUSH_BUTTON :
    dynamic_cast<GuiPushButton*>(myDerivedClass)->getPushButton()->setText( t );
    break ;
  case GuiItem::WT_TEXT_EDIT :
    dynamic_cast<GuiTextEdit*>(myDerivedClass)->getTextEdit()->setText( t );
    break ;
  case GuiItem::WT_TOOLBAR :
    dynamic_cast<GuiToolBar*>(myDerivedClass)->getToolBar()->setWindowTitle( t );
    break ;
  case GuiItem::WT_VIEW_POPUPMENU :
    dynamic_cast<GuiViewPopupMenu*>(myDerivedClass)->getPopupMenu()->setTitle( t );
    break ;
  default:
    MscDg::error( CLASS_NAME , "setString()" , "Text:'%s' . method not implemented for Type:%d Id:%d" ,
                 GuiUtl::getString(t) , myWidgetType , myId );
    isOk = false ;
  }
  return isOk ;
}



QString GuiItem::getString() const
{
  QString str ;
  switch ( myWidgetType ) {
  case GuiItem::WT_ACTION :
    str = dynamic_cast<GuiAction*>(myDerivedClass)->getAction()->text();
    break;
  case GuiItem::WT_ACTION_GROUP :
    str = dynamic_cast<GuiActionGroup*>(myDerivedClass)->getMenu()->title();
    break ;
  case GuiItem::WT_CHECK_BOX :
    str = dynamic_cast<GuiCheckBox*>(myDerivedClass)->getCheckBox()->text();
    break ;
  case GuiItem::WT_COMBO_BOX :
    str = dynamic_cast<GuiComboBox*>(myDerivedClass)->getComboBox()->currentText();
    break ;
  case GuiItem::WT_GROUP_BOX :
    str = dynamic_cast<GuiGroupBox*>(myDerivedClass)->getGroupBox()->title();
    break ;
  case GuiItem::WT_LABEL :
    str = dynamic_cast<GuiLabel*>(myDerivedClass)->getLabel()->text();
    break ;
  case GuiItem::WT_LINE_EDIT :
    str = dynamic_cast<GuiLineEdit*>(myDerivedClass)->getLineEdit()->text();
    break ;
  case GuiItem::WT_POPUPMENU :
    str = dynamic_cast<GuiPopupMenu*>(myDerivedClass)->getPopupMenu()->title();
    break ;
  case GuiItem::WT_PUSH_BUTTON :
    str = dynamic_cast<GuiPushButton*>(myDerivedClass)->getPushButton()->text();
    break ;
  case GuiItem::WT_TEXT_EDIT :
    str = dynamic_cast<GuiTextEdit*>(myDerivedClass)->getTextEdit()->toPlainText();
    break ;
  case GuiItem::WT_TOOLBAR :
    str = dynamic_cast<GuiToolBar*>(myDerivedClass)->getToolBar()->windowTitle();
    break ;
  case GuiItem::WT_VIEW_POPUPMENU :
    str = dynamic_cast<GuiViewPopupMenu*>(myDerivedClass)->getPopupMenu()->title();
    break ;
  default:
    MscDg::error( CLASS_NAME , "getString()" ,  "method not implemented for Type:%d Id:%d" ,
                 myWidgetType , myId );
  }
  return str ;
}


MscString GuiItem::getMscString() const
{
   QString str = getString();
   return MscString(str.toStdString().c_str());
}


void GuiItem::setTooltip( const QString & toolTip )
{
  // no change occurred
  if ( myToolTipString == toolTip ) return ;
  // save the tooltip
  myToolTipString = toolTip ;
  // set t to the action
  if ( isAction() == true ) {
    getAction()->setToolTip( myToolTipString );
  }
  // set it to the widget
  else if ( isWidget() == true ) {
    // see also: "QStandardItem::setToolTip" "QColumnView" as it enables
    // to customize parts of the GUI
    getWidget()->setToolTip(myToolTipString);
  }
}



void GuiItem::setBlockSignals( bool b )
{
  if ( isWidget() == true ) {
    getWidget()->blockSignals( b );
  }
}


void GuiItem::setIconFromXpm( const char * xpm[] )
{
  static const char * METHOD_NAME = "setPixmapFromXpm()" ;
  // the resize factor
  float rf = myFormatHint.myPixmapPercentage ;

  switch ( myWidgetType ) {
  case GuiItem::WT_CHECK_BOX   :
  case GuiItem::WT_PUSH_BUTTON :
    // also inherits from "QAbstractButton":  QRadioButton QToolButton
    dynamic_cast< QAbstractButton * >(getWidget())->setIcon( GuiUtl::getPixmap(xpm,rf) );
    break;
  case GuiItem::WT_LABEL :
    // TODO ... dynamic_cast<GuiLabel*>(myDerivedClass)->getLabel()->setIcon( GuiUtl::getPixmap(xpm,rf) );
    break;
  default :
    MscDg::error( CLASS_NAME , METHOD_NAME , "WidgetType %d not inplemented" , myWidgetType );
  }
}



bool GuiItem::isActiveWindow() const
{
  if ( isWidget() == true ) {
    return getWidget()->isActiveWindow();
  } 
  else {
    return false ;
  }
}




//-------------------------------------------------------------------------------------//
//                        LISTENER (GuiItems management)                               //
//-------------------------------------------------------------------------------------//





GuiTeam::GuiTeam( GuiTeam::TeamType teamType , int id , QWidget * widget , const char * name ,
                  GuiTeam * teamLeader , GuiScreen * screen )
{
  myTeamType   = teamType   ;
  myId         = id         ;
  myName       = name       ;
  myTopWidget  = widget     ;
  myIsDirty    = GuiTeam::FLAG_ALL_DIRTY ; // useful in the case of a page that needs to be redrawn
  myTeamLeader = teamLeader ;
  myScreen     = screen     ;
  // widget characteristics
  myPointSize  = GuiItem::DEFAULT_POINT_SIZE ;
  // format hint
  myFormatHint = GuiItem::myApplicationFormatHint ;
  if ( myTeamLeader != 0 ) {
    myFormatHint = myTeamLeader->getFormatHint() ;
    myTeamLeader->addGuiTeam( this , true ); 
  }
  else if ( myScreen != 0 ) {
    myFormatHint = myScreen->getFormatHint() ;
    myScreen->addGuiTeam( this , true ); 
  }
  else {
    myFormatHint = GuiItem::myApplicationFormatHint ;
  }
}


GuiTeam::~GuiTeam()
{
  static const char * METHOD_NAME = "~GuiTeam()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "TeamLeader %d Screen %d" , myTeamLeader , myScreen );
  if ( myTeamLeader != 0 ) {
    myTeamLeader->addGuiTeam( this , false ); 
  }
  else if ( myScreen != 0 ) {
    myScreen->addGuiTeam( this , false ); 
  } 
}


GuiTeam * GuiTeam::getParentTeam( GuiTeam::TeamType teamType )
{
  GuiTeam * team = this ;
  // it can be itself
  while ( team != nullptr ) {
    if ( team->myTeamType != teamType ) {
      // next one in he hierarch
      team = team->myTeamLeader ;
    }
    // found it
    else {
      break;
    }
  }
  return team;
}



GuiForm * GuiTeam::getParentForm()
{
  return static_cast<GuiForm*>(getParentTeam(GuiTeam::TP_FORM));
}



bool GuiTeam::addGuiTeam( GuiTeam * guiTeam , bool addIt )
{
  static const char * METHOD_NAME = "addGuiTeam()" ;
  bool isPresent    = false ;
  for ( auto iter=myTeams.begin() ; iter != myTeams.end() ; ++iter ) {
    if ( *iter == guiTeam ) {
      isPresent = true ;
      // remove it
      if ( addIt == false ) {
        myTeams.erase(iter);
      }
      // cancel search
      break;
    }
  }
  // not present so add it
  if ( isPresent == false && addIt == true ) {
    myTeams.push_back( guiTeam );
  }
  // message
  if ( addIt == true ) {
    if ( isPresent == false ) {
      MscDg::trace( CLASS_NAME , METHOD_NAME , "'%s' : '%s' successfully added" , getName() , guiTeam->getName() );
      return true ;
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "'%s' : '%s' already present" , getName() , guiTeam->getName() );
      return false ;
    }
  }
  else {
    if ( isPresent == true ) {
      MscDg::trace( CLASS_NAME , METHOD_NAME , "'%s' : '%s' successfully removed" , getName() , guiTeam->getName() );
      return true ;
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "'%s' : '%s' is not present" , getName() , guiTeam->getName() );
      return false ;
    } 
  }
}



GuiTeam * GuiTeam::getGuiTeam( int id , bool errorMessageIsAbsent )
{
  static const char * METHOD_NAME = "getGuiTeam()" ;
  GuiTeam * guiTeam = 0 ;
  for ( auto iter=myTeams.begin() ; iter != myTeams.end() ; ++iter ) {
    if ( (*iter)->getId() == id ) {
      guiTeam = (*iter) ;
      break;
    }
  }
  // message
  if ( errorMessageIsAbsent == true ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "'%s' : team %d is not present" , getName() , id );
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "'%s' : team %d is present: %s" , getName() , id , guiTeam ? "true" : "false" );
  return guiTeam ;
}



bool GuiTeam::addGuiItem( GuiItem * s , int dataId )
{
  static const char * METHOD_NAME = "addGuiItem()" ;
  if ( s == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "null item" );
    return false ;
  }
  // do not add 'Undefined' items . It's a convention.
  if ( s->getId() < GuiItem::ID_FIRST_ITEM ) {
    return true ;
  }
  // find the item in the list (should not exist)
  auto iter = myItems.find( s->getId() );
  if ( iter != myItems.end() ) {
    if ( iter->second == 0 ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "ItemId:%d Type:%d is already present (no storage)" ,
                   s->getId() , s->getWidgetType() );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME ,
                   "Team %d  ItemId:%d  (Type:%d) '%s' is already present (was Id:%d Type:%d '%s')" ,
                   getId() , s->getId() , s->getWidgetType() , s->getName() ,
                   iter->second->getId() , iter->second->getWidgetType() , iter->second->getName() );
    }
    iter->second = s ;
  }
  // store the item
  else {
    myItems[ s->getId() ] = s ;
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Id:%d  DataId:%d" , s->getId() , dataId );
  if ( dataId != MscDataItem::ID_UNDEFINED ) {
    s->setDataId( dataId );
  }
  return true ;
}



GuiItem * GuiTeam::removeGuiItem( GuiItem * e )
{
  static const char * METHOD_NAME = "removeGuiItem()" ;
  // do not remove 'Undefined' items . It's a convention.
  if ( e != 0 && e->getId() < GuiItem::ID_FIRST_ITEM ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "id %d less than GuiItem::ID_FIRST_ITEM" , e->getId() );
    return e ;
  }
  for ( auto iter=myItems.begin() ; iter != myItems.end() ; ++iter ) {
    if ( iter->second == e ) {
      myItems.erase(iter);
      return e ;
    }
  }
  MscDg::error( CLASS_NAME , METHOD_NAME , "not found" );
  return 0 ;
}



GuiItem * GuiTeam::removeGuiItemOfId( int id )
{
  static const char * METHOD_NAME = "removeGuiItemOfId()" ;
  for ( auto iter=myItems.begin() ; iter != myItems.end() ; ++iter ) {
    if ( iter->second->getId() == id ) {
      GuiItem * guiItem = iter->second ;
      myItems.erase(iter);
      return guiItem ;
    }
  }
  MscDg::error( CLASS_NAME , METHOD_NAME , "%d not found" , id );
  return 0 ;
}



bool GuiTeam::hasGuiItem( int id ) const
{
  return ( myItems.find( id ) != myItems.end() ) ;
}


GuiItem * GuiTeam::getGuiItem( int id , bool showMessage ) const
{
  static const char * METHOD_NAME = "getGuiItem()" ;
  // convention: non-existent GUI has id value less than 'GuiItem::ID_FIRST_ITEM'
  if ( id < GuiItem::ID_FIRST_ITEM ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "'%s': %d is less than GuiItem::ID_FIRST_ITEM" , getName() , id );
    return 0;
  }
  GuiTeam::ItemsMap::const_iterator iter = myItems.find( id );
  if ( iter != myItems.end() ) {
    return iter->second ;
  }
  else {
    if ( showMessage == true ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "'%s': Item of Id %d is not present" , getName() , id );
    }
    return 0 ;
  }
}


bool GuiTeam::isWidget( int id , bool showMessage ) const
{
  static const char * METHOD_NAME = "isWidget()" ;
  GuiItem * guiItem = getGuiItem(id);
  if ( guiItem == nullptr ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "'%s': item of Id %d is not present" , getName() , id );
    return false ;
  }
  if ( guiItem->isWidget() == false ) {
    if ( showMessage == true ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "'%s': item of Type %d Id %d is not a widget" ,
                   getName() , guiItem->getWidgetType() , id );
    }
    return false ;
  }
  return true ;
}


QWidget * GuiTeam::getWidget( int id , bool showMessage ) const
{
  static const char * METHOD_NAME = "isWidget()" ;
  GuiItem * guiItem = getGuiItem(id);
  if ( guiItem == nullptr ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "'%s': item of Id %d is not present" , getName() , id );
    return 0 ;
  }
  if ( guiItem->isWidget() == false ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "'%s': item of Type %d Id %d is not a widget" ,
                 getName() , guiItem->getWidgetType() , id );
    return 0 ;
  }
  return guiItem->getWidget();
}


bool GuiTeam::isLayout( int id , bool showMessage ) const
{
  static const char * METHOD_NAME = "isLayout()" ;
  if ( id < GuiItem::ID_FIRST_ITEM ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "'%s': id %d is UNDEFINED" , getName() , id );
    return false ;
  }
  GuiItem * guiItem = getGuiItem(id,showMessage);
  if ( guiItem == nullptr ) {
    if ( showMessage == true ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "'%s': item of Id:%d is not present" , getName() , id );
    }
    return false ;
  }
  if ( guiItem->isLayout() == false ) {
    if ( showMessage == true ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "'%s': Item '%s' of Type %d Id %d is not a layout" ,
                   getName() , guiItem->getName() , guiItem->getWidgetType() , id );
    }
    return false ;
  }
  return true ;
}


GuiLayout * GuiTeam::getLayout( int id , bool showMessage ) const
{
  GuiLayout * layout = 0 ;
  GuiTeam::ItemsMap::const_iterator iter = myItems.find( id );
  if ( iter != myItems.end() && iter->second->isLayout() == true ) {
    layout = dynamic_cast<GuiLayout *>(iter->second) ;
  }
  if ( layout == 0 ) {
    if ( showMessage == true ) {
      MscDg::error( CLASS_NAME , "getLayout()" , "'%s': layout of Id %d is not present" , getName() , id );
    }
  }
  return layout ;
}


void GuiTeam::addWidgetToLayout( int layoutId , QWidget * w , int row , int col )
{
  static const char * METHOD_NAME = "addWidgetToLayout()" ;
  if ( w == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "'%s': Layout %d. (widget) Widget is null" , getName() , layoutId );
    return ;
  }
  // layout
  if ( isLayout(layoutId,false) == true ) {
    GuiLayout * layout = getLayout(layoutId);
    if ( layout != 0 ) {
      layout->addWidget( w , row , col );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. (widget) no layout" , layoutId );
    }
    return ;
  }
  // group box
  GuiItem * guiItem = getGuiItem( layoutId );
  if ( guiItem == nullptr ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "LayoutId %d is null" , layoutId );
    return ;
  }
  if ( guiItem->getWidgetType() == GuiItem::WT_GROUP_BOX ) {
    GuiGroupBox * groupBox = dynamic_cast<GuiGroupBox*>(guiItem);
    if ( groupBox != 0 ) {
      MscDg::trace( CLASS_NAME , METHOD_NAME , "Layout:%d. (widget) group box" , layoutId );
      groupBox->addWidget( w );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. (widget) No group box" , layoutId );
    }
    return ;
  }
  //
  MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. (widget) Undefined values" , layoutId );
}


void GuiTeam::addWidgetToLayout( int layoutId , GuiItem * event_sender , int row , int col )
{
  static const char * METHOD_NAME = METHOD_NAME ;
  if ( event_sender == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. (guiItem)  Item is null" , layoutId );
    return ;
  }
  // layout
  if ( isLayout(layoutId,false) == true ) {
    GuiLayout * layout = getLayout(layoutId);
    if ( layout != 0 ) {
      layout->addWidget( event_sender , row , col );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. (guiItem) no layout" , layoutId );
    }
    return ;
  }
  // group box
  GuiItem * layoutItem = getGuiItem( layoutId );
  if ( layoutItem == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "LayoutId %d is null" , layoutId );
    return ;
  }
  if ( layoutItem->getWidgetType() == GuiItem::WT_GROUP_BOX ) {
    GuiGroupBox * groupBox = dynamic_cast<GuiGroupBox*>(layoutItem);
    if ( groupBox != 0 ) {
      groupBox->addItem( event_sender , row , col );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. (guiItem) No group box" , layoutId );
    }
    return ;
  }
  //
  MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. (guiItem) Undefined values" , layoutId );
}


void GuiTeam::addWidgetToLayout( int layoutId , int itemId , int row , int col )
{
  addWidgetToLayout( layoutId , getGuiItem(itemId) , row , col );
}



void GuiTeam::addPageToLayout( int layoutId , GuiPage * page , int row , int col )
{
  GuiLayout * layout = getLayout(layoutId);
  if ( layout != 0 && page != 0 ) {
    layout->addWidget( page->getWidget() , row , col );
  }
  else {
    MscDg::error( CLASS_NAME , "addPageToLayout()" , "Layout:%d. Undefined values" , layoutId );
  }
}


void GuiTeam::addLayoutToLayout( int layoutId , GuiLayout * addedLayout , int row , int col )
{
  static const char * METHOD_NAME = "addLayoutToLayout()" ;
  if ( addedLayout == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Layout %d. Item is null" , layoutId );
    return ;
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "LayoutId %d  IsLayout %d  AddedLayout %d  Row %d  Col %d" ,
               layoutId , isLayout(layoutId,false) , addedLayout , row , col );
  // layout
  if ( isLayout(layoutId,false) == true ) {
    GuiLayout * layout = getLayout(layoutId);
    if ( layout != 0 ) {
      layout->addLayout( addedLayout , row , col );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Layout %d. No layout" , layoutId );
    }
    return ;
  }
  // group box
  GuiItem * layoutItem = getGuiItem( layoutId );
  if ( layoutItem == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "LayoutId %d is null" , layoutId );
    return ;
  }
  if ( layoutItem->getWidgetType() == GuiItem::WT_GROUP_BOX ) {
    GuiGroupBox * groupBox = dynamic_cast<GuiGroupBox*>(layoutItem); ;
    if ( groupBox != 0 ) {
      groupBox->addLayout( addedLayout->getLayout() , row , col );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Layout %d. No group box" , layoutId );
    }
    return ;
  }
  //
  MscDg::error( CLASS_NAME , METHOD_NAME , "Layout %d. Undefined values . No layout target" , layoutId );
}


void GuiTeam::addLayoutToLayout( int layoutId , int itemId , int row , int col )
{
  addLayoutToLayout( layoutId , getLayout(itemId) , row , col );
}


void GuiTeam::addSpacerToLayout( int layoutId , int size , bool isHorizontal , int row , int col , bool isFixedSize )
{
  static const char * METHOD_NAME = "addSpacerToLayout()" ;
  // layout
  if ( isLayout(layoutId,false) == true ) {
    GuiLayout * layout = getLayout(layoutId);
    if ( layout != 0 ) {
      layout->addSpacer( size , isHorizontal , row , col , isFixedSize );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. no layout" , layoutId );
    }
    return ;
  }
  // group box
  GuiItem * layoutItem = getGuiItem( layoutId );
  if ( layoutItem == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "LayoutId %d is null" , layoutId );
    return ;
  }
  if ( layoutItem->getWidgetType() == GuiItem::WT_GROUP_BOX ) {
    GuiGroupBox * groupBox = dynamic_cast<GuiGroupBox*>(layoutItem); ;
    if ( groupBox != 0 ) {
      groupBox->addSpacer( size , isHorizontal , row , col , isFixedSize );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. no groupBox" , layoutId );
    }
    return ;
  }
  //
  MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. Undefined values" , layoutId );
}



void GuiTeam::addLineToLayout( int layoutId , int size , bool isHorizontal , int row , int col )
{
  static const char * METHOD_NAME = "addLineToLayout()" ;
  // layout
  if ( isLayout(layoutId,false) == true ) {
    GuiLayout * layout = getLayout(layoutId);
    if ( layout != 0 ) {
      layout->addLine( size , isHorizontal , row , col );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. no layout" , layoutId );
    }
    return ;
  }
  // group box
  GuiItem * layoutItem = getGuiItem( layoutId );
  if ( layoutItem == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "LayoutId %d is null" , layoutId );
    return ;
  }
  if ( layoutItem->getWidgetType() == GuiItem::WT_GROUP_BOX ) {
    GuiGroupBox * groupBox = dynamic_cast<GuiGroupBox*>(layoutItem); ;
    if ( groupBox != 0 ) {
      groupBox->addLine( size , isHorizontal , row , col );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. no groupBox" , layoutId );
    }
    return ;
  }
  //
  MscDg::error( CLASS_NAME , METHOD_NAME , "Layout:%d. Undefined values" , layoutId );
}


GuiComboBox * GuiTeam::getComboBox( int id , bool showMessage ) const
{
  GuiItem * guiItem = getGuiItem( id , showMessage );
  return ( guiItem ? guiItem->getComboBox() : 0 ) ;
}


const QString & GuiTeam::getName( int id ) const
{
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem != nullptr ) { return guiItem->getName(); }
  else { return "NoItem" ; }
}


void GuiTeam::setFormatHint( const GuiFormatHint & fh )
{
  static const char * METHOD_NAME = "setFormatHint()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "%s : Font %g Pixmap %g" ,
               GuiUtl::getString(myName) , myFormatHint.myFontPercentage , myFormatHint.myPixmapPercentage );
  // pixmap
  if ( myFormatHint.myPixmapPercentage != fh.myPixmapPercentage ) {
    myFormatHint.myPixmapPercentage = fh.myPixmapPercentage ;
    std::cerr << CLASS_NAME << "::" <<  METHOD_NAME << "  updateIcon" << std::endl ;
    updateIcon();
  }
  // font
  if ( myFormatHint.myFontPercentage != fh.myFontPercentage ) {
    std::cerr << CLASS_NAME << "::" <<  METHOD_NAME << "  updateFont" << std::endl ;
    updateFont();
  }
  // tool tip
  QFont font( QToolTip::font() ); 
  font.setPointSizeF( myPointSize * fh.myFontPercentage );
  QToolTip::setFont(font);
  // apply to items
  for ( auto itemIter=myItems.begin() ; itemIter != myItems.end() ; ++itemIter ) {
    itemIter->second->setFormatHint(fh);
  }
  // apply to teams
  for ( auto teamIter=myTeams.begin() ; teamIter != myTeams.end() ; ++teamIter ) {
    (*teamIter)->setFormatHint(fh);
  }
}


void GuiTeam::updateFont( QWidget * w  )
{
  static const char * METHOD_NAME = "updateFont()" ;
  if ( w == 0 ) { return ; }
  MscDg::error( CLASS_NAME , METHOD_NAME , "%s: widget '%s' PointSize %g Percentage %g" ,
               GuiUtl::getString(myName) , GuiItem::objectName(w) , myPointSize , myFormatHint.myFontPercentage );
  // own font !!
  if ( true ) { //  w->ownFont() == true ) {
    QFont font( w->font() );
    font.setPointSizeF( myPointSize * myFormatHint.myFontPercentage );
    w->setFont( font );
  }
}


void GuiTeam::setFontIsBold( int id , bool b , bool testIfExists )
{
  if ( testIfExists == true && hasGuiItem( id ) == false ) return ;
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem != nullptr ) guiItem->setFontIsBold( b );
}


void GuiTeam::refresh()
{
  static const char * METHOD_NAME = "refresh()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Is called. Should be re-implemented" );
}


void GuiTeam::refresh( int id )
{
  static const char * METHOD_NAME = "refresh()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Id %d Is called. Should be re-implemented" , id );
}


bool GuiTeam::setFocusOnWidget( int id )
{
  if ( isWidget(id,false) == true ) {
    getWidget(id,true)->setFocus();
    return true ;
  }
  else {
    return false ;
  }
}


bool GuiTeam::getIsVisible( int id )
{
  GuiItem * guiItem = getGuiItem( id );
  return ( guiItem ? guiItem->getIsVisible() : false ) ;
}



void GuiTeam::setIsVisible( int id , bool b , bool testIfExists )
{
  if ( testIfExists == true && hasGuiItem( id ) == false ) return ;
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem != nullptr ) { guiItem->setIsVisible( b ); }
}


bool GuiTeam::getIsEnabled( int id )
{
  GuiItem * guiItem = getGuiItem( id );
  return ( guiItem ? guiItem->getIsEnabled() : false ) ;
}


void GuiTeam::setIsEnabled( int id , bool isEnabled , bool testIfExists )
{
  if ( testIfExists == true && hasGuiItem( id ) == false ) return ;
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem != nullptr ) guiItem->setIsEnabled( isEnabled );
}



bool GuiTeam::getIsEditable( int id ) const
{
  GuiItem * guiItem = getGuiItem( id );
  return ( guiItem ? guiItem->getIsEditable() : false ) ;
}


void GuiTeam::setIsEditable( int id , bool isEnabled , bool testIfExists )
{
  if ( testIfExists == true && hasGuiItem( id ) == false ) return ;
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem != nullptr ) guiItem->setIsEditable( isEnabled );
}


void GuiTeam::setFocusOnItem( int id )
{
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem != nullptr && guiItem->isWidget() == true ) {
    guiItem->setFocusOnItem();
  }
}


bool GuiTeam::changeFont( int id , int bold , const char * family , int size )
{
  GuiItem * guiItem = getGuiItem( id );
  return guiItem ? guiItem->changeFont( bold , family , size ) : false ;
}



bool GuiTeam::getBool( int id ) const
{
  GuiItem * guiItem = getGuiItem( id );
  return ( guiItem ? guiItem->getBool() : false ) ;
}


bool GuiTeam::setBool( int id , bool b , bool testIfExists , bool forceMessage )
{
  if ( testIfExists == true && hasGuiItem( id ) == false ) { return false; }
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem == nullptr ) { return false ; }
  return guiItem->setBool( b , forceMessage );
}


int  GuiTeam::getInt( int id , bool *isOk )
{
  GuiItem * guiItem = getGuiItem( id );
  return ( guiItem ? guiItem->getInt( isOk ) : 0 ) ;
}


bool GuiTeam::getCheckedInt( int id , int &value , const char * name , bool resetIfNeeded )
{
  GuiItem * guiItem = getGuiItem( id );
  return ( guiItem ? guiItem->getCheckedInt( value , name , resetIfNeeded ) : false ) ;
}


bool GuiTeam::setInt( int id , int value , bool testIfExists , bool forceMessage )
{
  if ( testIfExists == true && hasGuiItem( id ) == false ) return false ;
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem == nullptr ) { return false ; }
  return guiItem->setInt( value , forceMessage ); 
}


float GuiTeam::getFloat( int id , bool *isOk ) const
{
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem != nullptr ) {
    return guiItem->getFloat( isOk );
  }
  else {
    if ( isOk != 0 ) { *isOk = false ; }
    return 0.0f ;
  }
}


bool GuiTeam::setFloat( int id , float value , bool testIfExists , bool forceMessage)
{
  if ( testIfExists == true && hasGuiItem( id ) == false ) { return false ; }
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem == nullptr ) { return false ; }
  return guiItem->setFloat( value , forceMessage );   
}


double GuiTeam::getDouble( int id , bool *isOk ) const
{
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem != nullptr ) {
    return guiItem->getDouble( isOk );
  }
  else {
    if ( isOk != 0 ) { *isOk = false ; }
    return 0.0 ;
  }
}


bool GuiTeam::setDouble( int id , double value , bool testIfExists , bool forceMessage )
{
  if ( testIfExists == true && hasGuiItem( id ) == false ) { return false ; }
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem == nullptr ) { return false ; }
  return guiItem->setDouble( value , forceMessage );   
}


bool GuiTeam::setString( int id , const QString & text , bool testIfExists , bool forceMessage )
{
  if ( testIfExists == true && hasGuiItem( id ) == false ) { return false ; }
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem == nullptr ) { return false ; }
  return guiItem->setString( text , forceMessage );
}



QString GuiTeam::getString( int id ) const
{
  QString str ;
  GuiItem * guiItem = getGuiItem( id );
  if ( guiItem != nullptr ) {
    str = guiItem->getString();
  }
  return str ;
}



//====================================================================================
//====================================================================================
// DATA TRANSFER
//====================================================================================
//====================================================================================



void GuiTeam::setupValuesTransfer( const std::shared_ptr< MscDataTeam > & dh )
{
  static const char * METHOD_NAME = "setupValuesTransfer()" ;

  // something to do
  if ( myDataTeam != dh ) {
    
    // disconnect if needed 
    if ( myDataTeam.get() != 0 ) { // not empty // isEmpty() == false ) {
      // TODO Disconnect( *myDataTeam , myDataTeam->ChangedSignalsSet , *this , &GuiTeam::transferDataValueToGuiValue );
      myDataTeam = 0 ;
    }
    
    // collect the ids of the items to transfer
    myDataGuiIdsMap.clear();
    myTransferableDataIds.clear();
    for ( auto iter=myItems.cbegin() ; iter != myItems.cend() ; ++iter ) {
      int dataId = iter->second->getDataId() ;
      if ( dataId != MscDataItem::ID_UNDEFINED ) {
        myDataGuiIdsMap[ dataId ] = iter->second->getId();
        myTransferableDataIds.insert(dataId);
      }
    }
    
    // if there is something to do
    if ( myDataGuiIdsMap.empty() == false ) {
      // connect
      myDataTeam = dh ;
      // TODO Connect( *myDataTeam , myDataTeam->ChangedSignalsSet , *this , &GuiTeam::transferDataValueToGuiValue );
      // transfer
      transferDataValueToGuiValue(0); // "0" parameter has the same effect as "&myTransferableDataIds" 
    }
    
    // degug
    MscDg::trace( CLASS_NAME , METHOD_NAME , "DataGuiIdsMap.Size:%ld " , myDataGuiIdsMap.size() );
  }
}


//========================//
// **** GUI <=> DATA **** //
//========================//


int  GuiTeam::transferValues( GuiTeam::TransferType transferType , std::set<int> * changes )
{
  static const char * METHOD_NAME = "transferValues()" ;
  int numberOfTransfer = 0 ;
  int numberOfChanges  = 0 ; 

  if ( myDataTeam.get() != nullptr ) { // not empty

    // for each GUI item
    for ( auto iter=myItems.cbegin() ; iter != myItems.cend() ; ++iter ) {

      // get the data id related to the GUI item
      GuiItem * guiItem = iter->second ;
      int dataId = guiItem->getDataId() ;

      // nothing to do if no data is associated to the GUI item ...
      if ( (dataId == MscDataItem::ID_UNDEFINED) ||
           // ... or the data is not to be transfered
           (changes != 0 && changes->find(dataId) != changes->end() ) ) {
        continue ;
      }

      // find the Data Id item
      MscDataItem * dataItem = myDataTeam->getDataPtr(dataId);
      numberOfTransfer += 1 ;
      bool valueHasChanged = false ;

      //------------------------
      // transfer : GUI -> DATA
      //------------------------

      if ( transferType == GuiTeam::TF_USER_TO_DATA ) {
        
        // set the value
        switch ( dataItem->getDataType() ) {
        case MscDataItem::DT_BOOL   :
          {
            valueHasChanged = myDataTeam->setBool  ( dataId , guiItem->getBool()   );
          } break ;
          /** case of a "Boolean" displayed in a combo-box */
        case MscDataItem::DT_BOOL_I :
          {
            valueHasChanged = myDataTeam->setBool  ( dataId , guiItem->getInt() != (int)false );
          } break ;
        case MscDataItem::DT_INT   :
          {
            valueHasChanged = myDataTeam->setInt   ( dataId , guiItem->getInt()    );
          } break ;
        case MscDataItem::DT_FLOAT  :
          {
            valueHasChanged = myDataTeam->setFloat ( dataId , guiItem->getFloat()  );
          } break ;
        case MscDataItem::DT_DOUBLE  :
          {
            valueHasChanged = myDataTeam->setDouble( dataId , guiItem->getDouble() );
          } break ;
        case MscDataItem::DT_STRING  :
          {
            valueHasChanged = myDataTeam->setString( dataId , guiItem->getMscString() );
          } break ;
        default :
            ; // consider it to avoid warnings
        }        
      }

      //------------------------
      // transfer : DATA -> GUI
      //------------------------ 

      else if ( transferType == GuiTeam::TF_DATA_TO_USER ) {
        bool forceMessage = false ;
        switch ( dataItem->getDataType() ) {    
        case MscDataItem::DT_BOOL   :
          {
            valueHasChanged = guiItem->setBool  ( dataItem->getBool()   , forceMessage );
          } break ;
          /** the "Boolean" is stored in the "Integer" */
        case MscDataItem::DT_BOOL_I :
        case MscDataItem::DT_INT  :
          {
            valueHasChanged = guiItem->setInt   ( dataItem->getInt()    , forceMessage );
          } break ;
        case MscDataItem::DT_FLOAT  :
          {
            valueHasChanged = guiItem->setFloat ( dataItem->getFloat()  , forceMessage );
          } break ;
        case MscDataItem::DT_DOUBLE  :
          {
            valueHasChanged = guiItem->setDouble( dataItem->getDouble() , forceMessage );
          } break ;
        case MscDataItem::DT_STRING  :
          {
            valueHasChanged = guiItem->setString( dataItem->getString().c_str() , forceMessage );
          } break ;
        default :
            ; // consider it to avoid warnings
        }
      }

      //------------------------
      // changed
      //------------------------ 
      
      if ( valueHasChanged == true ) { numberOfChanges += 1 ; }
    }
  }
  // has been recognized , so it should be okay
  if ( numberOfTransfer > 0 ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME ,  "Transfer %d succeeded with %d transfer(s) and %d change(s)" ,
                 transferType , numberOfTransfer , numberOfChanges );

    
  }
  else {
    MscDg::trace( CLASS_NAME , METHOD_NAME ,  "Transfer %d : no transfer (dataTeamIsEmpty: %d)" ,
                 transferType , (myDataTeam.get() == nullptr)  );
  }
  // send signal if needed
  if ( numberOfChanges > 0 && transferType == GuiTeam::TF_DATA_TO_USER ) {
    myDataTeam->sendSignals();
  }
  return numberOfTransfer ;  
}


//========================//
// **** GUI ==> DATA **** //
//========================//


bool GuiTeam::transferGuiValueToDataValue( const std::shared_ptr< MscDataTeam > & dataTeam , GuiEvent & e )
{
  static const char * METHOD_NAME = "transferGuiValueToDataValue()" ;

  bool transferWasDone = false ;
  bool valueHasChanged = false ;
  int  guiId  = e.getGuiItemId() ;
  int  dataId = MscDataItem::ID_UNDEFINED ;

  GuiItem * guiItem = e.getGuiItem() ;
  if ( dataTeam.get() != nullptr && // not empty
       guiItem != nullptr &&
       (dataId = guiItem->getDataId()) != MscDataItem::ID_UNDEFINED ) {
    
    // find the Data Id item
    MscDataItem * dataItem = dataTeam->getDataPtr( dataId );
    
    if ( dataItem != 0 ) {

      transferWasDone = true ;
      bool sendMessage = true ;
      // "valueHasChanged" is "true" if the value has changed

      switch ( dataItem->getDataType() ) {
      case MscDataItem::DT_BOOL   :
        {
          valueHasChanged = dataTeam->setBool  ( dataId , e.getBool()   , sendMessage );
        } break ;
        /** case of a "Boolean" displayed in a combo-box */
      case MscDataItem::DT_BOOL_I :
        {
          valueHasChanged = dataTeam->setBool  ( dataId , (e.getInt() != int(false)) , sendMessage );
        } break ;
      case MscDataItem::DT_INT   :
        {
          valueHasChanged = dataTeam->setInt   ( dataId , e.getInt()    , sendMessage );
        } break ;
      case MscDataItem::DT_FLOAT  :
        {
          valueHasChanged = dataTeam->setFloat ( dataId , e.getFloat()  , sendMessage );
        } break ;
      case MscDataItem::DT_DOUBLE  :
        {
          valueHasChanged = dataTeam->setDouble( dataId , e.getFloat()  , sendMessage );
        } break ;
      case MscDataItem::DT_STRING  :
        {
          valueHasChanged = dataTeam->setString( dataId , e.getMscString() , sendMessage );
        } break ;
      default :
          ; // consider it to avoid warnings
      }
    }
  }

  // has been recognized , so it should be okay
  if ( valueHasChanged == true ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME ,  "GuiId %d changed with DataId %d" , guiId , dataId );
    dataTeam->sendSignals();
  }
  else if ( dataId != MscDataItem::ID_UNDEFINED ) {
    if ( transferWasDone == true ) {
      MscDg::trace( CLASS_NAME , METHOD_NAME ,  "GuiId %d no change with DataIdId %d" , guiId , dataId );
    }
    else {
      MscDg::trace( CLASS_NAME , METHOD_NAME ,  "GuiId %d no transfer with DataIdId %d" , guiId , dataId );
    }
  }
  else {
    MscDg::trace( CLASS_NAME , METHOD_NAME ,  "GuiId %d has no data attached to it" );
  }
  return valueHasChanged ;
}



//========================//
// **** DATA ==> GUI **** //
//========================//


void GuiTeam::transferDataValueToGuiValue( std::set<int> * changes )
{
  static const char * METHOD_NAME = "transferDataValueToGuiValue()" ;
  
  // if no signal have all the signals
  if ( changes == 0 ) { changes = &myTransferableDataIds ; }

  // for each data
  QString string ;
  bool hasBeenFound = false ;
  bool addToSignals = true  ;
  bool forceMessage = false ;
  int  numberOfTransfer = 0 ;
  int  numberOfChanges  = 0 ; 
  
  for ( auto dataIter=changes->cbegin() ; dataIter != changes->cend() ; ++dataIter ) {
    
    // if the DATA item is associated to a GUI item
    int dataId = *dataIter ;
    std::map< int , int >::const_iterator idIter = myDataGuiIdsMap.find( dataId );
    
    if ( idIter != myDataGuiIdsMap.end() ) {

      // the items
      MscDataItem * dataItem = myDataTeam->getDataPtr( dataId );
      GuiItem     * guiItem  = getGuiItem( idIter->second );
      
      if ( dataItem != 0 && guiItem != nullptr ) {
        
        bool valueHasChanged = false ;
        numberOfTransfer += 1 ;
        switch ( dataItem->getDataType() ) {

        case MscDataItem::DT_BOOL   :
          {
            valueHasChanged = guiItem->setBool( dataItem->getBool() , forceMessage );
          } break ;
          /** the "Boolean" is stored in the "Integer" */
        case MscDataItem::DT_BOOL_I :
        case MscDataItem::DT_INT  :
          {
            valueHasChanged = guiItem->setInt( dataItem->getInt() , forceMessage );
          } break ;
        case MscDataItem::DT_FLOAT  :
          {
            valueHasChanged = guiItem->setString( string.sprintf( "%f" , dataItem->getFloat() ) , forceMessage );
          } break ;
        case MscDataItem::DT_DOUBLE  :
          {
            valueHasChanged = guiItem->setString( string.sprintf( "%g" , dataItem->getDouble() ) , forceMessage );
          } break ;
        case MscDataItem::DT_STRING  :
          {
            valueHasChanged = guiItem->setString( dataItem->getString().c_str() , forceMessage );
          } break ;
        default :
          numberOfTransfer -= 1 ;
        }
        if ( valueHasChanged == true ) { numberOfChanges += 1 ; }
      }
    }
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "NumberOfChanges %d -> Transfered %d Changed %d" ,
               changes->size() , numberOfTransfer , numberOfChanges );
}
 


//====================================================================================
//====================================================================================
// HANDLING WITH THE KEY EVENTS
//====================================================================================
//====================================================================================



GuiEvent * GuiTeam::considerKeyEvent( GuiItem * guiItem , QKeyEvent * e , int senderId )
{
  // create the new event
  GuiEvent * event = new GuiEvent( guiItem , myKeys , e , senderId );
  // find out if the event is considered
  if ( event->getEventType() != GuiEvent::ET_KEY ) {
    delete event ;
    event = 0 ;
  }
  // considered . store it
  else {
    myKeyEvent.reset(event) ;
  }
  return event ;
}


#include "GuiUtilities.hpp"

#include "MscDebug.hpp"
#include "MscString.hpp"

#include <QObject>
#include <QPushButton>
#include <QWidget>


const char * GuiUtl::getObjectName ( QObject * )
{
    return "";
}



const char * GuiUtl::getObjectClassName( QObject * )
{
    return "";
}


void   GuiUtl::raise( QWidget * w )
{
    if ( w && w->isTopLevel() ) {
      //w->show();
      if ( w->isMinimized() == true ) {
        Qt::WindowStates state = w->windowState() ;
        w->setWindowState( state & (~Qt::WindowMinimized | Qt::WindowActive) );
      }
      w->raise();
    }
}



void GuiUtl::removeDefaultButton( QObject * obj )
{
  if ( obj == 0 ) return;
  // Button
  if ( obj->inherits( "QPushButton") ) {
    static_cast<QPushButton*>(obj)->setAutoDefault(false);
  }
  const QList<QObject*> objectList = obj->children();
  if ( objectList.size() == 0 ) return;
  // list of objects
  QListIterator<QObject*> iter(objectList);
  while ( iter.hasNext() ) {
     GuiUtl::removeDefaultButton( iter.next() );
  }
}


bool GuiUtl::isBlank( const char * str )
{
    return str==0 || *str=='\0';
}


MscString GuiUtl::getMscString( const QString & str )
{
   return MscString(str.toStdString().c_str());
}


// Qt
#include <QAction>
#include <QFont>
#include <QIcon>
#include <QObject>
#include <QPushButton>
#include <QTableWidget>
#include <QWidget>

// widget factory library
#include "GuiItem.hpp"
#include "GuiUtilities.hpp"




/**************************************************************************************************
**************************************************************************************************
** GuiWidgetAspect
**************************************************************************************************
*************************************************************************************************/



const char * GuiWidgetAspect::CLASS_NAME = "GuiWidgetAspect" ;



/** save the initial aspect */
GuiWidgetAspect::GuiWidgetAspect( QObject * obj , float fontPercentage , float pixmapPercentage )
{
  static const char * METHOD_NAME = "GuiWidgetAspect()" ;

  myPointSize = GuiItem::DEFAULT_POINT_SIZE ;
  myObject    = obj   ;
  myWidget    =  0    ;
  myWidth     = -1    ;
  myMinWidth  = -1    ;
  myMinHeight = -1    ;
  myMaxWidth  = -1    ;
  myMaxHeight = -1    ;
  myTableRow  = -1    ;
  // previous percentages
  myFontPercentage    = 1.0f ;
  myPixmapPercentage  = 1.0f ;

  //================
  // action
  //================
  if ( myObject->inherits("QAction") == true ) {
    if ( ((QAction*)myObject)->icon().isNull() == false ) {
      // ISSUE : MODIFIED THE IMAGE . myImage = ((QAction*)myObject)->icon().pixmap().convertToImage();
    }
  }
  // not a widget
  else if ( myObject->isWidgetType() == false ) {
    return ;
  }

  //================
  // widget
  //================
  myWidget = (QWidget*)obj ;
  QFont font( myWidget->font() );
  if ( myPointSize != font.pointSizeF() ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "'%s' Mismatch %g %g" ,
                   GuiItem::objectName(myObject) , myPointSize , font.pointSizeF() );
      myPointSize = font.pointSizeF();
  }
  // debug
  MscDg::trace( CLASS_NAME , METHOD_NAME ,
               "'%s'   Widget %d -> %d -> %d -> %d   Height %d -> %d" ,
               GuiItem::objectName(myWidget) ,
               myWidget->minimumWidth()  , myWidget->width() , myWidget->maximumWidth() ,
               myWidget->minimumHeight() , myWidget->maximumHeight() );

  // save values
  myWidth     = myWidget->width()         ;
  myMinWidth  = myWidget->minimumWidth()  ;
  myMaxWidth  = myWidget->maximumWidth()  ;
  myMinHeight = myWidget->minimumHeight() ;
  myMaxHeight = myWidget->maximumHeight() ;

  // pushbutton
  if ( myWidget->inherits("QPushButton") == true ) {
    QIcon icon = ((QPushButton*)myWidget)->icon();
    if ( icon.isNull() == false ) {
      // ISSUE: MODIFIES THE IMAGE myImage = icon->pixmap().convertToImage();
    }
  }
  // table
  else if ( myWidget->inherits("QTableWidget") == true ) {
    QTableWidget * table = (QTableWidget*)myWidget ;
    if ( table->rowCount() > 0 ) {
      myTableRow = table->rowHeight(0);
    }
  }
  // update
  if ( fontPercentage != 1.0f && pixmapPercentage != 1.0f ) {
    update( fontPercentage , pixmapPercentage );
  }
}




void GuiWidgetAspect::update( float fontPercentage , float pixmapPercentage )
{
  static const char * METHOD_NAME = "update()" ;
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME , "Font %g  Pixmap %g" , fontPercentage , pixmapPercentage );
  if ( fontPercentage <= 0.1f || pixmapPercentage <= 0.1f ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Font %g  Pixmap %g" , fontPercentage , pixmapPercentage );
    return ;
  }

  // pixmap
#if 0
  if ( false ) {
    // NOT WORKING
    if ( myImage.isNull() == false ) {
      // ISSUE: RESIZE IS NOT WORKING CORRECTLY ****
      // scaledToHeight
      // scaledToWidth
      // QImage image = GuiMisc::resizeImage(myImage,pixmapPercentage);
      QPixmap pixmap( myImage );
      QIcon icon( pixmap );
      if ( myObject->inherits("QAction") == true ) {
        ((QAction*)myObject)->setIcon( icon);
      }
      if ( myObject->inherits("QPushButton") == true ) {
        ((QPushButton*)myObject)->setIcon( icon );
      }
    }
  }
#endif

  // font
  if ( myWidget != 0 ) {
    // change font
    QFont font( myWidget->font() );
    font.setPointSizeF( myPointSize * fontPercentage );
    myWidget->setFont( font );
    // min / max
    if ( myMaxWidth  < 20000 ) { myWidget->setMaximumWidth ((int)(myMaxWidth  * fontPercentage)) ; }
    myWidget->resize( (int)(myWidth  * fontPercentage) , myWidget->height() );
    if ( myMinWidth  > 0     ) { myWidget->setMinimumWidth ((int)(myMinWidth  * fontPercentage)) ; }
    if ( myMaxHeight < 20000 ) { myWidget->setMaximumHeight((int)(myMaxHeight * fontPercentage)) ; }
    if ( myMinHeight > 0     ) { myWidget->setMinimumHeight((int)(myMinHeight * fontPercentage)) ; }
    // pushbutton
    if ( myObject->inherits("QPushButton") == true ) {

    }
    // table
    if ( myObject->inherits("QTableWidget") == true ) {
      QTableWidget * table = (QTableWidget*)myObject ;
      int numberOfRows = table->rowCount();
      if ( myTableRow == -1 ) {
        myTableRow = table->rowHeight(0);
      }
      for ( int row=0 ; row < numberOfRows ; ++row ) {
        // TODO ... check what can be done table->adjustRow(row);
      }
      for ( int col=0 ; col < table->columnCount() ; ++col ) {
        int colWidth =  table->columnWidth(col);
        colWidth = (int)( colWidth * (fontPercentage / myFontPercentage) );
        // debug
        if ( dbOn == true ) {
          GuiUtl::print( "  Table column[%d]  %d -> %d" ,
                         col ,  table->columnWidth(col) , colWidth );
        }
        // table->setColumnWidth( col , colWidth );
      }
      //
      // TODO .... table->horizontalHeader()->adjustHeaderSize();
    }
  }
  // save
  myFontPercentage   = fontPercentage   ;
  myPixmapPercentage = pixmapPercentage ;
}







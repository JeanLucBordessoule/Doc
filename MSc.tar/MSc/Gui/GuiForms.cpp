#include "GuiForms.hpp"

#include <memory>

#include "MscDataAccess.hpp"
#include "MscDebug.hpp"

#include "GuiDisplay.hpp"

#include <QAction>
#include <QActionGroup>
#include <QApplication>
#include <QButtonGroup>
#include <QCheckBox>
#include <QComboBox>
#include <QCursor>
#include <QDateTime>       // see also QDir
#include <QDesktopWidget>
#include <QDockWidget>
#include <QEvent>
#include <QFileDialog>
#include <QFrame>
#include <QGroupBox>
#include <QImage>
#include <QHeaderView>
#include <QHideEvent>
#include <QLabel>
// layout
#include <QLayout>
#include <QHBoxLayout>
#include <QVBoxLayout> 
#include <QGridLayout> 
// 
#include <QLineEdit>
#include <QListView>
#include <QListWidget>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QMouseEvent>
#include <QObject> 
#include <QPainter>
#include <QPixmap>
#include <QProgressBar>
#include <QProgressDialog>
#include <QPushButton>
#include <QKeyEvent>
#include <QResizeEvent>
#include <QScrollArea>
#include <QScrollBar>
#include <QShowEvent>
#include <QSlider>
#include <QSpinBox>
#include <QSplitter>
#include <QStackedWidget>
#include <QStatusBar>
#include <QStringList>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QTabWidget>
#include <QTextEdit>
#include <QTimer>
#include <QToolBar>
#include <QToolTip>
#include <QValidator>





/** Page holder . Inherits from "GuiItem" and not from "GuiTeam" but more appropriate here */
const char * GuiPageHolder::CLASS_NAME = "GuiPageHolder"  ;
/** Main window (can be of 2 types) */




/*! ************************************************************************************************
************************************************************************************************** 
** Group of Senders
************************************************************************************************** 
*************************************************************************************************/

const char * GuiWidgetGroup::CLASS_NAME = "GuiWidgetGroup"  ;


GuiWidgetGroup::GuiWidgetGroup( GuiTeam::TeamType teamType , int id , QWidget * parent ,
                                const char * name , GuiTeam * teamLeader , GuiScreen * screen )
    : GuiTeam(teamType,id,parent,name,teamLeader,screen)
{
  //
}



void GuiWidgetGroup::createItems( GuiForm * teamLeader , const GuiWidgetGroup::CreateInfo & createInfo )
{
  static const char * METHOD_NAME = "createItems()" ;
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME );
  MscDg::check( CLASS_NAME , METHOD_NAME ,
               (teamLeader != 0 && teamLeader->getMainWindow() != 0) ,
               "Main window must be provided" );

  // menubar is the one of the main window
  QMainWindow * parent  = teamLeader->getMainWindow();
  QMenuBar    * menuBar = parent->menuBar();

  // create the items (they are added to the list)
  int i=0 ;
  // bool test = true ;
  
  //=====================================================
  // CREATE THE SIMPLE ITEMS (if they don't exist)
  // show / hide is not called at this moment
  //=====================================================

  // Actions
  for ( i=0 ; i < createInfo.myActionsBPnumber ; ++i ) {
    int guiItemId  = createInfo.myActionsBP[i].myId ;
    bool isVisible = isTheItemVisible(guiItemId) ;
    if ( isVisible == true ) {
      if ( hasGuiItem(guiItemId) == false ) {
        if ( dbOn == true ) { GuiUtl::print( "  Action" ); }
        new GuiAction( *this , parent , createInfo.myActionsBP[i] );
      }
    }
  }
  // Actions Groups
  for ( i=0 ; i < createInfo.myActionGroupBPnumber ; ++i ) {
    int guiItemId  = createInfo.myActionGroupBP[i].myId ;
    bool isVisible = isTheItemVisible(guiItemId) ;
    if ( isVisible == true ) {
      if ( hasGuiItem(guiItemId) == false ) {
        MscDg::trace( CLASS_NAME , METHOD_NAME , "ActionGroup" );
        new GuiActionGroup( *this , parent , createInfo.myActionGroupBP[i] );
      }
    }
  }
  // Spin Boxes
  for ( i=0 ; i < createInfo.mySpinBoxBPnumber ; ++i ) {
    int guiItemId  = createInfo.mySpinBoxBP[i].myId ;
    bool isVisible = isTheItemVisible(guiItemId) ;
    if ( isVisible == true ) {
      if ( hasGuiItem(guiItemId) == false ) {
        MscDg::trace( CLASS_NAME , METHOD_NAME , "SpinBox" );
        new GuiSpinBox( *this , parent , createInfo.mySpinBoxBP[i] );
      }
    }
  }
  // Labels
  for ( i=0 ; i < createInfo.myLabelBPnumber ; ++i ) {
    int guiItemId  = createInfo.myLabelBP[i].myId ; 
    bool isVisible = isTheItemVisible(guiItemId) ;
    if ( isVisible == true ) {
      if ( hasGuiItem(guiItemId) == false ) {
        MscDg::trace( CLASS_NAME , METHOD_NAME , "Label" );
        new GuiLabel( *this , parent , createInfo.myLabelBP[i] );
      }
    }
  }
  // Push Buttons
  for ( i=0 ; i < createInfo.myPushButtonBPnumber ; ++i ) {
    int guiItemId  = createInfo.myPushButtonBP[i].myId ;
    bool isVisible = isTheItemVisible(guiItemId) ;
    if ( isVisible == true ) {
      if ( hasGuiItem(guiItemId) == false ) {
        MscDg::trace( CLASS_NAME , METHOD_NAME , "PushButton" );
        new GuiPushButton( *this , parent , createInfo.myPushButtonBP[i] ); 
      }
    }
  }
  // Check Boxes
  for ( i=0 ; i < createInfo.myCheckBoxBPnumber ; ++i ) {
    int guiItemId  = createInfo.myCheckBoxBP[i].myId ;
    bool isVisible = isTheItemVisible(guiItemId) ;
    if ( isVisible == true ) {
      if ( hasGuiItem(guiItemId) == false ) {
        MscDg::trace( CLASS_NAME , METHOD_NAME , "CheckBox" );
        new GuiCheckBox( *this , parent , createInfo.myCheckBoxBP[i] );     
      }
    }
  }
  // Line Edit
  for ( i=0 ; i < createInfo.myLineEditBPnumber ; ++i ) {
    int guiItemId  = createInfo.myLineEditBP[i].myId ;
    bool isVisible = isTheItemVisible(guiItemId) ;
    if ( isVisible == true ) {
      if ( hasGuiItem(guiItemId) == false ) {
        MscDg::trace( CLASS_NAME , METHOD_NAME , "LineEdit" );
        new GuiLineEdit( *this , parent , createInfo.myLineEditBP[i] );
      }
    }
  }
  // Combo Box
  for ( i=0 ; i < createInfo.myComboBoxBPnumber ; ++i ) {
    int guiItemId  = createInfo.myComboBoxBP[i].myId ;
    bool isVisible = isTheItemVisible(guiItemId) ;
    if ( isVisible == true ) {
      if ( hasGuiItem(guiItemId) == false ) {
        MscDg::trace( CLASS_NAME , METHOD_NAME , "ComboBox %d" , guiItemId );
        new GuiComboBox( *this , parent , createInfo.myComboBoxBP[i] );       
      }
    }
  }
  // Separator . Visibility is not considered here .
  for ( i=0 ; i < createInfo.mySeparatorBPnumber ; ++i ) {
    int guiItemId  = createInfo.mySeparatorBP[i].myId ;  
    if ( hasGuiItem(guiItemId) == false ) {
      MscDg::trace( CLASS_NAME , METHOD_NAME , "Separator %d" , guiItemId );
      new GuiSeparator( *this , parent , createInfo.mySeparatorBP[i] );       
    }    
  }

  //=====================================================
  // CREATE THE CONTAINERS (if they don't exist)
  // It's the toolbars or popup menus
  // show / hide is called here in 'addExistingItemToCaller()'
  // to make sure the items are shown or hidden
  //=====================================================

  // Toolbar 
  for ( i=0 ; i < createInfo.myToolBarBPnumber ; ++i ) {
    int guiItemId  = createInfo.myToolBarBP[i].myId ;
    bool isVisible = isTheItemVisible(guiItemId) && 
      // Extra test to see if it needs to be created
      GuiToolBar::testIfToolBarIsToBeCreated( *this , createInfo.myToolBarBP[i] ) ;
    GuiToolBar * toolbarItem = hasGuiItem(guiItemId) ? dynamic_cast<GuiToolBar*>(getGuiItem(guiItemId)) : 0 ;
    if ( isVisible == true ) {
      // create
      if ( toolbarItem == 0 ) {
        MscDg::trace( CLASS_NAME , METHOD_NAME , "ToolBar" );
        toolbarItem = new GuiToolBar( *this , parent , createInfo.myToolBarBP[i] );
      }
      // update
      else {
        int numberOfItemsSinceLastSeparator = 0 ;
        for ( int j=0 ; j < createInfo.myToolBarBP[i].myNumberOfIds ; ++j ) { 
          addExistingItemToCaller( toolbarItem , createInfo.myToolBarBP[i].myIds[j] ,
                                   numberOfItemsSinceLastSeparator );
        }
      }      
    }
    // hide it despite it has items to show
    if ( toolbarItem != 0 && toolbarItem->modifyVisibility() == true && isVisible == true ) {
      setIsVisible( guiItemId , isVisible , false );
    }
  }
  // Menu
  for ( i=0 ; i < createInfo.myPopupMenuBPnumber ; ++i ) {
    int guiItemId  = createInfo.myPopupMenuBP[i].myId ;
    bool isVisible = isTheItemVisible(guiItemId) ;
    GuiItem * popupMenuItem = hasGuiItem(guiItemId) ? getGuiItem(guiItemId) : 0 ;
    if ( isVisible == true ) {
      // create it
      if ( hasGuiItem(guiItemId) == false ) {
        MscDg::trace( CLASS_NAME , METHOD_NAME , "Menu" );
        new GuiPopupMenu( *this , parent , menuBar , createInfo.myPopupMenuBP[i] );       
      }
      // update
      else {
        int numberOfItemsSinceLastSeparator = 0 ;
        for ( int j=0 ; j < createInfo.myPopupMenuBP[i].myNumberOfIds ; ++j ) { 
          addExistingItemToCaller( popupMenuItem , createInfo.myPopupMenuBP[i].myIds[j] ,
                                   numberOfItemsSinceLastSeparator );
        }
      }
    }
    else if ( popupMenuItem != 0 ) {
      setIsVisible( guiItemId , isVisible , false ); 
    }
  }
  // Modify the Aspect
  for ( i=0 ; i < createInfo.myGenericBPnumber ; ++i ) {
    int guiItemId  = createInfo.myGenericBP[i].myId ;
    bool isVisible = isTheItemVisible(guiItemId) ;
    if ( isVisible == true ) {
      MscDg::trace( CLASS_NAME , METHOD_NAME , "Generic" );
        // find the item
      GuiTeam::ItemsMap::iterator iter = myItems.find(guiItemId);
      // set the properties
      if ( iter != myItems.end() ) { iter->second->setValues( createInfo.myGenericBP[i] ); }   
    }
  }
}



void GuiWidgetGroup::addExistingItemToCaller( GuiItem * caller , int itemId , int & numberOfItemsSinceLastSeparator )
{
  static const char * METHOD_NAME = "addExistingItemToCaller()" ;
  
  // *** test if the item is present *** //
  GuiTeam::ItemsMap::iterator iter = myItems.find( itemId );
  if ( iter == myItems.end() ) {
    return ;
  }
  // item does not exist.
  GuiItem * item = iter->second ;
  if ( item == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Group %d  ItemId:%d has not been found" , getId() , itemId );
    return ;
  }

  // *** add the item to the toolbar or the popup menu (if visible) *** //
  bool isVisible = item->isSeparator() || isTheItemVisible( item->getId() );
  if ( isVisible == true ) {
    // separator
    if ( item->isSeparator() == true ) {
      // previous was a separator... don't add it
      if ( numberOfItemsSinceLastSeparator == 0 ) {
        return ;
      }
      // add it
      numberOfItemsSinceLastSeparator = 0 ;
    }
    // not a separator
    else {
      numberOfItemsSinceLastSeparator += 1 ;
    }
  }
  // add it in the toolbar
  if ( caller->getWidgetType() == GuiItem::WT_TOOLBAR ) {
    GuiToolBar * toolBar = dynamic_cast<GuiToolBar*>(caller->getDerivedClass());
    // add it to the toolbar . It does test if it's already present .
    toolBar->addItem( item );
  }
  // add it in the menu 
  else if ( caller->getWidgetType() == GuiItem::WT_POPUPMENU ) {
    GuiPopupMenu * popUpMenu = dynamic_cast<GuiPopupMenu*>(caller->getDerivedClass()) ;
    // add it to the menu . It does test if it's already present .
    popUpMenu->addItem( item );
  }
  // undefined
  else {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Group %d  ItemId:%d . not a popup or a menu" , getId() , itemId );
  }
  // hide or show
  item->setIsVisible( isVisible );
}


void GuiWidgetGroup::modifySensitivityOfTheItems( int modifierId )
{
  for ( auto iter=myItems.begin() ; iter != myItems.end() ; ++iter ) {
    if ( iter->second == 0 ) continue ;
    iter->second->setIsEnabled( isTheItemSensitive( iter->first , modifierId ) );
  }
}



void GuiWidgetGroup::modifyVisibilityOfTheItems()
{
  GuiTeam::ItemsMap::iterator iter ;
  // show or hide 
  for ( iter=myItems.begin() ; iter != myItems.end() ; ++iter ) {
    // ignore the separator
    if ( iter->second == 0 || iter->second->isSeparator() == true ) continue ;
    // update visibility
    iter->second->setIsVisible( isTheItemVisible( iter->first ) );
  }
  // hide the toolbar with separators only (SHOULD not exists anymore)
  for ( iter=myItems.begin() ; iter != myItems.end() ; ++iter ) {
    if ( iter->second == 0 ) continue ;
    if ( iter->second->getWidgetType() == GuiItem::WT_TOOLBAR ) {
      (dynamic_cast<GuiToolBar*>(iter->second->getDerivedClass()))->modifyVisibility();
    }
  }
}


bool GuiWidgetGroup::receiveEventOfSender( int senderId , GuiEvent::EventType eventType )
{ 
  // create event
  GuiEvent e( 0 , eventType , senderId ) ;
  // send event
  return receiveEvent(e) ; 
}


void GuiWidgetGroup::refresh()
{
  static const char * METHOD_NAME = "refresh()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "getId %d" , getId() );
}


void GuiWidgetGroup::refresh( int id )
{
  static const char * METHOD_NAME = "refresh()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "getId %d Id %d" , getId() , id );
}



GuiCheckBox * GuiWidgetGroup::createCheckBox( const GuiCheckBox::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold ,
                                              int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget        * parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiCheckBox  * widget = new GuiCheckBox( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


GuiComboBox * GuiWidgetGroup::createComboBox( const GuiComboBox::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                              int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiComboBox  * widget = new GuiComboBox( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


GuiFrame * GuiWidgetGroup::createFrame( const GuiFrame::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                        int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiFrame     * widget = new GuiFrame( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


GuiGroupBox * GuiWidgetGroup::createGroupBox( const GuiGroupBox::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                              int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiGroupBox  * widget = new GuiGroupBox( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


GuiLabel * GuiWidgetGroup::createLabel( const GuiLabel::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                        int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiLabel     * widget = new GuiLabel( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


/** parent could be a layout (and hints at the widget to use as a parent ... */
GuiLayout * GuiWidgetGroup::createLayout( const GuiLayout::CreateInfo & createInfo , int parentId , int rowId , int colId )
{
  static const char * METHOD_NAME = "createLayout()" ;
  QString tmp, comment ;
  // error
  MscDg::check( CLASS_NAME , METHOD_NAME , (createInfo.myId != parentId) ,
               "Id %d %d Ids must be different" , createInfo.myId , parentId );

  //----------------------
  // nothing to do
  //----------------------
  GuiLayout * guiLayout = 0 ;
  if ( myTopWidget == 0 ) {
    return guiLayout ;
  }

  //----------------------
  // find parent
  //----------------------
  // GUI item . No message if it doesn't exist
  GuiItem   * parentItem   = getGuiItem(parentId,false);
  GuiLayout * parentLayout = 0 ;
  // layout has no parent if created at the application level
  QWidget   * w = 0 ;
  // find the parent and check it doesn't already contain a layout.
  if ( parentItem == 0 ) {
    QString layoutClass ;
    if ( GuiLayout::findLayout( myTopWidget , layoutClass ) == 0 ) {
      w = myTopWidget ;
      comment += tmp.sprintf( "  %d created using top widget '%s' as parent  " , createInfo.myId , GuiItem::objectName(w) );
    }
    else {
      comment += tmp.sprintf( "  %d created at application's level (layout present in top)" , createInfo.myId );
    }
  }
  // widget is provided
  else if ( parentItem->isWidget() == true ) {
    w = parentItem->getWidget();
    comment += tmp.sprintf( "  %d created using '%s' as parent  " , createInfo.myId , GuiItem::objectName(w) );
  }
  // layout is provided
  else if ( parentItem->isLayout() == true ) {
    w = (parentLayout=dynamic_cast<GuiLayout*>(parentItem))->getCreatorWidget();
    comment += tmp.sprintf( "  %d created using layout creator '%s' as parent  " , createInfo.myId , GuiItem::objectName(w) );
  }
  // nothing is provided (should never arive here)
  else {
    comment += tmp.sprintf( "  %d created at application's level with %s" , createInfo.myId , parentItem->getName() );
  }

  //----------------------
  // create layout
  //----------------------
  guiLayout = new GuiLayout( *this , w , createInfo , "createLayout" ) ;
  guiLayout->setCreator( parentItem );

  //----------------------
  // layout is provided
  //----------------------
  if ( parentLayout != 0 ) {
    // add to the provided layout
    parentLayout->addLayout( guiLayout , rowId , colId );
    comment += tmp.sprintf( "  *  added to existing layout '%s' " , parentLayout->getName() );
  }
  // debug
  MscDg::trace( CLASS_NAME , METHOD_NAME , "'%s' %s" , getName() , GuiUtl::getString(comment) );
  return guiLayout ;
}



GuiLineEdit * GuiWidgetGroup::createLineEdit( const GuiLineEdit::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                              int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget      * parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiLineEdit  * widget = new GuiLineEdit( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


GuiListBox * GuiWidgetGroup::createListBox( const GuiListBox::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                            int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiListBox   * widget = new GuiListBox( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


GuiListView * GuiWidgetGroup::createListView( const GuiListView::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                              int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiListView  * widget = new GuiListView( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}



GuiPushButton * GuiWidgetGroup::createPushButton( const GuiPushButton::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                                  int dataId , int row , int col )
{
  GuiLayout  * guiLayout = 0 ;
  QWidget   *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiPushButton * widget = new GuiPushButton( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}



GuiSlider * GuiWidgetGroup::createSlider( const GuiSlider::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                          int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiSlider  * widget = new GuiSlider( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


GuiSpinBox * GuiWidgetGroup::createSpinBox( const GuiSpinBox::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                            int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiSpinBox   * widget = new GuiSpinBox( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


GuiSplitter * GuiWidgetGroup::createSplitter( const GuiSplitter  ::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                              int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiSplitter  * widget = new GuiSplitter( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  return widget ;
}


GuiStackedWidget * GuiWidgetGroup::createStackedWidget( const GuiStackedWidget::CreateInfo & createInfo , int parentId , BoldType isBold ,
                                                        int row , int col )
{
  GuiLayout     * guiLayout = 0 ;
  QWidget            * parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiStackedWidget * widget = new GuiStackedWidget( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  return widget ;  
}



GuiTable * GuiWidgetGroup::createTable( const GuiTable::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                        int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiTable     * widget = new GuiTable( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


GuiTabWidget * GuiWidgetGroup::createTabWidget( const GuiTabWidget::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                                int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiTabWidget * widget = new GuiTabWidget( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  return widget ;
}


GuiTextEdit * GuiWidgetGroup::createTextEdit( const GuiTextEdit::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold , 
                                              int dataId , int row , int col )
{
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiTextEdit  * widget = new GuiTextEdit( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  return widget ;
}


GuiWidget * GuiWidgetGroup::createWidget( const GuiWidget::CreateInfo & createInfo , int parentId , 
                                          int row , int col )
{
  static const char * METHOD_NAME = "createWidget()" ;
  GuiLayout * guiLayout = 0 ;
  QWidget  *       parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiWidget    * widget = new GuiWidget( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  return widget ;  
}



QWidget * GuiWidgetGroup::myGetWidgetAndLayout( int parentId , GuiLayout* &guiLayout , GuiItem **guiItemPtr )
{
  static const char * METHOD_NAME = "myGetWidgetAndLayout()" ;
  QWidget   * parent        =  myTopWidget ; // by default, the top widget of the team
  GuiItem * parentItem    = (myTopWidget != 0 && parentId >= GuiItem::ID_FIRST_ITEM) ? getGuiItem(parentId) : 0 ;
  QWidget   * creatorWidget = 0 ;
  guiLayout = 0 ;

  // nothing
  if ( parentItem == 0 ) {
    //
  }
  // group box
  else if ( parentItem->getWidgetType() == GuiItem::WT_GROUP_BOX ) {
    parent    = dynamic_cast<GuiGroupBox*>(parentItem)->getInternalWidget();
    guiLayout = dynamic_cast<GuiGroupBox*>(parentItem)->getInternalLayout();
  }
  // other widget
  else if ( parentItem->isWidget() == true ) {
    parent = parentItem->getWidget(); 
  }
  // layout
  else if ( parentItem->isLayout() == true ) {
    guiLayout = getLayout(parentId);
    // could know the widget to deal with
    creatorWidget = guiLayout->getCreatorWidget();
    if ( creatorWidget != 0 ) { parent = creatorWidget ; }
  }
  // undefined ... what is it?
  else {
    MscDg::error( CLASS_NAME , METHOD_NAME , "ParentId %d undefined type %d" ,
                 parentId , parentItem->getWidgetType() );
  }
  // debug
  MscDg::trace( CLASS_NAME , METHOD_NAME , "ParentId %d -> '%s' Layout %s Creator '%s'" ,
               parentId , GuiItem::objectName(parent) , (guiLayout ? guiLayout->getName() : "") , 
               GuiItem::objectName(creatorWidget) );
  if ( guiItemPtr != 0 ) { *guiItemPtr = parentItem ; }
  return parent;
}





/*! ************************************************************************************************
**************************************************************************************************
** Page: set of widgets in a frame or in a group box
** The purpose is to ease the creation management of tab in a form .
**************************************************************************************************
*************************************************************************************************/


const char * GuiPage::CLASS_NAME = "GuiPage" ;


GuiPage::GuiPage( QWidget * parent , const GuiPage::CreateInfo & createInfo )
  : QObject( parent ) , GuiWidgetGroup( GuiTeam::TP_PAGE )
{
  myInitialize( parent , 0 , createInfo );
}


GuiPage::GuiPage( GuiPageHolder * pageHolder , const GuiPage::CreateInfo & createInfo )
  : QObject( pageHolder->getWidget() ) , GuiWidgetGroup( GuiTeam::TP_PAGE )
{
  myInitialize( pageHolder->getWidget() , pageHolder , createInfo );
}



void GuiPage::myInitialize( QWidget * parent , GuiPageHolder * pageHolder , const GuiPage::CreateInfo & createInfo )
{
  // initialize
  myPageHolder     = pageHolder        ;
  // save some parameters
  myId             = createInfo.myId    ;
  myIcon           = createInfo.myGuiGroupBox->myIcon  ;
  myTitle          = createInfo.myGuiGroupBox->myTitle ;
  myHelpPage       = createInfo.myHelpPage ;
  myNumberOfLinks  = createInfo.myNumberOfLinks ;
  myLinks          = createInfo.myLinks ;
  // create the top widget
  myIsActive       = true ;
  myFrame          = new GuiGroupBox( *this , parent , *createInfo.myGuiGroupBox , 0 , 1 );
  // new GuiFrameOfPage( *this , parent , *createInfo.myGuiGroupBox ) ;
  myGroupBox       = myFrame->getGroupBox();
  myTopWidget      = myFrame->getWidget();
  // initialize key
  myKey            = Qt::Key_unknown ;
  myModifiers      = Qt::NoModifier  ;
  // customize the top widget // Can't use the "setTooltip" method.
  // if ( createInfo.myToolTip != 0 ) { QToolTip::add( myGroupBox , createInfo->myGuiGroupBox.myToolTip ); }
  GuiItem::setSizes( myGroupBox , createInfo.mySizes );
  // add to the list of the form (should not be already in it)
  MscDg::trace( CLASS_NAME , "myInitialize()" , "Id %d  PageHolder %ld" , getId() , myPageHolder );
  if ( myPageHolder != 0 ) {
    myPageHolder->addPage(this);
  }
}



GuiPage::~GuiPage()
{
  static const char * METHOD_NAME = "~GuiPage()";
  MscDg::trace( CLASS_NAME , METHOD_NAME  );
  // remove page
  if ( myPageHolder != 0 ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "remove page" );
    myPageHolder->removePage( this );
  }
}


QWidget * GuiPage::getWidget()
{
  return myGroupBox ;
}


void GuiPage::setBoolean( bool b ) 
{ 
  myIsActive = b ; 
  if ( myGroupBox->isCheckable() == true ) {
    myGroupBox->setChecked( myIsActive );
  }
}


bool GuiPage::getBoolean() const
{ 
  return myIsActive ;
}


void GuiPage::showFrame( bool show )
{
  MscDg::trace( CLASS_NAME , "showFrame()" , "Show %d" , show );
  if ( show == false ) {
    myGroupBox->setTitle( "" );
    myGroupBox->setCheckable(false);
    myGroupBox->setFlat(true); // setFrameShape( QFrame::NoFrame );
  }
  else {
    myGroupBox->setFlat(false); // setFrameShape( QFrame::Box );
    myGroupBox->setCheckable(true);
    myGroupBox->setTitle( getTitle() );
  }
  if ( myGroupBox->isCheckable() == true ) {
    myGroupBox->setChecked(myIsActive);
  }
}


bool GuiPage::isActive()
{
  if ( myPageHolder != 0 ) {
    if ( myPageHolder->getPageHolderType() == GuiPageHolder::PHT_SIDE_BY_SIDE ) {
      myIsActive = myGroupBox->isChecked();
      return myIsActive ;
    }
    else if ( myPageHolder->getPageHolderType() == GuiPageHolder::PHT_TAB ) {
      myIsActive = myPageHolder->isPageShownToTheUser( this );
      return myIsActive ;
    }
    else {
      MscDg::error( CLASS_NAME , "isActive()" , "undefined type" );
      return true ;
    }
  }
  else if ( myGroupBox->isCheckable() == true ) {
    myIsActive = myGroupBox->isChecked();
    return myIsActive ;
  }
  else {
    return true ;
  }
}


bool GuiPage::pageKeyPressEvent( QKeyEvent * e )
{
  MscDg::trace( CLASS_NAME , "pageKeyPressEvent()" , "Key:%d (F5:%d) %s" ,
               e->key() , Qt::Key_F5 , GuiUtl::getString(e->text()) );
  // the derived class has not implemented and considered the case 
  // and do not wish the event to be considered anymore 
  if ( derivedPageKeyPressEvent( e ) == false ) { 
    return false ;
  }   
  // consider the event
  else {
    // key is the same : avoid to treat it 
    // It prevents the issues when the user keeps the key down 
    // (multiple same key events)
    if ( myKey == e->key() && myModifiers == e->modifiers() ) {
      // nothing to do
    }
    // F2: test the updating of the application parameter model
    else if ( e->key() == Qt::Key_F2 && myDataTeam.get() != nullptr ) { // no empty
      // not very useful at the moment
      // transferValues( *myDataTeam , GuiTeam::TF_USER_TO_DATA , myNumberOfLinks , myLinks );
      // myDataTeam->discartSignals();
    } 
    // F5: refresh the lists from the project
    else if ( e->key() == Qt::Key_F5 ) {
      setIsDirty();
      // refresh the current page
      refresh(true);
    }
    // Ctrl+0 : open file
    else if ( e->key() == Qt::Key_O && e->modifiers() == Qt::ControlModifier && myDataTeam.get() != nullptr ) { // no empty
      GuiForm * form = getParentForm();
      if ( form != nullptr ) {
        QString file = form->getOpenFileName( QString() , "*.xml" , "Read" );
        if ( file.isEmpty() == false ) {
          MscDataAccess da( file.toLatin1() , MscDataAccess::DA_READ_ASCII , 0 );
          myDataTeam->dataAccess( da );
          // check:  transferValues( *myDataTeam , GuiTeam::TF_DATA_TO_USER , myNumberOfLinks  , myLinks  );
        }
      }
    }
    // Ctrl+S : save file
    else if ( e->key() == Qt::Key_S && e->modifiers() == Qt::ControlModifier && myDataTeam.get() != nullptr ) { // no empty
      GuiForm * form = getParentForm();
      if ( form != nullptr ) {
        QString file = form->getSaveFileName( GuiUtl::getDirectory() , "*.xml" , "Save" , "xml" );
        if ( file.isEmpty() == false ) {
          // check:  transferValues( *myDataTeam , GuiTeam::TF_USER_TO_DATA , myNumberOfLinks , myLinks );
          MscDataAccess da( file.toLatin1() , MscDataAccess::DA_WRITE_ASCII , 0 );
          myDataTeam->dataAccess( da );
        }
      }
    }
    // Ctrl+T : toggle display
    else if ( e->key() == Qt::Key_T && e->modifiers() == Qt::ControlModifier && myPageHolder != 0 ) {
      myPageHolder->toggleDisplay();
    }
    // store the key so it is applied once only
    myKey       = e->key()       ;
    myModifiers = e->modifiers() ;
    // continue to propagate the event
    return true ;
  }
}


bool GuiPage::pageKeyReleaseEvent( QKeyEvent * e )
{
  MscDg::trace( CLASS_NAME , "pageKeyReleaseEvent()" , "Key:%d" , e->key() );
  myKey       = Qt::Key_unknown ;
  myModifiers = Qt::NoModifier  ;

  // is registered
  GuiEvent * keyEvent = considerKeyEvent( 0 , e , myId );
  if ( keyEvent != 0 ) {
    return receiveEvent( *keyEvent );
  }
  // the derived class has not implemented and considered the case 
  // and do not wish the event to be considered anymore 
  else if ( derivedPageKeyReleaseEvent( e ) == false ) { 
    return false ;
  }
  // consider the event
  else {
    // continue to propagate the event
    return true ;
  }    
}
 

void GuiPage::refresh()
{
  static const char * METHOD_NAME = "refresh()" ;
  // TODO .... MscDg::error( CLASS_NAME , METHOD_NAME , "getId %d" , getId() );
}


void GuiPage::refresh( int id )
{
  static const char * METHOD_NAME = "refresh()" ;
  // TODO ?? CHECK WHY THE 'id' IS NOT TAKEN INTO ACCOUNT
  MscDg::warning( CLASS_NAME , METHOD_NAME , "TODO getId %d= Id %d IS NOT TAKEN INTO ACCOUNT" , getId() , id );
  setIsDirty();
  refresh();
}


bool GuiPage::receiveEvent( GuiEvent & e ) 
{
  MscDg::error( CLASS_NAME , "receiveEvent()" , "Reimplement it. Event %d" , e.getGuiItemId() );
  return false ; 
} 


bool GuiPage::derivedPageKeyPressEvent( QKeyEvent * e ) 
{
  MscDg::trace( CLASS_NAME , "derivedPageKeyPressEvent()" , "Reimplement it. Event %d %s" ,
               e->key() , GuiUtl::getString(e->text()) );
  return true ;
}


bool GuiPage::derivedPageKeyReleaseEvent( QKeyEvent * e ) 
{
  MscDg::trace( CLASS_NAME , "derivedPageKeyReleaseEvent()" , "Reimplement it. Event %d %s" ,
               e->key() , GuiUtl::getString(e->text()) );
  return true ;
}








/*! ************************************************************************************************
**************************************************************************************************
** Form: set of pages in a QDialog or QMainWindow
** The purpose is to manage pages in a form
**************************************************************************************************
*************************************************************************************************/


//------------------------------------------------// 
//     Creation of a QDialog               .      //
//------------------------------------------------// 


class GuiDialogOfForm : public QDialog
{
public :
  static const char * CLASS_NAME ;
  GuiDialogOfForm( GuiForm & form ,
                   QWidget * parent ,
                   const GuiSplitter::CreateInfo * splitterBP ,
                   const GuiLayout::CreateInfo * layoutBP ,
                   Qt::WindowFlags flags )
    : QDialog( parent , flags ) , myForm( form )
  {
    static const char * METHOD_NAME = "GuiDialogOfForm()" ;
    myLayout   = 0 ;
    mySplitter = 0 ;   
    // layout must exist in order to have a splitter
    if ( layoutBP != 0 ) {
      myLayout = new GuiLayout( form , this , *layoutBP , CLASS_NAME ) ;
      // splitter
      if ( splitterBP != 0 ) {
        mySplitter = new GuiSplitter( form , this , *splitterBP ) ;
        myLayout->addWidget( mySplitter , 1 , 1 );
      }
    }
    // resize grip
    setSizeGripEnabled( true );
  }
  ~GuiDialogOfForm()
  {
    MscDg::error( CLASS_NAME , "~GuiDialogOfForm()" , "called" );
  }
  bool customWhatsThis() const
  {
    return GuiMisc::enterWhatsThisMode( this , myForm.getName() );
  }
  void showEvent( QShowEvent * e )
  {
    QDialog::showEvent( e );
    myForm.messageFromBaseForm( GuiEvent::ET_SHOW );
  }
  void resizeEvent( QResizeEvent *e )
  {
    QDialog::resizeEvent( e ); 
    myForm.messageFromBaseForm( GuiEvent::ET_RESIZE );
  }
  void hideEvent( QHideEvent * e ) 
  {
    myForm.messageFromBaseForm( GuiEvent::ET_HIDE );
    QDialog::hideEvent( e );
  }
  void closeEvent( QCloseEvent * e )
  {
    myForm.storeSizeLocationOfForm();
    if ( myForm.messageFromBaseForm( GuiEvent::ET_CLOSE ) == false ) {
      e->ignore();
    }
  }
  void destroy( bool destroyWindow , bool destroySubWindows ) 
  {
    myForm.messageFromBaseForm( GuiEvent::ET_DESTROY );
    QDialog::destroy( destroyWindow , destroySubWindows );
  }
  void mousePressEvent( QMouseEvent * e )
  {
    if ( myForm.baseMousePressEvent(e) == false ) {
      QDialog::mousePressEvent(e);
    }
  }
  void keyPressEvent( QKeyEvent * e )
  { 
    if ( myForm.formKeyPressEvent(e) == false ) {
      QDialog::keyPressEvent(e) ;
    }
  }
  void keyReleaseEvent( QKeyEvent * e )
  { 
    if ( myForm.formKeyReleaseEvent(e) == false ) {
      QDialog::keyReleaseEvent(e) ;
    }
  }
  // used by the caller
public :
  GuiLayout   * myLayout    ;
  GuiSplitter * mySplitter  ;
private :
  GuiForm     & myForm      ;
  QString         myClassName ;
} ;
const char * GuiDialogOfForm    ::CLASS_NAME = "GuiDialogOfForm"    ;



//------------------------------------------------// 
//     Creation of a QMainWindow                  //
//------------------------------------------------// 


class GuiMainWindowOfForm : public QMainWindow
{
public :
  static const char * CLASS_NAME ;
  GuiMainWindowOfForm( GuiForm & form ,
                       QWidget * parent ,
                       const GuiSplitter::CreateInfo * splitterBP ,
                       const GuiLayout::CreateInfo * layoutBP ,
                       Qt::WindowFlags flags ,
                       GuiForm::FormType type )
    : QMainWindow( parent , flags )
    , myForm(form) 
  {
    setObjectName(GuiMainWindowOfForm::CLASS_NAME);
    // add status bar
    (void)statusBar();
    // toolbar should move below...
    setDockOptions( QMainWindow::ForceTabbedDocks );

    // values
    QString nameStr ;
    myCreatedWidget  = 0 ;
    myLayout         = 0 ;
    mySplitter       = 0 ;
    mySplitterWidget = 0 ;

    // *** NOTHING ELSE : used when the GUI is created with 
    if ( type == GuiForm::FT_MAINWINDOW_ONLY ) {
      // nothing else to do

    }
    // *** LAYOUT IS PROVIDED
    else if ( layoutBP != 0 ) {
      // widget  *  ISSUE NOT SOLVED: DOES NOT RESIZE CORRECTLY (25/11/2013)
      nameStr.sprintf( "%s-CENTRAL-WIDGET" , CLASS_NAME );
      myCreatedWidget = new QWidget( this );
      myCreatedWidget->setObjectName(nameStr);
      setCentralWidget( myCreatedWidget );
      // layout
      myLayout = new GuiLayout( form , myCreatedWidget , *layoutBP , CLASS_NAME ) ;
      MscDg::trace( CLASS_NAME , "GuiMainWindowOfForm()" , "CentralWidget %s  Layout %d is present %d" ,
                   GuiItem::objectName( centralWidget() ) , layoutBP->myId , form.hasGuiItem( layoutBP->myId ) );
      // splitter
      if ( splitterBP != 0 ) {
        mySplitter = new GuiSplitter( form , myCreatedWidget , *splitterBP ) ;
        myLayout->addWidget( mySplitter , 1 , 1 );
      }
    }
    // *** SPLITTER IS PROVIDED
    else if ( splitterBP != 0 ) {
      mySplitter = new GuiSplitter( form , this , *splitterBP );
      setCentralWidget( mySplitter->getWidget() );
    }
    // *** VERTICAL SPLITTER
    else { 
      // splitter
      nameStr.sprintf( "%s-SPLITTER" , CLASS_NAME );
      mySplitterWidget = new QSplitter( Qt::Vertical , this );
      mySplitterWidget->setObjectName( nameStr );
      mySplitterWidget->setChildrenCollapsible(false);
      setCentralWidget( mySplitterWidget );
      MscDg::trace( CLASS_NAME , "GuiMainWindowOfForm()" , "CentralWidget %s  Splitter" ,
                   GuiItem::objectName(centralWidget()) );
    }
  }
  ~GuiMainWindowOfForm()
  {
    MscDg::error( CLASS_NAME , "~GuiMainWindowOfForm()" , "called" );
  }
  bool customWhatsThis() const
  {
    return GuiMisc::enterWhatsThisMode( this , myForm.getName() );
  }
  void showEvent( QShowEvent * e )
  {
    QMainWindow::showEvent( e );
    myForm.messageFromBaseForm( GuiEvent::ET_SHOW );
  }
  void resizeEvent( QResizeEvent *e )
  {
    QMainWindow::resizeEvent( e );  
    myForm.messageFromBaseForm( GuiEvent::ET_RESIZE );
  }
  void hideEvent( QHideEvent * e ) 
  {
    myForm.messageFromBaseForm( GuiEvent::ET_HIDE );
    QMainWindow::hideEvent( e );
  }
  void closeEvent( QCloseEvent * e )
  {
    myForm.storeSizeLocationOfForm();
    if ( myForm.messageFromBaseForm( GuiEvent::ET_CLOSE ) == false ) {
      e->ignore();
    }
  }
  void destroy( bool destroyWindow , bool destroySubWindows ) 
  {
    myForm.messageFromBaseForm( GuiEvent::ET_DESTROY );  
    QMainWindow::destroy( destroyWindow , destroySubWindows );
  }
  void mousePressEvent( QMouseEvent * e )
  {
    if ( myForm.baseMousePressEvent(e) == false ) {
      QMainWindow::mousePressEvent(e);
    }
  }
  void keyPressEvent( QKeyEvent * e )
  { 
    if ( myForm.formKeyPressEvent(e) == false ) {
      QMainWindow::keyPressEvent(e) ;
    }
  }
  void keyReleaseEvent( QKeyEvent * e )
  { 
    if ( myForm.formKeyReleaseEvent(e) == false ) {
      QMainWindow::keyReleaseEvent(e) ;
    }
  }
public :
  // used by the caller
  QWidget     * myCreatedWidget  ;
  GuiLayout   * myLayout         ;
  GuiSplitter * mySplitter       ;
  QSplitter   * mySplitterWidget ;
private:
  GuiForm     & myForm           ;
} ;
const char * GuiMainWindowOfForm::CLASS_NAME = "GuiMainWindowOfForm";


//------------------------------------------------// 
//     Creation of a GuiForm                      //
//------------------------------------------------// 

const char              * GuiForm::CLASS_NAME  = "GuiForm" ;
GuiForm::Interface      * GuiForm::myInterface = 0         ;
int                       GuiForm::myApplicationFormat     ;


GuiForm::GuiForm( const CreateInfo & createInfo  ,
                  GuiForm       * teamLeader   ,
                  GuiScreen     * screen       )
  : GuiWidgetGroup(GuiTeam::TP_FORM,createInfo.myId) // not added at this stage
{
  static const char * METHOD_NAME = "GuiForm()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "created with dialog" );

  // initialize
  mySameTypeCreationIndex = 0    ;
  myBeingDeleted      = false    ;
  myShowEventHappened = true     ; // might not always been set...
  myGuiTabWidget      = 0        ;
  myCurrentPageHolder = 0        ;
  myTeamLeader        = 0        ; // see below 'setTeamLeader()'
  myScreen            = 0        ; // set below 'setScreen()'
  myName              = createInfo.myName ;
  myDialog            = 0        ;
  myMainWindow        = 0        ;
  myProgressBar       = 0        ;
  myType              = createInfo.myType ;
  myIsFirstPopUp      = true     ;
  myPopupMenu         = 0        ;
  myTopWidget         = 0        ;
  myTimer             = 0        ;

  // crash issue
  //  if ( myType == GuiForm::FT_MAINWINDOW_ONLY ) { myType = GuiForm::FT_MAINWINDOW_KEEP ; }

  // *** create the top widget ***
  QWidget * parentOfForm = teamLeader ? teamLeader->getForm() : 0 ;
  Qt::WindowFlags flags = Qt::Widget ; // same as 0.
  QWidget * form = 0 ;
  
  switch ( myType ) {
    // *** FORM IS CREATED *** //
  case GuiForm::FT_DIALOG_ONLY    :
  case GuiForm::FT_DIALOG_KEEP    :
  case GuiForm::FT_DIALOG_DESTROY :
    {
      Qt::WindowFlags flags = Qt::WindowFlags();
      if ( myType == GuiForm::FT_DIALOG_DESTROY ) { /** flags |= Qt::WDestructiveClose ; **/ }
      myDialog = new GuiDialogOfForm( *this                  ,
                                      parentOfForm           ,
                                      createInfo.mySplitterBP ,
                                      createInfo.myLayoutBP   ,
                                      flags                  ) ;
      // values ??? needed ????
      if ( myType != GuiForm::FT_DIALOG_ONLY ) { 
        myTopWidget = myDialog ;
      }    
      form = myDialog ;
    } break; 
    // *** FORM IS CREATED *** //
  case GuiForm::FT_MAINWINDOW_ONLY    :
  case GuiForm::FT_MAINWINDOW_KEEP    :
  case GuiForm::FT_MAINWINDOW_DESTROY :
    {
      Qt::WindowFlags flags = Qt::WindowFlags();
      // show it as a dialog if it's not a top-level
      if ( parentOfForm != nullptr ) { flags |= Qt::Dialog ; }
      if ( myType == GuiForm::FT_MAINWINDOW_DESTROY ) { /** flags |= Qt::WDestructiveClose ; **/ }
      myMainWindow = new GuiMainWindowOfForm( *this                  ,
                                              parentOfForm           ,
                                              createInfo.mySplitterBP ,
                                              createInfo.myLayoutBP   ,
                                              flags                  ,
                                              myType                 ) ;
      // just create the main window 
      if ( myType != GuiForm::FT_MAINWINDOW_ONLY ) { 
        myTopWidget = myMainWindow->centralWidget() ;
      }
      form = myMainWindow ; 
    } break;
  default :
    MscDg::fatal( CLASS_NAME , METHOD_NAME , "Type %d not considered" , myType );
  }

  // name
  if ( createInfo.myName != 0 ) {
    form->setObjectName( createInfo.myName );
  }
  if ( myName.isEmpty() == true ) {
    myName = GuiUtl::getObjectName(form);
  }
  // title
  if ( createInfo.myTitle != 0 ) { 
    form->setWindowTitle( createInfo.myTitle );
  }
  // icon
  if ( myMainWindow != 0 ) {
      showAppIcon( myMainWindow->statusBar() );
  }
  if ( createInfo.myIcon  != 0 ) { 
    myIconName = createInfo.myIcon ;
    updateIcon();
  }
  else {
    showAppIcon( form );
  }
  // icon text
  if ( createInfo.myIconText != 0 ) { 
    form->setWindowIconText( createInfo.myIconText ); // deprecated
  }
  // tooltip
  if ( createInfo.myToolTip != 0 ) { 
    form->setToolTip( createInfo.myToolTip );
  }
  // size
  if ( createInfo.mySizesBP != 0 ) {
    GuiItem::setSizes( form , createInfo.mySizesBP , true );
  }

  // update aspect (generally created by Qt Designer)
  bool updateAspect   = false ;
  // add to the team or the screen
  if ( teamLeader != 0 ) {
    setTeamLeader( teamLeader , updateAspect );
  }
  else if ( screen != 0 ) {
    setScreen( screen , updateAspect ) ;
  }
  else if ( GuiDisplay::instance() != 0 ) {
    setScreen( GuiDisplay::instance()->getDefaultScreen() , updateAspect ) ;
  }
}


void GuiForm::finishAspect( GuiItem::SizesCreateInfo * size , bool doRetrieveSize )
{
  static const char * METHOD_NAME = "finishAspect()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Size %d" , size );
  // resize
  if ( size != 0 ) {
    GuiItem::setSizes( getForm() , size , true );
  }
  else if ( doRetrieveSize == true ) {
    retrieveSizeOfForm();
  }
  // default button
  GuiUtl::removeDefaultButton( getForm() );
  // WAS used in "vqBackupProjectForm"
  adjustFormSize(); 
  // polish
  // getForm()->clearWState( Qt::WState_Polished );  //  setAttribute( Qt::WA_WState_Polished );
  getForm()->ensurePolished();
}


void GuiForm::updateFont()
{
  // update main window
  if ( myMainWindow != 0 && myFormatHint.myFontPercentage > 1.0f ) {
    //
    QWidget * w1 = myMainWindow->statusBar();
    QFont font1( w1->font() );
    font1.setPointSizeF( myPointSize * myFormatHint.myFontPercentage );
    w1->setFont( font1 );
    //
    QWidget * w2 = myMainWindow->menuBar() ;
    QFont font2( w2->font() );
    font2.setPointSizeF( myPointSize * myFormatHint.myFontPercentage );
    w2->setFont( font2 );
  }  
}



void GuiForm::setAcceptDrops( bool b )
{
  if ( myMainWindow != 0 ) {
    myMainWindow->setAcceptDrops(b);
  }
}


void GuiForm::setMinimumSize( int width , int height )
{
  getForm()->setMinimumSize( QSize( width , height ) );
}




void GuiForm::setIconText( const char * iconText )
{
  if ( myDialog != 0 ) {
    myDialog->setWindowIconText( iconText );
  }
}




void GuiForm::setIconName( const char * iconName )
{
  if ( iconName == 0 ) {
    myIconName.clear();
    QWidget * w = myDialog ;
    if ( w == nullptr ) { w = myMainWindow ; }
    showAppIcon( w );
  }
  else {
    myIconName = iconName ;
    updateIcon();
  }
}


void GuiForm::showAppIcon( QWidget * w )
{
  // icon to consider
  QString iconName = Defs::getAppName( Defs::APP_ICON );
  if ( iconName.isEmpty() == true ) { return ; }
  // get the icon
  QIcon icon = GuiUtl::getIcon( iconName , myFormatHint.myPixmapPercentage );
  // QStatusBar
  if ( w->inherits("QStatusBar") == true ) {
      QLabel * label = new QLabel();
      label->setObjectName("StatusBarApplicationIcon");
      label->setWindowIcon(icon);
      // tooltip
      QString toolTip = Defs::getAppName( Defs::APP_TOOLTIP );
      if ( iconName.isEmpty() == false ) {
          label->setToolTip(toolTip);
      }
      // add it to the statusbar
      dynamic_cast<QStatusBar*>(w)->addWidget(label,0);
  }
  // QDialog
  else if ( w->inherits("QDialog") == true ) {
    dynamic_cast<QStatusBar*>(w)->setWindowIcon( icon );
  }
  // QMainWindow
  else if ( w->inherits("QMainWindow") == true ) {
    dynamic_cast<QStatusBar*>(w)->setWindowIcon( icon );
  }
}


void GuiForm::updateIcon()
{
  if ( myIconName.isEmpty() == false ) {
    if ( myDialog != 0 ) {
      myDialog->setWindowIcon( GuiUtl::getIcon( myIconName , myFormatHint.myPixmapPercentage ) );
    }
    else if ( myMainWindow != 0 ) {
      myMainWindow->setWindowIcon( GuiUtl::getIcon( myIconName , myFormatHint.myPixmapPercentage ) );
    }
  }
}


void GuiForm::setTeamLeader( GuiTeam * teamLeader , bool updateAspect )
{
  static const char * METHOD_NAME = "setTeamLeader()" ;
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME , "UpdateAspect %d" , updateAspect );
  // add to team leader
  myTeamLeader = teamLeader ;
  myFormatHint = myTeamLeader->getFormatHint() ;
  myTeamLeader->addGuiTeam( this , true );
}


void GuiForm::reparentForm( GuiForm * newOne )
{
  static const char * METHOD_NAME = "reparentForm()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "TeamLeader %d => New %d" , myTeamLeader , newOne );

  // if a change occurred...
  if ( myTeamLeader != newOne ) {
    // detach it
    if ( myTeamLeader != 0 ) {
      myTeamLeader->addGuiTeam( this , false );
    }
    // keep the new 
    myTeamLeader = newOne ;
    // attach it
    if ( myTeamLeader != 0 ) {
      myTeamLeader->addGuiTeam( this , true );
      getForm()->setParent( newOne->getForm() , Qt::Dialog );
    }
  }
}



void GuiForm::setScreen( GuiScreen * screen , bool updateAspect )
{
  static const char * METHOD_NAME = "setScreen()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Screen %s UpdateAspect %d" , GuiUtl::getString(screen->getName()) , updateAspect );
  // add to screen
  myScreen     = screen ;
  myFormatHint = myScreen->getFormatHint() ;
  myScreen->addGuiTeam( this , true );
}




bool GuiForm::messageFromBaseForm( GuiEvent::EventType e )
{
  static const char * METHOD_NAME = "messageFromBaseForm()" ;

  // message is used to grt the answer of the user
  bool userAnswer = true ;
  GuiEvent * guiEvent = 0 ;
  
  switch ( e ) {
  case GuiEvent::ET_SHOW :
    {
      myShowEventHappened = true ;
      guiEvent = new GuiEvent( 0 , GuiEvent::ET_SHOW , GuiItem::ID_FORM );
      guiEvent->setBool(true);
      // if ( myTimer != 0 ) { myTimer->start(); }
      receiveEvent( *guiEvent );    
    } break ;
  case GuiEvent::ET_HIDE : 
    {
      guiEvent = new GuiEvent( 0 , GuiEvent::ET_HIDE , GuiItem::ID_FORM );
      guiEvent->setBool(true);
      receiveEvent( *guiEvent );    
      myShowEventHappened = false ;
    } break ;
  case GuiEvent::ET_RESIZE :
    {
      guiEvent = new GuiEvent( 0 , GuiEvent::ET_RESIZE , GuiItem::ID_FORM );
      guiEvent->setBool(true);
      receiveEvent( *guiEvent );
    } break;
  case GuiEvent::ET_CLOSE :
    {
      guiEvent = new GuiEvent( 0 , GuiEvent::ET_CLOSE , GuiItem::ID_FORM );
      guiEvent->setBool(true);
      if ( myTimer != 0 ) { myTimer->stop() ; }
      receiveEvent( *guiEvent );
    } break ;
    case GuiEvent::ET_DESTROY :
    {
      guiEvent = new GuiEvent( 0 , GuiEvent::ET_DESTROY , GuiItem::ID_FORM );
      guiEvent->setBool(true);
      receiveEvent( *guiEvent );
    } break ;
  }

  // the answer of the user
  if ( guiEvent != 0 ) { userAnswer = guiEvent->getBool(); }
  delete guiEvent ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "'%s'  Event %d  UserAnswer %d" , getName() , e , userAnswer );
  return userAnswer ;
}



GuiForm::~GuiForm()
{
  static const char * METHOD_NAME = "~GuiForm()" ;
  myBeingDeleted  = true ;
  MscDg::trace( CLASS_NAME , METHOD_NAME );
  // page holders
  std::vector< GuiPageHolder * >::iterator iter ;
  while ( (iter = myPageHolders.begin()) != myPageHolders.end() ) {
    GuiPageHolder * pageHolder = *iter;
    // the destructor will remove the page holder from the list
    delete pageHolder ;
    // remove it from the list
    myPageHolders.erase( iter );
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "End" ) ;
}


void GuiForm::setTimer( GuiTimer * t )
{
  static const char * METHOD_NAME = "setTimer()" ;
  MscDg::check( CLASS_NAME , METHOD_NAME , (myTimer == 0) , "Timer already present" );
  myTimer = t ;
}


int GuiForm::getHeightOfTheTopFrame()
{
  // ISSUE: it has to be determined.
  return 30 ; // was HEIGHT_OF_THE_TOPFRAME ;
}


bool GuiForm::centerFormOnItem( int itemId )
{
  static const char * METHOD_NAME = "centerFormOnItem()" ;
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME , "Item %d" , itemId );
  QString outCome ;
  
  // find out where to focus on. If there is no widget,
  // let's focus on the active window 
  QWidget * focusWidget = getWidget( itemId , false );
  
  // test: center the dialog on the default button
  if ( focusWidget != 0 ) {
    outCome.sprintf( "Centered on widget '%s'" , GuiItem::objectName(focusWidget) );
    // take the default button into account
    QRect focusGeometry = focusWidget->geometry() ;
    // where the cursor is
    QPoint targetCenter( QCursor::pos() - focusGeometry.center() ) ;
    targetCenter.setY( targetCenter.y() - getHeightOfTheTopFrame() );
    // rectangle of the dialog box
    QRect targetRect( targetCenter , QSize( getForm()->geometry().width() , getForm()->geometry().height() ) );
    // check it's inside the window. Correct if needed.
    QRect screenGeometry = qApp->desktop()->screenGeometry( QCursor::pos() ) ;
    // debug
    if ( dbOn == true ) {
      GuiUtl::print( "    Left %d  Geom %d"    , targetRect.left()   , screenGeometry.left()   );
      GuiUtl::print( "    Right %d  Geom %d"   , targetRect.right()  , screenGeometry.right()  );
      GuiUtl::print( "    Top %d  Geom %d"     , targetRect.top()    , screenGeometry.top()    );
      GuiUtl::print( "    Bottom  %d  Geom %d" , targetRect.bottom() , screenGeometry.bottom() );
    }
    int dx      = 0 ;
    int dy      = 0 ;
    if ( targetRect.left()   < screenGeometry.left()   ) {
      dx = - targetRect.left()   + screenGeometry.left() ;
    }
    if ( targetRect.right()  > screenGeometry.right()  ) {
      dx = - targetRect.right()  + screenGeometry.right() ;
    }
    if ( targetRect.bottom() > screenGeometry.bottom() ) {
      dy = - targetRect.bottom() + screenGeometry.bottom() ;
    }
    if ( targetRect.top()    < screenGeometry.top()    ) {
      dy = - targetRect.top()    + screenGeometry.top() ;
    }
    // move the window. 
    if ( dbOn == true ) {
      GuiUtl::print( "    RESULT 1 " );
      GuiUtl::print( "    dx%d  dy%d" , dx , dy );
    }
    targetRect.translate( dx , dy );
    getForm()->move( targetRect.topLeft() );
  }
  // center on the active window.
  else if ( qApp != 0 && qApp->activeWindow() != 0 && qApp->activeWindow() != getForm() ) {
    outCome.sprintf( "Centered on window '%s'" , GuiItem::objectName(qApp->activeWindow()) );
    QRect targetRect = qApp->activeWindow()->geometry();
    QPoint targetCenter( (targetRect.left() + targetRect.right() ) / 2  ,
                         (targetRect.top()  + targetRect.bottom()) / 2  );
    QRect rect = getForm()->geometry();
    targetCenter -= QPoint( rect.width() / 2 ,  rect.height() / 2 );
    getForm()->move( targetCenter );
  }
  
  // debug
  if ( dbOn == true ) {
    GuiUtl::print( "  =====> %s" , GuiUtl::getString(outCome) );
  }
  return (outCome.isEmpty()==false);
}



void GuiForm::setTitle( const QString & title )
{
  if ( myDialog != 0 ) {
    myDialog->setWindowTitle( title );
  }
  else if ( myMainWindow != 0 ) {
    myMainWindow->setWindowTitle( title );
  }
}


bool GuiForm::isFormShown() const
{
  if ( myDialog != 0 ) {
    return myDialog->isVisible();
  }
  else if ( myMainWindow != 0 ) {
    return  myMainWindow->isVisible();
  }
  else {
    return false;
  }
}


void GuiForm::raiseForm( bool mustBeShown )
{
  if ( mustBeShown == true ) {
    if ( isFormShown() == true ) {
      showForm( myDialog != 0 && myDialog->isModal() == true );
    }
  }
  else {
    showForm( false );
  }
}


bool GuiForm::isFormModal() const
{
  return (myDialog != 0 && myDialog->isModal() == true);
}


void GuiForm::setFormModal( bool b )
{
  if ( myDialog != 0 ) { 
    myDialog->setModal(b);
  }
}


void GuiForm::adjustFormSize()
{
  getForm()->adjustSize();
}


bool GuiForm::showForm( bool isModal )
{
  if ( myDialog != 0 ) {
    if ( myDialog->isVisible() == true ) {
      GuiUtl::raise( myDialog );
      return true ;
    }
    else if ( isModal == true ) {
      return (myDialog->exec() == QDialog::Accepted);
    }
    else {
      myDialog->show();
      return true ;
    }
  }
  else if ( myMainWindow != 0 ) {
    if ( myMainWindow->isVisible() == false ) {
      myMainWindow->show();
    }
    if ( myMainWindow->isMinimized() == true ) {
      Qt::WindowStates state = myMainWindow->windowState() ;
      myMainWindow->setWindowState( state & ~Qt::WindowMinimized | Qt::WindowActive ); 
    }
    GuiUtl::raise( myMainWindow );
    return true ;
  }
  else {
    return false ;  
  }
}


void GuiForm::hideForm( bool acceptIt )
{
  // stop tracking
  // **** trackingWhenTheCursorMovesOnThePage(); 
  // hide
  if ( myDialog != 0 ) {
    myDialog->close(); 
    /* PROTECTED ...
    if ( acceptIt == true ) {
      myDialog->accept();
    }
    else {
      myDialog->reject();
    }
    */
  }
  else if ( myMainWindow != 0 ) {
    myMainWindow->close();
  }
}

#if 0
void GuiForm::propagateDisplayMessage( GuiDisplayMessage & msg )
{
  static const char * METHOD_NAME = "propagateDisplayMessage()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "MsgId %d IntSize %ld" , msg.myMessageId , msg.myInts.size() );

  switch( msg.myMessageId ) 
    {
    case GuiDisplayMessage::MSG_DELETE_POPUP_MENU :
      {
        deletePopupMenu() ;
      } break ;
    case GuiDisplayMessage::MSG_CLOSE_FORMS :
      {
        if ( msg.myInts.find(myId) == msg.myInts.end() ) {
          doPopDown();
        }
        else {
          showForm( false );
        }
      } break ;
    }
}
#endif


// Implementation is protected .
QMainWindow * GuiForm::getMainWindow() const 
{
  return myMainWindow ; 
}


// Implementation is protected .
QDialog * GuiForm::getDialog() const 
{
  return myDialog ;
}


QWidget * GuiForm::getForm() const 
{
  if ( myMainWindow != 0 ) {
    return myMainWindow ;
  }
  else if ( myDialog != 0 ) {
    return myDialog ;
  }
  else {
    MscDg::error( CLASS_NAME , "getForm()" , "no widget is available" ) ;
    return 0 ;
  }
}


//-------------------------------------------------------------------------------------//
//                             Services provided by the form                           //
//-------------------------------------------------------------------------------------//


bool GuiForm::alignViewWithSource( GuiForm * source , int & x , int & y , int & w , int & h )
{
  static const char * METHOD_NAME = "alignViewWithSource()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME );

  // source area
  if ( source == 0 ) return false ;
  if ( source->getMainWindow() == 0 ) return false ;
  if ( getMainWindow() == 0 ) return false ;
  QMainWindow * sourceMain = source->getMainWindow() ;
  QMainWindow * targetMain = getMainWindow() ;
  QWidget   * sourceWidget = sourceMain->centralWidget() ;
  QWidget   * targetWidget = targetMain->centralWidget() ;

  int widthOfFrame = (targetMain->frameGeometry().width() - targetWidget->width()) / 2;

  // find the size and location.
  int sourceMenuBarHeight = sourceMain->menuBar()->height() ;
  int targetMenuBarHeight = targetMain->menuBar()->height() ;
  x = sourceMain->x()  
    + sourceMain->frameGeometry().width() ;
  y = sourceWidget->geometry().y() // location inside the parent
    + sourceMain->geometry().y()   // parent => coordinate from the top
    - targetWidget->geometry().y() // location of the target inside its parent.
    - targetMenuBarHeight          // less the height of the target's menubar
    - widthOfFrame                 // less the width of the Frame
    ; // - (targetMain->geometry().y() - targetMain->y()) ;
  if ( x < 0 ) x = 0 ;
  targetMain->move( x , y ) ;

  // width of the central widget stays the same
  w = targetWidget->frameGeometry().width()  ;

  // change height of the central widget: consider the toolbar heights
  int targetToolBarHeight = targetMain->height() - targetWidget->height() ;
  int sourceToolBarHeight = sourceMain->height() - sourceWidget->height() ;
  h = sourceMain->height() + ( targetToolBarHeight - sourceToolBarHeight ) ;

  targetMain->resize( w , h );
  return true ;
}


void GuiForm::setStatusMessage( QString msg )
{
  static const char * METHOD_NAME = "setStatusMessage()" ;  
  if ( myMainWindow == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "no main window" );
    return ;
  }
  myMainWindow->statusBar()->showMessage( msg );
}


void GuiForm::addMessage( const QString & , bool isPermanent , bool doFlush )
{
  static const char * METHOD_NAME = "addMessage()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "not implemented" );
}


void GuiForm::getMessages( QString & )
{
  static const char * METHOD_NAME = "getMessages()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "not implemented" );
}


MscDg::UserAnswer GuiForm::messageBox( QString         message ,
                                       QString         title   ,
                                       int             numberOfButtons ,
                                       int             defaultButton   ,
                                       MscDg::UserCallbackType messageBoxType ,
                                       const char    * btn1 ,
                                       const char    * btn2 ,
                                       const char    * btn3 ,
                                       int             escapeButton )
{
  static const char * METHOD_NAME = "messageBox()" ;
  
  // *** check ***
  if ( numberOfButtons < 1 ) { numberOfButtons = 1 ; } // should never happen
  if ( numberOfButtons > 3 ) { numberOfButtons = 3 ; } // should never happen
  if ( defaultButton < 1 || defaultButton > numberOfButtons ) { defaultButton = 1 ; }
  if ( escapeButton  < 1 || escapeButton  > numberOfButtons ) { escapeButton  = numberOfButtons ; }
  // *** define the default icon and the button labels ***
  if ( btn2 == 0 ) { btn2 = "No"     ; }
  if ( btn3 == 0 ) { btn3 = "Cancel" ; }
  QMessageBox::Icon icon = QMessageBox::NoIcon ;
  switch ( numberOfButtons ) {
  case 1 :
    if ( btn1 == 0 ) { btn1 = "Ok" ; }
    // by default, information
    if ( messageBoxType == MscDg::CALLBACK_DIALOG ) {
      icon = QMessageBox::Information ;
    }
    break ;
  case 2 :
  case 3 :
    if ( btn1 == 0 ) { btn1 = "Yes" ; }
    // by default, question
    if ( messageBoxType == MscDg::CALLBACK_DIALOG ) {
      icon = QMessageBox::Question ;
    }
    break ;
  }
  // take into account the icon that is provided
  if ( icon == QMessageBox::NoIcon ) {
    switch ( messageBoxType ) {
    case MscDg::CALLBACK_FATAL_BOX    :
    case MscDg::CALLBACK_ERROR_BOX    : icon = QMessageBox::Critical    ; break ;
    case MscDg::CALLBACK_WARNING_BOX  : icon = QMessageBox::Warning     ; break ;
    case MscDg::CALLBACK_INFO_BOX     : icon = QMessageBox::Information ; break ;
    case MscDg::CALLBACK_QUESTION_BOX : icon = QMessageBox::Question    ; break ;
    }
  }
  /* ** create the dialog box and add the buttons (titles of the buttons might be provided) ** */
  QWidget * parent = getForm(); // getTopWidget();
  // if ( parent != 0 && parent == QApplication::activeWindow() ) {
  parent = QApplication::focusWidget();
  //}
  QMessageBox mb( icon , title , message , QMessageBox::NoButton , parent );
  QPushButton * pbn1 = (numberOfButtons >= 1) ? mb.addButton( btn1 , QMessageBox::AcceptRole      ) : 0 ;
  QPushButton * pbn2 = (numberOfButtons >= 2) ? mb.addButton( btn2 , QMessageBox::RejectRole      ) : 0 ;
  QPushButton * pbn3 = (numberOfButtons >= 3) ? mb.addButton( btn3 , QMessageBox::DestructiveRole ) : 0 ;
  // *** default & escape buttons ***
  switch ( defaultButton ) {
  case 1 : mb.setDefaultButton( pbn1 ); break;
  case 2 : mb.setDefaultButton( pbn2 ); break;
  case 3 : mb.setDefaultButton( pbn3 ); break;
  }
  QAbstractButton * escapePbn = 0 ;
  switch ( escapeButton ) {
  case 1 : mb.setEscapeButton( escapePbn = pbn1 ); break;
  case 2 : mb.setEscapeButton( escapePbn = pbn2 ); break;
  case 3 : mb.setEscapeButton( escapePbn = pbn3 ); break;
  }
  // *** center the dialog box
  // TODO
  // *** show and get the answer ***
  mb.exec();
  QAbstractButton * button = mb.clickedButton();
  if ( button == 0 ) { button = escapePbn ; }
  // answer
  MscDg::UserAnswer answer = MscDg::ANS_YES ;
  if ( button == pbn1 ) { answer = MscDg::ANS_YES    ; }
  if ( button == pbn2 ) { answer = MscDg::ANS_NO     ; }
  if ( button == pbn3 ) { answer = MscDg::ANS_CANCEL ; }
  return answer ;
}



//-------------------------------------------------------------------------------------//
//                             File access                                             //
//-------------------------------------------------------------------------------------//


QString GuiForm::getOpenFileName( const QString & directoryOrFile ,
                                  const QString & types ,
                                  const QString & caption )
{
  QString dirString = directoryOrFile ;
  if ( dirString.isEmpty() == true ) { dirString = GuiUtl::getDirectory(); }
  QString s =   QFileDialog::getOpenFileName( getForm()           , // parent
                                              caption             , // caption
                                              dirString           , // dir
                                              types                 // filter
                                            );
  return s ;
}


std::vector< QString > GuiForm::getOpenFileNames( const QString & directoryOrFile ,
                                                  const QString & types   ,
                                                  const QString & caption )
{
  QString dirString = directoryOrFile ;
  if ( dirString.isEmpty() == true ) { dirString = GuiUtl::getDirectory(); }
  QStringList s =   QFileDialog::getOpenFileNames( getForm()            ,
                                                   caption              ,
                                                   dirString            , // directory
                                                   types                  // filter
                                                 );
  std::vector< QString > values ;
  for ( auto iter = s.begin() ; iter != s.end() ; ++iter ) {
    values.push_back( *iter );
  }
  return values ;
}
  

QString GuiForm::getSaveFileName( const QString & directoryOrFile ,
                                  const QString & types           ,
                                  const QString & caption         ,
                                  const char    * extension       )
{
  QString fileName ;
  QString dirString = directoryOrFile ;
  if ( dirString.isEmpty() == true ) { dirString = GuiUtl::getDirectory(); }
  QString s =   QFileDialog::getSaveFileName( getForm()           ,
                                              caption             ,
                                              dirString           ,
                                              types
                                            );
  // add extension if missing
  GuiUtl::stripString(s);
  if ( s.isEmpty() == false ) {
    fileName = s ;
    // UNIX type
    fileName.replace('\\','/') ;
    // extension
    if ( extension != 0 ) {
      // add missing if needed.
      bool isMissing = true ;
      int strLength  = fileName.length() ;
      int extLength  = ::strlen(extension) ;
      if ( (strLength > extLength) &&
           (::strcmp(GuiUtl::getString(fileName) + (strLength - extLength) , extension) != 0) ) {
        fileName += "." ;
        fileName += extension ;
      }
    }
  }
  return fileName ;
}


QString GuiForm::getExistingDirectory( const QString & directoryOrFile ,
                                       const QString & caption )
{
  QString dirString = directoryOrFile ;
  if ( dirString.isEmpty() == true ) { dirString = GuiUtl::getDirectory(); }
  QString s =   QFileDialog::getExistingDirectory( getForm()                ,
                                                   caption                  ,
                                                   dirString                ,
                                                   QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks
                                                  );
  GuiUtl::stripString(s);
  return s ;
}



//-------------------------------------------------------------------------------------//
//                             Progress                                                //
//-------------------------------------------------------------------------------------//


/** more elaborated. The 'Cancel' is possible */
void GuiForm::indicateProgressStart( bool stopButton , const char * message , const char * title )
{
  static const char * METHOD_NAME = "indicateProgressStart()" ;
  // create if needed
  if ( myProgressBar == 0 ) {
    myProgressBar = new GuiProgressBar( this );
  } 
  MscDg::trace( CLASS_NAME , METHOD_NAME , myProgressBar ? "implemented" : "not created" );
  myProgressBar->indicateProgressStart( stopButton , message , title );
}


bool GuiForm::indicateProgress( float percentage , const char * message )
{
  static const char * METHOD_NAME = "indicateProgress()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , myProgressBar ? "implemented" : "not created" );
  if ( myProgressBar != 0 ) {
    return myProgressBar->indicateProgress( percentage , message );
  }
  else {
    return true;
  }
}


void GuiForm::indicateProgressEnd( const char * message )
{
  static const char * METHOD_NAME = "indicateProgressEnd()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , myProgressBar ? "implemented" : "not created" );
  if ( myProgressBar != 0 ) {
    myProgressBar->indicateProgressEnd( message ); }
}



//-------------------------------------------------------------------------------------//
//                             Management of the Page Holders                          //
//-------------------------------------------------------------------------------------//




GuiPageHolder * GuiForm::createPageHolder( const GuiPageHolder::CreateInfo & createInfo , int parentId , GuiWidgetGroup::BoldType isBold ,
                                               int dataId , int row , int col )
{
  GuiLayout  * guiLayout = 0 ;
  QWidget  *        parent = myGetWidgetAndLayout( parentId , guiLayout );
  GuiPageHolder * widget = new GuiPageHolder( *this , parent , createInfo ) ;
  if ( guiLayout != 0 ) { guiLayout->addWidget( widget , row , col ); }
  if ( isBold != GuiWidgetGroup::BOLD_IGNORED ) { widget->setFontIsBold( isBold == GuiWidgetGroup::BOLD_YES ); }
  widget->setDataId(dataId);
  // it's already added by the constructor and it's the active one
  // (no need to call "addPageHolderToList")
  // add it 
  return widget ;
}


int GuiForm::getPageHolderId( QWidget * widget ) const
{
  // find the page with this widget
  for ( auto iter = myPageHolders.begin() ; iter != myPageHolders.end() ; ++iter ) {
    GuiPageHolder * pageHolder = *iter; 
    if ( pageHolder->getWidget() == widget ) {
      return pageHolder->getId();
    }
  }
  // not present
  MscDg::error( CLASS_NAME , "getPageHolderId()" , "Widget '%s' is not found" , GuiItem::objectName(widget) );
  return 0 ;  
}


QWidget * GuiForm::getWidgetOfPageHolder( int id ) const
{
  // find the page with this id
  for ( auto iter = myPageHolders.cbegin() ; iter != myPageHolders.cend() ; ++iter ) {
    GuiPageHolder * pageHolder = *iter; 
    if ( pageHolder->getId() == id ) {
      return pageHolder->getWidget();
    }
  }  
  // not present
  MscDg::error( CLASS_NAME , "getWidgetOfPageHolder()" , "Id:%d is not found" , id );
  return 0 ;
}


bool GuiForm::getPageHolderIsActive( GuiPageHolder * pageHolder ) const
{
  if ( pageHolder == 0 ||  pageHolder->getWidget() == 0 ) { return false ; }
  if ( myGuiTabWidget == 0 ) { return true ; }
  QWidget * w = myGuiTabWidget->getTabWidget()->currentWidget() ;
  if ( pageHolder->getWidget() == w ) {
    return true ;
  }
  else {
    return false ;
  }
  /*
  // pages are in a QTabWidget (one at a time)
  if ( myCurrentPageHolder != 0 ) {
  return ( pageHolder == myCurrentPageHolder ) ;
  }
  else {
  return false ;
  }
  */
}



GuiPageHolder * GuiForm::setActivePageHolder( QWidget * widget )
{
  // find the page with this widget
  for ( auto iter = myPageHolders.begin() ; iter != myPageHolders.end() ; ++iter ) {
    GuiPageHolder * pageHolder = *iter; 
    if ( pageHolder->getWidget() == widget ) {
      myCurrentPageHolder = pageHolder;
      return myCurrentPageHolder ;
    }
  }
  // not present
  MscDg::error( CLASS_NAME , "setActivePageHolder()" , "Widget '%s' is not found" , GuiItem::objectName(widget) );
  return 0 ;
}


bool GuiForm::setActivePageHolder( GuiPageHolder * pageHolder )
{
  // find the page with this widget
  for ( auto iter = myPageHolders.begin() ; iter != myPageHolders.end() ; ++iter ) {
    if ( *iter == pageHolder ) {
      myCurrentPageHolder = pageHolder;
      return true ;
    }
  }
  // not present
  MscDg::error( CLASS_NAME , "setActivePageHolder()" , "Page %d is not found" , pageHolder );
  return false ;
}



bool GuiForm::addPageHolderToList( GuiPageHolder * pageHolder )
{
  static const char * METHOD_NAME = "addPageHolderToList()" ;
  if ( pageHolder == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "pageHolder is null" );
    return false ;
  }
  // find if the page is present
  for ( auto iter = myPageHolders.begin() ; iter != myPageHolders.end() ; ++iter ) {
    if ( *iter == pageHolder ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "PageHolder Id:%d is already owned" , pageHolder->getId() );
      return false ;
    }
  }
  // add the page
  myPageHolders.push_back(pageHolder);
  // update the list of files
  // UNUSED ... updateUserParameters();
  setActivePageHolder(pageHolder);
  return true ;
}


bool GuiForm::removePageHolderFromList( GuiPageHolder * pageHolder )
{
  static const char * METHOD_NAME = "removePageHolderFromList()" ;
  if ( pageHolder == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , " page is null" );
    return false ;
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME ,
               "BeingDeleted:%d Name:'%s' amongst the %d pages" , myBeingDeleted ,
               GuiItem::objectName(pageHolder->getWidget()) , int(myPageHolders.size()) );
  // find if the page is present
  for ( auto iter = myPageHolders.begin() ; iter != myPageHolders.end() ; ++iter ) {
    GuiPageHolder * p = *iter; 
    if ( p == pageHolder ) {
      // remove from the vector
      myPageHolders.erase( iter );
      // update the list of files
      // UNUSED .... updateUserParameters();
      return true ;
    }
  }
  // not present
  MscDg::trace( CLASS_NAME , METHOD_NAME ,
               "PageId:%d Name:'%s' is not found amongst the %d pages" ,
               pageHolder->getId() , GuiItem::objectName(pageHolder->getWidget()) , int(myPageHolders.size()) );      
  return false ;
}



QString GuiForm::getActiveHelpPage()
{
  QString helpPage ;
  if ( myCurrentPageHolder != 0 && myCurrentPageHolder->getActivePage() != 0 ) {
    helpPage = myCurrentPageHolder->getActivePage()->getHelpPage();
  }
  return helpPage ;
}



void GuiForm::showActiveHelpPage( const char * defaultHelpPage )
{
  QString helpPage = getActiveHelpPage();
  if ( helpPage.isEmpty() == true ) {
    helpPage = defaultHelpPage ;
  }
  showHelpPage( helpPage );
}


void GuiForm::showHelpPage( const QString & helpPage )
{
  if ( helpPage.isEmpty() == false ) {
    GuiUtl::launchBrowser( this , helpPage ) ;
  }
  else {
    GuiForm::informationBox( "Sorry, no page help is available." );
  }
}



//-------------------------------------------------------------------------------------//
//                             Event dealt by the form                                 //
//-------------------------------------------------------------------------------------//



bool GuiForm::baseMousePressEvent( QMouseEvent * e )
{
  MscDg::trace( CLASS_NAME , "baseMousePressEvent()" , "Button %d" , e ? e->button() : (-1) );
  bool blockEvent = (e != 0) ;

  // derived class has not dealt with the event
  if ( derivedMousePressEvent(e) == true ) {
    // create default menu if not present
    if ( e == 0 || e->button() == Qt::RightButton ) {
      createPopupMenuId();
    }
    // show it
    if ( (myPopupMenu != 0) && (e == 0 || e->button() == Qt::RightButton) ) {
      myPopupMenu->getPopupMenu()->exec( QCursor::pos() ) ;
    }
  }

  return blockEvent ;
}


void  GuiForm::createPopupMenuId()
{
  MscDg::trace( CLASS_NAME , "createPopupMenuId()" );
  if ( myInterface != 0 && myPopupMenu == 0 ) {
    myPopupMenu = myInterface->createPopupMenuId( this ) ;
  }  
}


void  GuiForm::deletePopupMenu()
{
  MscDg::trace( CLASS_NAME , "deletePopupMenu()" );
  if ( myPopupMenu != 0 ) {
    delete myPopupMenu ;
    myPopupMenu = 0 ;
  }
}



bool GuiForm::formKeyPressEvent( QKeyEvent * e ) 
{
  MscDg::trace( CLASS_NAME , "formKeyPressEvent()" , "Key:%d" , e ? e->key() : (-1) );
  bool blockEvent = false ;

  // the derived class has not implemented and considered the case */
  if ( derivedFormKeyPressEvent( e ) == true ) {
    // send the event to the active(s) page(s)
    for ( auto iter = myPageHolders.begin() ; iter != myPageHolders.end() ; ++iter ) {
      if ( getPageHolderIsActive( *iter ) == true ) {
        (*iter)->pageHolderKeyPressEvent( e );
      }
    }
    blockEvent = false ;
  }
  // nothing
  else if ( e == 0 ) {
    blockEvent = true ;
  }
  // use base class dealing of the event
  else {
    blockEvent = false ;
  }
  return blockEvent ;
}


bool GuiForm::formKeyReleaseEvent( QKeyEvent * e ) 
{
  MscDg::trace( CLASS_NAME , "formKeyReleaseEvent()" , "Key:%d" , e ? e->key(): (-1) );
  bool blockEvent = false ;

  // the derived class has implemented and considered the case */
  if ( derivedFormKeyReleaseEvent( e ) == true ) {
    // send the event to the active(s) page(s)
    for ( auto iter = myPageHolders.begin() ; iter != myPageHolders.end() ; ++iter ) {
      if ( getPageHolderIsActive( *iter ) == true ) {
        (*iter)->pageHolderKeyReleaseEvent( e );
      }
    }
    blockEvent = false ;
  }
  // nothing
  else if ( e == 0 ) {
    blockEvent = true ;
  }
  // use base class dealing of the event
  else {
    blockEvent = false ;
  }
  return blockEvent ;
}


bool GuiForm::transferParameters( int transferType , bool activeHolderOnly , bool activePageOnly , QString & message )
{
  for ( auto iter = myPageHolders.begin() ; iter != myPageHolders.end() ; ++iter ) {
    if ( activeHolderOnly == false || getPageHolderIsActive( *iter ) == true ) {
      if ( (*iter)->transferParameters( transferType , activePageOnly , message ) == false ) {
        return false ;
      }
    }
  }
  return true ;
}


//-------------------------------------------------------------------------------------//
//                             Protected methods                                       //
//-------------------------------------------------------------------------------------//


void GuiForm::refresh()
{
  static const char * METHOD_NAME = "refresh()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "Id %d" , getId() );
  refresh( false , false );
}


void GuiForm::refresh( int id )
{
  static const char * METHOD_NAME = "refresh()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "Id %d Provided Id %d" , getId() , id );
  refresh( false , false );
}


void GuiForm::refresh( bool activeHolderOnly , bool activePageOnly ) 
{
  static const char * METHOD_NAME = "refresh()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "ActiveHolderOnly %d   ActivePageOnly %d" , activeHolderOnly , activePageOnly );
  for ( auto iter = myPageHolders.begin() ; iter != myPageHolders.end() ; ++iter ) {
    if ( activeHolderOnly == false || getPageHolderIsActive( *iter ) == true ) {
      (*iter)->setIsDirty();
      (*iter)->refresh( activePageOnly );
    }
    else {
      (*iter)->setIsDirty();
    }
  }
}


void GuiForm::setIsDirty( int i )
{
  for ( auto iter = myPageHolders.begin() ; iter != myPageHolders.end() ; ++iter ) {
    (*iter)->setIsDirty(i);
  }
}



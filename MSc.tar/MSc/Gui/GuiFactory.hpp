#ifndef GUI_FACTORY_HPP
#define GUI_FACTORY_HPP

#include "guifactory_global.h"

class GUIFACTORYSHARED_EXPORT GuiFactory
{

public:
    GuiFactory();
};

#endif // GUI_FACTORY_HPP

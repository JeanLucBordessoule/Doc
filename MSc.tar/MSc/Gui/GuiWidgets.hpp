#ifndef GUI_WIDGETS_HPP
#define GUI_WIDGETS_HPP


#include <map>
#include <set>
#include <vector>
#include <utility> // pair

//#include "GuiDataDefinitions.hpp"
#include "GuiItem.hpp"
#include "GuiUtilities.hpp"

#include "TypStructure.hpp"

#include <QSlider>
#include <QValidator>
#include <QImage>

class QAbstractButton ;
class QAction         ;
class QActionGroup    ;
class QButtonGroup    ;
class QCheckBox       ;
class QComboBox       ;
class QFrame          ;
class QGroupBox       ;
class QHeaderView     ;
class QKeyEvent       ;
class QLabel          ;
// layout
class QLayout         ;
class QHBoxLayout     ;
class QVBoxLayout     ;
class QGridLayout     ;
//
class QListWidget     ;
class QListWidgetItem ;
class QLineEdit       ;
class QListView       ;
class QMainWindow     ;
class QMenu           ;
class QMenuBar        ;
class QProgressBar    ;
class QProgressDialog ;
class QPushButton     ;
class QRadioButton    ;
class QScrollArea     ;
class QSlider         ;
class QSpinBox        ;
class QSplitter       ;
class QStackedWidget  ;
class QStatusBar      ;
class QTable          ;
class QTabWidget      ;
class QTableWidget    ;
class QTableWidgetItem;
class QTextEdit       ;
class QTimer          ;
class QToolBar        ;




/**************************************************************************************************
 **************************************************************************************************
 *
 * The purpose is to provide facilities related to the Widgets.
 * This file is structured with:the following order:
 *
 *  * UTILITY COMPONENTS  Progress bar, Movie slider, Movie spin box.(does not inherit from "GuiItem")
 *  * ACTION and group of actions
 *  * LAYOUT and GROUPBOX
 *  * BASIC WIDGETS
 *  * TOOLBAR POPUPMENU
 *  * WIDGET GROUP
 *  * TAB , PAGE . DIALOG
 *
 * REMARK:
 * the Widget are either encapsulated or the base class .
 * In order to avoid the distinction (implementation might change)
 * it is recommended to use the method providing access to the Qt widget.
 *
 **************************************************************************************************
 *************************************************************************************************/




/**-------------------------------------------------------
* Encapsulates a QTimer . It avoids to issues with the 
* declaration of the 'QObject' required for the time out slot
*-------------------------------------------------------*/


class GuiTimer : public QObject {
  Q_OBJECT 
public :
  static const char * CLASS_NAME ; 
 // TODO// TODO Signal0 TimeOut ;
  // TODO // TODO SENDERCLASS;
  GuiTimer( QObject * parent , const char * name = CLASS_NAME , int intervalMs = 1000 );
  bool isActive() const ;
  void setIntervalMs( int );
  void start();
  void stop();
protected slots :
  void slotTimeOut();
private :
  void     myCreateTimer() ;
  QString  myName          ;
  QTimer * myTimer         ;
  int      myIntervalMs    ;
};




/**-------------------------------------------------------
* Integer Validator dealing with % or normal values
* MUST derived from "QValidator" as methods are customized
*-------------------------------------------------------*/


class GuiIntValidator : public QValidator {
public:
  static const char * CLASS_NAME ;
  GuiIntValidator( QObject * parent ) ;
  State validateString( QString s , int pos ) ;
  State validate( QString & s, int & pos ) const ;
  // Accessed directly by "GuiMovieSlider"
  int               myValue          ;
  bool              myIsPercent      ;
  QValidator::State myAnswer         ;
  bool              myCanShowPercent ;
};


/**-------------------------------------------------------
* Movie Slider.
* Customizes a QSlider from the management of a movie.
* MUST derived from "QSlider" as "mouseReleaseEvent" is customized
*-------------------------------------------------------*/


class GuiMovieSlider : public QSlider , public GuiItem {

public :
  static const char * CLASS_NAME ;
  // TODO // TODO RECEIVERCLASS ;

  /** map of data dealt by this slider */
  typedef std::map< int , std::pair< int , float > > MapType ;

  /** INTERFACE to receive the events */
  class Interface {
  public :
    // TODO SENDERCLASS ;
   // TODO Signal0 PanelChanged ;
    /** update the map used (owner provides it) */
    virtual int  sliderUpdateMap( MapType & ) = 0 ;
    /** ask the owner to use the information to update its view */
    virtual void sliderUpdateCurrentView( int , bool ) = 0 ;
  } ;

  GuiMovieSlider( GuiTeam & wg , int viewId , QWidget * parent , const char * name ) ;
  void       setInterface( Interface * interFace );
  void       disconnectInterface() { setInterface(0); }
  void       copyMovieMap() ;
  void       mouseReleaseEvent( QMouseEvent * e ) ; // derived from "QSlider"
  QSlider  * getSlider() const { return mySlider ; }

private :

  Interface              * myInterface ;
  MapType                  myMovieMap  ;
  QSlider                * mySlider    ;
};


/**-------------------------------------------------------
* Encapsulated Progress Bar in a status bar.
* Customizes a QProgressBar.
---------------------------------------------------------*/

class GuiForm ;

class GuiProgressBar : public QObject
{
  Q_OBJECT  // needed as there is a slot.

public:
  static const char * CLASS_NAME ;
  GuiProgressBar( QStatusBar * parent ) ;
  GuiProgressBar( GuiForm  * parent ) ;
  ~GuiProgressBar();

  void  indicateProgressStart( bool stopButton=false , const char * message=0 , const char *title=0 );
  bool  indicateProgress( float percentage , const char * message=0 );
  void  indicateProgressEnd( const char * message=0 );

private slots :

  void  slotCancelButton();

private:

  void  myInitialize();

  // parent
  GuiForm         * myGuiForm      ;
  QStatusBar      * myStatusBar    ;
  QWidget         * myWidget       ;
  // created items
  QProgressBar    * myProgressBar  ;
  QProgressDialog * myProgressDlg  ;
  QPushButton     * myCancelButton ;
  // state
  bool              myHasCancel    ;
  bool              myDoProgress   ;
  QString           myMessage      ;
  int               myPercentage   ;
};



/**-------------------------------------------------------
* Movie Spin Box : encapsulates a "QSpinBox" and manages slices of movie.
*-------------------------------------------------------*/

class GuiMovieSpinBox : public QObject , public GuiItem
{
  Q_OBJECT  // needed as there is a slot.

public:
  static const char * CLASS_NAME ;
  // TODO RECEIVERCLASS ;

  GuiMovieSpinBox( GuiTeam & wg , int viewId , GuiMovieSlider * slider , QWidget * parent , const char * name );
  /** same interface as the slider */
  void       setInterface( GuiMovieSlider::Interface * interFace );
  void       disconnectInterface() { setInterface(0); }
  void       copyMovieMap() ;
  /** set the value without sending a message . Returns true if a value has changed */
  bool       setCurrentValue( int );
  QSpinBox * getSpinBox() const { return mySpinBox ; }
protected slots :
  /** callback when a value has changed */
  void    slotSliderValueChanged( int i ) ;
  void    slotValueChanged( int i ) ;
protected:
  int     mapTextToValue( bool * ok ) ;
  QString mapValueToText( int panel ) ;

private :

  QSpinBox                    * mySpinBox        ; // created or provided

  GuiMovieSlider              * mySlider         ;
  GuiMovieSlider::Interface   * myInterface      ;
  GuiIntValidator             * myValidator      ;

  bool                          myConsiderText   ;
  GuiMovieSlider::MapType       myMovieMap       ;
  bool                          myCanShowPercent ;

};



/**-------------------------------------------------------
* GuiMovieTimer encapsulates a QTimer and the related state  for the movie purposes.
* The 'Interface' needs to be provided so it's operational.
*-------------------------------------------------------*/

class GuiMovieTimer : public QObject
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  /** movie commands */
  enum MovieEventType {
    MOVIE_STOPPED  =   0 ,
    MOVIE_START    , // just to inform
    MOVIE_CLEAR    , // clean-up
    MOVIE_NEXT     , // the 3 below use the timer
    MOVIE_PREVIOUS ,
    MOVIE_CYCLE    ,
    SLICE_PREVIOUS =  50 , SLICE_NEXT  , // move 1 slice
    CURSOR_BUSY    = 100 , CURSOR_IDLE , } ; // cursor management

  /** INTERFACE to receive the events */
  class Interface {
  public :
    /** returns 'true' if the action is successful */
    virtual bool derivedMovieEvent( MovieEventType ) = 0 ;
  } ;

  /** constructor */
  GuiMovieTimer( Interface & , QWidget * parent , const char * name ) ;
  ~GuiMovieTimer() ;

  /** commands . Feedback is done with 'Interface' */
  void changeMovieTimerState( MovieEventType ) ;

  /** change the delay value */
  void changeMovieDelay( int );

private slots :

  void slotMovieTimeOut() ;

private :

  bool        myInterfaceMovieEvent( MovieEventType );
  Interface & myInterface ;

protected :

  MovieEventType       myMovieState ;
  int                  myMovieDelay ;
  QTimer             * myMovieTimer ;
  bool                 myIsBusy     ;
} ;



/**************************************************************************************************
 **************************************************************************************************
 ** "Action" and "Group of Actions"
 **************************************************************************************************
 *************************************************************************************************/



class GuiAction : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId        ;
    const char * myName      ;
    // labels
    const char * myText      ;
    const char * myMenuText  ;
    const char * myAccelText ;
    const char * myToolTip   ;
    const char * myIconName  ;
    // miscellaneous
    bool         myIsToggle  ;
  } CreateInfo ;
  GuiAction( GuiTeam & wg , QObject * , const CreateInfo & );
  ~GuiAction() ;
  void updateIcon();
  QAction * getAction() { return myAction ; }

private slots :
  void  slotActivated();

private :
  QAction * myAction ; // provided or created
} ;


class GuiActionGroup : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId        ;
    const char * myName      ;
    // labels
    const char * myText      ;
    const char * myMenuText  ;
    const char * myAccelText ;
    const char * myToolTip   ;
    const char * myIconName  ;
    // miscellaneous
    bool         myIsExclusive     ;
    // actions
    int          myNumberOfActions ;
    const GuiAction::CreateInfo * myActionCreateInfos ;
    // callbacks
    int          myCallbackTypes   ;
  } CreateInfo ;

  GuiActionGroup(  GuiTeam & wg , QWidget * , const CreateInfo & );
  ~GuiActionGroup();
  void updateIcon();
  
  QMenu * getMenu() { return myMenu ; }

  /** set values to the menu */
  void    setAccelText( const char * c );

private slots :
  void slotActivated();
  void slotSelectedAction( QAction* );

private :
  QMenu                   * myMenu            ;
  QActionGroup            * myActionGroup     ; // created if exclusive
  std::vector< GuiAction >  myGuiActionVector ;
} ;



/**************************************************************************************************
 **************************************************************************************************
 ** "ToolBar"   "MenuBar"   "PopupMenu"
 **************************************************************************************************
 *************************************************************************************************/



class GuiWidgetGroup ;
class GuiToolBar : public QObject , public GuiItem
{
  Q_OBJECT // USELESS ?

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId            ;
    const char * myName          ;
    // labels
    const char * myText          ;
    const char * myToolTip       ;
    // parameters
    bool         myIsStretchable ;
    // components
    int          myNumberOfIds   ;
    int        * myIds           ;
    // color
    int          myRed           ;
    int          myGreen         ;
    int          myBlue          ;
    // callbacks
    int          myCallbackTypes ;
  } CreateInfo ;

  /** create the toolbar only if items are visible */
  static bool testIfToolBarIsToBeCreated( GuiWidgetGroup & group , const CreateInfo & ) ;

  GuiToolBar( GuiWidgetGroup & wg , QMainWindow * , const CreateInfo & );
  ~GuiToolBar() {}
  void  updateFont();
  void  updateIcon();
  bool  addItem( GuiItem * );
  void  modifySensitivity( int modifierId );
  bool  modifyVisibility(); // returns 'true' if some items are visible
  int   getNumberOfItems() { return myItems.size() ; }
  QToolBar * getToolBar() { return myToolBar ; }

private:

  QToolBar * myToolBar ; // provided or created
  // items added to the toolbar. Useful to hide or show
  std::map< int , GuiItem * > myItems ;
} ;


/**
* Popup Menu
*/


class GuiPopupMenu : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId            ;
    const char * myName          ;
    // labels
    const char * myText          ; // icon should be memtioned
    const char * myToolTip       ;
    // components
    int          myNumberOfIds   ;
    int        * myIds           ;
    // callbacks
    int          myCallbackTypes ;
  } CreateInfo ;

  GuiPopupMenu( GuiWidgetGroup & wg , QWidget * parent , QMenuBar * menuBar , const CreateInfo & );
  ~GuiPopupMenu() {}
  QMenu * getPopupMenu() { return myPopupMenu ; }
  void  updateFont();
  bool  addItem( GuiItem * );

private slots :

  void slotAboutToShow() ;

private :

  QMenu * myPopupMenu ;
  // items added to the toolbar. Useful to hide or show
  std::map< int , GuiItem * > myItems ;

} ;



class GuiViewPopupMenu : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  enum PredefinedItemTypes { SEPARATOR_ITEM=-999999 , LABEL_ITEM , SUB_MENU , UNDEFINED_ITEM=-99999 } ;

  class MenuItem {
  public:
    MenuItem( int id=UNDEFINED_ITEM , const char *label=0 , const char *icon=0 , std::vector< MenuItem > *subMenu=0 ) ;
    MenuItem( const MenuItem & m ) ;
    const MenuItem & operator= ( const MenuItem & m ) ;
    bool operator== ( const MenuItem & m ) ;
    bool operator!= ( const MenuItem & m ) ;
    int             getId()    const { return myId    ; }
    const QString & getLabel() const { return myLabel ; }
    const QString & getIcon () const { return myIcon  ; }
    const std::vector< MenuItem > & getSubMenu() const { return mySubMenu ; }
  private:
    int                myId        ;
    QString            myLabel     ;
    QString            myIcon      ;
    std::vector< MenuItem > mySubMenu   ;
  } ;
  typedef std::vector< MenuItem >  SimpleMenu ;
  /* TODO: replace by following.
  class SimpleMenu : public map< int , MenuItem >
  {
  public :
    const SimpleMenu & operator== ( const SimpleMenu & m )
    {
      if ( &m != this ) {
        clear();
        for ( map< int , MenuItem >::const_iterator iter=m.begin() ; iter != m.end() ; ++iter ) {
          insert( iter->first , MenuItem(iter->second) );
        }
      }
      return *this ;
    }
  } ;
  */
  GuiViewPopupMenu( GuiTeam & wg , QWidget * parent , int viewId , const SimpleMenu & );
  ~GuiViewPopupMenu();

  QMenu * getPopupMenu() { return myPopupMenu ; }
  void    popupAtCursorLocation() ;
  void    createMenuItem( QMenu * popupMenu , const MenuItem * );
  bool    enableItemWithId( int , bool );
  bool    setString( int itemId , const QString & s );
  
private slots :
  void  slotActivated( int );
  void  slotAboutToShow();
private :
  QMenu                   * myPopupMenu   ; // create or inherited from
  SimpleMenu                mySimpleMenu  ;
  std::map< int , QMenu * > myNestedMenus ;
} ;




/**************************************************************************************************
 **************************************************************************************************
 ** "Layout" and "GroupBox"
 **************************************************************************************************
 *************************************************************************************************/



class GuiPage ;
class GuiLayout : public QObject , public GuiItem
{
public :
  static const char * CLASS_NAME ;
  enum { DEF_SPACING=6 , DEF_MARGIN=6 };

  typedef struct {
    int          myId      ;
    const char * myName    ;
    // layout ( 1,0 => horizontal   0,1 => vertical else grid layout).
    int          myNumRows ;
    int          myNumCols ;
    // spacing
    int          myMargin  ; // DEF_MARGIN
    int          mySpacing ; // DEF_SPACING
  } CreateInfo ;

  /** constructor used in:
   *   "GuiGroupBox::GuiGroupBox"
   *   "GuiDialogOfForm::GuiDialogOfForm"
   *   "GuiMainWindowOfForm::GuiMainWindowOfForm"
   */ 
  GuiLayout( GuiTeam & wg , QWidget * , const CreateInfo & , const char * callerMsg );
  /** constructor called by:  "GuiWidgetGroup::createLayout()" */
  GuiLayout( GuiTeam & wg , const CreateInfo & , int rowId , int colId ,
             QWidget * topWidgetForThe , GuiItem * parentItem , GuiLayout * parentLayout );

  ///  ... find out where they are used .... 

  /** use an existing layout out */
  GuiLayout( GuiTeam & wg , QWidget * , QLayout * , const CreateInfo & );
  /** add it to an existing layout */
  GuiLayout( GuiTeam & wg , GuiLayout * , const CreateInfo & , int rowId , int colId );
  /** constructors */
  GuiLayout( GuiTeam & wg , QObject * , int id  , int row=1 , int col=0 ,
               int spacing=DEF_SPACING , int margin=DEF_MARGIN , const char * name = 0 );
  GuiLayout( GuiTeam & wg , QObject * , const CreateInfo & );


  /** destructor */
  ~GuiLayout() ;
  /** find out a layout in an existing widget */
  static QLayout  * findLayout( QWidget * , QString & layoutClass );

  /** the Qt layout */
  QLayout         * getLayout() const  ;
  /** the creator of this layout */
  void              setCreator( GuiItem * guiItem ) { myCreator = guiItem ; }
  /** when multiple levels of layouts, find the gui item that has a widget */
  GuiItem       * getCreator( bool upToTheTop = true );
  /** the widget to use as a parent when creating a new gui item */
  QWidget         * getCreatorWidget();

  /** add item to the layout  */
  void              addWidget( QWidget   * , int row=-1 , int col=-1 );
  void              addWidget( GuiItem   * , int row=-1 , int col=-1 );
  void              addWidget( int id      , int row=-1 , int col=-1 );
  void              addWidget( GuiPage   * , int row=-1 , int col=-1 );

  void              addLayout( QLayout   * , int row=-1 , int col=-1 );
  void              addLayout( GuiLayout * , int row=-1 , int col=-1 );

  /** the orientation is relevent for the grid layout (else it's ignored) */
  void              addSpacer( int size , bool hor=true , int row=-1 , int col=-1 , bool isFixedSize=false );
  void              addLine  ( int size , bool hor=true , int row=-1 , int col=-1 );

private :

  void         myInitialize  ( QObject * parent , int numRows , int numCols , int margin , int spacing , const char * name );
  const char * myCreateLayout( QWidget * w , QLayout * l , int numRows , int numCols , int margin , int spacing , const char * name );

  /** the creator of the layout . It enables to find a suitable QWidget in '' */
  GuiItem         * myCreator            ;

  /** internally managed layout */
  QHBoxLayout     * myHorizontalLayout   ;
  QVBoxLayout     * myVerticalLayout     ;
  QGridLayout     * myGridLayout         ;
  bool              myHasBeenCreatedHere ;
} ;




/** ===========================================================
* Frame
*** =========================================================== */




class GuiFrame : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId      ;
    const char * myName    ;
    const char * myToolTip ;
    /** size of the widget */
    GuiItem::SizesCreateInfo * mySizes ;
  } CreateInfo ;

  GuiFrame( GuiTeam & wg , QWidget * parent , const CreateInfo & );
  ~GuiFrame() ;
  QFrame * getFrame() { return myFrame ; }

private :

  QFrame               * myFrame  ; // created
} ;



/** ===========================================================
* Group Box . It creates and manages an internal layout (GuiLayout)
* If a widget is added to it, its font is NOT bold and it is added to the layout.
*** =========================================================== */


class GuiGroupBox : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  enum GroupBoxLayoutType {
    GBLT_HORIZONTAL = 0 ,
    GBLT_VERTICAL       ,
    GBLT_GRID
  };

  typedef struct {
    int          myId        ;
    int          myLayoutId  ;
    const char * myName      ;
    /** title & option */
    const char * myTitle     ;
    const char * myIcon      ;
    const char * myToolTip   ;
    bool         myCheckable ;
    /** layout ( 1,0 => horizontal   0,1 => vertical else grid layout). */
    int          myNumRows   ;
    int          myNumCols   ;
    /** spacing */
    int          mySpacing   ; /** GuiLayout::DEF_SPACING */
    int          myMargin    ; /** GuiLayout::DEF_MARGIN  */
  } CreateInfo ;

  GuiGroupBox( GuiTeam & wg , QWidget * , const CreateInfo & , QGroupBox * groupBox = 0 , int callerId = 0 );
  ~GuiGroupBox() ;

  /** font */
  void           updateFont();
  void           updateIcon();

  /** internal components */
  QGroupBox    * getGroupBox()  { return myGroupBox ; }
  QWidget      * getInternalWidget() { return myInternalWidget ; } // parent for the widget created in it
  GuiLayout    * getInternalLayout() { return myInternalLayout ; }

  /** add item to the internal layout
   *  ( changeFont: 1:set font to bold . 0: set font to false. -1: no font operation ) */
  void           addItem  ( GuiItem * , int row=-1 , int col=-1 , int fontOperation=0 );
  void           addWidget( QWidget   * , int row=-1 , int col=-1 , int fontOperation=0 );
  void           addLayout( QLayout   * , int row=-1 , int col=-1 );
  void           addSpacer( int size , bool hor=true , int row=-1 , int col=-1 , bool isFixedSize=false );
  void           addLine  ( int size , bool hor=true , int row=-1 , int col=-1 );

  /** change the aspect (needed when the group box is part of a tab) */
  void           setIsFlat( bool b );
  

private slots :

  void  slotToggled( bool );

private :

  QGroupBox    * myGroupBox       ; // created
  QWidget      * myInternalWidget ; // created
  GuiLayout    * myInternalLayout ; // created

  QString        myString         ; // title (could be in "GuiItem")
} ;



/**************************************************************************************************
 **************************************************************************************************
 ** Base Widgets
 **************************************************************************************************
 *************************************************************************************************/


/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Label
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiLabel : public QObject , public GuiItem
{
public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId        ;
    const char * myName      ;
    // labels
    const char * myText      ;
    const char * myToolTip   ;
    const char * myIconName  ;
    // size
    int          myMaxWidth  ;
    int          myMaxHeight ;
    // miscellaneous
    GuiItem::AlignmentType myAlignment ;
  } CreateInfo ;

  GuiLabel( GuiTeam & wg , QWidget * , const CreateInfo & );
  ~GuiLabel() ;
  void updateIcon();
  QLabel * getLabel() { return myLabel ; }
private :
  QLabel * myLabel ; // provided
} ;





/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a List View
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiListView : public QObject , public GuiItem
{
  Q_OBJECT
  
public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId       ;
    const char * myName     ;
    // labels
    const char * myText     ;
    const char * myToolTip  ;
    // size
    int          myMaxWidth  ;
    int          myMaxHeight ;
    // miscellaneous
    GuiItem::AlignmentType myAlignment ;
  } CreateInfo ;

  GuiListView( GuiTeam & wg , QWidget * , const CreateInfo & );
  ~GuiListView() ;
  QListView * getListView() { return myListView ; }
  /** update the font & the icons (of itself & the ones that are inside) */
  void    updateFont();
  void    updateIcon();
private :
  QListView * myListView ; // created
};



/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Check Box
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiCheckBox : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId        ;
    const char * myName      ;
    // labels
    const char * myText      ;
    const char * myAccelText ;
    const char * myToolTip   ;
    const char * myIconName  ;
    // size
    int          myMaxWidth  ;
    int          myMaxHeight ;
    // callbacks
    int          myCallbackTypes ;
  } CreateInfo ;

  GuiCheckBox( GuiTeam & wg , QWidget * , const CreateInfo & );
  GuiCheckBox( GuiGroupBox & , const CreateInfo & );
  ~GuiCheckBox() ;
  QCheckBox * getCheckBox() { return myCheckBox ; }

private slots :

  void  slotClicked();

private :

  QCheckBox * myCheckBox ;
} ;




/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Push Button
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiPushButton : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME  ;
  static const char * CANCEL_TEXT ;
  typedef struct {
    int          myId        ;
    const char * myName      ;
    // labels
    const char * myText      ;
    const char * myAccelText ;
    const char * myToolTip   ;
    const char * myIconName  ;
    // size
    int          myMaxWidth  ;
    int          myMaxHeight ;
    // callbacks
    int          myCallbackTypes ;
  } CreateInfo ;
  GuiPushButton( GuiTeam & wg , QWidget * , const CreateInfo & );
  GuiPushButton( GuiGroupBox & , const CreateInfo & );
  ~GuiPushButton() ;
  void updateIcon();
  QPushButton * getPushButton() { return myPushButton ; }

private slots :

  void  slotClicked();

private :
  QPushButton * myPushButton ;
} ;




/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates Radio Buttons . It's mainly a facility to deal with them .
 * It's a namespace
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiButtonGroup
{
public :
  static const char * CLASS_NAME  ;
  /** static member (required when dealing with "ui" generated widgets) */
  struct Item {
    QAbstractButton * myButton ;
    int               myId     ;
  };
  static QButtonGroup * createButtonGroup( QObject * , int numberOfItems = 0 , const Item * = 0 );
  static void           setButton( QButtonGroup * , int idOfButton  );
  static int            getButton( QButtonGroup * , bool * isOk = 0 );
};




/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Slider
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiSlider : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId        ;
    const char * myName      ;
    // labels
    const char * myToolTip   ;
    // values
    int          myMinValue  ;
    int          myValue     ;
    int          myMaxValue  ;
    // size
    int          myMaxWidth  ;
    int          myMaxHeight ;
    // aspect (uses values of GuiItem::AlignmentType)
    int          myAspect    ;
    // callbacks
    int          myCallbackTypes ;
  } CreateInfo ;

  GuiSlider( GuiTeam & wg , QWidget * , const CreateInfo & );
  GuiSlider( GuiGroupBox & , const CreateInfo & );
  ~GuiSlider() {}
  QSlider * getSlider() { return mySlider ; }
  void updateFont();
  void setUserValue( int userValue , bool forceMessage=false );

private slots :

  void slotValueChanged( int v );
  void slotSliderMoved ( int v );

private :

  QSlider * mySlider ; // created
} ;




/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Spin Box
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiSpinBox : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId       ;
    const char * myName     ;
    // labels
    const char * myToolTip  ;
    // values
    int          myMinValue ;
    int          myValue    ;
    int          myMaxValue ;
    // size
    int          myMaxWidth  ;
    int          myMaxHeight ;
    // callbacks
    int          myCallbackTypes ;
  } CreateInfo ;

  GuiSpinBox( GuiTeam & wg , QWidget * , const CreateInfo & );
  GuiSpinBox( GuiGroupBox & , const CreateInfo & );
  ~GuiSpinBox() {}
  QSpinBox * getSpinBox() { return mySpinBox ; }
  void updateFont();
  void setUserValue( int userValue , bool forceMessage=false );

private slots :

  void slotValueChanged( int v );

private :

  QSpinBox * mySpinBox ; // created
} ;





/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Line Edit
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiLineEdit : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId       ;
    const char * myName     ;
    // labels
    const char * myText     ;
    const char * myToolTip  ;
    // sizes
    int          myMaxWidth ;
    int          myMaxHeight;
    // callbacks
    int          myCallbackTypes   ;
  } CreateInfo ;

  /** constructor / destructor */
  GuiLineEdit( GuiTeam & wg , QWidget * , const CreateInfo & , QLineEdit * lineEdit = 0 );
  ~GuiLineEdit() {}

  QLineEdit * getLineEdit() { return myLineEdit ; }
  void setUserValue( const QString & userValue , bool forceMessage=false );
  bool getCheckedInt( int & , const char * name=0 , bool resetIfNeeded = true );

protected:

  const CreateInfo * myCreateInfo ;

private slots :

  void slotReturnPressed();
  void slotTextChanged( const QString & s );

private :

  /** not implemented */
  GuiLineEdit();
  GuiLineEdit( const GuiLineEdit & );
  const GuiLineEdit &operator=( const GuiLineEdit & );

  QLineEdit * myLineEdit ; // create or provided

  /** update the font & the icons (of itself & the ones that are inside) */
  void        updateFont();
  void        updateIcon();
};




/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a List Box / List Widget
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiListBox : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;

  /** ********************************
   * STATIC MEMBERS : NEW VERSION : dealing with QListWidget.
   * row is from 0 to count(0 . -1 to put at the end.
   ** ***************************** */

  /** flags for finding . By default search is case-unsensitive */
  enum SearchFlag { SRC_BEGINS      ,  // Qt::MatchStartsWith
                    SRC_BEGINS_CASE ,  // Qt::MatchStartsWith | Qt::MatchCaseSensitive
                    SRC_EXACT_CASE  }; // Qt::MatchExactly | Qt::MatchCaseSensitive



  typedef struct {
    int          myId       ;
    const char * myName     ;
    const char * myToolTip  ;
    // selection mode
    GuiItem::SelectionMode mySelectionMode ;
    const char * myText     ;
    // sizes
    int          myMaxWidth ;
    int          myMaxHeight;
    // callbacks
    int          myCallbackTypes   ;
  } CreateInfo ;

  /** constructor / destructor */
  GuiListBox( GuiTeam & wg , QWidget * parent , const CreateInfo & , QListWidget * listBox = 0 );
  ~GuiListBox();

  QListWidget * getListBox() { return myListBox ; }

  /** update the font & the icons (of itself & the ones that are inside) */
  void       updateFont();
  void       updateIcon();

  /** methods encapsulating the ones of QListWidget, or to mange the list of items */
  // not presented here...

protected slots :

  void slotSelectionChanged();
  void slotSelected( QListWidgetItem * );
  void slotDoubleClicked( QListWidgetItem * );

private :

  /** not implemented */
  GuiListBox();
  GuiListBox( const GuiListBox & );
  const GuiListBox &operator=( const GuiListBox & );

  QListWidget  * myListBox ; // create or provided

  /** link of an item and of the user value (set with "appendTextAtTheEnd( const QString & s , int userValue )") */
  std::vector< int > myUserValues ;
};




/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Combo Box
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/



class GuiComboBox : public QObject , public GuiItem
{
  Q_OBJECT

public :

  static const char * CLASS_NAME ;

  typedef struct {
    int           myId            ;
    const char  * myName          ;
    // labels
    const char  * myToolTip       ;
    // size
    int           myMaxWidth      ;
    int           myMaxHeight     ;
    int           myValuesNumber  ;
    const Typ::ValuesStruct * myValues ;
    // callbacks
    int           myCallbackTypes ;
  } CreateInfo ;

  /** constructor / destructor */
  GuiComboBox( GuiTeam & wg , QWidget * parent , const CreateInfo & , QComboBox * provided = 0 );
  GuiComboBox( GuiGroupBox & , const CreateInfo & );
  ~GuiComboBox() {}

  /** Qt combo-box */
  QComboBox * getComboBox() { return myComboBox ; }
  static QComboBox * toQtComboBox( GuiItem * );

  /** update the font & the icons (of itself & the ones that are inside) */
  void updateFont();
  void updateIcon();

  /** values and the number of them */
  void clearValues();
  int  getNumberOfItems() const;

  /** add single . if "indexOfItem" is -1, it's added at the end else it's inserted */
  void addValue   ( const char * label , const char * iconName , const Typ::ColorId * , int userValue , int indexOfItem = -1 );
  bool insertValue( const char * label , const char * iconName , const Typ::ColorId * , int userValue , int indexOfItem , bool replaceIt=false );
  void setString( const QString & , bool forceMessage=false );

  /** clean-up the combobox and set all the values . if "values" is nullptr , "number" can be an enumeration type . "option" is 1 to display user value before name */
  bool setValues( int number , const Typ::ValuesStruct * values , int option = 0 , bool sendMessage = false );
  bool setValues( const std::vector< Typ::ValuesStruct > & , int option = 0 , bool sendMessage = false );

  /** current string. Empty if none and index is provided . (index is (-1) if the combo-box is empty) */
  QString getString( int * indexPtr=0 );
  /** get current user value at a given index .
   *  Current one if index is '-1' Error if the combo-box is empty */
  int  getUserValue( int indexOfItem = -1 , bool * isOkPtr = 0 );
  /** set the user value. Return 'false' if it was not present . Error message if not present */
  bool setUserValue( int userValue , bool forceMessage=false , bool showErrorMessage=true );
  /** change the text pertaining to a user value */
  bool changeTextOfUserValue( const QString & str , int userValue );
  /** change the text at a given *index* */
  bool changeTextAtIndex( const QString & str , int index );

  /** find the closest item in the combobox . Returns 'true' if it's the same */
  static bool getClosestMatch( QComboBox * , const QString & model , QString & found , bool mustMatch );
  static bool setClosestMatch( QComboBox * , const QString & model , QString & found , bool mustMatch , bool sendSignals );

  bool getClosestMatch( const QString & model , QString & found , bool mustMatch )
  { return getClosestMatch( myComboBox , model , found , mustMatch ); }
  bool setClosestMatch( const QString & model , QString & found , bool mustMatch , bool sendSignals )
  { return setClosestMatch( myComboBox , model , found , mustMatch , sendSignals ); }

  /** find out if the user value is present (in 'myMap') */
  bool hasUserValue( int userValue ) const ;

private slots :

  void  slotActivated( int );

private:

  QComboBox  * myComboBox ; // provided or created
  std::map< int , int >  myMap ; // index in combobox <-> user value
} ;


/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Splitter
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiSplitter : public QObject , public GuiItem
{
  Q_OBJECT // usefull (?) to be removed.
  
public :
  static const char * CLASS_NAME ;
  enum { DEF_HANDLE_WIDTH = 10  } ;
  
  typedef struct {
    int          myId            ;
    const char * myName          ;
    bool         myIsVertical    ;
    bool         myIsCollapsable ;
    int          myMargin        ;
    int          myHandleWidth   ;
  } CreateInfo ;
  
  GuiSplitter( GuiTeam & wg , QWidget * , const CreateInfo & );
  ~GuiSplitter() ;
  QSplitter * getSplitter() { return mySplitter ; }
  
private :
  
  QSplitter             * mySplitter ; // created
  
} ;



/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Stacked Widget
 *-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*/

class GuiStackedWidget : public QObject , public GuiItem
{
  Q_OBJECT // not useful : no slot

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId        ;
    const char * myName      ;
    // title & option
    const char * myToolTip   ;
    // pages are group-boxes
    int          myNumberOfGroupBoxes ;
    GuiGroupBox::CreateInfo * myGroupBoxes ;
  } CreateInfo ;

  GuiStackedWidget( GuiTeam & wg , int       , const CreateInfo & );
  GuiStackedWidget( GuiTeam & wg , GuiItem * , const CreateInfo & );
  GuiStackedWidget( GuiTeam & wg , QWidget * , const CreateInfo & );
  ~GuiStackedWidget() ;
  QStackedWidget  * getStackedWidget()  { return myStackedWidget  ; }
  QWidget         * getInternalWidget() { return myInternalWidget ; }
  
  // set the combo box that will raise the specified page
  void              setComboBox( GuiComboBox * );

  // add the widget to the stack
  void              addWidget( QWidget * , int userId );
  void              addWidget( GuiItem * , int userId );
  void              addGroupBox( GuiGroupBox * );

  // set / get the user id
  void              setUserValue( int userValue , bool forceMessage=false );
  int               getUserValue( int indexOfItem = -1 , bool * isOkPtr = 0 );

private slots :

  void              slotAboutToShow( int )      ; // called when the page are about the show it
  void              slotComboBoxActivsted( int ); // connect with the provided combobox

private :

  QStackedWidget           * myStackedWidget  ; // created
  QWidget                  * myInternalWidget ; // widget . parent of the widget in the stacked widget
  GuiComboBox              * myComboBox       ; // provided ComboBox to have the pages titles in it
  std::vector<GuiGroupBox *> myGroupBoxes     ; // pages to add to the combobox

  std::map< int , int >      myMap            ; // index in Widget Stack <-> user value
  void                       myInitialize( QWidget * parent , const CreateInfo & createInfo );
} ;



/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * GuiTableTracking Event
   * used for the tracking of the values 
   
   * tracking event: be informed when the cursor is on a Table (and get the values) 
   * See: "trackingWhenTheCursorMovesOnThePage()"
   * See: "trackingEvent()" 
   * tell if the cursor is inside
   * tell the column to track
   * find out the row where the cursor is
   * get the values 
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiTable ;
class GuiTableTrackingEvent
{
public :
  static const char * CLASS_NAME ;
  GuiTableTrackingEvent();
  /** define what to track . It checks the values */
  bool  setColumnsToTrack( GuiTable * ,
                           int firstColumn , int secondColumn ,
                           int thirdColumn , int fourthColumn );
  /** define the defaults values (in the case they can't be found in the column) */
  void  setDefaultValues(  int firstColumnValue = -1 , int secondColumnValue = -1 ,
                           int thirdColumnValue = -1 , int fourthColumnValue = -1 );

  /** cursor moved inside / outside . If the cursor is inside, row & col are positive */
  bool  setRowColumn( int  row , int  col ) ; // returns "true" if a change occurred.
  bool  getRowColumn( int &row , int &col ) { row=myRow ; col=myColumn ; return (row >= 0) && (col >= 0); }

  /** track the event */
  GuiTableTrackingEvent * getValues();
  
  /** identification */
  GuiTable * myTable       ;
  int   myFirstColumn      ;
  int   mySecondColumn     ;
  int   myThirdColumn      ;
  int   myFourthColumn     ;
  /** previous location */
  int   myPreviousRow      ;
  int   myPreviousColumn   ;
  /** current location */
  int   myRow              ;
  int   myColumn           ;
  /** values */
  int   myFirstIntValue    ;
  int   mySecondIntValue   ;
  int   myThirdIntValue    ; 
  float myFourthFloatValue ;
} ;




/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulate a QTableWidget and customize it.
 * Selection is single .
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiDerivedTable ;
class GuiTable : public QObject , public GuiItem
{
  Q_OBJECT
  
public :
  static const char * CLASS_NAME ;
  /** values for the horizontal headers */
  typedef struct {
    int                 myColumnIndex ;
    const char *        myText        ; /** text in the header */
    GuiItem::EditType myEditType    ; /** how to treat the field (validator, type, ...)*/
    int                 mySize        ; /** size of the header */
  } ColumnCreateInfo ;
  /** storage of the above values (used to keep the name of the header ...) */
  class ColumnHeader {
  public :
    ColumnHeader( int columnIndex=-1 , const char * text="undefined" , GuiItem::EditType editType=GuiItem::EDT_NONE , int size=50 )
    {
      myColumnIndex = columnIndex ;
      myText        = text        ;
      myEditType    = editType    ;
      mySize        = size        ;
    }
    ColumnHeader( const ColumnCreateInfo & bp )
    { 
      myColumnIndex = bp.myColumnIndex ;
      myText        = bp.myText        ;
      myEditType    = bp.myEditType    ;
      mySize        = bp.mySize        ;
    }
    ColumnHeader( const ColumnHeader & bp ) 
    { 
      *this = bp;
    }
    const ColumnHeader & operator= ( const ColumnHeader & bp )
    {
      if ( &bp != this ) {
        myColumnIndex = bp.myColumnIndex ;
        myText        = bp.myText        ;
        myEditType    = bp.myEditType    ;
        mySize        = bp.mySize        ;    
      }
      return *this ;
    }
    // values
    int                 myColumnIndex ;
    QString             myText        ;
    GuiItem::EditType   myEditType    ;
    int                 mySize        ;
  };  
  /** Blue Print */
  typedef struct {
    int               myId            ;
    const char      * myName          ;
    // labels
    const char      * myToolTip       ;
    // selection mode
    GuiItem::SelectionMode mySelectionMode ;
    // horizontal headers
    int               myColumnsNumber ;
    ColumnCreateInfo * myColumns       ;
    // callbacks
    int               myCallbackTypes ;
  } CreateInfo ;
  
  /** constructor / destructor (might be created outside) */
  GuiTable( GuiTeam & wg , int         , const CreateInfo & );
  GuiTable( GuiTeam & wg , GuiItem * , const CreateInfo & );
  GuiTable( GuiTeam & wg , QWidget *   , const CreateInfo & , QTableWidget * provided = 0 );
  ~GuiTable();

  
  //------------------------------------------------------------
  /** INSTANCE MEMBERS                                        */
  //------------------------------------------------------------

  /** the widget */
  QTableWidget * getTable() const ;
  
  /** update the font & the icons (of itself & the ones that are inside) */
  void    updateFont();
  void    updateIcon();
  
  /** selection mode */
  void    setSelectionMode( GuiItem::SelectionMode );

  /** set the headers labels and values . Initially used by 'GuiMessageForm' */
  void    setColumnHeaders( int numberOfColumns , ColumnCreateInfo * columns );
  void    setEditTypes( const std::vector< GuiItem::EditType > & edit )
  { if ( edit.empty() == false ) { myEditTypeVector = edit ; } }
  Qt::ItemDataRole  getRole( int col ) const ;
  void    setHeaderStrings( const std::list <QString> & textList ,
                            bool columnsHeaders , 
                            std::map< int , ColumnHeader > * columnHeaderMap = 0 );
  void    setHorizontalLabel( int columnIndex , const QString & label , const char * toolTip = 0 );
  void    setColumnHeader( int columnIndex , const QString & label ) { setHorizontalLabel(columnIndex,label); }
  void    setColumnIsEditable( int columnIndex , bool isEditable );
  void    setEditable( bool b );

  /** the number of rows */
  void    setNumberOfRows( int );
  int     getNumberOfRows() const ;
  
  /** the number of columns */
  void    setNumberOfColumns( int );
  int     getNumberOfColumns() const ;
    
  /** move , delete . Does not deal with cells that have a 'GuiItem' in them */
  bool    swapRows( int fromRow , int toRow );
  void    ensureCellVisible( int row , int col );
  void    clearCell( int rowIndex , int columnIndex );
  void    clearCurrentCell();
  void    updateCell( int rowIndex , int columnIndex );
  void    updateCurrentCell();
  bool    getCellIsEmpty( int rowIndex , int columnIndex ) ; // no text in the cell
  bool    moveSelectedRow( int step );
  bool    moveRowsAfter( int rowIndex , int orientation ); // (-1):down:erases 'rowIndex' * (+1):up:duplicates 'rowIndex'
  bool    deleteRow( int rowIndex );
  void    removeRow( int rowIndex );
  void    insertRow( int rowIndex );
  int     contentsWidth();

  /** set a widget in the table . It stores the "GuiItem" in "myGuiItems"
   * WARNING: they are also stored in "GuiTeam" so attention must be paid to the deletion
   * When a "GuiItem" is destroyed, it automatically is taken out of the list
   * maintained by "GuiTeam" (see the destructor of "GuiItem") */
  void      setGuiItem( int rowIndex , int columnIndex , GuiItem * );
  GuiItem * getGuiItem( int rowIndex , int columnIndex , bool removeFromList );
  /** returns 'true' if deleted. WARNING: it's removed from the list as 'getGuiItem(,,true)' is used  */
  bool      deleteGuiItem( int rowIndex , int columnIndex , bool mustBePresent );
  
  /** cell in the table */
  QTableWidgetItem * getCell( int rowIndex , int columnIndex , bool createIt );

  /** set a specific value in a cell */
  void    setString ( int rowIndex , int columnIndex , const QString & value );
  void    setBool   ( int rowIndex , int columnIndex , bool value , const QString * = 0 );
  void    setInt    ( int rowIndex , int columnIndex , int value             );
  void    setFloat  ( int rowIndex , int columnIndex , float value           );
  void    setDouble ( int rowIndex , int columnIndex , double value          );

  /** get a specific value from a cell (without checking) */
  QString getString ( int rowIndex , int columnIndex );
  bool    getBool   ( int rowIndex , int columnIndex );
  int     getInt    ( int rowIndex , int columnIndex );
  float   getFloat  ( int rowIndex , int columnIndex );
  double  getDouble ( int rowIndex , int columnIndex );

  /* error message. It will show the location & provide a pop-up dialog
   *  if error : update the error message
   *           : show the area
   *           : pops-up the error message (if 'showError' is 'true') */
  void    showErrorMessage( int rowIndex , int columnIndex , const QString & errorMessage );

  /** same as 'getInt', 'getFloat', 'getString' but with error message .
   *  at the start: does nothing if error message is already used 
   *  if error : uses 'showErrorMessage' if 'showError' is 'true' */
  QString getQString( int rowIndex , int columnIndex , QString & errorMessage , bool showError = true );
  int     getInt    ( int rowIndex , int columnIndex , QString & errorMessage , bool showError = true );
  float   getFloat  ( int rowIndex , int columnIndex , QString & errorMessage , bool showError = true );
  QString getString ( int rowIndex , int columnIndex , QString & errorMessage , bool showError = true );

  /** actions on the table values. // DEALING WITH 'QStringList'
   *  might be removed at same time // OBSOLETE (?)
   *  If the index is '-1' add at the end or deal with the current row
   *  The provided string list is updated
   *  Return 'true' if no problem */
  void    setList     ( const QStringList & );
  void    getList     ( QStringList & );
  bool    addRow      ( int   minLeft , int   maxLeft , int   minRight , int   maxRight , QStringList & , int row = -1 );
  bool    getRow      ( int & minLeft , int & maxLeft , int & minRight , int & maxRight , int row = -1 );
  QString getRowString( int row );
  bool    setRow      ( int   minLeft , int   maxLeft , int   minRight , int   maxRight , int row = -1 );
  bool    upRow       ( QStringList & , int row = -1 );
  bool    downRow     ( QStringList & , int row = -1 );
  bool    deleteRow   ( QStringList & , int row = -1 );

  /** add text for the "textList.size() (true)" columns and "textList.size() (false)" rows.
   *  there might be an extra coliumn for a toggle */
  void    setCellValues( const std::list< std::list<QString> > & forEachRowTheListOfText , const std::vector<bool> * checkList = 0 );
  /** select / deselect all */
  bool    selectAll( bool ) ;
  /** row selection */
  bool    getRowIsSelected( int rowIndex );
  bool    isRowSelected( int rowIndex ) { return getRowIsSelected(rowIndex); }
  /** select the row */
  void    setRowIsSelected( int rowIndex ) { setSelectedRow(rowIndex); }
  bool    setSelectedRow( int rowIndex );
  /** get the first selected row (unique one if selection mode is 'SM_SINGLE') .  Return 'false' if no selected row */
  bool    getSelectedRow( int & firstRow , int & selectedRow , int & lastRow ) const ;
  /** get the current row .  Return '-1' if none */
  int     getSelectedRow() const ;
  /** get the current rows (e.g.:multiple selection with "GuiItem::SM_MULTI_ROW") */
  std::set< int > getSelectedRows() const ;
  /** how to how a cell . It deselects everything and show it */
  bool    selectCellAndEnsureVisibility( int rowIndex , int columnIndex );

  /** init all the remark fields */
  void    initializeRemarks();
  /** set the remark text */
  void    setRemarkText( int row , const QString & );


  /** ==========================
   ** Create a Popup Menu (activated by Qt 'pressed()' with right button)
   ** ========================*/
  
  void    createViewPopupMenu( int viewId , const GuiViewPopupMenu::SimpleMenu & menu );
  bool    getPopupRowColumn( int & row , int & col );

  /** ==========================
   ** Resize
   ** ========================*/

  /** set the resize strategy (NB: could be using a QTable method) */
  enum ResizeStrategyType { RST_NO_RESIZE=0 , RST_RESIZE_AS_DEFINED , RST_RESIZE_AS_PRESENT };
  void    setResizeStrategy( ResizeStrategyType s ) { myResizeStrategy = s ; }
  /** resize with what is visible */
  void    resizeInVisibleArea();

  /** add the update for the vertical scrollbar WARNING: do it one only (see "mySliderFlags") */
  void    addUpdateForHorizontalScrollbar();
  void    addUpdateForVerticalScrollbar();

  /** ==========================
   ** Tracking
   ** (could use "void	cellEntered ( int row, int column )")
   ** ========================*/
  
  /** directly ask fior the tracking. It sets "row" "column" the cursor is under .
   *  It starts / stops the mouse tracking of the QTableWidget */
  void    storeRowColumnOfCursor( bool );

  /** set the column to track (up to four columns) . No tracking if out of range (e.g. -1) */ 
  void    setColumnsToTrack( int firstColumn = -1 , int secondColumn = -1 ,
                             int thirdColumn = -1 , int fourthColumn = -1 );
  /** define the defaults values (in the case they can't be found in the column) */
  void    setDefaultTrackedValues(  int firstColumnValue = -1 , int secondColumnValue = -1 ,
                                    int thirdColumnValue = -1 , int fourthColumnValue = -1 );
  
  /** The two above methods trigger "setMouseTracking( true )" so the mouse position is known
   *  in "GuiDerivedTable::mouseMoveEvent( QMouseEvent * e )"
   *  and the row & col8umn indexes are identified . 
   *  row & col8umn indexes are turned into (-1) and (-1) when the moose leaves the table.
   * 
   *  Below methods get the values . "" returns "false" if row & col aren't valid.
   */
  bool    setRowColumnWhereCursorIs( int   row , int   col ) ;
  bool    getRowColumnWhereCursorIs( int & row , int & col ) { return myTrackingEvent.getRowColumn(row,col); }

  /** used for the tracking of the values */
  GuiTableTrackingEvent * getTrackingEvent();
  
protected :

  /** popup menu */
  GuiViewPopupMenu   * myPopupMenu   ;
  int                  myPopupRow    ;
  int                  myPopupColumn ;

private slots :

  void   slotCellPressed( int row , int col );
  void   slotClicked( int row , int col );
  void   slotDoubleClicked( int row , int col );
  void   slotSelectionChanged();
  void   slotValueChanged( int row , int col );
  void   slotSliderReleased();
  /** used by the pop-up menu */
  void   slotMenuPressed( int row , int col );

private:

  QHeaderView * getHorizontalHeaderView();
  void          myInitialize( QWidget * parent , const CreateInfo & createInfo , QTableWidget * provided ); 

  /** the table (derived from QTableWidget) */
  QTableWidget              * myTable             ;
  GuiDerivedTable           * myDerivedTable      ;
  /** editing mode and column width (copy from ) */
  std::vector< GuiItem::EditType > myEditTypeVector  ;
  std::map< int , ColumnHeader >   myColumnHeaders     ;
  int                         myColumnsTotalWidth ;
  ResizeStrategyType          myResizeStrategy    ;
  GuiItem::SelectionMode      mySelectionMode     ;
  /** row,column map with the items */
  std::vector < GuiItem * >   myGuiItems          ;
  /** enter / leave . columns to track (if not (-1) */
  bool                        myCursorIsInside    ;
  /** tracking event */
  GuiTableTrackingEvent       myTrackingEvent     ;
  /** slider flags */
  int                         mySliderFlags       ;
};





/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Tab Widget
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiTabWidget : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId        ;
    const char * myName      ;
    // title & option
    const char * myToolTip   ;
  } CreateInfo ;

  GuiTabWidget( GuiTeam & wg , int         , const CreateInfo & );
  GuiTabWidget( GuiTeam & wg , GuiItem * , const CreateInfo & );
  GuiTabWidget( GuiTeam & wg , QWidget *   , const CreateInfo & );
  ~GuiTabWidget() ;
  
  QTabWidget      * getTabWidget() { return myTabWidget ; }

  /** find the current active widget */
  QWidget         * getCurrentWidget() const ;
  bool              isWidgetCurrent( QWidget * ) const ;
  bool              isWidgetCurrent( GuiItem * ) const ;
  bool              setCurrentWidget( QWidget * ) const ;
  bool              setCurrentWidget( GuiItem * ) const ;

  /** add the widget to the tab */
  void              addWidget( QWidget * , int userId , const char * tab , const char * icon = 0 , int index = -1 );
  void              addWidget( GuiItem * , int userId , const char * tab , const char * icon = 0 , int index = -1 );
  void              addGroupBox( GuiGroupBox * );

  /** set / get the user id */
  void              setUserValue( int userValue , bool forceMessage=false );
  int               getUserValue( int indexOfItem = -1 , bool * isOkPtr = 0 );

private slots :

  void              slotCurrentChanged( QWidget * ) ; // called when the page are about the show it

private :

  QTabWidget            * myTabWidget ; // created
  std::map< int , int >   myMap       ; // index in the tab widget <-> user value
  void                    myInitialize( QWidget * parent , const CreateInfo & createInfo );

} ;



/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Text Edit
 *-----------------------------------------------------------------------------------*
 -----------------------------------------------------------------------------------*/


class GuiTextEdit : public QObject , public GuiItem
{
  Q_OBJECT
  
public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId        ;
    const char * myName      ;
    // labels
    const char * myText      ;
    const char * myToolTip   ;
    // size
    int          myMaxWidth  ;
    int          myMaxHeight ;
    // miscellaneous
    GuiItem::AlignmentType myAlignment ;
  } CreateInfo ;

  GuiTextEdit( GuiTeam & wg , QWidget * , const CreateInfo & );
  ~GuiTextEdit() {}
  /** define the format of the text */
  void setTextAsPlainText();
  /** clear text */
  void clearString();
  /** add text (append on a new line) */
  void addString( const QString & );
  void addString( const char *    );
  /** get the text */
  QString getString();
  void    getString( QString & );
  /** set the cursor position . scroll */
  void setCursorPosition( int , int );
  void scrollToBottom();
  /** add text (test if not empty) */
  void addTextAtTheEnd( const QString & , bool testItsNotBlank = true , bool scrollToEnd = true );
  /** access to the Qt item */
  QTextEdit * getTextEdit() { return myTextEdit ; }

  /** STATIC */
  static void scrollToBottom( QTextEdit * );
  static void addTextAtTheEnd( QTextEdit * , const QString & , bool testItsNotBlank = true , bool scrollToEnd = true );

private :
  QTextEdit * myTextEdit ; // created
};




/**-------------------------------------------------------
* Separator . It is registered (so it can be identified)
* and not added twice.
*-------------------------------------------------------*/


class GuiSeparator : public GuiItem
{
public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId      ;
    const char * myName    ;
  } CreateInfo ;
  GuiSeparator( GuiTeam & wg , QWidget * parent , const CreateInfo & );
  ~GuiSeparator();
  void setMenu( GuiPopupMenu * m ) { myMenu = m ; }
  void setToolBar( GuiToolBar * t ) { myToolBar = t ; }
private :
  GuiPopupMenu * myMenu    ;
  GuiToolBar   * myToolBar ;
};



/*-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*
 * Encapsulates a Widget (e.g.: a dummy one used as central widget)                  *
 *-----------------------------------------------------------------------------------*
 *-----------------------------------------------------------------------------------*/


  
class GuiWidget : public QObject , public GuiItem
{
  Q_OBJECT // not useful (no signal is used)

public :
  static const char * CLASS_NAME ;
  typedef struct {
    int          myId      ;
    const char * myName    ;
    const char * myToolTip ;
    /** size of the widget */
    GuiItem::SizesCreateInfo * mySizes ;
  } CreateInfo ;

  GuiWidget( GuiTeam & wg , QWidget * parent , const CreateInfo & );
  ~GuiWidget() ;
  QWidget * getWidget() { return myWidget ; }

private :

  QWidget      * myWidget  ; // created
} ;




/**************************************************************************************************
 **************************************************************************************************
 ** Page Holder
 **************************************************************************************************
 *************************************************************************************************/


//class GuiPageTabWidget ;
class GuiPageHolder : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME ;
    /** the display of the pages */
  enum PageHolderType {
    PHT_UNDEFINED = 0 ,
    PHT_TAB           ,
    PHT_SIDE_BY_SIDE
  };

  /** parameters for the page holder */
  typedef struct {
    /** id of the event sender  */
    int          myId       ;
    /** name of the widget */
    const char * myName     ;
    /** tooltip */
    const char * myToolTip  ;
    /** page display type: how the pages are presented (e.g.:tab, splitter ...)*/
    PageHolderType myType   ;
  } CreateInfo ;

  /** constructor / destructor */
  GuiPageHolder( GuiForm & form , QWidget * parent , const CreateInfo & );
  ~GuiPageHolder();

  /** the form that owns the page holder */
  GuiForm  * getForm() const { return & myForm ; }

  /** the type of the holder */
  GuiPageHolder::PageHolderType getPageHolderType() const { return myType ; }

  /** the implemented widget */
  QWidget    * getWidget() const ;

  /** id of the page holder */
  int          getId() const { return myId ; }

  /** set the current page . It uses the 'getId()' of the page . Return 'false' if error */
  bool         setInt( int pageId , bool forceMessage=true ) ; // by default it sends a// TODO Signal

  /** get the current page */
  int          getInt() const ;

  /********************************
   * Management of the Pages
   *******************************/

  /** get page that has the required id . '0' if not found */
  GuiPage    * getPage( int ) const ;

  /** get the id of a page . '0' if not found */
  int          getPageId( QWidget * ) const ;

  /** find out if the page is visible to the user (the fact that it might not be enabled is not considered) */
  bool         isPageShownToTheUser( GuiPage * page ) const ;

  /** get the widget of the page with a specific id */
  QWidget    * getWidgetOfPage( int pageId ) const ;

  /** find out if the page is active */
  bool         getPageIsActive( GuiPage * ) const ;

  /** the active page */
  GuiPage    * getActivePage() const { return myCurrentPage ; }

  /** page holder has changed the active page */
  GuiPage    * setActivePage( QWidget * );

  /** add a page to the page holder */
  bool         addPage( GuiPage * );

  /** toggle the display : Tsb / Side-by-side */
  void         toggleDisplay();

  /** enable the page or not (return 'true' if a change occurred) */
  bool         setPageIsEnabled( int , bool );

  /** show or hide the tab of the page.
   * Returns 'true' if a change occurred else 'false'.
   * Does not delete the instance */
  bool         showTabOfPage  ( GuiPage * , bool );
  bool         showTabOfPageId( int pageId  , bool );

  /** remove a page from the list.
   * Returns 'true' if the page was present else 'false'
   * Does not delete the instance */
  bool         removePage( GuiPage * );

  /** add / remove the page from the internally managed list */
  bool         addPageToList( GuiPage * );
  bool         removePageFromList( GuiPage * );

  /********************************
   * Event dealt by the page holder
   *******************************/

  /** called by the top widget implemented in this class */
  bool         pageHolderKeyPressEvent  ( QKeyEvent * e ) ;
  bool         pageHolderKeyReleaseEvent( QKeyEvent * e ) ;

  /** for the pages : storage and read / write of the parameters : 'read_write' 'launch_method' **/
  bool         transferParameters( int transferId , bool activePageOnly , QString & message ) ;

  /** refresh all the pages */
  virtual void refresh(); // re-implement the 'refresh()' of 'GuiTeam'
  virtual void refresh( int ); // re-implement the 'refresh()' of 'GuiTeam'
  void         refresh( bool activePageOnly );
  void         setIsDirty( int = GuiTeam::FLAG_ALL_DIRTY );

protected :

  /** user pressed a key on the top widget encapsulated in this class
   * .Reimplemented by the derived class.
   *  Return 'true' to have the event treated by the base class */
  virtual bool derivedPageHolderKeyPressEvent  ( QKeyEvent * e ) { return true ; }
  virtual bool derivedPageHolderKeyReleaseEvent( QKeyEvent * e ) { return true ; }

public slots :

  /** tab has changed */
  void slotPageChanged( QWidget * );

private :

  /** id of the page holder and other parameters provided by the constructor */
  int              myId            ;

  /** type of the implemented widget */
  GuiPageHolder::PageHolderType myType ;

  /** implemented widget with the pages */
  QStackedWidget * myStackedWidget  ; // top widget
  QWidget        * myInternalWidget ; // created . parent of below created widgets
  QTabWidget     * myTabWidget      ; // tab widget on the front (PHT_TAB)
  QScrollArea    * myScrollView     ; // scroll view
  QWidget        * myScrollWidget   ;
  QHBoxLayout    * myScrollLayout   ;
  int              myScrollViewX    ; // where to add the next widget (hence width of the viewport)
  int              myScrollViewY    ; // height of the viewport

  /** form that own this page holder */
  GuiForm      & myForm ;

  /** management of the pages */
  std::vector< GuiPage * > myPages       ;
  GuiPage           * myCurrentPage ;

  /** flag to avoid some actions */
  bool             myBeingDeleted ;
} ;





#endif // GUI_WIDGETS_HPP


#include "GuiDisplay.hpp"


const char * GuiFormatHint::CLASS_NAME = "GuiFormatHint" ;




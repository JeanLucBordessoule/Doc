#include "GuiForms.hpp"

#include "MscDebug.hpp"
#include "MscUtl.hpp"

#include "GuiWidgets.hpp"

#include <QAction>
#include <QActionGroup>
#include <QApplication>
#include <QButtonGroup>
#include <QCheckBox>
#include <QComboBox>
#include <QCursor>
#include <QDateTime>
#include <QDesktopWidget>
#include <QDockWidget>
#include <QEvent>
#include <QFrame>
#include <QGroupBox>
#include <QImage>
#include <QHeaderView>
#include <QHideEvent>
#include <QLabel>

// layout
#include <QLayout>
#include <QHBoxLayout>
#include <QVBoxLayout> 
#include <QGridLayout> 

// 
#include <QLineEdit>
#include <QListView>
#include <QListWidget>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QMouseEvent>
#include <QObject> 
#include <QPainter>
#include <QPixmap>
#include <QProgressBar>
#include <QProgressDialog>
#include <QPushButton>
#include <QKeyEvent>
#include <QResizeEvent>
#include <QScrollArea>
#include <QScrollBar>
#include <QShowEvent>
#include <QSlider>
#include <QSpinBox>
#include <QSplitter>
#include <QStackedWidget>
#include <QStatusBar>
#include <QStringList>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QTabWidget>
#include <QTextEdit>
#include <QTimer>
#include <QToolBar>
#include <QToolTip>
#include <QValidator>





const char * GuiTimer        ::CLASS_NAME = "GuiTimer" ;
const char * GuiIntValidator ::CLASS_NAME = "GuiIntValidator";
const char * GuiMovieSlider  ::CLASS_NAME = "GuiMovieSlider";
const char * GuiProgressBar  ::CLASS_NAME = "GuiProgressBar";
const char * GuiMovieSpinBox ::CLASS_NAME = "GuiMovieSpinBox";
const char * GuiMovieTimer   ::CLASS_NAME = "GuiMovieTimer";
const char * GuiAction       ::CLASS_NAME = "GuiAction";
const char * GuiActionGroup  ::CLASS_NAME = "GuiActionGroup";
const char * GuiLayout       ::CLASS_NAME = "GuiLayout";
const char * GuiGroupBox     ::CLASS_NAME = "GuiGroupBox";
const char * GuiLabel        ::CLASS_NAME = "GuiLabel";
const char * GuiPushButton   ::CLASS_NAME = "GuiPushButton";
const char * GuiButtonGroup  ::CLASS_NAME = "GuiButtonGroup";
//const char * GuiRadioButton  ::CLASS_NAME = "GuiRaioButton";
const char * GuiFrame        ::CLASS_NAME = "GuiFrame" ;
const char * GuiCheckBox     ::CLASS_NAME = "GuiCheckBox";
const char * GuiSpinBox      ::CLASS_NAME = "GuiSpinBox";
const char * GuiComboBox     ::CLASS_NAME = "GuiComboBox";
const char * GuiTableTrackingEvent::CLASS_NAME = "GuiTableTrackingEvent" ;

const char * GuiTable        ::CLASS_NAME = "GuiTable" ;
const char * GuiSplitter     ::CLASS_NAME = "GuiSplitter";
const char * GuiTabWidget    ::CLASS_NAME = "GuiTabWidget";
const char * GuiStackedWidget::CLASS_NAME = "GuiStackedWidget";
const char * GuiSeparator    ::CLASS_NAME = "GuiSeparator";
const char * GuiWidget       ::CLASS_NAME = "GuiWidget";
const char * GuiToolBar      ::CLASS_NAME = "GuiToolBar";
const char * GuiPopupMenu    ::CLASS_NAME = "GuiPopupMenu";
const char * GuiViewPopupMenu::CLASS_NAME = "GuiViewPopupMenu";

const char * GuiTextEdit     ::CLASS_NAME = "GuiTextEdit";
const char * GuiListView     ::CLASS_NAME = "GuiListView";




/**************************************************************************************************
************************************************************************************************** 
** UTILITY COMPONENTS 
************************************************************************************************** 
*************************************************************************************************/



//-------------------------------------------------------//
// Timer (encapsulate a QTimer)                          //
//-------------------------------------------------------//



GuiTimer::GuiTimer( QObject * parent , const char * name , int intervalMs ) 
  : QObject(parent)
  , myName(name)
  , myIntervalMs(intervalMs)
  , myTimer(0)
{
    setObjectName(myName);
    if ( myIntervalMs < 100 ) { myIntervalMs = 100 ; }
}


bool GuiTimer::isActive() const 
{
  return myTimer ? myTimer->isActive() : false ;
}


void GuiTimer::setIntervalMs( int intervalMs )
{
  if ( intervalMs < 100 ) { intervalMs = 100 ; }
  if ( myIntervalMs != intervalMs ) {
    myIntervalMs = intervalMs ;
    // change value (could use "QTimer::setInterval")
    if ( isActive() == true ) {
      myTimer->stop();
      myTimer->start(myIntervalMs);
    }
  }
}


void GuiTimer::start()
{
  static const char * METHOD_NAME = "start()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "IsActive %d" , isActive() );
  myCreateTimer();
  if ( myTimer->isActive() == false ) {
    myTimer->start(myIntervalMs);
  }
}


void GuiTimer::stop()
{
  if ( isActive() == true ) {
    myTimer->stop();
  }
}


void GuiTimer::slotTimeOut()
{
  static const char * METHOD_NAME = "slotTimeOut()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "IsActive %d" , isActive() );
  // TODO Send( *this , TimeOut );
}


void GuiTimer::myCreateTimer()
{
  if ( myTimer == 0 ) {
    QString name ;
    name.sprintf( "%sTimer" , GuiUtl::getString(myName) );
    myTimer = new QTimer(this);
    myTimer->setObjectName(name);
    QObject::connect( myTimer , SIGNAL(timeout()), this , SLOT(slotTimeOut()) );    
  }
}



//-------------------------------------------------------//
// Integer Validator  (must derive from "QValidator")    //
//-------------------------------------------------------//


GuiIntValidator::GuiIntValidator( QObject * parent ) 
  : QValidator(parent)
  , myValue(0)
  , myIsPercent(false)
  , myAnswer(QValidator::Acceptable)
  , myCanShowPercent(false)
{
}


QValidator::State GuiIntValidator::validateString( QString s , int pos )
{
  if ( pos == 0 ) {
    myValue     = 0;
    myIsPercent = false;
    myAnswer    = QValidator::Acceptable;
  }
  else {
    QChar c = s.at(pos);
    if ( c.isDigit() == true ) {
      myValue     = c.digitValue();
      myIsPercent = false;
      myAnswer    = QValidator::Acceptable;
    }
    else if ( c == '%' && myIsPercent == false && myCanShowPercent == true ) {
      myIsPercent = true;
      myAnswer    = QValidator::Acceptable;
    }
    else {
      myAnswer    = QValidator::Invalid;
    }
  }
  return myAnswer;
}

QValidator::State GuiIntValidator::validate( QString & s, int & pos ) const
{
  // Let's get rid of the  limitation of the "const" (use a cast).
  ((GuiIntValidator*)this)->validateString( s , pos );
  return myAnswer;
}



//-------------------------------------------------------//
// Movie Slider  (must derive from "QSlider")            //
//-------------------------------------------------------//



GuiMovieSlider::GuiMovieSlider( GuiTeam & wg , int viewId , QWidget * parent , const char * name ) 
  : QSlider(parent) , GuiItem(wg,name,this,GuiItem::WT_MOVIE_SLIDER,viewId) , myInterface(0)
{
  // MUST inherits from it AS it derives the method "mouseReleaseEvent"
  mySlider = this ;
  // cuastomizes
  mySlider->setOrientation( Qt::Horizontal );
  //mySlider->setTickmarks( QSlider::NoTicks );
  mySlider->setMaximumWidth( 50 );
  mySlider->setToolTip("Set the movie slice");
}


void GuiMovieSlider::copyMovieMap()
{
  if ( myInterface != 0 ) {
    int panel = myInterface->sliderUpdateMap( myMovieMap );
    if ( myMovieMap.size() > 1 ) {
      mySlider->blockSignals( true ) ;
      mySlider->setRange( myMovieMap.begin()->first , myMovieMap.rbegin()->first );
      mySlider->setValue( panel );
      mySlider->blockSignals( false );
    }
  }
}


void GuiMovieSlider::setInterface( GuiMovieSlider::Interface * interFace )
{
  if ( myInterface != interFace ) {
    // disconnect
    if ( myInterface != 0 ) {
      // TODO Disconnect( *myInterface , myInterface->PanelChanged , *this , &GuiMovieSlider::copyMovieMap );
    }
    myInterface = interFace ; 
    // connect
    if ( myInterface != 0 ) {
      // TODO Connect( *myInterface , myInterface->PanelChanged , *this , &GuiMovieSlider::copyMovieMap );
    }
  }
}


void GuiMovieSlider::mouseReleaseEvent( QMouseEvent * e )
{ 
  QSlider::mouseReleaseEvent(e);
  if ( myInterface != 0 ) {
    myInterface->sliderUpdateCurrentView( mySlider->value() , true );
  }
}



//-------------------------------------------------------//
// Encapsulated Progress Bar                             //
//-------------------------------------------------------//


GuiProgressBar::GuiProgressBar( QStatusBar * parent ) : QObject(parent)
{
  myGuiForm   = 0 ;
  myStatusBar = parent ;
  myWidget    = 0 ;
  myInitialize();
}


GuiProgressBar::GuiProgressBar( GuiForm * parent ) : QObject(parent ? parent->getForm() : 0)
{
  myGuiForm   = parent ;
  myStatusBar = 0 ;
  myWidget    = 0 ;
  myInitialize();
}


GuiProgressBar::~GuiProgressBar()
{
  static const char * METHOD_NAME = "~GuiProgressBar()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "is used" );
}


void GuiProgressBar::slotCancelButton()
{
  static const char * METHOD_NAME = "slotCancelButton()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "%d -> %d" , myDoProgress , false );
  myDoProgress = false ;
}


void GuiProgressBar::myInitialize()
{
  static const char * METHOD_NAME = "myInitialize()" ;
  myProgressBar  = 0 ;
  myProgressDlg  = 0 ;
  myCancelButton = 0 ;
  myHasCancel    = false ;

  // it's turned to 'false' by the 'Cancel' button 
  // and it's initialized in 'indicateProgressStart()'
  myDoProgress   = true ;
  myPercentage   = -1   ;

  // create GUI
  if ( myGuiForm != 0 ) {
    if ( myGuiForm->getMainWindow() != 0 ) {
      myStatusBar = myGuiForm->getMainWindow()->statusBar();
    }
    else {
      myWidget = myGuiForm->getForm();
    }
  }
  // add it to the status bar
  if ( myStatusBar != 0 ) {
    myProgressBar = new QProgressBar( myStatusBar );
    // customize
    myProgressBar->setMinimum(0);
    myProgressBar->setMaximum(100);
    myProgressBar->setTextVisible(false);
    // myProgressBar->setPercentageVisible ( false );

    myProgressBar->setSizePolicy( QSizePolicy::Fixed , QSizePolicy::Preferred );
    myStatusBar->addWidget( myProgressBar , 0 );
    // cancel button
    myCancelButton = new QPushButton( "Stop" , myStatusBar );
    myCancelButton->setObjectName("GuiProgressBarButton");
    myStatusBar->addWidget( myCancelButton , 0 );
  }
  // use a QProgressDialog
  else {
    myProgressDlg = new QProgressDialog( myWidget );
    // customize
    myProgressDlg->setMinimum(0);
    myProgressDlg->setMaximum(100);
    myProgressDlg->setAutoReset( false );
    //
    myProgressDlg->setWindowTitle("Operation in progress...");
    myProgressDlg->setModal(true);
    myProgressDlg->setMinimumDuration( 2000 );
    myCancelButton = new QPushButton( "Stop" , myProgressDlg );
    myCancelButton->setObjectName("GuiProgressBarButton");
    myProgressDlg->setCancelButton( myCancelButton );    
  }
  // add callback to the button
  QObject::connect( myCancelButton , SIGNAL( clicked() ) , this , SLOT( slotCancelButton() ) );
}


// use of the Progress bar
void  GuiProgressBar::indicateProgressStart( bool stopButton , const char * message , const char * title )
{
  // reset . turned to 'false' if the user press 'Cancel'
  myDoProgress = true ;
  myMessage    = ""   ;
  myPercentage = -1   ;
  myHasCancel  = stopButton ;

  // progress bar
  if ( myProgressBar != 0 ) {
    myProgressBar->setValue( 0 );
    myProgressBar->show();
    if ( message != 0 ) { myStatusBar->showMessage( message ); } // delay could be mentionned
    if ( myHasCancel == true ) {
      myCancelButton->show();
    }
    else {
      myCancelButton->hide();
    }
  }
  // progress dialog
  if ( myProgressDlg != 0 ) {
    myProgressDlg->reset();
    myProgressDlg->setValue(0);
    if ( message != 0 ) { myProgressDlg->setLabelText( message ); }
    if ( title   != 0 ) { myProgressDlg->setWindowTitle(title); }
    myCancelButton->setEnabled( myHasCancel );
    myProgressDlg->show();
  }  
}


bool  GuiProgressBar::indicateProgress( float percentage , const char * message )
{
  static const char * METHOD_NAME = "indicateProgress()" ;
  // correct the percentage . Move every 5 %
  int numberOfSteps = (int)int(percentage + 0.5f);
  numberOfSteps = 5 * (numberOfSteps / 5);
  if ( numberOfSteps <=   0 ) numberOfSteps =   1;
  if ( numberOfSteps >= 100 ) numberOfSteps =  99;
 
  // progress (if possible)
  if ( myProgressBar != 0 ) {
    if ( myPercentage != numberOfSteps ) {
      myProgressBar->setValue( myPercentage );
    }
    if ( message != 0 && myMessage != message ) {
      myStatusBar->showMessage( message );// delay can be specified
    } 
  }
  if ( myProgressDlg != 0 ) {
    if ( myPercentage != numberOfSteps ) {
      myProgressDlg->setValue( myPercentage );
    }
    if ( message != 0 && myMessage != message ) {
      myProgressDlg->setLabelText( message );
    }
  }

  // process event . It will consider the "Cancel" event
  // 24 March 2015 : crash identified here .
  if ( myHasCancel == true ) {
    GuiUtl::processEvents( CLASS_NAME , METHOD_NAME );
  }

  // done
  myPercentage = numberOfSteps ;
  myMessage    = message ;
  return myDoProgress ;
}


void  GuiProgressBar::indicateProgressEnd( const char * message )
{
  // progress bar
  if ( myProgressBar != 0 ) {
    myProgressBar->setValue( 100 );
    if ( message != 0 ) { myStatusBar->showMessage( message ); } // delay can be specified
    myCancelButton->hide();
    myProgressBar->hide();
  }
  // progress dialog
  if ( myProgressDlg != 0 ) {
    myProgressDlg->setValue( 100 );
    myProgressDlg->hide();
  }
}



//-------------------------------------------------------//
// Movie Spin Box Movie                                  //
//-------------------------------------------------------//



GuiMovieSpinBox::GuiMovieSpinBox( GuiTeam & wg , int viewId , GuiMovieSlider * slider ,
                                  QWidget * parent , const char * name )
  : QObject(parent)
  , GuiItem(wg,name,this,GuiItem::WT_MOVIE_SPINBOX,viewId)
  , myInterface(0)
  , myConsiderText(false)
  , myCanShowPercent(false)
{
  static const char * METHOD_NAME = "GuiMovieSpinBox()" ;

  // created if needed
  mySpinBox = new QSpinBox(parent) ;
  mySpinBox->setObjectName(name);
  myInitializeFont( mySpinBox );

  // provided slider
  mySlider  = slider  ;
  MscDg::check( CLASS_NAME , METHOD_NAME , (mySlider != 0) , "slider is null" );

  // customizes
  myValidator = 0 ;
  // Qt4: qt3to4: validator replaced by setMinimum and setMaximum
  // myValidator = new GuiIntValidator( this );
  // mySpinBox->setValidator(myValidator);

  mySpinBox->setButtonSymbols( QSpinBox::PlusMinus );
  mySpinBox->setMaximum( +9999 ); /*Qt4*/
  mySpinBox->setMinimum( -9999 ); /*Qt4*/
  mySpinBox->setToolTip("Set the movie slice");
  QObject::connect( mySpinBox , SIGNAL( valueChanged(int) ) , this , SLOT( slotValueChanged(int) ) );
  if ( mySlider != 0 ) {
    QObject::connect( mySlider->getSlider() , SIGNAL( valueChanged(int) ) , this , SLOT( slotSliderValueChanged(int) ) );
  }
}




void GuiMovieSpinBox::setInterface( GuiMovieSlider::Interface * interFace )
{
  if ( myInterface != interFace ) {
    // disconnect
    if ( myInterface != 0 ) {
      // TODO Disconnect( *myInterface , myInterface->PanelChanged , *this , &GuiMovieSpinBox::copyMovieMap );
    }
    myInterface = interFace ; 
    // connect
    if ( myInterface != 0 ) {
      // TODO Connect( *myInterface , myInterface->PanelChanged , *this , &GuiMovieSpinBox::copyMovieMap );
    }
  }
}


void GuiMovieSpinBox::copyMovieMap()
{
  if ( myInterface != 0 ) {
    int panel = myInterface->sliderUpdateMap( myMovieMap );
    bool canShowPercent = false;
    if ( myMovieMap.size() > 1  ) {
      mySpinBox->blockSignals( true ) ;
      mySpinBox->setRange( myMovieMap.begin()->first , myMovieMap.rbegin()->first );
      mySpinBox->setValue( panel );
      mySpinBox->blockSignals( false );
      for ( auto iter=myMovieMap.begin() ; iter != myMovieMap.end() ; ++iter ) {
        if ( iter->first <= 0 ) { 
          // no percent.
          canShowPercent = false;
          break;
        }
        if ( iter->second.second != 0.0f ) {
          canShowPercent = true;
          break;
        }
      }
      if ( myCanShowPercent != canShowPercent ) {
        myCanShowPercent = canShowPercent;
        if ( myValidator != 0 ) {
          myValidator->myCanShowPercent = myCanShowPercent;
        }
        if ( myCanShowPercent == true ) {
          mySpinBox->setMinimumSize( QSize( 80, 0 ) );
        }
      }
      mySpinBox->setValue( mySpinBox->value() );
    }
  }
}


bool GuiMovieSpinBox::setCurrentValue( int pos )
{
  bool valueHasChanged = false ;
  if ( mySlider != 0 ) {
    if ( pos != mySlider->value() ) valueHasChanged = true ;
    mySlider->blockSignals( true  );
    mySlider->setValue( pos );
    mySlider->blockSignals( false );
  }
  if ( pos != mySpinBox->value() ) valueHasChanged = true ;
  mySpinBox->blockSignals( true  );
  mySpinBox->setValue( pos );
  mySpinBox->blockSignals( false );
  return valueHasChanged ;
}


void GuiMovieSpinBox::slotValueChanged( int pos )
{
  // make sure both have the same value
  bool valueHasChanged = setCurrentValue( pos );
  // inform the owner
  if ( myInterface != 0 ) {
    myInterface->sliderUpdateCurrentView( pos , true );
  }
}


void GuiMovieSpinBox::slotSliderValueChanged( int pos )
{
  // make sure both have the same value
  bool valueHasChanged = setCurrentValue( pos );
  // inform the owner
  if ( myInterface != 0 ) {
    myInterface->sliderUpdateCurrentView( pos , false );
  }
}


int GuiMovieSpinBox::mapTextToValue( bool * ok )
{
  // Remark; Work done by the validator could be here:
  // Turning 50% or 12.
  // MscDg::trace( CLASS_NAME , "mapTextToValue()" , "Text:'%s'" , GuiUtl::getString(text()) );
  *ok = true;
  myConsiderText = true;
  return 0;
}


QString GuiMovieSpinBox::mapValueToText( int panel )
{
  QString msg;
  if ( myMovieMap.size() < 2 ) {
    msg.sprintf("%d",panel);
    return msg;
  }
  int min = myMovieMap. begin()->first;
  int max = myMovieMap.rbegin()->first; 
  
  if ( min != mySpinBox->minimum() || max != mySpinBox->maximum() ) {
    mySpinBox->setRange(min,max);
  }
  int range = (max-min);
  if ( myConsiderText == true && myValidator != 0 ) {
    if ( myValidator->myIsPercent == true ) {
      panel = MscUtl::toInt( min + (0.01f * myValidator->myValue * range) );
    }
    else {
      panel = myValidator->myValue ;  
    }
  }
  if ( panel < min ) panel = min;
  if ( panel > max ) panel = max;
  if ( myConsiderText ) {
    myConsiderText = false;
    mySpinBox->setValue(panel);
    return msg;
  }
  float percent = 100.0f;
  auto iter=myMovieMap.find(panel);
  if ( iter != myMovieMap.end() ) { percent = iter->second.second; }
  if ( myCanShowPercent == true ) {
    msg.sprintf( "%.1f%% - %d", percent , panel );
  }
  else {
    msg.sprintf( "%d", panel );
  }
  return msg;
}



//-------------------------------------------------------//
// Movie Facilities                                      //
//-------------------------------------------------------//



GuiMovieTimer::GuiMovieTimer( GuiMovieTimer::Interface & interFace , QWidget * parent , const char * name ) 
: QObject( parent ) , myInterface( interFace )
{
  setObjectName(name);
  myMovieTimer = 0  ;
  myMovieState = GuiMovieTimer::MOVIE_STOPPED ;
  myMovieDelay = 0 ;
  myIsBusy     = false ;
}


GuiMovieTimer::~GuiMovieTimer()
{
  if ( myMovieTimer != 0 && myMovieTimer->isActive() == true) {
    myMovieTimer->stop();
  }
}


void GuiMovieTimer::changeMovieTimerState( GuiMovieTimer::MovieEventType state )
{
  static const char * METHOD_NAME ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "State %d->%d"  , myMovieState , state );

  // nothing to do (same state)
  if ( myMovieState == state ) {
    if ( (myMovieState == GuiMovieTimer::SLICE_PREVIOUS ||
          myMovieState == GuiMovieTimer::SLICE_NEXT) ) {
      // do not return and should proceed to show the next or previous slice
    } else {
      return;
    }
  }

  
  // change of state
  switch ( state ) {

    // *** STOP THE TIMER
  case GuiMovieTimer::MOVIE_STOPPED  :
  case GuiMovieTimer::MOVIE_CLEAR    :
  case GuiMovieTimer::SLICE_PREVIOUS :
  case GuiMovieTimer::SLICE_NEXT     :
    {
      // stop the timer
      if ( myMovieTimer != 0 && myMovieTimer->isActive() == true ) {
        myMovieTimer->stop();
        if ( myMovieState != GuiMovieTimer::MOVIE_STOPPED ) {
          myInterfaceMovieEvent( GuiMovieTimer::MOVIE_STOPPED );
        }
      }
      // remove the busy cursor
      if ( myIsBusy == true ) {
        myIsBusy = false ;
        myInterfaceMovieEvent( GuiMovieTimer::CURSOR_IDLE );
      } 
      // inform of the new state
      myInterfaceMovieEvent( state );
    } break;

    // *** TIMER IS REQUIRED
  case GuiMovieTimer::MOVIE_NEXT     :
  case GuiMovieTimer::MOVIE_PREVIOUS :
  case GuiMovieTimer::MOVIE_CYCLE    :
    {
      // create the timer
      if ( myMovieTimer == 0 ) {
        myMovieTimer = new QTimer( this );
        myMovieTimer->setObjectName("GuiMovieQtTimer");
        QObject::connect( myMovieTimer , SIGNAL(timeout()) , this , SLOT(slotMovieTimeOut()) );
      }
      // busy cursor
      if ( myIsBusy == false ) {
        myIsBusy = true ;
        myInterfaceMovieEvent( GuiMovieTimer::CURSOR_BUSY ) ;
      }
      // start the movie
      if ( myMovieTimer->isActive() == false ) {
        // movie is starting
        myInterfaceMovieEvent( GuiMovieTimer::MOVIE_START ) ;
        // start the timer
        myMovieTimer->start( 10 + myMovieDelay );
      }
      // it's informed at the next time-out => slotMovieTimeOut()
    } break;
  case GuiMovieTimer::MOVIE_START :
  case GuiMovieTimer::CURSOR_IDLE :
  case GuiMovieTimer::CURSOR_BUSY :
  default :
    MscDg::error( CLASS_NAME , METHOD_NAME , "State %d->%d not considered"  , myMovieState , state );
  }
  // save the new state
  myMovieState = state;
}


void GuiMovieTimer::slotMovieTimeOut()
{
  bool result = false ;
  switch ( myMovieState ) {
  case GuiMovieTimer::MOVIE_NEXT     :
  case GuiMovieTimer::MOVIE_PREVIOUS :
  case GuiMovieTimer::MOVIE_CYCLE    :
    result = myInterfaceMovieEvent( myMovieState );
    break;
  }
  // can't perform the action : end
  if ( result == false ) {
    changeMovieTimerState( GuiMovieTimer::MOVIE_STOPPED );
  }
}


void GuiMovieTimer::changeMovieDelay( int delay )
{
  if ( delay < 0 ) delay = -delay;
  if ( myMovieDelay != delay ) {
    myMovieDelay = delay ;
    if ( myMovieTimer != 0 && myMovieTimer->isActive() == true ) {
      myMovieTimer->stop();
      myMovieTimer->start( 10 + myMovieDelay );
    }
  }
}


bool GuiMovieTimer::myInterfaceMovieEvent( GuiMovieTimer::MovieEventType event )
{
  return myInterface.derivedMovieEvent( event );
}



/**************************************************************************************************
************************************************************************************************** 
** "Action" and "Group of Actions"
************************************************************************************************** 
*************************************************************************************************/



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiAction                                //
//-------------------------------------------------------------------------------------//



GuiAction::GuiAction( GuiTeam & wg , QObject * parent , const GuiAction::CreateInfo & createInfo )
  : QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_ACTION,createInfo.myId)
{
  myAction = new QAction(parent) ;
  myAction->setObjectName(createInfo.myName) ;
  // labels
  if ( createInfo.myText != 0 ) {
    myAction->setText( createInfo.myText );
  }
  if ( createInfo.myMenuText != 0 ) {
    myAction->setIconText( createInfo.myMenuText );
  }
  if ( createInfo.myAccelText != 0 ) {
    myAction->setShortcut( QKeySequence( createInfo.myAccelText ) );
  }
  if ( createInfo.myToolTip != 0 ) {
    myAction->setToolTip( createInfo.myToolTip );
  }
  if ( createInfo.myIconName != 0 ) {
    myIconName = createInfo.myIconName ;
    updateIcon() ;
  }
  // miscellaneous
  myAction->setCheckable( createInfo.myIsToggle );
  // calbacks
  QObject::connect( myAction , SIGNAL( activated() ) , this , SLOT( slotActivated() ) ); 
}


GuiAction::~GuiAction()
{
}


void GuiAction::updateIcon() 
{
  if ( myIconName.isEmpty() == false ) {
    myAction->setIcon( GuiUtl::getIcon( myIconName , myFormatHint.myPixmapPercentage ) );
  }
}


void GuiAction::slotActivated()
{
  // send event
  GuiEvent e( this , GuiEvent::ET_ACTIVATED );
  if ( myAction->isCheckable() == true ) { e.setBool( myAction->isChecked() ); }
  // if ( myAction->isToggleAction() == true ) { e.setBool( myAction->isOn() ); }
  myTeam.receiveEvent( e );
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiActionGroup                           //
//-------------------------------------------------------------------------------------//



GuiActionGroup::GuiActionGroup( GuiTeam & wg , QWidget * parent , const GuiActionGroup::CreateInfo & createInfo )
  : QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_ACTION_GROUP,createInfo.myId)
{
  // menu
  myMenu = new QMenu( parent );
  myMenu->setObjectName( createInfo.myName );
  // action group
  myActionGroup = 0 ;
  if ( createInfo.myIsExclusive == true ) {
    myActionGroup = new QActionGroup( myMenu );
  }
  // customize
  if ( createInfo.myText != 0 ) {
    setAccelText( createInfo.myText );
  }
  if ( createInfo.myMenuText != 0 ) {
    setString( createInfo.myMenuText , false );
  }
  if ( createInfo.myAccelText != 0 ) {
    setAccelText( createInfo.myAccelText );
  }
  if ( createInfo.myToolTip != 0 ) {
    myMenu->setToolTip( createInfo.myToolTip );
  }
  if ( createInfo.myIconName != 0 ) {
    myIconName = createInfo.myIconName ;
    updateIcon() ;
  }
  // actions
  for ( int i=0 ; i < createInfo.myNumberOfActions ; ++i ) {
    GuiAction * guiAction = new GuiAction( wg , myMenu , createInfo.myActionCreateInfos[i] ) ;
    QAction * menuAction = guiAction->getAction();
    guiAction->setMenuAction( menuAction );
    myMenu->addAction( menuAction );
    if ( myActionGroup != 0 ) { myActionGroup->addAction( menuAction ); }
  }
  // callbacks
  if ( createInfo.myCallbackTypes & GuiEvent::ET_ACTIVATED ) {
    QObject::connect( myMenu , SIGNAL( aboutToShow() ) , this , SLOT( slotActivated() ) ); 
  }
  if ( createInfo.myCallbackTypes & GuiEvent::ET_SELECTION ) {
    QObject::connect( myMenu , SIGNAL( triggered(QAction*) ) , this , SLOT( slotSelectedAction(QAction*) ) );
  }
}


GuiActionGroup::~GuiActionGroup()
{
}


void GuiActionGroup::updateIcon()
{
  if ( myIconName.isEmpty() == false ) {
    myMenu->setIcon( GuiUtl::getIcon( myIconName , myFormatHint.myPixmapPercentage ) );
  }
}


void GuiActionGroup::setAccelText( const char * c )
{
  QKeySequence keySequence( c );
  // myMenu->setAccel( QKeySequence( // TODO
}


void GuiActionGroup::slotActivated()
{
  // send event
  GuiEvent e( this , GuiEvent::ET_ACTIVATED );
  myTeam.receiveEvent( e );
}


void GuiActionGroup::slotSelectedAction( QAction * a )
{
  // send event
  GuiEvent e( this , GuiEvent::ET_SELECTION );
  e.setAction(a);
  myTeam.receiveEvent( e );
}



/**************************************************************************************************
************************************************************************************************** 
** "ToolBar"   "MenuBar"   "PopupMenu"
************************************************************************************************** 
*************************************************************************************************/



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER :  GuiToolBar                              //
//-------------------------------------------------------------------------------------//



bool GuiToolBar::testIfToolBarIsToBeCreated( GuiWidgetGroup & group , const GuiToolBar::CreateInfo & createInfo )
{
  for ( int i=0 ; i < createInfo.myNumberOfIds ; ++i ) {
    int itemId = createInfo.myIds[i] ;
    if ( itemId != GuiItem::ID_SEPARATOR ) {
      if ( group.isTheItemVisible( itemId ) == true ) {
        return true ;
      }
    }
  }
  return false ;
}


GuiToolBar::GuiToolBar( GuiWidgetGroup & wg , QMainWindow * parent , const GuiToolBar::CreateInfo & createInfo )
  : QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_TOOLBAR,createInfo.myId)
{
  // create if not provided
  myToolBar = new QToolBar( parent );
  myToolBar->setObjectName( createInfo.myName ) ;
  parent->addToolBar(myToolBar);
  myInitializeFont( myToolBar );
  // customize
  if ( createInfo.myText != 0 ) {
    myToolBar->setWindowTitle( createInfo.myText );
  }
  if ( createInfo.myToolTip != 0 ) {
    myToolBar->setToolTip( createInfo.myToolTip );
  }
  // Qt4 NOT AVAILABLE TODO // myToolBar->setHorizontalStretchable( createInfo.myIsStretchable );
  // index to count the number of non-separator since last separator 
  // avoid to have useless separator
  int numberOfItemsSinceLastSeparator = 0 ;
  for ( int i=0 ; i < createInfo.myNumberOfIds ; ++i ) {
    // add it
    wg.addExistingItemToCaller( this , createInfo.myIds[i] , numberOfItemsSinceLastSeparator ) ;
  }
  // color (don't print out a message)
  GuiItem::setBackgroundColor( createInfo.myRed , createInfo.myGreen , createInfo.myBlue , false );
  // callbacks
  if ( createInfo.myCallbackTypes != 0 ) {
    //
  }
}


void GuiToolBar::updateFont()
{
  GuiItem::updateFont( myToolBar );
  for ( auto iter=myItems.begin() ; iter != myItems.end() ; ++iter ) {
    iter->second->updateFont();
  }
}


void GuiToolBar::updateIcon()
{
  for ( auto iter=myItems.begin() ; iter != myItems.end() ; ++iter ) {
    iter->second->updateIcon();
  }
}


bool GuiToolBar::addItem( GuiItem * guiItem )
{
  static const char * METHOD_NAME = "addItem()" ;
  if ( guiItem == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Toolbar %d  Item is null" ,  getId() );
    return false ;
  }
  // already present
  if ( myItems.find( guiItem->getId() ) != myItems.end() ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "Toolbar %d  Item %d is already present" ,
                 getId() , guiItem->getId() );
    // make it visible (it might have been hidden)
    if ( guiItem->getToolBarAction() != 0 ) { guiItem->getToolBarAction()->setVisible(true); }
    return false;
  }
  // add it to the toolbar
  QAction * actionInToolBar = 0 ;
  guiItem->setFormatHint( myFormatHint );
  if ( guiItem->isAction() == true ) {
    actionInToolBar = guiItem->getAction() ;
    myToolBar->addAction(guiItem->getAction());
  }
  else if ( guiItem->isWidget() == true ) {
    actionInToolBar = myToolBar->addWidget(guiItem->getWidget());
  }
  else if ( guiItem->isSeparator() == true ) {
    actionInToolBar = myToolBar->addSeparator();
    dynamic_cast<GuiSeparator*>(guiItem)->setToolBar( this );
  }
  // store ...
  if ( actionInToolBar != 0 ) {
    guiItem->setToolBarAction(actionInToolBar);
  }
  // 
  myItems[ guiItem->getId() ] = guiItem ;
  return true ;
}


bool GuiToolBar::modifyVisibility()
{
  int numberOfVisibleItems = 0 ;
  for ( auto iter=myItems.begin() ; iter != myItems.end() ; ++iter ) {
    if ( iter->second == 0 ) continue ;
    // ignore the separators...
    if ( iter->second->isSeparator() == false && iter->second->getIsVisible() == true ) {
      numberOfVisibleItems += 1 ;
    }
  }
  setIsVisible( numberOfVisibleItems != 0 );
  return ( numberOfVisibleItems != 0 );
}


//-------------------------------------------------------------------------------------//
//                             EVENT SENDER :  GuiPopupMenu                            //
//-------------------------------------------------------------------------------------//


GuiPopupMenu::GuiPopupMenu( GuiWidgetGroup & wg , QWidget * parent , QMenuBar * menubar ,
                            const GuiPopupMenu::CreateInfo & createInfo )
: QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_POPUPMENU,createInfo.myId)
{
  // create it
  QString title( createInfo.myText ? createInfo.myText : "" );
  // icon
  if ( false ) { // createInfo.myIcon != 0 ) {
      myPopupMenu = menubar->addMenu( title );
  }
  else {
      myPopupMenu = menubar->addMenu( title );
  }
  myPopupMenu->setObjectName(createInfo.myName) ;
  myInitializeFont( myPopupMenu );

  // customize
  if ( createInfo.myToolTip != 0 ) {
    myPopupMenu->setToolTip( createInfo.myToolTip );
  }
  int numberOfItemsSinceLastSeparator = 0 ;
  for ( int i=0 ; i < createInfo.myNumberOfIds ; ++i ) {
    wg.addExistingItemToCaller( this , createInfo.myIds[i] , numberOfItemsSinceLastSeparator ) ;
  }
  // callbacks
  QObject::connect( myPopupMenu , SIGNAL( aboutToShow()  ) , this , SLOT( slotAboutToShow()  ) ) ;
  if ( createInfo.myCallbackTypes != 0 ) {
    //
  }
}


void GuiPopupMenu::updateFont()
{
  GuiItem::updateFont( myPopupMenu );
  for ( auto iter=myItems.begin() ; iter != myItems.begin() ; ++iter ) {
    iter->second->updateFont();
  }
  myInitializeFont( myPopupMenu );
}


void GuiPopupMenu::slotAboutToShow()
{
  // send event
  GuiEvent e( this , GuiEvent::ET_ABOUT_TO_SHOW );
  myTeam.receiveEvent( e );
}


bool GuiPopupMenu::addItem( GuiItem * guiItem )
{
  static const char * METHOD_NAME = "addItem()" ;
  if ( guiItem == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "PopupMenu %d  Item is null" ,  getId() );
    return false ;
  }
  // already present
  if ( myItems.find( guiItem->getId() ) != myItems.end() ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "PopupMenu %d  Item %d is already present" ,
                 getId() , guiItem->getId() );
    // make it visible (it might have been hidden)
    if ( guiItem->getMenuAction() != 0 ) { guiItem->getMenuAction()->setVisible(true); }
    return false;
  }  
  // set correct font
  guiItem->setFormatHint( myFormatHint );
  // add it to the popup menu
  QAction * actionInMenu = 0 ;
  // action
  if ( guiItem->isAction() == true ) {
    actionInMenu = guiItem->getAction();
    myPopupMenu->addAction( actionInMenu );
  }
  // sub-menu
  else if ( guiItem->getWidgetType() == GuiItem::WT_ACTION_GROUP ) {
    actionInMenu = myPopupMenu->addMenu( dynamic_cast<GuiActionGroup*>(guiItem)->getMenu() );
  }
  // is it used ???
  else if ( guiItem->isWidget() == true ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "PopupMenu %d:  Widget %d is added ... don't know how to deal with it" ,
                 getId() , guiItem->getId() );
    QPoint p ;
    guiItem->getWidget()->setParent( myPopupMenu ) ; // reparent( myPopupMenu , p , true ) ;
  }
  else if ( guiItem->isSeparator() == true ) {
    actionInMenu = myPopupMenu->addSeparator();
    dynamic_cast<GuiSeparator*>(guiItem)->setMenu( this );
  }
  else {
    MscDg::error( CLASS_NAME , METHOD_NAME , "PopupMenu %d:  Item %d undefined type" ,
                 getId() , guiItem->getId() );
  }
  // store ...
  if ( actionInMenu != 0 ) {
    guiItem->setMenuAction(actionInMenu);
  }
  //
  myItems[ guiItem->getId() ] = guiItem ;
  return true ;
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiPopupMenu                             //
//-------------------------------------------------------------------------------------//



GuiViewPopupMenu::GuiViewPopupMenu( GuiTeam & wg , QWidget * parent , int viewId ,
                                        const GuiViewPopupMenu::SimpleMenu & menu )
: QObject(parent) , GuiItem(wg,"GuiViewPopupMenu",this,GuiItem::WT_VIEW_POPUPMENU,viewId)
{
  // inherits from
  myPopupMenu = new QMenu(parent) ;
  // customize
  QObject::connect( myPopupMenu , SIGNAL( aboutToShow()  ) , this , SLOT( slotAboutToShow()  ) ) ;
  QObject::connect( myPopupMenu , SIGNAL( activated(int) ) , this , SLOT( slotActivated(int) ) ) ;
  myNestedMenus[ myNestedMenus.size() ] = myPopupMenu ;
  for ( auto iter=menu.cbegin() ; iter != menu.cend() ; ++iter ) {
    createMenuItem( myPopupMenu , &(*iter) ) ;
  }
}


GuiViewPopupMenu::MenuItem::MenuItem( int id , const char *label , const char *icon , std::vector< MenuItem > *subMenu )
: myId(id) 
, myLabel(label) 
, myIcon(icon) 
{
  if ( subMenu ) mySubMenu=*subMenu ; 
}


GuiViewPopupMenu::MenuItem::MenuItem( const GuiViewPopupMenu::MenuItem & m ) 
: myId     ( m.myId      )
, myLabel  ( m.myLabel   )
, myIcon   ( m.myIcon    )
, mySubMenu( m.mySubMenu )
{
}


const GuiViewPopupMenu::MenuItem & GuiViewPopupMenu::MenuItem::operator= ( const GuiViewPopupMenu::MenuItem & m ) 
{ 
  if ( &m != this ) {
    myId      = m.myId      ;
    myLabel   = m.myLabel   ;
    myIcon    = m.myIcon    ;
    mySubMenu = m.mySubMenu ;
  } 
  return *this; 
}


bool GuiViewPopupMenu::MenuItem::operator==( const MenuItem & m )
{ 
  if ( &m == this ) return true ;
  if ( myId    != m.myId    ) return false ;
  if ( myLabel != m.myLabel ) return false ;
  if ( myIcon  != m.myIcon  ) return false ;
  int numberOfItems = mySubMenu.size() ;
  if ( numberOfItems != m.mySubMenu.size() ) return false ;
  for ( int i=0 ; i < numberOfItems ; ++i ) {
    if ( mySubMenu[i] != m.mySubMenu[i] ) return false ;
  }
  return true ;
}


bool GuiViewPopupMenu::MenuItem::operator!= ( const MenuItem & m )
{
  return ( (*this == m) ? false : true );
}


GuiViewPopupMenu::~GuiViewPopupMenu()
{
}


void GuiViewPopupMenu::popupAtCursorLocation()
{
  myPopupMenu->exec( QCursor::pos() ) ;
}



void  GuiViewPopupMenu::createMenuItem( QMenu * popupMenu , const GuiViewPopupMenu::MenuItem * menuItem )
{
  // created items
  QAction * action = 0 ;
  QMenu   * subPopupMenu = 0 ;
  // submenu
  if ( menuItem->getId() == GuiViewPopupMenu::SUB_MENU ) {

    // move below in the hierarchy, create the sub-menu and add it to the parent
    QString text( menuItem->getLabel().isEmpty()==false ? menuItem->getLabel() : "Sub-menu" );
    if ( menuItem->getIcon() != 0 ) {
      subPopupMenu = popupMenu->addMenu( GuiUtl::getIcon(menuItem->getIcon(), myFormatHint.myPixmapPercentage) , text );
    }
    else {
      subPopupMenu = popupMenu->addMenu( text );
    }
    subPopupMenu->setObjectName( "mySimpleMenu" ) ;
    subPopupMenu->menuAction()->setData( QVariant(menuItem->getId()) );
    QObject::connect( subPopupMenu , SIGNAL( aboutToShow()  ) , this , SLOT( slotAboutToShow()  ) ) ;
    QObject::connect( subPopupMenu , SIGNAL( activated(int) ) , this , SLOT( slotActivated(int) ) ) ;
    myNestedMenus[ myNestedMenus.size() ] = subPopupMenu ;

    // create the items that are in the menu
    const GuiViewPopupMenu::SimpleMenu & menu = menuItem->getSubMenu() ;
    for ( auto iter=menu.cbegin() ; iter != menu.cend() ; ++iter ) {
      createMenuItem( subPopupMenu , &(*iter) );
    }
  }
  // separator
  else if ( menuItem->getLabel() == 0 || menuItem->getId() == GuiViewPopupMenu::SEPARATOR_ITEM ) {
    action = popupMenu->addSeparator() ;
  }
  // label
  else if ( menuItem->getId() == GuiViewPopupMenu::LABEL_ITEM ) {
    action = popupMenu->addAction( menuItem->getLabel() );
  }
  // icon
  else if ( menuItem->getIcon() != 0 ) {
    QString text( menuItem->getLabel().isEmpty()==false ? menuItem->getLabel() : "Menu-Item" );
    action = popupMenu->addAction( GuiUtl::getIcon(menuItem->getIcon(), myFormatHint.myPixmapPercentage) , text );
  }
  // text
  else {
    action = popupMenu->addAction( menuItem->getLabel() );
  }
  // add the user data in the created item
  if ( action != 0 ) { action->setData( QVariant(menuItem->getId()) ); }
}



// static
static QAction * MenuItemHasId( QMenu * menu , int itemId , bool & isMenuItem )
{
    bool isOk = false ;
    // it's the menu itself
    QVariant userData = menu->menuAction()->data();
    if ( userData.toInt(&isOk) == itemId && isOk == true ) {
        isMenuItem = true ;
        return menu->menuAction() ;
    }
    // analyse the items of the menu
    QList< QAction* > actions = menu->actions();
    for ( auto iter=actions.cbegin() ; iter != actions.cend() ; ++iter ) {
        userData = (*iter)->data();
        if ( userData.toInt(&isOk) == itemId && isOk == true ) {
            isMenuItem = false ;
            return (*iter);
        }
    }
    // not present
    return nullptr;
}



bool  GuiViewPopupMenu::enableItemWithId( int itemId , bool b )
{
  MscDg::trace( CLASS_NAME , "enableItemWithId()" , "ItemId:%d Bool:%d" , itemId , b );
  // sub-menus
  for ( auto iter=myNestedMenus.begin() ; iter != myNestedMenus.end() ; ++iter ) {
      // find it
      bool isMenuItem = false ;
      QAction * action = MenuItemHasId( iter->second , itemId , isMenuItem );
      if ( action != nullptr ) {
        // menu itself
        if ( isMenuItem == true ) {
            action->setEnabled(b);
        }
        // item
        else {
            action->setEnabled(b);
        }
      return true ;
    }
  }
  // not found
  return false ;
}


bool GuiViewPopupMenu::setString( int itemId , const QString & text )
{
  MscDg::trace( CLASS_NAME , "setString()" , "ItemId:%d Text:%s" , itemId , GuiUtl::getString(text) );
  // sub-menus
  for ( auto iter=myNestedMenus.begin() ; iter != myNestedMenus.end() ; ++iter ) {
    // find it
    bool isMenuItem = false ;
    QAction * action = MenuItemHasId( iter->second , itemId , isMenuItem );
    if ( action != nullptr ) {
      // menu itself
      if ( isMenuItem == true ) {
        action->setText(text);
      }
      // item
      else {
        action->setText(text);
      }
      // done
      return true ;
    }
  }
  MscDg::error( CLASS_NAME , "setString()" , "ItemdId:%d Can't set text:'%s'" , itemId , GuiUtl::getString(text) );
  return false ;
}


void  GuiViewPopupMenu::slotAboutToShow()
{
  MscDg::trace( CLASS_NAME , "slotAboutToShow()" );
  // send event
  GuiEvent e( this , GuiEvent::ET_ABOUT_TO_SHOW );
  e.setViewPopupMenu(this);
  myTeam.receiveEvent( e );
}


void  GuiViewPopupMenu::slotActivated( int i )
{
  MscDg::trace( CLASS_NAME , "slotActivated()" , "Int:%d" , i );
  // send event
  GuiEvent e( this , GuiEvent::ET_ACTIVATED );
  e.setViewPopupMenu(this);
  e.setInt( i );
  myTeam.receiveEvent( e );
}



/**************************************************************************************************
************************************************************************************************** 
** "Layout" and "GroupBox"
************************************************************************************************** 
*************************************************************************************************/



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiLayout                                //
//-------------------------------------------------------------------------------------//



// TODO : CONSIDER QFormLayout
static const char * LayoutClasses[] = { "QHBoxLayout" ,  // 0
                                        "QVBoxLayout" ,  // 1
                                        "QGridLayout" ,  // 2
                                        "QLayout"     }; // 3




// USED BY "GuiWidgetGroup::createLayout"
QLayout * GuiLayout::findLayout( QWidget * parent , QString & layoutClass )
{
  QLayout * layout = 0 ;
  layoutClass.clear();

  // if it's a QWidget
  QWidget * w = ( parent != 0 && parent->inherits("QWidget")==true ) ? parent : 0 ;
  if ( w != 0 ) {
    // find the first layout (if any)
    QLayout * layout = w->findChild<QLayout *>( QString() , Qt::FindDirectChildrenOnly );
    // find out the class name
    if ( layout != nullptr ) {
      for ( int i=0 ; i <= 3 ; ++i ) {
        if ( layout->inherits(LayoutClasses[i]) == true ) {
          layoutClass = LayoutClasses[i];
          break;
        }
      }
    }
  }

  MscDg::trace( CLASS_NAME , "findLayout()" ,
               "Widget %s '%s' containing layout '%s' Layout %d" ,
               GuiUtl::getObjectClassName(parent) , GuiUtl::getObjectName(parent) ,
               GuiUtl::getString(layoutClass) );
  return layout ;
}






GuiLayout::GuiLayout( GuiTeam & wg , QWidget * parent , const CreateInfo & createInfo , const char * callerMsg )
  : QObject(parent) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_LAYOUT,createInfo.myId)
{
  static const char * METHOD_NAME = "GuiLayout()" ;
  if ( callerMsg == 0 ) { callerMsg = "" ; }
  myHorizontalLayout   = 0 ;
  myVerticalLayout     = 0 ;
  myGridLayout         = 0 ;
  myHasBeenCreatedHere = true ;
  myCreator            = 0 ;

  //-----------------------------------
  // find out the parent
  //-----------------------------------

  QLayout * l = 0;
  QWidget * w = 0;
  int numberOfLayouts = 0 ;
  if ( parent != 0 ) {
      // find the first layout
      QLayout * layout = parent->findChild<QLayout *>( QString() , Qt::FindDirectChildrenOnly );
      if ( layout == nullptr ) {
        w = parent ;
      }
      else {
        // was missing . same as ""
      }
  }

  //-----------------------------------
  // create the layout
  //-----------------------------------

  int numRows = createInfo.myNumRows ;
  int numCols = createInfo.myNumCols ;
  int margin  = createInfo.myMargin  ;
  int spacing = createInfo.mySpacing ;
  const char * name = createInfo.myName ? createInfo.myName : "" ;

  // create layout
  const char * layoutClass = myCreateLayout( w , l , numRows , numCols , margin , spacing , name );

  MscDg::trace( CLASS_NAME , METHOD_NAME ,
               "Caller '%s' Id %d ParentClass '%s'  ParentName '%s' containing %d layout . Created %d row %d col '%s' %s %s %s" ,
               callerMsg ,
               createInfo.myId , GuiUtl::getObjectClassName(parent) , GuiUtl::getObjectName(parent) ,
               numberOfLayouts , numRows , numCols , layoutClass , 
               ((w || l) ? "with" : "") , GuiItem::objectName(w) , GuiItem::objectName(l) );
}



// *************** CONSTRUCTOR WHERE THE LAYOUT IS PROVIDED ******************* //
GuiLayout::GuiLayout( GuiTeam & wg , QWidget * parent , QLayout * layout , const CreateInfo & createInfo )
  : QObject(parent) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_LAYOUT,createInfo.myId)
{
  // modify the aspect
  layout->setMargin( createInfo.myMargin  );
  layout->setMargin( createInfo.mySpacing );
  layout->setObjectName( createInfo.myName );
  myHorizontalLayout   = 0 ;
  myVerticalLayout     = 0 ;
  myGridLayout         = 0 ;
  myHasBeenCreatedHere = false ;
  myCreator            = 0 ;
  // use the existing
  int i = -1;
  if ( layout->inherits(LayoutClasses[0]) == true ) {
    i=0;
    myHorizontalLayout = (QHBoxLayout*)layout ;
  }
  else if ( layout->inherits(LayoutClasses[1]) == true ) {
    i=1;
    myVerticalLayout   = (QVBoxLayout*)layout ;
  }
  else if ( layout->inherits(LayoutClasses[2]) == true ) {
    i=2;
    myGridLayout       = (QGridLayout*)layout ;
  }
  // error
  if ( i == -1 ) {
    MscDg::error( CLASS_NAME , "GuiLayout()" , "Widget %s '%s' . Undefined type of layout" ,
                 GuiUtl::getObjectClassName(parent) , GuiUtl::getObjectName(parent) );
    return ;
  }
  // trace
  else {
    MscDg::trace( CLASS_NAME , "GuiLayout()" , "Widget %s '%s' . EXISTING %s" ,
                 GuiUtl::getObjectClassName(parent) , GuiUtl::getObjectName(parent) , LayoutClasses[i] );
  }
}



GuiLayout::GuiLayout( GuiTeam & wg , GuiLayout * layout , const CreateInfo & createInfo , int rowId , int colId )
  : QObject(layout) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_LAYOUT,createInfo.myId)
{
  // create it
  myInitialize( 0 /*layout->getLayout()*/ , createInfo.myNumRows , createInfo.myNumCols ,
                createInfo.myMargin  , createInfo.mySpacing , createInfo.myName    );
  // add it
  layout->addLayout( this , rowId , colId );
}



GuiLayout::GuiLayout( GuiTeam & wg , QObject * parent , int id ,
                      int numRows , int numCols , int margin , int spacing , const char * name )
: QObject(parent) , GuiItem(wg,name,this,GuiItem::WT_LAYOUT,id)
{
  myInitialize( parent , numRows , numCols , margin , spacing , name );
}



GuiLayout::GuiLayout( GuiTeam & wg , QObject * parent , const GuiLayout::CreateInfo & createInfo )
: QObject(parent) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_LAYOUT,createInfo.myId)
{
  myInitialize( parent , createInfo.myNumRows , createInfo.myNumCols ,
                createInfo.myMargin , createInfo.mySpacing , createInfo.myName );
}




void GuiLayout::myInitialize( QObject * parent , int numRows , int numCols ,
                              int margin , int spacing , const char * name )
{
  static const char * METHOD_NAME = "myInitialize()" ;
  if ( name == 0 ) { name = "" ; }
  myHorizontalLayout  = 0 ;
  myVerticalLayout    = 0 ;
  myGridLayout        = 0 ;
  myCreator           = 0 ;
  int numberOfLayouts = 0 ;
  const char * layoutClass = "" ;

  // create it here
  myHasBeenCreatedHere = true ;

  //-----------------------------------
  // find out if parent is a layout or already has a layout
  //-----------------------------------

  QWidget * w = 0;
  QLayout * l = 0;
  if ( parent != 0 ) {
      if ( parent->inherits("QLayout")==true ) {
          l = static_cast<QLayout*>(parent);
      }
      else if ( parent->inherits("QDialog")==true || parent->inherits("QWidget")==true ) {
          w = static_cast<QWidget*>(parent);
          // widget already has a layout // ISSUE when using it ... (??)
          if ( w != 0 ) {
              // find the first layout
              l = w->findChild<QLayout*>( QString() , Qt::FindDirectChildrenOnly );
              if ( l != nullptr ) {
                 w = 0 ;
                 // existing layout classes
                 for ( int i=0 ; i < 4 ; ++i ) {
                    if ( l->inherits(LayoutClasses[i]) == true ) {
                        layoutClass = LayoutClasses[i];
                        break;
                    }
                 }
              }
          }
      }
  }
  else {
    MscDg::error( CLASS_NAME , METHOD_NAME , "parent is null" );
  }
  
  MscDg::trace( CLASS_NAME , METHOD_NAME ,
               "Layout '%s' (Row %d Col %d) Parent %s '%s' containing layout '%s' Widget %d Layout %d" ,
               name , numRows , numCols , 
               GuiUtl::getObjectClassName(parent) , GuiUtl::getObjectName(parent) , layoutClass , w , l );

  // create layout
  myCreateLayout( w , l , numRows , numCols , margin , spacing , name );
}


const char * GuiLayout::myCreateLayout( QWidget * w , QLayout * l , int numRows , int numCols ,
                                        int margin , int spacing , const char * name )
{
  static const char * METHOD_NAME = "myCreateLayout()" ;
  const char * layoutClass = "error" ;
  // horizontal layout
  if ( numRows == 1 && numCols <= 0 ) {
    myHorizontalLayout = l ? new QHBoxLayout() : new QHBoxLayout( w ) ;
    if ( l != nullptr ) {
        if ( l->inherits("QBoxLayout") == true ) {
            QBoxLayout * boxLayout = static_cast<QBoxLayout*>(l);
            boxLayout->addLayout(myHorizontalLayout);
        }
        else if ( l->inherits("QGridLayout") == true ) {
            QGridLayout * gridLayout = static_cast<QGridLayout*>(l);
            gridLayout->addLayout(myHorizontalLayout,gridLayout->rowCount(),gridLayout->columnCount());
        }
    }
    myHorizontalLayout->setObjectName(name);
    myHorizontalLayout->setAlignment( Qt::AlignTop );
    myHorizontalLayout->setContentsMargins(margin,margin,margin,margin);
    myHorizontalLayout->addSpacing( spacing );
    layoutClass = LayoutClasses[0] ;
  }
  // vertical layout
  else if ( numRows <= 0 && numCols == 1 ) {
    myVerticalLayout = l ? new QVBoxLayout() : new QVBoxLayout( w ) ;
    if ( l != nullptr ) {
        if ( l->inherits("QBoxLayout") == true ) {
            QBoxLayout * boxLayout = static_cast<QBoxLayout*>(l);
            boxLayout->addLayout(myVerticalLayout);
        }
        else if ( l->inherits("QGridLayout") == true ) {
            QGridLayout * gridLayout = static_cast<QGridLayout*>(l);
            gridLayout->addLayout(myVerticalLayout,gridLayout->rowCount(),gridLayout->columnCount());
        }
    }
    myVerticalLayout->setObjectName(name);
    myVerticalLayout->setAlignment( Qt::AlignTop );
    myVerticalLayout->setContentsMargins(margin,margin,margin,margin);
    myVerticalLayout->addSpacing( spacing );
    layoutClass = LayoutClasses[1] ;
  }
  // not valid
  else if ( numRows <= 0 || numCols <= 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "invalid parameters for Id %d" , myId );
  }
  // grid
  else {
    myGridLayout = l ? new QGridLayout() : new QGridLayout( w );
    if ( l != nullptr ) {
        if ( l->inherits("QBoxLayout") == true ) {
            QBoxLayout * boxLayout = static_cast<QBoxLayout*>(l);
            boxLayout->addLayout(myGridLayout);
        }
        else if ( l->inherits("QGridLayout") == true ) {
            QGridLayout * gridLayout = static_cast<QGridLayout*>(l);
            gridLayout->addLayout(myGridLayout,gridLayout->rowCount(),gridLayout->columnCount());
        }
    }
    myGridLayout->setObjectName(name);
    myGridLayout->setAlignment( Qt::AlignTop );
    myGridLayout->setContentsMargins(margin,margin,margin,margin);
    myGridLayout->setVerticalSpacing( spacing );
    myGridLayout->setHorizontalSpacing( spacing );

    // rowCount columnCount . Qt 5.7 doesn't consider it .
    //   myGridLayout->setRowCount(numRows);
    //   myGridLayout->setColumnCount(numCols);
    layoutClass = LayoutClasses[2] ;
  }
  return layoutClass ;
}



GuiLayout::~GuiLayout() 
{
}


QLayout * GuiLayout::getLayout() const 
{
  if ( myHorizontalLayout != 0 ) { return myHorizontalLayout ; }
  if ( myVerticalLayout   != 0 ) { return myVerticalLayout   ; }
  if ( myGridLayout       != 0 ) { return myGridLayout       ; }
  MscDg::error( CLASS_NAME , "getLayout()" , "Undefined layout" );
  return 0;
}


GuiItem * GuiLayout::getCreator( bool upToTheTop )
{
  GuiItem * guiItem = myCreator ;
  if ( upToTheTop == true ) {
    // if it's a layout, get its creator till it's not a layout
    while ( guiItem != 0 && 
            guiItem->getWidgetType() == GuiItem::WT_LAYOUT &&
            dynamic_cast<GuiLayout*>(guiItem)->getCreator(false) != 0 ) {
      guiItem = dynamic_cast<GuiLayout*>(guiItem)->getCreator(false);
    }
  }
  return guiItem ;
}


QWidget * GuiLayout::getCreatorWidget()
{
  QWidget * w = 0 ;
  GuiItem * guiItem = getCreator(true);
  if ( guiItem == 0 ) {
    //
  }
  else if ( guiItem->getWidgetType() == GuiItem::WT_GROUP_BOX ) {
    w = dynamic_cast<GuiGroupBox*>(guiItem)->getInternalWidget(); 
  }
  else if ( guiItem->getWidgetType() == GuiItem::WT_STACKED_WIDGET ) {
    w = dynamic_cast<GuiStackedWidget*>(guiItem)->getInternalWidget(); 
  }
  else if ( guiItem->isWidget() == true ) {
    w = guiItem->getWidget();
  }
  return w ;
}


/** add item to the layout  */
void GuiLayout::addWidget( QWidget * widget , int rowNumber , int colNumber )
{
  if ( widget == 0 ) {
    MscDg::error( CLASS_NAME , "addWidget()" , "null widget" );
  }
  else if ( myHorizontalLayout != 0 ) { 
    myHorizontalLayout->addWidget( widget );
  }
  else if ( myVerticalLayout != 0 ) { 
    myVerticalLayout->addWidget( widget );
  }
  else if ( myGridLayout != 0 ) { 
    myGridLayout->addWidget( widget , rowNumber , colNumber ); 
  }  
}


void GuiLayout::addWidget( GuiItem * guiItem , int rowNumber , int colNumber )
{
  addWidget( guiItem->getWidget() , rowNumber , colNumber ); 
}


void GuiLayout::addWidget( int id , int rowNumber , int colNumber )
{
  addWidget( myTeam.getGuiItem(id) , rowNumber , colNumber ); 
}


void GuiLayout::addWidget( GuiPage * page , int rowNumber , int colNumber )
{
  addWidget( page->getWidget() , rowNumber , colNumber ); 
}


void GuiLayout::addLayout( QLayout * layout , int rowNumber , int colNumber )
{
  if ( layout == 0 ) {
    MscDg::error( CLASS_NAME , "addLayout()" , "no layout" );
  }
  else if ( myHorizontalLayout != 0 ) {
    myHorizontalLayout->addLayout( layout );
  }
  else if ( myVerticalLayout != 0 ) {
    myVerticalLayout->addLayout( layout );
  }
  else if ( myGridLayout != 0 ) {
    myGridLayout->addLayout( layout , rowNumber , colNumber );
  }
  else {
    MscDg::error( CLASS_NAME , "addLayout()" , "Undefined case" );
  }  
}


void GuiLayout::addLayout( GuiLayout * layout , int rowNumber , int colNumber )
{
  addLayout( layout->getLayout() , rowNumber , colNumber ); 
}


void GuiLayout::addSpacer( int size , bool isHorizontal , int row , int col , bool isFixedSize )
{
  // resize policy
  QSizePolicy::Policy sizePolicy = isFixedSize ? QSizePolicy::Fixed : QSizePolicy::MinimumExpanding ;

  // the spacer
  QSpacerItem * spacer = 0 ;
  // fixed size imposes the orientation
  if ( isFixedSize == true ) {
    if ( isHorizontal == true ) {
      spacer = new QSpacerItem( size , 5 , QSizePolicy::Minimum , sizePolicy );
    }
    else {
      spacer = new QSpacerItem( 5 , size , QSizePolicy::Minimum , sizePolicy );
    }
  }
  // horizontal
  else if ( (myHorizontalLayout != 0) ||
            (myGridLayout != 0    && isHorizontal == true) ) {
    spacer = new QSpacerItem( size , 5 , sizePolicy , QSizePolicy::Minimum );
  }
  // vertical
  else {
    spacer = new QSpacerItem( 5 , size , QSizePolicy::Minimum , sizePolicy );
  }

  // add spacer
  if ( myHorizontalLayout != 0 ) {
    myHorizontalLayout->addItem( spacer );
  }
  else if ( myVerticalLayout != 0 ) {
    myVerticalLayout->addItem( spacer );
  }
  else if ( true ) { // Qt 5.7: can't set predefined numbers . 0 < row && row <= myGridLayout->rowCount() && 0 < col && col <= myGridLayout->colCount() ) {
    if ( isHorizontal == true ) {
      myGridLayout->addItem( spacer , row, col );
    }
    else {
      myGridLayout->addItem( spacer , row, col );
    }
  } 
  else {
    MscDg::error( CLASS_NAME , "addSpacer()" , "error" );
  }
}


void GuiLayout::addLine( int size , bool isHorizontal , int row , int col )
{
  // need to find the parent widget // TODO ... improve it
  QWidget * parent = myTeam.getTopWidget();
  
  // create the line
  QFrame * line = new QFrame( parent );
  line->setObjectName ( "LAYOUT-LINE"  );
  line->setFrameShape ( QFrame::HLine  );
  line->setFrameShadow( QFrame::Sunken );
  line->setFrameShape ( QFrame::HLine  );

  // add the line
  if ( myHorizontalLayout != 0 ) {
    myHorizontalLayout->addWidget( line );
  }
  else if ( myVerticalLayout != 0 ) {
    myVerticalLayout->addWidget( line );
  }
  else if ( true ) { // Qt 5.7: can't set predefined numbers 0 < row && row <= myGridLayout->numRows() && 0 < col && col <= myGridLayout->numCols() ) {
    if ( isHorizontal == true ) {
      myGridLayout->addWidget( line , row , col );
    }
    else {
      myGridLayout->addWidget( line , row , col );
    }
  } 
  else {
    MscDg::error( CLASS_NAME , "addLine()" , "error" );
  }
}


//-------------------------------------------------------------------------------------//
//                             EVENT SENDER GuiGroupBox                                //
//-------------------------------------------------------------------------------------//


GuiGroupBox::GuiGroupBox( GuiTeam & wg , QWidget * parent , const GuiGroupBox::CreateInfo & createInfo ,
                          QGroupBox * groupBox , int callerId )
: QObject(parent) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_GROUP_BOX,createInfo.myId)
{
  static const char * METHOD_NAME = "GuiGroupBox()" ;

  // create it
  myGroupBox = new QGroupBox( parent ) ;
  myGroupBox->setObjectName( createInfo.myName );
  myGroupBox->setAlignment( Qt::AlignTop); //  Qt::Vertical
  myInitializeFont( myGroupBox );  
  // customize the group box (it contains a layout)
  myGroupBox->setCheckable( createInfo.myCheckable );
  // title
  if ( createInfo.myTitle != 0 ) {
    myString = createInfo.myTitle ;
    myGroupBox->setTitle( myString );
  }
  if ( createInfo.myIcon  != 0 ) {
    myIconName = createInfo.myIcon ; // Name ;
    updateIcon() ;
  }
  // tooltip
  if ( createInfo.myToolTip != 0 ) {
     myGroupBox->setToolTip( createInfo.myToolTip );
  }
  myInternalWidget = myGroupBox ;

  // Create an internal layout with the information provided by the Blue Print
  QString layoutStr;
  layoutStr.sprintf( "%s-LAYOUT" , createInfo.myName ? createInfo.myName : CLASS_NAME );
  GuiLayout::CreateInfo layoutBP = { createInfo.myLayoutId , GuiUtl::getString(layoutStr)  ,
                                    createInfo.myNumRows  , createInfo.myNumCols ,
                                    createInfo.myMargin   , createInfo.mySpacing } ;
  myInternalLayout = new GuiLayout( wg , myInternalWidget , layoutBP , METHOD_NAME /*caller*/ );
  myInternalLayout->setCreator( this );

  // callbacks
  QObject::connect( myGroupBox , SIGNAL( toggled(bool) ) , this , SLOT( slotToggled(bool) ) );
}


GuiGroupBox::~GuiGroupBox()
{
  // no need to delete it as it's managed by 'GuiTeam'
}


void GuiGroupBox::updateFont()
{
  GuiItem::updateFont(myGroupBox);    
}


void GuiGroupBox::updateIcon()
{
  if ( myIconName.isEmpty() == false ) {
    myGroupBox->setWindowIcon( GuiUtl::getIcon( myIconName , myFormatHint.myPixmapPercentage ) );
  }
}


void GuiGroupBox::slotToggled( bool )
{
  // send event
  GuiEvent e( this , GuiEvent::ET_CLICKED );
  e.setBool( myGroupBox->isChecked() );
  myTeam.receiveEvent( e );
}



void GuiGroupBox::addItem( GuiItem * guiItem , int row , int col , int fontOperation )
{
  static const char * METHOD_NAME = "addItem()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "row %d col %d" , row , col );
  if ( guiItem == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "row %d col %d  Is null" , row , col );
    return ;
  }
  if ( guiItem->isWidget() == true ) {
    addWidget( guiItem->getWidget() , row , col , fontOperation );
  }
  else if ( guiItem->isLayout() == true ) {
    addLayout( guiItem->getLayout() , row , col );
  }
  else {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Id:%d not widget or layout. Not implemented" , guiItem->getId() );
  }
}


void GuiGroupBox::addWidget( QWidget * w , int rowNumber , int colNumber , int fontOperation )
{
  static const char * METHOD_NAME = "addWidget()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "row %d col %d" , rowNumber , colNumber );
  if ( w == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Id:%d  null layout" );
    return ;
  }
  myInternalLayout->addWidget( w , rowNumber , colNumber );
  // font operation 
  switch ( fontOperation ) {
  case 0 : 
  case 1 : 
    {
      QFont font( w->font() );
      font.setBold( (fontOperation==1) ? true : false );
      w->setFont( font );
    } break ;
  }
}


void GuiGroupBox::addLayout( QLayout * l , int rowNumber , int colNumber )
{
  if ( l == 0 ) {
    MscDg::error( CLASS_NAME , "addLayout()" , "null layout to add" );
    return ;
  }
  myInternalLayout->addLayout( l , rowNumber , colNumber );
}


void GuiGroupBox::addSpacer( int size , bool isHorizontal , int row , int col , bool isFixedSize )
{
  myInternalLayout->addSpacer( size , isHorizontal , row , col , isFixedSize );
}


void GuiGroupBox::addLine( int size , bool isHorizontal , int row , int col )
{
  myInternalLayout->addLine( size , isHorizontal , row , col );
}


void GuiGroupBox::setIsFlat( bool b )
{
  if ( b == true ) {
    myGroupBox->setTitle( "" );
    myGroupBox->setFlat( true );
  }
  else {
    myGroupBox->setFlat( false ); 
    myGroupBox->setTitle( myString );
  }
}




/**************************************************************************************************
************************************************************************************************** 
** Base Widgets
*    GuiLabel
*    GuiPushButton
*    GuiButtonGroup
*    GuiRadioButton
*    GuiCheckBox
*    GuiComboBox
*    GuiFrame
*    GuiListView
*    GuiSpinBox
*    GuiTable
*    GuiSplitter
*    GuiTabWidget
*    GuiStackedWidget
*    GuiTextEdit
*    GuiWidget
************************************************************************************************** 
*************************************************************************************************/



//-------------------------------------------------------------------------------------//
//                             GuiLabel  (no event is sent)                            //
//-------------------------------------------------------------------------------------//


GuiLabel::GuiLabel( GuiTeam & wg , QWidget * parent , const GuiLabel::CreateInfo & createInfo )
: QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_LABEL,createInfo.myId)
{
  // create if needed
  myLabel = new QLabel(parent) ;
  myLabel->setObjectName( createInfo.myName) ;
  myInitializeFont( myLabel );
  // customize
  if ( createInfo.myText != 0 ) {
    myLabel->setText( createInfo.myText );
  }
  // ERROR if no name and no icon. The icon name is shown.
  else if ( createInfo.myIconName != 0 ) {
    myLabel->setText( "" );
  }
  myMaxWidth  = createInfo.myMaxWidth  ;
  myMaxHeight = createInfo.myMaxHeight ;
  setMaxWidth ( myMaxWidth  , true );
  setMaxHeight( myMaxHeight , true );
  if ( createInfo.myToolTip != 0 ) {
    myLabel->setToolTip( createInfo.myToolTip );
  }
  if ( createInfo.myIconName != nullptr ) {
    myIconName = createInfo.myIconName ;
    updateIcon();
  }
  Qt::AlignmentFlag alignmentH = Qt::AlignLeft ;
  switch ( createInfo.myAlignment ) {
  case GuiItem::AT_LEFT   : alignmentH = Qt::AlignLeft    ; break ;
  case GuiItem::AT_CENTER : alignmentH = Qt::AlignHCenter ; break ;
  case GuiItem::AT_RIGHT  : alignmentH = Qt::AlignRight   ; break ;    
  }
  myLabel->setAlignment( alignmentH | Qt::AlignVCenter );//| Qt::TextExpandTabs );
}


GuiLabel::~GuiLabel()
{
}



void GuiLabel::updateIcon() 
{
  if ( myIconName.isEmpty() == false ) {
    myLabel->setWindowIcon( GuiUtl::getIcon( myIconName , myFormatHint.myPixmapPercentage ) );
  }
}


//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiPushButton                            //
//-------------------------------------------------------------------------------------//


const char * GuiPushButton::CANCEL_TEXT = "Dismiss" ;



GuiPushButton::GuiPushButton( GuiTeam & wg , QWidget * parent , const GuiPushButton::CreateInfo & createInfo )
: QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_PUSH_BUTTON,createInfo.myId)
{
  // create if needed
  myPushButton = new QPushButton(parent);
  myPushButton->setObjectName(createInfo.myName) ;
  myInitializeFont( myPushButton );
  // customize
  myPushButton->setText( createInfo.myText );
  if ( createInfo.myToolTip != 0 ) {
    myPushButton->setToolTip( createInfo.myToolTip );
  }
  if ( createInfo.myIconName != 0 ) {
    myIconName = createInfo.myIconName ;
    updateIcon();
  }
  myMaxWidth  = createInfo.myMaxWidth  ;
  myMaxHeight = createInfo.myMaxHeight ;
  setMaxWidth ( myMaxWidth  , true );
  setMaxHeight( myMaxHeight , true );
  // callbacks
  QObject::connect( myPushButton , SIGNAL( clicked() ) , this , SLOT( slotClicked() ) );
  if ( createInfo.myCallbackTypes != 0 ) {
    //
  }
} 

GuiPushButton::~GuiPushButton()
{
}


void GuiPushButton::updateIcon() 
{
  if ( myIconName.isEmpty() == false ) {
    myPushButton->setIcon( GuiUtl::getIcon( myIconName , myFormatHint.myPixmapPercentage ) );
  }
}


void GuiPushButton::slotClicked()
{
  // send event
  GuiEvent e( this , GuiEvent::ET_CLICKED );
  if ( myPushButton->isCheckable() == true ) { e.setBool( myPushButton->isChecked() ); }
  myTeam.receiveEvent( e );
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiButtonGroup                           //
//-------------------------------------------------------------------------------------//



QButtonGroup * GuiButtonGroup::createButtonGroup( QObject * parent , int numberOfItems , const GuiButtonGroup::Item * items )
{
  QButtonGroup * buttonGroup = new QButtonGroup( parent );
  for ( int i=0 ; i < numberOfItems ; ++i ) {
    buttonGroup->addButton( items[i].myButton , items[i].myId );
  }
  return buttonGroup ;
}



void GuiButtonGroup::setButton( QButtonGroup * buttonGroup , int idOfButton )
{
  static const char * METHOD_NAME = "setButton()" ;
  QList<QAbstractButton *>	buttons = buttonGroup->buttons();
  for ( auto iter=buttons.cbegin() ; iter != buttons.cend() ; ++iter ) {
    if ( buttonGroup->id(*iter) == idOfButton ) {
      (*iter)->setChecked(true);
      return ;
    }
  }
  MscDg::error( CLASS_NAME , METHOD_NAME , "Id %d not found in '%s'" , idOfButton , GuiUtl::getObjectName(buttonGroup) );
}



int GuiButtonGroup::getButton( QButtonGroup * buttonGroup , bool * isOk )
{
  static const char * METHOD_NAME = "getButton()" ;
  QList<QAbstractButton *>	buttons = buttonGroup->buttons();
  for ( auto iter=buttons.cbegin() ; iter != buttons.cend() ; ++iter ) {
    if ( (*iter)->isChecked() == true ) {
      if ( isOk != 0 ) { *isOk = true ; }
      return buttonGroup->id(*iter);
    }
  }
  if ( isOk != 0 ) { *isOk = false ; }
  else { MscDg::error( CLASS_NAME , METHOD_NAME , "no button is checked in '%s'" , GuiUtl::getObjectName(buttonGroup) ); }
  return -1;
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiCheckBox                              //
//-------------------------------------------------------------------------------------//



GuiCheckBox::GuiCheckBox( GuiTeam & wg , QWidget * parent , const GuiCheckBox::CreateInfo & createInfo )
: QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_CHECK_BOX,createInfo.myId)
{
  // create if needed
  myCheckBox = new QCheckBox(parent);
  myCheckBox->setObjectName(createInfo.myName) ;
  myInitializeFont( myCheckBox );
  // set values
  myCheckBox->setText( createInfo.myText );
  if ( createInfo.myToolTip != 0 ) {
    myCheckBox->setToolTip( createInfo.myToolTip );
  }
  myMaxWidth  = createInfo.myMaxWidth  ;
  myMaxHeight = createInfo.myMaxHeight ;
  setMaxWidth ( myMaxWidth  , true );
  setMaxHeight( myMaxHeight , true );
  // callbacks
  QObject::connect( myCheckBox , SIGNAL( clicked() ) , this , SLOT( slotClicked() ) );
  if ( createInfo.myCallbackTypes != 0 ) {
    //
  }
} 

GuiCheckBox::~GuiCheckBox()
{
}

void GuiCheckBox::slotClicked()
{
  // send event
  GuiEvent e( this , GuiEvent::ET_CLICKED );
  e.setBool( myCheckBox->isChecked() );
  myTeam.receiveEvent( e );
}


//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiComboBox                              //
//-------------------------------------------------------------------------------------//



GuiComboBox::GuiComboBox( GuiTeam & wg , QWidget * parent , const GuiComboBox::CreateInfo & createInfo , QComboBox * provided )
: QObject(parent) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_COMBO_BOX,createInfo.myId)
{
  myComboBox = provided ;
  // create if not provided
  if ( myComboBox == 0 ) {
    myComboBox = new QComboBox( parent );
  }

  // customize
  myComboBox->setObjectName( createInfo.myName );
  myComboBox->setEditable(false);
  myComboBox->setSizePolicy( QSizePolicy::MinimumExpanding , QSizePolicy::Fixed );

  myInitializeFont( myComboBox );
  if ( createInfo.myToolTip != 0 ) {
    myComboBox->setToolTip( createInfo.myToolTip );
  }
  
  myMaxWidth  = createInfo.myMaxWidth  ;
  myMaxHeight = createInfo.myMaxHeight ;
  setMaxWidth ( myMaxWidth  , true );
  setMaxHeight( myMaxHeight , true );

  // values
  setValues( createInfo.myValuesNumber , createInfo.myValues );
  // callbacks
  QObject::connect( myComboBox , SIGNAL( activated (int ) ) , this , SLOT( slotActivated(int)  ) );
  if ( createInfo.myCallbackTypes != 0 ) {
    //
  }
}


void GuiComboBox::updateFont()
{
  GuiItem::updateFont(myComboBox);
  
}


void GuiComboBox::updateIcon()
{
  
}


void GuiComboBox::slotActivated( int id )
{
  // send event
  GuiEvent e( this , GuiEvent::ET_ACTIVATED );
  e.setInt( myMap[id] );
  myTeam.receiveEvent( e );
}


void GuiComboBox::clearValues()
{
  myMap.clear();
  myComboBox->clear();
}


QComboBox * GuiComboBox::toQtComboBox( GuiItem * guiItem )
{
  GuiComboBox * cb = dynamic_cast<GuiComboBox*>( guiItem );
  return cb ? cb->myComboBox : 0 ;
}


int  GuiComboBox::getNumberOfItems() const 
{ 
  int boxCount = myComboBox->count() ; 
  int mapSize  = myMap.size();
  if ( boxCount != mapSize ) {
    MscDg::trace( CLASS_NAME , "getNumberOfItems()" , "Mismatch. ComboBoxCount:%d  MapSize:%d" , boxCount , mapSize );
  }
  return boxCount ; 
}


void GuiComboBox::addValue( const char * text , const char * iconName , const Typ::ColorId * colorId , int userValue , int indexOfItem )
{
  static const char * METHOD_NAME = "addValue()" ;
  // icon
  QIcon icon ;
  if ( iconName != 0 ) {
    icon    = GuiUtl::getIcon( iconName , myFormatHint.myPixmapPercentage );
  }
  else if ( colorId != 0 && *colorId != Typ::COL_UNDEFINED ) {
    // color
    QPixmap pixmap ;
    pixmap = pixmap.scaled(16,8);
    pixmap.fill( GuiUtl::getColor(*colorId) );
    // frame
    QPainter p(&pixmap);
    int w = pixmap.width();	
    int h = pixmap.height();
    p.setPen(QPen(Qt::gray, 0, Qt::SolidLine));
    p.drawRect(0, 0, w, h);
    // icon
    icon = QIcon(pixmap);
  }
  // text
  bool hasText = false ;
  QString textString ;
  if ( text != 0 ) {
    hasText = true ;
    textString = text ;
  }
  // keep the correct item location . TODO : CHECK IT !!
  int indexInTheMap = myComboBox->count() ;
  // add the choice
  QVariant userData(userValue);
  if ( icon.isNull() == false && textString.isEmpty() == false ) {
    myComboBox->insertItem( indexOfItem , icon , textString , userData );
  }
  else if ( icon.isNull() == false ) {
    myComboBox->insertItem( indexOfItem , icon , QString::null , userData );
  }
  else {
    myComboBox->insertItem( indexOfItem , textString , userData );
  }
  // check
  if ( indexInTheMap != myMap.size() ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "mismatch: NewValueIndex:%d and MapSize:%d" , indexInTheMap , myMap.size() );
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Add at index %d value %d text '%s'" , indexInTheMap , userValue , GuiUtl::getString(textString) );
  // add value
  myMap[ indexInTheMap ] = userValue ;
  // check
  (void)getNumberOfItems();
}



bool GuiComboBox::insertValue( const char * text , const char * iconName , const Typ::ColorId * colorId ,
                               int userValue , int indexOfItem , bool replaceIt )
{
  static const char * METHOD_NAME = "insertValue()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "not implemented. Index %d  replace %d" , indexOfItem , replaceIt );
  return false ;
}



bool GuiComboBox::setValues( const std::vector< Typ::ValuesStruct > & comboBoxValues , int option , bool sendMessage )
{
  static const char * METHOD_NAME = "setValues()" ;
  int numberOfValues  = comboBoxValues.size();
  MscDg::trace( CLASS_NAME , METHOD_NAME , "NumberOfValues %d  Option %d" , numberOfValues , option );
  
  Typ::ValuesStruct * values = 0 ;
  if ( numberOfValues != 0 ) {
     // allocate
     values = new Typ::ValuesStruct [numberOfValues] ;
     // fill with pointers
     for ( int i=0 ; i < numberOfValues ; ++i ) {
         values[i] = comboBoxValues[i];
     }
  }

  // set values
  bool isOk = setValues( numberOfValues , values , option , sendMessage );
  // free memory
  delete [] values ;
  // done
  return isOk ;
}


bool GuiComboBox::setValues( int numberOfValues , const Typ::ValuesStruct * comboBoxValues , int option , bool sendMessage )
{
  static const char * METHOD_NAME = "setValues()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "NumberOfValues %d" , numberOfValues );
  bool isOk = true ;

  // keep the current one
  int currentItem  = -1 ;
  int currentValue = INT_MIN ;
  if ( myMap.empty() == false && myComboBox->currentIndex() != -1 ) {
    currentItem  = myComboBox->currentIndex();
    currentValue = myMap[ currentItem ] ; 
  }

  // empty
  clearValues();

  // values . if "comboBoxValues" is null, "numberOfValues" is used as a reference
  if ( comboBoxValues == 0 && MscDataItem::getTypeIsEnum( numberOfValues ) == true ) {
      int number = 0 ;
      comboBoxValues = Defs::getValues( (MscDataItem::DataType)numberOfValues , number );
      numberOfValues = number ;
  }

  // fill in the combo-box
  for ( int i=0 ; i < numberOfValues ; ++i ) {
    QString label;
    Typ::ColorId colorId = (Typ::ColorId)comboBoxValues[i].myColorId ;
    // label is provided
    switch ( option ) {
    // label is specific (add number in the display)
    case 1 :
        label.sprintf( "%d:  %s" , comboBoxValues[i].myValue , comboBoxValues[i].myLabel );
        addValue( GuiUtl::getString(label) , comboBoxValues[i].myPixmap , &colorId  , comboBoxValues[i].myValue );
        break;
    default :
        addValue( comboBoxValues[i].myLabel , comboBoxValues[i].myPixmap , &colorId  , comboBoxValues[i].myValue );
    }
    if ( comboBoxValues[i].myValue == currentValue ) {
      currentItem = i ;
    }
  }

  // select the current one
  if ( currentItem != -1 ) {
    myComboBox->setCurrentIndex( currentItem );
    if ( sendMessage == true ) {
      slotActivated( currentItem );
    }
  }
  else if ( sendMessage == true && numberOfValues > 0 ) {
    slotActivated( 0 );
  }

  return isOk;
}



void GuiComboBox::setString( const QString & value , bool forceMessage )
{
  const int numberOfItems = myComboBox->count() ;
  int row=0 ;
  // already in the list
  for ( row=0 ; row < numberOfItems ; ++row ) {
    if ( value == myComboBox->itemText(row) ) {
      myComboBox->setCurrentIndex( row );
      if ( forceMessage == true ) {
        slotActivated( row );
      }
      return ;
    }
  }
  // useless to say it if values aren't (or can't be) set.
  if ( numberOfItems != 0 ) {
    MscDg::error( CLASS_NAME , "setString()" , "value:'%s' not present amongst the %d values" , GuiUtl::getString(value) , numberOfItems );
    for ( row=0 ; row < numberOfItems ; ++row ) {
      GuiUtl::print( "     %s" , GuiUtl::getString(myComboBox->itemText(row)) ) ;
    }
  }
}



QString GuiComboBox::getString( int * indexPtr )
{
  QString str ;
  if ( myComboBox->count() == 0 ) {
    if ( indexPtr != 0 ) {
      *indexPtr = -1 ;
    }
  }
  else {
    if ( indexPtr != 0 ) {
      *indexPtr = myComboBox->currentIndex();
    }
    str = myComboBox->currentText() ;
  }
  return str ;
}



int  GuiComboBox::getUserValue( int indexOfItem , bool * isOkPtr )
{
  static const char * METHOD_NAME = "getUserValue()" ; 
  int value = 0 ;
  bool isOk = false ;
  const int numberOfItems = myComboBox->count() ;
  // no value has been defined
  if ( numberOfItems == 0 ) {
    if ( isOkPtr == 0 ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Combo box is empty." );
    }
    value = 0 ;
    isOk = false ;
  }
  // mismatch
  else if ( numberOfItems != myMap.size() ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Mismatch: NumberOfItems:%d MapSize:%d" , numberOfItems , myMap.size() );
    value = 0 ;
    isOk = false ;
  }
  // default is current item.
  else if ( indexOfItem < 0 ) {
    value = myMap[ myComboBox->currentIndex() ];
    isOk  = true ;
  }
  // out of range (error)
  else if ( numberOfItems <= indexOfItem ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "index %d is out of bounds. 0<-<%d" , indexOfItem , numberOfItems );
    value = myMap[ myComboBox->currentIndex() ];
    isOk = false ;
  }
  // in range
  else {
    value = myMap[ indexOfItem ];
    isOk  = true ;
  }
  if ( isOkPtr != 0 ) *isOkPtr = isOk;
  return value ;
}



bool GuiComboBox::setUserValue( int userValue , bool forceMessage , bool showErrorMessage )
{
  static const char * METHOD_NAME = "setUserValue()" ;
  for ( auto iter=myMap.begin() ; iter != myMap.end() ; ++iter ) {
    if ( iter->second == userValue ) {
      myComboBox->setCurrentIndex( iter->first );
      if ( forceMessage == true ) {
        slotActivated( iter->first );
      }
      MscDg::trace( CLASS_NAME , METHOD_NAME , "Id %d value %d   (%s)" , iter->first , iter->second , forceMessage ? "message" : "no message" );
      return true ;
    }
  }
  // show the choices
  if ( showErrorMessage == true ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Id %d value %d not seen amongst the %d existing" ,
                 myId , userValue , myMap.size() );
    for ( auto iter=myMap.begin() ; iter != myMap.end() ; ++iter ) {
      QString value = "Error in the values" ;
      if ( 0 <= iter->first && iter->first < myComboBox->count() ) {
        value = myComboBox->itemText(iter->first) ;
      }
      GuiUtl::print( "    Index:%d  UserValue:%d  %s" , iter->first , iter->second , GuiUtl::getString(value) );
    }
  }
  // not present
  return false ;
}


static int NumberOfSameCharacters( const QString & modelStr , const QString & searchStr , bool & isSame )
{
  int numberOfCommonCharacters = 0;
  const char * model  = GuiUtl::getString(modelStr );
  const char * search = GuiUtl::getString(searchStr);
  // useless to test in fact....
  if ( model == 0 || search == 0 ) {
    isSame = true ;
  }
  // compare
  else {
    int mLength = strlen( model  );
    int sLength = strlen( search );
    int length  = (mLength < sLength) ? mLength : sLength ;
    for ( int i=0 ; i < length ; ++i ) {
      if ( model[i] == search[i] ) {
        numberOfCommonCharacters += 1 ;
      }
      else {
        break;
      }
    }
    isSame = (mLength == sLength);
  }
  return numberOfCommonCharacters ;
}


bool GuiComboBox::changeTextOfUserValue( const QString & str , int userValue )
{
  for ( auto iter=myMap.cbegin() ;  iter != myMap.cend() ; ++iter ) {
    if ( iter->second == userValue ) {
      return changeTextAtIndex( str , iter->first );
    }
  }
  return false ;
}


bool GuiComboBox::changeTextAtIndex( const QString & str , int indexOfItem )
{
  if ( 0 <= indexOfItem && indexOfItem < myComboBox->count() ) {
    myComboBox->setItemText( indexOfItem , str ) ;
    return true ;
  }
  else {
    return false ;
  }
}


bool GuiComboBox::getClosestMatch( QComboBox * comboBox , const QString & model ,
                                   QString & found , bool mustMatch )
{
  bool isInList = false ;
  found = "" ;
  if ( comboBox == 0 || comboBox->count() == 0 ) {
    return isInList;
  }
  
  // count the number of characters in common
  int numberOfCommonCharacters = 0;
  QString modelStr( model );
  GuiUtl::stripString(modelStr);
  // find amongst the 
  int position = -1 ;
  for ( int i=0 ; i < comboBox->count() ; ++i ) {
    QString searchStr = comboBox->itemText(i);
    GuiUtl::stripString(searchStr);
    bool isSame = false ;
    int n = NumberOfSameCharacters( modelStr , searchStr , isSame );
    if ( n > numberOfCommonCharacters ) {
      numberOfCommonCharacters = n ;
      found    = searchStr ;
      position = i;
      // same one 
      if ( isSame == true ) {
        isInList = true ;
        // stop searching
        break;
      }
    }
  }
  // show closest
  if ( position != (-1) ) {
    comboBox->blockSignals(true);
    comboBox->setCurrentIndex( position );
    comboBox->blockSignals(false);
  }
  // closest
  return isInList;
}


bool GuiComboBox::setClosestMatch( QComboBox * comboBox , const QString & model ,
                                   QString & found , bool mustMatch , bool sendSignals )
{
  // find nearest
  found = "" ;
  if ( comboBox != 0 && comboBox->count() != 0 &&
       getClosestMatch( comboBox , model , found , mustMatch ) == true ) {
    // avoid signal
    if ( sendSignals == false ) {
      comboBox->blockSignals(true);
    }
    // set value
    comboBox->setCurrentText( found );
    // restore signals
    if ( sendSignals == false ) {
      comboBox->blockSignals(false);
    }
    return true ;
  }
  // not found
  else {
    return false;
  }
}


bool GuiComboBox::hasUserValue( int userValue ) const
{
  for ( auto iter=myMap.cbegin() ; iter != myMap.cend() ; ++iter ) {
    if ( iter->second == userValue ) {
      return true ;
    }
  }
  return false ;
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER :  GuiFrame                                //
//-------------------------------------------------------------------------------------//



GuiFrame::GuiFrame( GuiTeam & wg , QWidget * parent , const CreateInfo & createInfo )
  : QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_FRAME,createInfo.myId)
{
  // create if needed
  myFrame = new QFrame(parent);
  myFrame->setObjectName(createInfo.myName) ;
  myFrame->setFrameShape( QFrame::StyledPanel );
  myFrame->setFrameShadow( QFrame::Raised );
  if ( createInfo.myToolTip != 0 ) {
    myFrame->setToolTip( createInfo.myToolTip );
  }
  GuiItem::setSizes( myFrame , createInfo.mySizes );
}


GuiFrame::~GuiFrame()
{
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiListView                              //
//-------------------------------------------------------------------------------------//


GuiListView::GuiListView( GuiTeam & wg , QWidget * parent , const GuiListView::CreateInfo & createInfo )
  : QObject(parent) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_LIST_VIEW,createInfo.myId)
{
  // create if needed
  myListView = new QListView(parent) ;
  myListView->setObjectName( createInfo.myName );
  myInitializeFont( myListView );
  // customize
  if ( createInfo.myText != 0 ) {
    // myListView->setText( createInfo.myText );
  }
  myMaxWidth  = createInfo.myMaxWidth  ;
  myMaxHeight = createInfo.myMaxHeight ;
  setMaxWidth ( myMaxWidth  , true );
  setMaxHeight( myMaxHeight , true );
  if ( createInfo.myToolTip != 0 ) {
    myListView->setToolTip( createInfo.myToolTip );
  }
  // alignment
  int alignmentH = Qt::AlignLeft ;
  switch ( createInfo.myAlignment ) {
  case GuiItem::AT_LEFT   : alignmentH = Qt::AlignLeft    ; break ;
  case GuiItem::AT_CENTER : alignmentH = Qt::AlignHCenter ; break ;
  case GuiItem::AT_RIGHT  : alignmentH = Qt::AlignRight   ; break ;    
  }
  // TODO ... myListView->setAlignment( alignmentH | AlignVCenter | ExpandTabs );
}


GuiListView::~GuiListView()
{
}


/** update the font & the icons (of itself & the ones that are inside) */
void GuiListView::updateFont()
{
  GuiItem::updateFont(myListView);  
}


void GuiListView::updateIcon()
{

}


//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiSlider                                //
//-------------------------------------------------------------------------------------//



GuiSlider::GuiSlider( GuiTeam & wg , QWidget * parent , const GuiSlider::CreateInfo & createInfo )
: QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_SLIDER,createInfo.myId)
{
  // create if needed
  mySlider = new QSlider(parent);
  mySlider->setObjectName(createInfo.myName);
  // orientation
  Qt::Orientation orientation = mySlider->orientation();
  if ( createInfo.myAspect & GuiItem::AT_VERTICAL   ) { orientation = Qt::Vertical   ; }
  if ( createInfo.myAspect & GuiItem::AT_HORIZONTAL ) { orientation = Qt::Horizontal ; }
  mySlider->setOrientation( orientation );
  bool isVertical = (orientation == Qt::Vertical);
  // resize policy
  QSizePolicy::Policy hor  = isVertical ? QSizePolicy::Minimum   : QSizePolicy::Expanding ; // MinimumExpanding ;
  QSizePolicy::Policy vert = isVertical ? QSizePolicy::Expanding : QSizePolicy::Minimum ;
  mySlider->setSizePolicy( hor , vert );
  // ticks
  QSlider::TickPosition tickSetting = mySlider->tickPosition();
  if ( createInfo.myAspect & GuiItem::AT_TICK_ABOVE ) { tickSetting = isVertical ? QSlider::TicksAbove : QSlider::TicksLeft  ; }
  if ( createInfo.myAspect & GuiItem::AT_TICK_BELOW ) { tickSetting = isVertical ? QSlider::TicksBelow : QSlider::TicksRight ; }
  if ( createInfo.myAspect & GuiItem::AT_TICK_BOTH  ) { tickSetting = QSlider::TicksBothSides ; }
  mySlider->setTickPosition( tickSetting );
  // tooltip
  if ( createInfo.myToolTip != 0 ) {
    mySlider->setToolTip( createInfo.myToolTip );
  }
  // font
  myInitializeFont( mySlider );
  // values
  mySlider->setRange( createInfo.myMinValue , createInfo.myMaxValue );
  mySlider->setValue( createInfo.myValue );
  // size
  myMaxWidth  = createInfo.myMaxWidth  ;
  myMaxHeight = createInfo.myMaxHeight ;
  setMaxWidth ( myMaxWidth  , true );
  setMaxHeight( myMaxHeight , true );
  // callbacks
  QObject::connect( mySlider , SIGNAL( valueChanged(int) ) , this , SLOT( slotValueChanged(int) ) );
  QObject::connect( mySlider , SIGNAL( sliderMoved(int)  ) , this , SLOT( slotSliderMoved (int) ) );
  if ( createInfo.myCallbackTypes != 0 ) {
    // 
  }
}


void GuiSlider::updateFont()
{
  GuiItem::updateFont(mySlider);
}


void GuiSlider::setUserValue( int userValue , bool forceMessage )
{
  mySlider->setValue( userValue );
  if ( forceMessage == true ) {
    slotValueChanged( userValue );
  }
}



void GuiSlider::slotValueChanged( int v )
{
  // send event
  GuiEvent e( this , GuiEvent::ET_VALUE_CHANGED );
  e.setInt(v);
  myTeam.receiveEvent( e );
}



void GuiSlider::slotSliderMoved( int v )
{
  // send event
  GuiEvent e( this , GuiEvent::ET_MOUSE_MOVE );
  e.setInt(v);
  myTeam.receiveEvent( e );
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiSpinBox                               //
//-------------------------------------------------------------------------------------//


GuiSpinBox::GuiSpinBox( GuiTeam & wg , QWidget * parent , const GuiSpinBox::CreateInfo & createInfo )
: QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_SPIN_BOX,createInfo.myId)
{
  // create if needed
  mySpinBox = new QSpinBox(parent);
  mySpinBox->setObjectName(createInfo.myName);
  myInitializeFont( mySpinBox ); 
  // customize
  if ( createInfo.myToolTip != 0 ) {
    mySpinBox->setToolTip( createInfo.myToolTip );
  }
  mySpinBox->setRange( createInfo.myMinValue , createInfo.myMaxValue );
  mySpinBox->setValue( createInfo.myValue );

  myMaxWidth  = createInfo.myMaxWidth  ;
  myMaxHeight = createInfo.myMaxHeight ;
  setMaxWidth ( myMaxWidth  , true );
  setMaxHeight( myMaxHeight , true );

  mySpinBox->setSizePolicy( QSizePolicy::MinimumExpanding , QSizePolicy::Fixed );

  // callbacks
  QObject::connect( mySpinBox , SIGNAL( valueChanged(int) ) , this , SLOT( slotValueChanged(int) ) );
  if ( createInfo.myCallbackTypes != 0 ) {
    //
  }
}


void GuiSpinBox::updateFont()
{
  GuiItem::updateFont(mySpinBox);
}


void GuiSpinBox::setUserValue( int userValue , bool forceMessage )
{
  mySpinBox->setValue( userValue );
  if ( forceMessage == true ) {
    slotValueChanged( userValue );
  }
}



void GuiSpinBox::slotValueChanged( int v )
{
  // send event
  GuiEvent e( this , GuiEvent::ET_VALUE_CHANGED );
  e.setInt(v);
  myTeam.receiveEvent( e );
}



//-------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------//
//    GuiTableTrackingEvent 
//    required by  EVENT SENDER : GuiTable                                             //
//-------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------//




GuiTableTrackingEvent::GuiTableTrackingEvent()
{
  /** identification */
  myTable            =  0 ;
  myFirstColumn      = -1 ;
  mySecondColumn     = -1 ;
  myThirdColumn      = -1 ;
  myFourthColumn     = -1 ;
  /** previous location */
  myPreviousRow      = -2 ;
  myPreviousColumn   = -2 ;
  /** current location */
  myRow              = -1 ;
  myColumn           = -1 ;
  /** values */
  myFirstIntValue    =  0 ;
  mySecondIntValue   =  0 ;
  myThirdIntValue    =  0 ;
  myFourthFloatValue =  0 ;
}


bool GuiTableTrackingEvent::setColumnsToTrack( GuiTable * table ,
                                               int firstColumn , int secondColumn ,
                                               int thirdColumn , int fourthColumn )
{
  myFirstColumn  = firstColumn  ;
  mySecondColumn = secondColumn ;
  myThirdColumn  = thirdColumn  ;
  myFourthColumn = fourthColumn ;
  // check at least one has to be tracked
  if ( myFirstColumn  >= 0 ||
       mySecondColumn >= 0 ||
       myThirdColumn  >= 0 ||
       myFourthColumn >= 0  ) {
    myTable = table ;
    return true ;
  }
  else {
    myTable = 0 ;
    return false ;
  }
}


bool GuiTableTrackingEvent::setRowColumn( int row , int col )
{
  if ( row < 0 ) { row = -1; }
  if ( col < 0 ) { col = -1; }
  if ( myRow != row || myColumn != col ) {
    myPreviousRow    = myRow    ;
    myPreviousColumn = myColumn ; 
    myRow            = row      ;
    myColumn         = col      ;
    return true ;
  }  
  else {
    return false ;
  }
}


void  GuiTableTrackingEvent::setDefaultValues(  int firstColumnValue , int secondColumnValue ,
                                                  int thirdColumnValue , int fourthColumnValue )
{
  if ( firstColumnValue  != -1 && myFirstColumn  == -1 ) {
    myFirstIntValue  = firstColumnValue ;
  }
  if ( secondColumnValue != -1 && mySecondColumn == -1 ) {
    mySecondIntValue = secondColumnValue ;
  }
  if ( thirdColumnValue  != -1 && myThirdColumn  == -1 ) {
    myThirdIntValue  = thirdColumnValue ;
  }
  if ( fourthColumnValue != -1 && myFourthColumn == -1 ) {
    myFourthFloatValue = fourthColumnValue ;
  }
}



GuiTableTrackingEvent * GuiTableTrackingEvent::getValues()
{
  static const char * METHOD_NAME = "getValues()" ;

  // not on the table
  if ( myTable == 0 || myRow < 0 ) { return 0 ; }

  // at the moment, the values are : INT INT INT FLOAT ...
  // it could be adapted according to the column type ()
  QString errorMessage ;
  if ( myFirstColumn  != -1 ) {
    myFirstIntValue  = myTable->getInt( myRow , myFirstColumn  , errorMessage , false );
  }
  if ( mySecondColumn != -1 ) {
    mySecondIntValue = myTable->getInt( myRow , mySecondColumn , errorMessage , false );
  }
  if ( myThirdColumn   != -1 ) {
    myThirdIntValue  = myTable->getInt( myRow , myThirdColumn  , errorMessage , false );
  }
  if ( myFourthColumn  != -1 ) {
    myFourthFloatValue = myTable->getFloat( myRow , myFourthColumn , errorMessage , false );
  }
  // values
  MscDg::trace( CLASS_NAME , METHOD_NAME , "%d   %d   %d   %d  Error '%s'" ,
               myFirstIntValue , mySecondIntValue , myThirdIntValue , myFourthFloatValue ,
               GuiUtl::getString(errorMessage) ) ;
  // error
  if ( errorMessage.isEmpty() == false ) {
    return 0 ;
  }
  // done
  else {
    return this ;
  }
}


//-------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------//
//    Derived "QTable" so the mouse event is considered                                //
//    required by  EVENT SENDER : GuiTable                                             //
//-------------------------------------------------------------------------------------//
//-------------------------------------------------------------------------------------//



class GuiDerivedTable : public QTableWidget
{
public :
  static const char * CLASS_NAME ;
  GuiDerivedTable( GuiTable & t , QWidget* parent=0, const char* name=0 ) 
    : QTableWidget( parent ) , myGuiTable( t )
  {
    setObjectName( name );
    // no need to track the column & row unless there are columns to track
    setMouseTracking( false );
  }
  //=========================
  // tracking
  //=========================

  // see: "setMouseTracking()"
  void mouseMoveEvent( QMouseEvent * e )
  {
    QTableWidget::mouseMoveEvent(e);   
    myGuiTable.setRowColumnWhereCursorIs( rowAt( e->pos().y() ) , columnAt( e->pos().x() ) );
  }
  void leaveEvent ( QEvent * e ) 
  {
    myGuiTable.setRowColumnWhereCursorIs( -1 , -1 );
    QTableWidget::leaveEvent(e);
  }
  //=========================
  // resize according to the strategy
  // used to resize the widget (if needed)
  //=========================
  void showEvent( QShowEvent * e ) 
  {
    QTableWidget::showEvent(e);
    myGuiTable.resizeInVisibleArea();
  }
  void resizeEvent( QResizeEvent * e )
  {
    QTableWidget::resizeEvent(e);
    myGuiTable.resizeInVisibleArea();
  }
private :
  GuiTable & myGuiTable ;
};
const char * GuiDerivedTable ::CLASS_NAME = "GuiDerivedTable" ;




//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiTable                                 //
//-------------------------------------------------------------------------------------//




//-----------------------------------------//
// Instance Methods of "GuiTable"          //
//-----------------------------------------//



GuiTable::GuiTable( GuiTeam & wg , int id , const GuiTable::CreateInfo & createInfo )
: QObject( wg.getGuiItem(id)->getWidget() ) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_TABLE,createInfo.myId)
{
  myInitialize( wg.getGuiItem(id)->getWidget() , createInfo , 0 );
}    


GuiTable::GuiTable( GuiTeam & wg , GuiItem * e , const GuiTable::CreateInfo & createInfo )
: QObject( e->getWidget() ) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_TABLE,createInfo.myId)
{
  myInitialize( e->getWidget() , createInfo , 0 );
}


GuiTable::GuiTable( GuiTeam & wg , QWidget * parent , const GuiTable::CreateInfo & createInfo , QTableWidget * provided )
: QObject( parent ) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_TABLE,createInfo.myId)
{
  myInitialize( parent , createInfo , provided );
}




void GuiTable::myInitialize( QWidget * parent , const GuiTable::CreateInfo & createInfo , QTableWidget * provided )
{
  static const char * METHOD_NAME = "myInitialize()" ;
  
  // selection : see QTable::SelectionMode
  mySliderFlags    = 0 ;
  mySelectionMode  = GuiItem::SM_NO_SELECTION ;
  myResizeStrategy = GuiTable::RST_RESIZE_AS_PRESENT ;

  // analyse the columns . it finds out the last column.
  // let's notice all the indexes must be defined
  myColumnsTotalWidth = 0 ;
  myColumnHeaders.clear();

  // popup menu
  myPopupMenu   =  0 ;
  myPopupRow    = -1 ;
  myPopupColumn = -1 ;

  // create it
  myDerivedTable = 0 ;
  if ( provided == 0 ) {
    myDerivedTable = new GuiDerivedTable(*this,parent,createInfo.myName);
    myTable        = myDerivedTable;
  }
  else {
    myTable        = provided ;
  }


  // font
  myInitializeFont( myTable ); 

  // tooltip
  if ( createInfo.myToolTip != 0 ) {
    myTable->setToolTip( createInfo.myToolTip );
  }
  // the unit to select is the row
  myTable->setSelectionBehavior( QAbstractItemView::SelectRows );

  // selection mode uses QAbstractItemView::SelectionMode . See also: ContiguousSelection
  setSelectionMode( createInfo.mySelectionMode );

  // set the columns 
  //getHorizontalHeaderView()->setResizeMode( QHeaderView::Stretch );
  setColumnHeaders(  createInfo.myColumnsNumber , createInfo.myColumns );

  // Remark: 'currentChanged(int,int)' is also called 
  // when 'clicked(int,int,int,const QPoint &)' is called. So avoid both
  // ET_CLICKED  
  QObject::connect( myTable , SIGNAL( cellClicked(int,int) )   , this , SLOT( slotClicked(int,int) ) );
  // ET_SELECTION
  QObject::connect( myTable , SIGNAL( itemSelectionChanged() ) , this , SLOT( slotSelectionChanged() ) );
  // ET_VALUE_CHANGED
  QObject::connect( myTable , SIGNAL( cellChanged(int,int) )   , this , SLOT( slotValueChanged(int,int) ) );
  // ET_DOUBLE_CLICK
  if ( createInfo.myCallbackTypes & GuiEvent::ET_DOUBLE_CLICK ) {
    QObject::connect( myTable , SIGNAL( cellDoubleClicked(int,int) ) , this , SLOT( slotDoubleClicked(int,int) ) );
  }
  // ET_PRESSED
  if ( createInfo.myCallbackTypes & GuiEvent::ET_PRESSED ) {
    QObject::connect( myTable , SIGNAL( cellPressed(int,int) ) , this , SLOT( slotCellPressed(int,int) ) );
  }

  // release the slider
  addUpdateForHorizontalScrollbar();
  addUpdateForVerticalScrollbar();
}


GuiTable::~GuiTable()
{
  // delete all the gui items
  std::vector< GuiItem * >::iterator iter ;
  while ( (iter=myGuiItems.begin()) != myGuiItems.end() ) {
    // DONT'T DELETE "*iter" AS IT'S DONE BY THE DESTRUCTOR OF THE GuiTeam.
    // Simply empty the list
    myGuiItems.erase(iter);
  }
}



Qt::ItemDataRole GuiTable::getRole( int col ) const 
{
  Qt::ItemDataRole role = Qt::EditRole ;
  if ( 0 <= col && col < myEditTypeVector.size() ) {
    switch ( myEditTypeVector[col] )
      {
      case GuiItem::EDT_NONE     : role = Qt::DisplayRole ; break ; /** not editable */
      case GuiItem::EDT_ANY      : role = Qt::EditRole    ; break ; /** no validator */
      case GuiItem::EDT_BOOL     : role = Qt::EditRole    ; break ; /**  */
      case GuiItem::EDT_INT      : role = Qt::EditRole    ; break ; /** int validator */
      case GuiItem::EDT_FLOAT    : role = Qt::EditRole    ; break ; /** float validator */
      case GuiItem::EDT_PROPERTY : role = Qt::EditRole    ; break ; /** string validator no space or special characters */
      case GuiItem::EDT_REMARK   : role = Qt::DisplayRole ; break ; /** identify the text as the remark field in a QTable */ 
      }
  }
  return role ;
}



QHeaderView * GuiTable::getHorizontalHeaderView()
{
  QHeaderView * headerView = myTable->horizontalHeader() ;
  if ( headerView == 0 ) { 
    headerView = new QHeaderView( Qt::Horizontal , myTable );
    myTable->setHorizontalHeader( headerView );
  }
  return headerView ;
}


QTableWidget * GuiTable::getTable() const
{
  return myTable ;
}


void GuiTable::updateFont()
{
  // QTable
  GuiItem::updateFont( myTable );
  for ( int row=0 ; row < myTable->rowCount() ; ++row ) {
    // TODO myTable->adjustRow(row);
  }
  // component
  for ( auto iter=myGuiItems.begin() ; iter != myGuiItems.end() ; ++iter ) {
    (*iter)->updateFont();
  }
  if ( myPopupMenu != 0 ) {
    myPopupMenu->updateFont();
  }
}


void GuiTable::updateIcon()
{
  for ( auto iter=myGuiItems.begin() ; iter != myGuiItems.end() ; ++iter ) {
    (*iter)->updateIcon();
  }
  if ( myPopupMenu != 0 ) {
    myPopupMenu->updateIcon();
  }
}




void GuiTable::slotCellPressed( int row , int col )
{
  // send event
  GuiEvent e( this , GuiEvent::ET_PRESSED );
  e.setRow(row);
  e.setColumn(col);
  myTeam.receiveEvent( e );
}



void GuiTable::slotClicked( int row , int col )
{
  // send event
  GuiEvent e( this , GuiEvent::ET_CLICKED );
  e.setRow(row);
  e.setColumn(col);
  myTeam.receiveEvent( e );
}



void GuiTable::slotDoubleClicked( int row , int col )
{
  // send event
  GuiEvent e( this , GuiEvent::ET_DOUBLE_CLICK );
  e.setRow(row);
  e.setColumn(col);
  myTeam.receiveEvent( e );
}


void GuiTable::slotSelectionChanged()
{
  // send event
  GuiEvent e( this , GuiEvent::ET_SELECTION );
  int row = getSelectedRow();
  e.setRow(row);
  myTeam.receiveEvent( e );
}



void GuiTable::slotValueChanged( int row , int col )
{
  static const char * METHOD_NAME = "slotValueChanged()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Row %d Col %d" , row , col );

  // event
  bool sendMessage = false ;
  GuiEvent e( this , GuiEvent::ET_VALUE_CHANGED );
  e.setRow(row);
  e.setColumn(col);
  e.setBool( getBool( row , col ) );

  // correct the value if needed 
  if ( 0 <= col && col < myColumnHeaders.size() ) {

    switch ( myColumnHeaders.find(col)->second.myEditType ) {
      
      //===================//
      // **** INTEGER **** //
      //===================//

    case GuiItem::EDT_BOOL :
      {
        e.setBool( getBool( row , col ) );
        sendMessage = true ;
      } break;

      //===================//
      // **** INTEGER **** //
      //===================//

    case GuiItem::EDT_INT : // SHOULD USE THE "Validator" facilities ... (?)
      {
        // initial text
        QString text = getString( row , col );
        // integer
        int value = text.toInt();
        // create a new string
        QString newText ;
        newText.sprintf("%d",value);
        // differs
        if ( newText != text ) {
          setString( row , col , newText );
        }
      } break ;
      
      
      //===================//
      // ****  FLOAT  **** //
      //===================//
      
    case GuiItem::EDT_FLOAT : // SHOULD USE DIRECTLY THE "QVariant" facilities ... (?)
      {
        // initial text
        QString text = getString( row , col );
        // create a new string
        QString newText ;
        for ( int i=0 ; i < text.length() ; ++i ) {
          QChar c = text.at(i);
          if ( c.isNumber() == true || c == 'e' || c == 'E' || c == '.' ) {
            newText += c ;
          }
        }
        if ( newText.isEmpty() == true ) {
          newText = "0.0";
        }
        // differs
        if ( newText != text ) {
          setString( row , col , newText );
        }
      } break ; 
    }
    
  }
   
  //===================//
  // ****  EVENT  **** //
  //===================//
  
  if ( sendMessage == true ) {
      myTeam.receiveEvent( e );
  }
}


void GuiTable::slotSliderReleased()
{
  // TODO (?) updateContents();
}


void GuiTable::setGuiItem( int rowIndex , int columnIndex , GuiItem * guiItem )
{
  static const char * METHOD_NAME = "setGuiItem()" ;
  if ( guiItem == 0 || guiItem->isWidget() == false ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Row:%d Column:%d Item is not a widget" ,
                 rowIndex , columnIndex );
  }
  else if ( rowIndex    < 0 || myTable->rowCount() <= rowIndex    || 
            columnIndex < 0 || myTable->columnCount() <= columnIndex ) {
    MscDg::error( CLASS_NAME , METHOD_NAME ,
                 "Row:%d Column:%d is out bounds Rows:(0-%d) Columns:(0-%d) " ,
                 rowIndex , columnIndex , myTable->rowCount() , myTable->columnCount() );
  }
  else {
    // SHOULD HAVE BEEN DELETED BEFORE ...
    if ( myTable->cellWidget( rowIndex , columnIndex ) != 0 ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Row:%d Column:%d Widget should have been cleaned before" ,
                   rowIndex , columnIndex );    
    }
    // add the "GuiItem"
    guiItem->setRowColumn(rowIndex,columnIndex);
    myGuiItems.push_back(guiItem) ;
    guiItem->setFormatHint( myFormatHint );
    // show the widget
    QWidget * w = guiItem->getWidget() ;
    // resize (if needed) the row
    int height = w->sizeHint().height();
    if ( height > myTable->rowHeight( rowIndex ) ) {
      myTable->setRowHeight( rowIndex , height );
    }
    // set the widget
    myTable->setCellWidget( rowIndex , columnIndex , w );
  }
}



GuiItem * GuiTable::getGuiItem( int rowIndex , int columnIndex , bool removeFromList )
{
  static const char * METHOD_NAME = "getGuiItem()" ;
  GuiItem * guiItem = 0 ;
  if ( rowIndex    < 0 || myTable->rowCount() <= rowIndex    || 
       columnIndex < 0 || myTable->columnCount() <= columnIndex ) {
    MscDg::error( CLASS_NAME , METHOD_NAME ,
                 "Row:%d Column:%d is out bounds Rows:(0-%d) Columns:(0-%d) " ,
                 rowIndex , columnIndex , myTable->rowCount() , myTable->columnCount() );
  }
  else {  
    // widget in the cell
    QWidget * widget = myTable->cellWidget( rowIndex , columnIndex );
    if ( widget != 0 ) {
      for ( auto iter=myGuiItems.begin() ; iter != myGuiItems.end() ; ++iter ) {
        if ( (*iter)->getWidget() == widget ) {
          guiItem = *iter ;
          // remove from the list
          if ( removeFromList == true ) {
            myGuiItems.erase(iter);
          }
          // must stop looking as the iterator is not valid anymore
          break;
        }
      }
    }
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Row:%d Col:%d Found:%s" ,
               rowIndex , columnIndex , (guiItem ? "true" : "false") );
  return guiItem ;
}



bool GuiTable::deleteGuiItem( int rowIndex , int columnIndex , bool mustBePresent )
{
  static const char * METHOD_NAME = "deleteGuiItem()" ;
  // values
  GuiItem * guiItem   = getGuiItem( rowIndex , columnIndex , true );
  QWidget * guiWidget   = guiItem ? guiItem->getWidget() : 0 ;
  QWidget * tableWidget = myTable->cellWidget( rowIndex , columnIndex );
  // check 
  if ( mustBePresent == true ) {
    if ( guiItem == 0 ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Row:%d Column:%d  GuiItem is null" ,
                   rowIndex , columnIndex );
    }
    if ( tableWidget == 0 ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Row:%d Column:%d  Table Widget is null" ,
                   rowIndex , columnIndex );
    }
    if ( tableWidget != guiWidget ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Row:%d Column:%d  Table %d Gui %d widget mismatch" ,
                   rowIndex , columnIndex , tableWidget , guiWidget );
    }
  }
  // clear (ok even if it's null)
  delete guiItem ;
  if ( tableWidget != 0 ) {
    myTable->removeCellWidget( rowIndex , columnIndex );    
  }
  return (guiItem != 0);
}



void GuiTable::setSelectionMode( GuiItem::SelectionMode selectionMode )
{
  mySelectionMode = selectionMode ;
  switch ( mySelectionMode ) {
  case GuiItem::SM_NO_SELECTION : myTable->setSelectionMode( QAbstractItemView::NoSelection       ); break;
  case GuiItem::SM_SINGLE       : myTable->setSelectionMode( QAbstractItemView::SingleSelection   ); break;
  case GuiItem::SM_EXTENDED     : myTable->setSelectionMode( QAbstractItemView::ExtendedSelection ); break;
  case GuiItem::SM_MULTI        : myTable->setSelectionMode( QAbstractItemView::MultiSelection    ); break; 
  case GuiItem::SM_SINGLE_ROW   : myTable->setSelectionMode( QAbstractItemView::SingleSelection   ); break;
  case GuiItem::SM_MULTI_ROW    : myTable->setSelectionMode( QAbstractItemView::ExtendedSelection ); break; // WAS Qt3::MultiRow
  }
}



void GuiTable::setColumnHeaders( int numberOfColumns , GuiTable::ColumnCreateInfo * columns )
{
  myColumnsTotalWidth = 0 ;
  myColumnHeaders.clear();

  // fill in the column headers
  int i=0 , columnIndex=0 ;
  std::map< int , ColumnHeader > columnHeaders ;
  for ( i = 0 ; i < numberOfColumns ; ++i ) {
    columnIndex = columns[i].myColumnIndex ;
    if ( 0 <= columnIndex && columnIndex < 100 ) {
      columnHeaders[ columnIndex ] = columns[i];
    }
  }
  // define the values
  const std::list<QString> textList ;
  setHeaderStrings( textList , true , &columnHeaders );

  // resize mode . Could be defined for each column
  /**
     QHeaderView::Interactive	0	The user can resize the 
     QHeaderView::Fixed	2	The user cannot resize the section.
     QHeaderView::Stretch	1	QHeaderView will automatically resize the section to fill the available space.
     QHeaderView::ResizeToContents	3	
  **/ 
  getHorizontalHeaderView()->setSectionResizeMode( QHeaderView::Stretch );
}



void GuiTable::setHeaderStrings( const std::list<QString> & headerStrings ,
                                 bool columnsHeaders ,
                                 std::map< int , ColumnHeader > * columnHeaderMap )
{
  static const char * METHOD_NAME = "setHeaderStrings()" ;
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME , "Number %ld for %s" ,
                           headerStrings.size() , columnsHeaders ? "columns" : "rows" );

  // ----------------------------------------
  // *** check all the column indexes have been defined
  //     else the indexes have not been set properly (they must be in order)
  //     THIS IS CALLED AT THE 
  // ----------------------------------------

  // values from the initialization
  if ( columnHeaderMap != 0 ) {
    
    // resize of the columns
    //QHeaderView * headerView = getHorizontalHeaderView();
    //headerView->setResizeMode( QHeaderView::ResizeToContents );

    // should provide an hint ...

    // check & get the values in the header
    int i=0 ;
    for ( auto iter=columnHeaderMap->begin() ; iter != columnHeaderMap->end() ; ++iter , ++i ) {
      QString label = iter->second.myText ;
      if ( iter->first != i ) {
        MscDg::fatal( CLASS_NAME , METHOD_NAME , "Index %d is not defined (%s)" , i , GuiUtl::getString(label) );
      }
      // debug
      if ( dbOn == true ) {
        GuiUtl::print( "  Col %d '%s'" , i , GuiUtl::getString(label) );
      }
    }

    // initialize
    myColumnsTotalWidth = 0 ;
    myColumnHeaders.clear();
    setNumberOfColumns( columnHeaderMap->size() );

    // need to update the map
    QStringList labels ;
    std::vector< GuiItem::EditType > editTypeVector ;
    for ( auto iter=columnHeaderMap->begin() ; iter != columnHeaderMap->end() ; ++iter , ++i ) {
      myColumnHeaders[iter->first] = iter->second ;
      myColumnsTotalWidth += iter->second.mySize ;
      labels.push_back( iter->second.myText );
      editTypeVector.push_back( iter->second.myEditType );
#if 0
      header->setLabel( iter->first         ,
                        iter->second.myText ,
                        iter->second.mySize );
      myTable->setColumnReadOnly( iter->first ,
                                  iter->second.myEditType == GuiItem::EDT_NONE );
#endif
    }
    myTable->setHorizontalHeaderLabels( labels );
    setEditTypes( editTypeVector );
  }

  // ----------------------------------------
  // *** change the headers of the columns
  // ----------------------------------------

  else if ( columnsHeaders == true ) {

    // resize of the columns
    QHeaderView * headerView = getHorizontalHeaderView();
    headerView->setSectionResizeMode( QHeaderView::ResizeToContents );

    int col=0 ;
    std::list <QString>::const_iterator colIter;
    std::vector< GuiItem::EditType > editTypeVector ;
    // initialize OR change the number of columns 
    if ( getNumberOfColumns() != headerStrings.size() ) {

      // debug
      if ( dbOn == true ) {
        GuiUtl::print( "    Table set numCols %d original size %d" , headerStrings.size() , getNumberOfColumns() );
      }

      // initialize
      myColumnsTotalWidth = 0 ;
      myColumnHeaders.clear();
      setNumberOfColumns( headerStrings.size() );

      // need to update the map
      for ( colIter=headerStrings.begin() ; colIter != headerStrings.end() ; ++colIter ) {
        GuiTable::ColumnHeader colHeader( col , "" , GuiItem::EDT_NONE , 50 );
        editTypeVector.push_back( colHeader.myEditType );
        colHeader.myText      = *colIter  ;
        myColumnHeaders[col]  = colHeader ;
        myColumnsTotalWidth  += colHeader.mySize ;
#if 0
        header->setLabel( iter->first         ,
                          iter->second.myText ,
                          iter->second.mySize );
        myTable->setColumnReadOnly( iter->first ,
                                    iter->second.myEditType == GuiItem::EDT_NONE );
#endif
      }
    }

    // set the headers of the columns (horizontally) 
    QStringList labels ;
    for ( col=0 , colIter=headerStrings.begin() ; colIter != headerStrings.end() ; ++colIter , ++col ) {
      labels.push_back( *colIter );
      // debug
      if ( dbOn == true ) {
        GuiUtl::print( "  Col %d '%s'" , col , GuiUtl::getString(*colIter) );
      }      
    }
    myTable->setHorizontalHeaderLabels( labels );
    setEditTypes( editTypeVector );
  }
  
  // ----------------------------------------
  // *** change the headers of the row
  // ----------------------------------------

  else {

    int row=0 ;
    std::list <QString>::const_iterator rowIter;
    // change the number of rows
    if ( getNumberOfRows() != headerStrings.size() ) { 
      // debug
      if ( dbOn == true ) {
        GuiUtl::print( "    Table set numRows %d original size %d" , headerStrings.size() , getNumberOfRows() );
      }
      setNumberOfRows( headerStrings.size() );
    }

    // set the headers of the rows (vertically)
    QStringList labels ;
    for ( row=0 , rowIter=headerStrings.begin() ; rowIter != headerStrings.end() ; ++rowIter , ++row ) {
      labels.push_back( *rowIter );
      // debug
      if ( dbOn == true ) {
        GuiUtl::print( "  Row %d '%s'" , row , GuiUtl::getString(*rowIter) );
      }
    }
    myTable->setVerticalHeaderLabels( labels );
  }
}



void GuiTable::setHorizontalLabel( int columnIndex , const QString & str , const char * toolTip )
{
  QTableWidgetItem * cell = myTable->horizontalHeaderItem( columnIndex );
  if ( cell == 0 ) {
    cell = new QTableWidgetItem();
    myTable->setHorizontalHeaderItem( columnIndex , cell );
  }
  if ( toolTip != 0 ) { cell->setToolTip( toolTip ); }
  myColumnHeaders[columnIndex].myText = str ;
  cell->setText( str );
}



void GuiTable::setColumnIsEditable( int columnIndex , bool isEditable )
{
  // WAS : table->setColumnReadOnly( col , b )
  // NOW should deal with the QFlags .
  // WAS: 
  //     <property name="readOnly">
  //     <bool>true</bool>
  //     </property> 
  // NOW DEALT WITH "GuiItem::EDT_NONE" IN "GuiTable::ColumnCreateInfo"
}
                   


void GuiTable::setEditable( bool b ) 
{
  for ( int col=0 ; col < myTable->columnCount() ; ++col ) {
    setColumnIsEditable( col , b );
  }
}




void GuiTable::setNumberOfRows( int numRows )
{
  if ( getNumberOfRows() != numRows ) {
    // delete the items that aren't needed any more (if any ... only if the function
    // "setGuiItem" have been used
    // Let's notice that QTable takes ownership of the widget and will delete it
    if ( myGuiItems.empty() == false ) {
      for ( int rowIndex=numRows ; rowIndex < myTable->rowCount() ; ++rowIndex ) {
        for ( int columnIndex=0 ; columnIndex < myTable->columnCount() ; ++columnIndex ) {
          // delete (no message if no 'GuiItem' is present) 
          deleteGuiItem( rowIndex , columnIndex , false );
        }
      }
    }
    // clean up the table
    myTable->setRowCount( numRows );
  }
}


int  GuiTable::getNumberOfRows() const
{
  return myTable->rowCount();
}


// SEE also: QTableView::showColumn( int column ) .


void GuiTable::setNumberOfColumns( int numCols )
{
  if ( getNumberOfColumns() != numCols ) {
    // delete the items that aren't needed any more (if any ... only if the function
    // "setGuiItem" have been used
    // Let's notice that QTable takes ownership of the widget and will delete it
    if ( myGuiItems.empty() == false ) {
      for ( int rowIndex=0 ; rowIndex < myTable->rowCount() ; ++rowIndex ) {
        for ( int columnIndex=numCols ; columnIndex < myTable->columnCount() ; ++columnIndex ) {
          // delete (no message if no 'GuiItem' is present) 
          deleteGuiItem( rowIndex , columnIndex , false );
        }
      }
    }
    // clean up the table
    myTable->setColumnCount( numCols );  
  }
}


int GuiTable::getNumberOfColumns() const
{
  return myTable->columnCount();
}


bool GuiTable::swapRows( int fromRow , int toRow )
{
  static const char * METHOD_NAME = "swapRows()" ;
  if ( fromRow < 0 || myTable->rowCount() <= fromRow || toRow < 0 || myTable->rowCount() <= toRow || fromRow == toRow ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Mismatch with from %d to %d range[0-%d]" , fromRow , toRow , myTable->rowCount() );
    return false ;
  }
  int col = 0 ;
  // storage of the items
  std::vector< QTableWidgetItem * > fromItems ;
  std::vector< QTableWidgetItem * > toItems   ;
  for ( col=0 ; col < myTable->columnCount() ; ++col ) {
    fromItems.push_back( myTable->takeItem( fromRow , col ) );
    toItems  .push_back( myTable->takeItem( toRow   , col ) );
  }
  // put them back
  std::vector< QTableWidgetItem * >::const_iterator fromIter , toIter ;
  for ( col  = 0 , fromIter=fromItems.begin() , toIter=toItems.begin() ;
        fromIter != fromItems.end() , toIter != toItems.end() ;
        col += 0 , ++fromIter , ++toIter ) {
    myTable->setItem( fromRow , col , *toIter   );
    myTable->setItem( toRow   , col , *fromIter );
  }
  return true ;
}


void GuiTable::ensureCellVisible( int row , int col )
{
  const QTableWidgetItem * cell = myTable->item(row,col) ;
  if ( (cell != 0) && (myTable->isColumnHidden(col)==true || myTable->isRowHidden(row)==true) ) {
    myTable->scrollToItem( cell );
  }
}


void GuiTable::clearCell( int rowIndex , int columnIndex )
{
  QTableWidgetItem * cell = getCell( rowIndex , columnIndex , false );
  // see what Qt3 did:
  if ( cell != 0 ) { cell->setText(""); }
  // SEE ALSO : myTable->clearContents();
}


void GuiTable::clearCurrentCell()
{
  clearCell( myTable->currentRow() , myTable->currentColumn() );
}


void GuiTable::updateCell( int rowIndex , int columnIndex )
{
  QTableWidgetItem * cell = getCell( rowIndex , columnIndex , false );
  // define what to do
  if ( cell != 0 ) {} //  { cell->setText(""); }
}


void GuiTable::updateCurrentCell()
{
  updateCell( myTable->currentRow() , myTable->currentColumn() );
}



bool GuiTable::getCellIsEmpty( int rowIndex , int columnIndex )
{
  QTableWidgetItem * cell = getCell( rowIndex , columnIndex , false );
  if ( cell == 0 ) { return true ; }
  QString str = cell->text();
  return str.isEmpty();
}


bool GuiTable::moveSelectedRow( int step )
{
  int numberOfRows = getNumberOfRows();
  int selectedRow  = getSelectedRow() ;
  int targetRow    = selectedRow + step ;
  if ( step != 0 && 0 <= targetRow && targetRow <= (numberOfRows-1) ) {
    // swap rows
    if ( swapRows( selectedRow , targetRow ) == false ) {
      return false ;
    }
    // CAN't DO IT : PROTECTED myTable->updateGeometries(); // WAS Qt3 updateContents();
    ensureCellVisible( selectedRow , 0 );
    return true  ;
  }
  else {
    return false ;
  }
}


// ... (-2):two rows  (-1):one down * (+1):one row up ... //
// it overwrites the target
// it's used to delete
bool GuiTable::moveRowsAfter( int rowIndex , int orientation )
{
  static const char * METHOD_NAME = "moveRowsAfter()" ;
  bool isOk = false ;
  int  numberOfRows = myTable->rowCount();
  int  numberOfCols = myTable->columnCount();
  int  startRow     = 0 ;
  int  endRow       = 0 ;
  // DUPLICATES THE TARGET STARTING FROM THE END
  if ( orientation > 0 ) {
    startRow = (numberOfRows - 1);
    endRow   = (rowIndex + orientation);
    for ( int toRow=startRow ; toRow >= endRow ; --toRow ) {
      int fromRow = (toRow - orientation);
      for ( int col=0 ; col < numberOfCols ; ++col ) {
        setString( toRow , col , getString( fromRow , col ) );
      }
    }
    isOk = true ;
  }
  // ERASE THE TARGET STARTING FROM THE TARGET
  else if ( orientation < 0 ) {
    startRow =  rowIndex ;
    endRow   = (numberOfRows + orientation) - 1;
    for ( int toRow=startRow ; toRow <= endRow ; ++toRow ) {
      int fromRow = (toRow - orientation);
      for ( int col=0 ; col < numberOfCols ; ++col ) {
        setString( toRow , col , getString( fromRow , col ) );
      }
    }
    isOk = true;
  }
  // find out if something has been done
  if ( isOk == false ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "RowIndex %d Orientation %d Moving %d -> %d" ,
                 rowIndex , orientation , startRow , endRow );
  }
  return isOk ;
}



bool GuiTable::deleteRow( int rowIndex )
{
  // move rows starting form the end . It erases the target
  moveRowsAfter( rowIndex , -1 );
  // change size
  myTable->setRowCount( myTable->rowCount() - 1 );
  return true ;
}



void GuiTable::removeRow( int rowIndex )
{
  deleteRow( rowIndex );
}


void GuiTable::insertRow( int rowTarget )
{
  myTable->clearSelection();
  // add a row
  myTable->setRowCount( myTable->rowCount() + 1 );
  // move existing to then end
  int lastRow = (myTable->rowCount() - 1) ;
  if ( 0 <= rowTarget && rowTarget < lastRow ) {
    // move all 
    for ( int col=0 ; col < myTable->columnCount() ; ++col ) {
      for ( int row=lastRow ; row > rowTarget ; --row ) {
        myTable->setItem( row , col , myTable->takeItem((row-1),col) );
      }
    }
  }
}


int GuiTable::contentsWidth()
{
  // not so sure about it ...
  return myTable->width() - 20 ; // place for the vertical scroller .. could do better.
}


/** cells */



//=========================
// get the cell
//=========================


QTableWidgetItem * GuiTable::getCell( int rowIndex , int colIndex , bool createIt )
{
  static const char * METHOD_NAME = "getCell()" ;
  // create if needed
  if ( createIt == true ) {
    if ( rowIndex    >= myTable->rowCount()    ) {
      myTable->setRowCount(rowIndex);
      MscDg::trace( GuiTable::CLASS_NAME , METHOD_NAME , "Created row %d" , rowIndex );
    }
    if ( colIndex >= myTable->columnCount() ) {
      myTable->setColumnCount(colIndex);
      MscDg::trace( GuiTable::CLASS_NAME , METHOD_NAME , "Created column %d" , colIndex );
    }
  }
  // 
  QTableWidgetItem * cell = 0 ;
  if ( 0 <= rowIndex && rowIndex < myTable->rowCount()    && 
       0 <= colIndex && colIndex < myTable->columnCount() ) {
    cell = myTable->item( rowIndex , colIndex );
    if ( cell == 0 && createIt == true ) {
      // identify how to create it
      
      // create it
      cell = new QTableWidgetItem();
      // set it
      myTable->setItem( rowIndex , colIndex , cell );  
      MscDg::trace( GuiTable::CLASS_NAME , METHOD_NAME , "Created cell at row %d col %d" , rowIndex , colIndex );
    }
  }
  else {
    MscDg::error( GuiTable::CLASS_NAME , METHOD_NAME , "RowIndex:%d ColumnIndex:%d out of bounds" ,
                 rowIndex , colIndex );      
  }
  return cell ;
}



/** set a specific value */


void GuiTable::setString( int rowIndex , int columnIndex , const QString & value )
{
  QTableWidgetItem * cell = getCell(rowIndex,columnIndex,true);
  if ( cell != 0 ) {
    QVariant variant( value );
    cell->setData( getRole(columnIndex) , variant );
  }
}


void GuiTable::setBool( int rowIndex , int columnIndex , bool value , const QString * label )
{
  QTableWidgetItem * cell = getCell(rowIndex,columnIndex,true);
  if ( cell != 0 ) {
    QVariant variant( value );
    cell->setData( getRole(columnIndex) , variant );
    if ( label != 0 ) { cell->setText(*label); }
    cell->setCheckState( value ? Qt::Checked : Qt::Unchecked );
  }
}


void GuiTable::setInt( int rowIndex , int columnIndex , int value )
{
  QTableWidgetItem * cell = getCell(rowIndex,columnIndex,true);
  if ( cell != 0 ) {
    QVariant variant( value );
    cell->setData( getRole(columnIndex) , variant );
  }  
}


void   GuiTable::setFloat( int rowIndex , int columnIndex , float value )
{
  QTableWidgetItem * cell = getCell(rowIndex,columnIndex,true);
  if ( cell != 0 ) {
    QVariant variant( value );
    cell->setData( getRole(columnIndex) , variant );
  }
}


void   GuiTable::setDouble( int rowIndex , int columnIndex , double value )
{
  QTableWidgetItem * cell = getCell(rowIndex,columnIndex,true);
  if ( cell != 0 ) {
    QVariant variant( value );
    cell->setData( getRole(columnIndex) , variant );
  }
}


// get


QString GuiTable::getString( int rowIndex , int columnIndex )
{
  QString value ;
  QTableWidgetItem * cell = getCell(rowIndex,columnIndex,false);
  if ( cell != 0 ) {
    value = cell->data( getRole(columnIndex) ).toString();
  }
  return value;
}


bool GuiTable::getBool( int rowIndex , int columnIndex )
{
  bool value = false ;
  QTableWidgetItem * cell = getCell(rowIndex,columnIndex,false);
  if ( cell != 0 ) {
    value = (cell->checkState() == Qt::Checked);
  }
  return value;
}


int  GuiTable::getInt( int rowIndex , int columnIndex )
{
  int value = 0 ; 
  QTableWidgetItem * cell = getCell(rowIndex,columnIndex,false);
  if ( cell != 0 ) {
    value = cell->data( getRole(columnIndex) ).toInt();
  }
  return value;
}


float  GuiTable::getFloat( int rowIndex , int columnIndex )
{
  float value = 0.0f ;
  QTableWidgetItem * cell = getCell(rowIndex,columnIndex,false);
  if ( cell != 0 ) {
    value = cell->data( getRole(columnIndex) ).toFloat();
  }
  return value;  
}


double  GuiTable::getDouble( int rowIndex , int columnIndex )
{
  double value = 0.0 ;
  QTableWidgetItem * cell = getCell(rowIndex,columnIndex,false);
  if ( cell != 0 ) {
    value = cell->data( getRole(columnIndex) ).toFloat();
  }
  return value;
}


// 


void GuiTable::showErrorMessage( int rowIndex , int columnIndex , const QString & errorMessage )
{
  static const char * METHOD_NAME = "showErrorMessage()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Row %d Col %d Error '%s'" , rowIndex , columnIndex , GuiUtl::getString(errorMessage) );
  // deselect all
  selectAll( false);
  // show the place
  if ( 0 < rowIndex ) {
    ensureCellVisible( rowIndex , columnIndex ) ;
    myTable->setCurrentCell( rowIndex , columnIndex ) ;
    myTable->selectRow( rowIndex );
  }
  // find the header name
  QString title ;
  title.sprintf( "Row %d Column %d" , rowIndex , columnIndex );
  // pop-up dialog of the form
  GuiForm * form = myTeam.getParentForm();
  if ( form != nullptr ) {
    form->messageBox( /*myTable ,*/ errorMessage , title );
  }
}


int GuiTable::getInt( int rowIndex , int columnIndex , QString & errorMessage , bool showError )
{
  int    value = 0 ;
  if ( errorMessage.isEmpty() == false ) {
    return value ;
  }
  bool    isOk = false ;
  QString str  = getString( rowIndex , columnIndex , errorMessage , false );
  if ( errorMessage.isEmpty() == true ) {
    value = str.toInt( &isOk );
    if ( isOk == false ) {
      errorMessage.sprintf( "Can't get Int from '%s'" , GuiUtl::getString(str) );
    }
  }
  // error
  if ( showError == true && isOk == false ) {
    showErrorMessage( rowIndex , columnIndex , errorMessage );
  }
  return value ;
}



float GuiTable::getFloat( int rowIndex , int columnIndex , QString & errorMessage , bool showError )
{
  float  value = 0 ;
  if ( errorMessage.isEmpty() == false ) {
    return value ;
  }
  bool    isOk = false ;
  QString str  = getString( rowIndex , columnIndex , errorMessage , false );
  if ( errorMessage.isEmpty() == true ) {
    value = str.toFloat( &isOk );
    if ( isOk == false ) {
      errorMessage.sprintf( "Can't get Float from '%s'" , GuiUtl::getString(str) );
    }
  }
  // error
  if ( showError == true && isOk == false ) {
    showErrorMessage( rowIndex , columnIndex , errorMessage );
  }
  return value ;
}




QString GuiTable::getString( int rowIndex , int columnIndex , QString & errorMessage , bool showError )
{
  QString value ;
  if ( errorMessage.isEmpty() == false ) {
    return value ;
  }
  if ( 0 <= rowIndex    && rowIndex    < myTable->rowCount() &&
       0 <= columnIndex && columnIndex < myTable->columnCount() ) {
    value = getString( rowIndex , columnIndex );
    if ( value.isEmpty() == true ) {
      errorMessage.sprintf( "RowIndex:%d ColumnIndex:%d: Empty string " , rowIndex , columnIndex );
    }
  }
  else {
    errorMessage.sprintf( "RowIndex:%d ColumnIndex:%d out of bounds" , rowIndex , columnIndex );
  }
  // error
  if ( showError == true && errorMessage.isEmpty() == false ) {
    showErrorMessage( rowIndex , columnIndex , errorMessage );
  }
  return value ;
}



void   GuiTable::setList( const QStringList & strList )
{
  // adject the size of the table
  myTable->setRowCount( strList.count() );
  // set the row values
  int row = 0 ;
  for ( auto iter = strList.cbegin() ; iter != strList.cend() ; ++iter ) {
    QString str = (*iter);
    int  minLeft , maxLeft , minRight , maxRight ;
    if ( sscanf( GuiUtl::getString(str) , "%d %d %d %d" , & minLeft , & maxLeft , & minRight , & maxRight ) == 4 ) {
      setRow(  minLeft , maxLeft , minRight , maxRight , row );
      row += 1 ;
    }
  }
}


void   GuiTable::getList( QStringList & strList )
{
  strList.clear() ;
  for ( int row=0 ; row < myTable->rowCount() ; ++row ) {
    strList.append( getRowString( row ) );
  }
}


bool   GuiTable::addRow( int minLeft , int maxLeft , int minRight , int maxRight , QStringList & strList , int row )
{
  QString str ;
  // add it
  int newRow = myTable->rowCount();
  myTable->setRowCount( newRow + 1 );
  if ( setRow( minLeft , maxLeft , minRight , maxRight , newRow ) == false ) { return false ; }
  // move it if needed TODO !!!!
  row = newRow ;
  // save the values
  getList( strList );
  // select 
  setSelectedRow( row );
  return true ;
}


bool   GuiTable::getRow( int & minLeft , int & maxLeft , int & minRight , int & maxRight , int row )
{
  if ( row < 0 || myTable->rowCount() <= row ) { row = getSelectedRow(); }
  if ( row == -1 ) {
    return false ;
  }
  else {
    bool noError = true ;
    bool ok = false ;
    minLeft  = getString( row , 0 ).toInt(&ok); if ( ok == false ) noError = false ;
    maxLeft  = getString( row , 1 ).toInt(&ok); if ( ok == false ) noError = false ;
    minRight = getString( row , 2 ).toInt(&ok); if ( ok == false ) noError = false ;
    maxRight = getString( row , 3 ).toInt(&ok); if ( ok == false ) noError = false ;
    return noError ;
  }
}


QString  GuiTable::getRowString( int row )
{
  QString str ;
  int minLeft , maxLeft , minRight , maxRight ;
  if ( getRow( minLeft , maxLeft , minRight , maxRight , row ) == true ) {
    str.sprintf( "%d %d %d %d" , minLeft , maxLeft , minRight , maxRight );
  }
  return str ;
}


bool   GuiTable::setRow( int minLeft , int maxLeft , int minRight , int maxRight , int row )
{
  if ( row < 0 || myTable->rowCount() <= row ) { row = getSelectedRow(); }
  if ( row == -1 ) {
    return false ;
  }
  else {
    setInt( row , 0 , minLeft  );
    setInt( row , 1 , maxLeft  );
    setInt( row , 2 , minRight );
    setInt( row , 3 , maxRight );
    return true ;
  }
}


bool   GuiTable::upRow( QStringList & strList , int row )
{
  if ( row < 0 || myTable->rowCount() <= row ) { row = getSelectedRow(); }
  // can't be the first
  if ( row < 1 ) { return false ; }
  // save the values of the target
  int minLeftTarget , maxLeftTarget , minRightTarget , maxRightTarget ;
  if ( getRow( minLeftTarget , maxLeftTarget , minRightTarget , maxRightTarget , (row-1) ) == false ) { return false ; }
  // get the values of the source
  int minLeftSource , maxLeftSource , minRightSource , maxRightSource ;
  if ( getRow( minLeftSource , maxLeftSource , minRightSource , maxRightSource , row     ) == false ) { return false ; }   
  // and copy it into the target
  if ( setRow( minLeftSource , maxLeftSource , minRightSource , maxRightSource , (row-1) ) == false ) { return false ; } 
  // the target values are copied where the source was
  if ( setRow( minLeftTarget , maxLeftTarget , minRightTarget , maxRightTarget , row     ) == false ) { return false ; }
  // save the values
  getList( strList );
  // select the target
  if ( setSelectedRow( row-1 ) == false ) { return false ; }
  return true ;
}


bool   GuiTable::downRow( QStringList & strList , int row )
{
  if ( row < 0 || myTable->rowCount() <= row ) { row = getSelectedRow(); }
  // can't be the last
  if ( row == (myTable->rowCount()-1) ) { return false ; }
  // save the values of the target
  int minLeftTarget , maxLeftTarget , minRightTarget , maxRightTarget ;
  if ( getRow( minLeftTarget , maxLeftTarget , minRightTarget , maxRightTarget , (row+1) ) == false ) { return false ; }
  // get the values of the source
  int minLeftSource , maxLeftSource , minRightSource , maxRightSource ;
  if ( getRow( minLeftSource , maxLeftSource , minRightSource , maxRightSource , row     ) == false ) { return false ; }   
  // and copy it into the target
  if ( setRow( minLeftSource , maxLeftSource , minRightSource , maxRightSource , (row+1) ) == false ) { return false ; } 
  // the target values are copied where the source was
  if ( setRow( minLeftTarget , maxLeftTarget , minRightTarget , maxRightTarget , row     ) == false ) { return false ; }
  // save the values
  getList( strList );
  // select the target
  if ( setSelectedRow( row+1 ) == false ) { return false ; }
  return true ;
}


bool   GuiTable::deleteRow( QStringList & strList , int row )
{
  getList( strList );
  if ( row < 0 || myTable->rowCount() <= row ) { row = getSelectedRow(); }
  if ( 0 <= row && row < strList.count() ) {
    // delete row
    int i=0 ;
    for ( auto iter = strList.begin() ; iter != strList.end() ; ++iter , ++i ) {
      if ( i == row ) {
        strList.erase(iter);
        break ;
      }
    }
    // show and selected the one after
    if ( row >= strList.count() ) { row -= 1; } 
    setList( strList );
    setSelectedRow( row );
    // update buttons
    slotValueChanged( row , 0 );     
    return true ;
  }
  return false ;
}




void GuiTable::setCellValues( const std::list< std::list<QString> > & rowColText , const std::vector<bool> * checkList )
{
  static const char * METHOD_NAME = "setCellValues()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "NumberOfRows %ld" , rowColText.size() );

  // set the rows
  setNumberOfRows(rowColText.size());

  // for each row...
  int row = 0;
  QString label("Ok");
  std::list<std::list<QString> >::const_iterator rowIter ;
  for ( row=0 , rowIter=rowColText.cbegin() ; rowIter != rowColText.cend() ; ++rowIter , ++row ) {
    // should have the correct number of columns
    int numberOfColumns = rowIter->size();
    if ( checkList != 0 && checkList->empty() == false ) { numberOfColumns += 1 ; }
    if ( getNumberOfColumns() < numberOfColumns ) { setNumberOfColumns(numberOfColumns); }
    // for each column, set the text
    int col=0;
    std::list<QString>::const_iterator colIter;
    for ( col=0 , colIter=rowIter->begin() ; colIter != rowIter->end() ; ++colIter , ++col ) {
      setString( row , col , *colIter );
    }
    // extra item at the end
    if ( checkList != 0 && row < checkList->size() ) {
      setBool( row , col , (*checkList)[row] , &label );
    }
  }  
}


bool GuiTable::selectAll( bool selectIt )
{
  // TODO. should filter the signal ?
  bool aChangeOccurred = true ;
  myTable->blockSignals(true );
  // select / deselect
  if ( selectIt == true ) {
    int row = 0 ;
    for ( row=0 ; row < myTable->rowCount() ; ++row ) {
      myTable->selectRow( row );
    }
  }
  // deslectg
  else {
    myTable->clearSelection();
  }
  // send
  myTable->blockSignals(false);
  if ( aChangeOccurred == true ) {
    slotSelectionChanged();
  }
  return aChangeOccurred ;
}


bool GuiTable::setSelectedRow( int row )
{
  if ( 0 <= row && row < myTable->rowCount() ) {
    myTable->clearSelection();
    myTable->selectRow( row );
    myTable->setCurrentCell( row , myTable->currentColumn() );
    return true ;
  }  
  else {
    // update the buttons
    slotValueChanged( -1 , -1 );
    return false ;
  }
}


// SEE also:   QItemSelectionModel::hasSelection()

bool GuiTable::getRowIsSelected( int row ) // can't be "const" because of "selectedItems()"
{
  const QList<QTableWidgetItem *> items = myTable->selectedItems();
  for ( auto iter=items.cbegin() ; iter != items.cend() ; ++iter ) {
    if ( (*iter)->row() == row ) {
      return true ;
    }
  }
  return false ;
}


int GuiTable::getSelectedRow() const
{
  const QList<QTableWidgetItem *> items = myTable->selectedItems();
  for ( auto iter=items.cbegin() ; iter != items.cend() ; ++iter ) {
    return (*iter)->row() ;
  }
  return (-1) ;
}


std::set< int > GuiTable::getSelectedRows() const
{
  const QList<QTableWidgetItem *> items = myTable->selectedItems();
  std::set< int > selected ;
  for ( auto iter=items.cbegin() ; iter != items.cend() ; ++iter ) {
    selected.insert( (*iter)->row() );
  }
  return selected;   
}


bool   GuiTable::getSelectedRow( int & firstRow , int & selectedRow , int & lastRow ) const
{
  firstRow    = 0 ;
  selectedRow = getSelectedRow() ;
  lastRow     = (myTable->rowCount() - 1);
  return (selectedRow != -1) ;
}



bool GuiTable::selectCellAndEnsureVisibility( int rowIndex , int columnIndex )
{
  myTable->clearSelection();
  if ( rowIndex >= 0 ) {
    ensureCellVisible( rowIndex , columnIndex );
    myTable->setCurrentCell( rowIndex , columnIndex );
    myTable->selectRow( rowIndex );
    return true ;
  }
  else {
    return false ;
  }
}


void GuiTable::initializeRemarks()
{
  QString emptyText ;
  for ( int row=0 ; row < myTable->rowCount() ; ++row ) {
    setRemarkText( row , emptyText );
  }
}


void GuiTable::setRemarkText( int row , const QString & text )
{
  // the remark field is the last field
  setString( row , (myTable->columnCount() - 1) , text );
}


//===============================================
// GuiTable : Create a Popup Menu
//===============================================



void GuiTable::createViewPopupMenu( int menuId , const GuiViewPopupMenu::SimpleMenu & menu )
{
  if ( myPopupMenu == 0 ) {
    // create it
    myPopupMenu = new GuiViewPopupMenu( getGuiTeam() , myTable , menuId , menu );
    QObject::connect( myTable , SIGNAL( cellPressed(int,int) ) ,
                      this  , SLOT( slotMenuPressed(int,int) ) );
  }
}


bool GuiTable::getPopupRowColumn( int & row , int & col )
{
  row = myPopupRow    ;
  col = myPopupColumn ;
  return ( row >= 0 && col >= 0 );
}



// used for the popup menu
void GuiTable::slotMenuPressed( int row , int col )
{
  static const char * METHOD_NAME = "slotPressed()" ;
  int button = QApplication::mouseButtons();
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Button %d Row %d Col %d" , button , row , col );

  if ( (myPopupMenu != 0) && (button & Qt::RightButton) && (row >= 0) && (col >= 0) ) {
    myPopupRow    = row ;
    myPopupColumn = col ;
    myPopupMenu->popupAtCursorLocation();
  }
  else {
    myPopupRow    = -1 ;
    myPopupColumn = -1 ;
  }
}


//===============================================
// GuiTable : Resize Event 
//===============================================



void GuiTable::resizeInVisibleArea()
{
  // width that can be seen : NOT OK at the start (as it's not visible)
  // int newWidth = myTable->visibleWidth() ;
  int scrollWidth = myTable->verticalScrollBar()->isVisible() ? myTable->verticalScrollBar()->width() : 0 ;
  int headerWidth = myTable->verticalHeader() ? myTable->verticalHeader()->width() : 0 ;
  int newWidth    = myTable->width() - scrollWidth - headerWidth - 4 ; // why 4 ? 2 for the border

  if ( newWidth < 200 ) { return ; }

  switch ( myResizeStrategy ) {

  case GuiTable::RST_NO_RESIZE : 
    {
    } break ;

  case GuiTable::RST_RESIZE_AS_DEFINED :
  case GuiTable::RST_RESIZE_AS_PRESENT :
    {
      // find the widths
      int   col = 0;
      float previousTotalWidths = 0 ;
      int   lastColumn  = (myTable->columnCount() - 1);
      std::map < int , int > mapColWidth ;
      for ( col=0 ; col <= lastColumn ; ++col ) {
        std::map< int , ColumnHeader >::iterator iter = myColumnHeaders.end();
        // if the width is provided,  use it
        if ( myResizeStrategy == GuiTable::RST_RESIZE_AS_DEFINED ) {
          iter = myColumnHeaders.find(col);
        }
        // column width
        mapColWidth[ col ] = (iter == myColumnHeaders.end()) ? myTable->columnWidth(col) : iter->second.mySize ;
        previousTotalWidths += mapColWidth[ col ] ;
      }
      // resize
      if ( previousTotalWidths != 0 ) {
        int totalWidth = 0 ;
        float ratio = newWidth / previousTotalWidths ; // to multiply the width with
        for ( col=0 ; col <= lastColumn ; ++col ) {
          int colWidth = (int)(ratio * mapColWidth[ col ]);
          if ( col == lastColumn ) { colWidth = (newWidth - totalWidth); }
          if ( colWidth < 50 ) { colWidth = 50 ; }
          myTable->setColumnWidth( col , colWidth ); 
          myTable->horizontalHeader()->resizeSection( col , colWidth ); // QHeaderView::resizeSection ( int logicalIndex, int size )
          totalWidth += colWidth ; 
        }
      }
    } break;
  }
}


void GuiTable::addUpdateForHorizontalScrollbar()
{
  if ( (myTable->horizontalScrollBar() != 0) && ((mySliderFlags & (1L<<0)) == 0) ) {
    mySliderFlags |= (1L<<0) ;
    QObject::connect( myTable->horizontalScrollBar() , SIGNAL(sliderReleased()) , this , SLOT(slotSliderReleased()) );
  }  
}


void GuiTable::addUpdateForVerticalScrollbar()
{
  if ( (myTable->verticalScrollBar() != 0) && ((mySliderFlags & (1L<<1)) == 0) ) {
    mySliderFlags |= (1L<<1) ;
    QObject::connect( myTable->verticalScrollBar() , SIGNAL(sliderReleased()) , this , SLOT(slotSliderReleased()) );
  }
}


//===============================================
// GuiTable : Tracking Event 
//===============================================



void GuiTable::storeRowColumnOfCursor( bool b )
{
  myTable->setMouseTracking( b );
}



void GuiTable::setColumnsToTrack( int firstColumn , int secondColumn ,
                                    int thirdColumn , int fourthColumn )
{
  // does it has a column to track ?
  bool hasColumns = myTrackingEvent.setColumnsToTrack( this ,
                                                       firstColumn , secondColumn ,
                                                       thirdColumn , fourthColumn );
  // start / stop the tracking
  storeRowColumnOfCursor( hasColumns );
}


void GuiTable::setDefaultTrackedValues( int firstColumnValue , int secondColumnValue ,
                                          int thirdColumnValue , int fourthColumnValue )
{
  myTrackingEvent.setDefaultValues( firstColumnValue , secondColumnValue ,
                                    thirdColumnValue , fourthColumnValue );
}


bool GuiTable::setRowColumnWhereCursorIs( int row , int col )
{
  // the values has changed
  if ( myTrackingEvent.setRowColumn(row,col) == true ) {
    // treat event (in the derived class)
    myTeam.trackingEventOfTable( this , myTrackingEvent.getValues() );
    return true ;
  }
  else {
    return false ;
  }
}




//-------------------------------------------------------------------------------------//
//                             EVENT SENDER : GuiSplitter                              //
//-------------------------------------------------------------------------------------//



GuiSplitter::GuiSplitter( GuiTeam & wg , QWidget * parent , const GuiSplitter::CreateInfo & createInfo )
: QObject(parent) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_SPLITTER,createInfo.myId)
{
  // create if needed
  mySplitter = new QSplitter(parent);
  mySplitter->setObjectName(createInfo.myName) ;
  // customize  
  mySplitter->setOrientation( createInfo.myIsVertical ? Qt::Vertical : Qt::Horizontal );
  mySplitter->setChildrenCollapsible( createInfo.myIsCollapsable );
  // mySplitter->setMargin( createInfo.myMargin );
  mySplitter->setHandleWidth( createInfo.myHandleWidth );
}



GuiSplitter::~GuiSplitter()
{
}




//-------------------------------------------------------------------------------------// 
//                             EVENT SENDER : GuiTabWidget                             //
//-------------------------------------------------------------------------------------// 


GuiTabWidget::GuiTabWidget( GuiTeam & wg , int id , const GuiTabWidget::CreateInfo & createInfo )
: QObject( wg.getGuiItem(id)->getWidget() ) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_TAB_WIDGET,createInfo.myId)
{
  myInitialize( wg.getGuiItem(id)->getWidget() , createInfo );
}


GuiTabWidget::GuiTabWidget( GuiTeam & wg , GuiItem * e , const GuiTabWidget::CreateInfo & createInfo )
: QObject( e->getWidget() ) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_TAB_WIDGET,createInfo.myId)
{
  myInitialize( e->getWidget() , createInfo );
}


GuiTabWidget::GuiTabWidget( GuiTeam & wg , QWidget * parent , const GuiTabWidget::CreateInfo & createInfo )
: QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_TAB_WIDGET,createInfo.myId)
{
  myInitialize( parent , createInfo );
}


void GuiTabWidget::myInitialize( QWidget * parent , const GuiTabWidget::CreateInfo & createInfo )
{ 
  // create it
  myTabWidget = new QTabWidget(parent);
  myTabWidget->setObjectName(createInfo.myName) ;
  // customize the widget stack 
  if ( createInfo.myToolTip != 0 ) {
    myTabWidget->setToolTip( createInfo.myToolTip );
  }
  // callbacks 
  QObject::connect( myTabWidget , SIGNAL( currentChanged( QWidget * ) ) , this , SLOT( slotCurrentChanged( QWidget * ) ) ); 
} 


GuiTabWidget::~GuiTabWidget() 
{
}


void GuiTabWidget::slotCurrentChanged( QWidget * ) 
{ 
  // send event
  GuiEvent e( this , GuiEvent::ET_ABOUT_TO_SHOW ); 
  e.setInt( getUserValue() ); 
  myTeam.receiveEvent( e ); 
} 


QWidget * GuiTabWidget::getCurrentWidget() const 
{
  return myTabWidget->currentWidget() ;
}


bool      GuiTabWidget::isWidgetCurrent( QWidget * w ) const
{
  return (getCurrentWidget() == w);
}


bool      GuiTabWidget::isWidgetCurrent( GuiItem * e ) const
{
  return isWidgetCurrent(e ? e->getWidget() : 0);
}


bool      GuiTabWidget::setCurrentWidget( QWidget * w ) const
{
  static const char * METHOD_NAME = "setCurrentWidget()" ;
  int id = -1 ;
  if ( w == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "null widget" );
    return false ;
  }
  else if ( (id = myTabWidget->indexOf(w)) == -1 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "widget '%s' is not present" , GuiItem::objectName(w) );
    return false ;
  }
  else {
    myTabWidget->setCurrentIndex( id ) ;
    return true ;
  }
}


bool GuiTabWidget::setCurrentWidget( GuiItem * e ) const
{
  return setCurrentWidget( e ? e->getWidget() : 0 );
}


void GuiTabWidget::addWidget( QWidget * w , int userId , const char * tab , const char * iconName , int index )
{ 
  static const char * METHOD_NAME = "addWidget()" ;
  if ( w == 0 ) { 
    MscDg::error( CLASS_NAME , METHOD_NAME , "widget for userId:%d is null" , userId );
    return ; 
  } 
  // already present 
  if ( myTabWidget->indexOf( w ) != -1 ) { 
    MscDg::error( CLASS_NAME , METHOD_NAME , "userId %d already present" , userId );
    return ; 
  } 
  int id = myMap.size() ;  
  myMap[ id ] = userId ; 
  if ( tab == 0 ) { tab = "Tab" ; }
  QString label(tab);
  if ( iconName == 0 ) {
    //myTabWidget->insertTab( w , label , id ); // TODO 
    myTabWidget->addTab( w , label ); 
  }
  else {
    //myTabWidget->insertTab( w , QIconSet( GuiUtl::getIcon(icon) ) , label , id ); // TODO
    myTabWidget->addTab( w , GuiUtl::getIcon(iconName,myFormatHint.myPixmapPercentage) , label );
  }
} 


void GuiTabWidget::addWidget( GuiItem * e , int userId , const char * tab , const char * icon , int index )
{
  QWidget * w = (e != 0) ? e->getWidget() : 0 ;
  addWidget( w , userId , tab , icon , index );
}


void GuiTabWidget::addGroupBox( GuiGroupBox * groupBox )
{
  addWidget( groupBox , groupBox->getId() , GuiUtl::getString(groupBox->getString()) );
  groupBox->setIsFlat(true);
}


int  GuiTabWidget::getUserValue( int indexOfItem , bool * isOkPtr ) 
{ 
  int value = 0 ; 
  bool isOk = false ; 
  const int numberOfItems = myMap.size() ; 
  // no value has been defined 
  if ( numberOfItems == 0 ) { 
    MscDg::error( CLASS_NAME , "getUserValue()" , "tab widget is empty." );
    value = 0 ; 
    isOk  = false ; 
  } 
  // default is current item. 
  else if ( indexOfItem < 0 ) { 
    value = myMap[ myTabWidget->indexOf( myTabWidget->currentWidget() ) ];
    isOk  = true ;
  } 
  // out of range (error) 
  else if ( numberOfItems <= indexOfItem ) { 
    MscDg::error( CLASS_NAME , "getUserValue()" , "Index:%d is out of bounds. 0<-<%d" , indexOfItem , numberOfItems );
    value = myMap[ myTabWidget->indexOf( myTabWidget->currentWidget() ) ];
    isOk  = false ; 
  } 
  // in range 
  else {
    value = myMap[ indexOfItem ]; 
    isOk  = true ;
  }
  if ( isOkPtr != 0 ) { *isOkPtr = isOk; }
  return value ; 
} 


void GuiTabWidget::setUserValue( int userValue , bool forceMessage ) 
{ 
  for ( auto iter=myMap.begin() ; iter != myMap.end() ; ++iter ) {
    if ( iter->second == userValue ) { 
      myTabWidget->setCurrentIndex( iter->first ); 
      if ( forceMessage == true ) {
        slotCurrentChanged(0);
      }
      return ; 
    } 
  } 
  MscDg::error( CLASS_NAME , "setUserValue()" , "unknown value:%d" , userValue );
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER :  GuiTextEdit                             //
//-------------------------------------------------------------------------------------//


GuiTextEdit::GuiTextEdit( GuiTeam & wg , QWidget * parent ,
                              const GuiTextEdit::CreateInfo & createInfo )
: QObject(parent) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_TEXT_EDIT,createInfo.myId)
{
  // create if needed
  myTextEdit = new QTextEdit(parent);
  myTextEdit->setObjectName(createInfo.myName) ;
  myInitializeFont( myTextEdit );
  // customize
  if ( createInfo.myText != 0 ) {
    myTextEdit->setText( createInfo.myText );
  }
  myMaxWidth  = createInfo.myMaxWidth  ;
  myMaxHeight = createInfo.myMaxHeight ;
  setMaxWidth ( myMaxWidth  , true );
  setMaxHeight( myMaxHeight , true );
  if ( createInfo.myToolTip != 0 ) {
    myTextEdit->setToolTip( createInfo.myToolTip );
  }
  // alignment
  Qt::Alignment alignmentH = Qt::AlignLeft ;
  switch ( createInfo.myAlignment ) {
  case GuiItem::AT_LEFT   : alignmentH = Qt::AlignLeft    ; break ;
  case GuiItem::AT_CENTER : alignmentH = Qt::AlignHCenter ; break ;
  case GuiItem::AT_RIGHT  : alignmentH = Qt::AlignRight   ; break ;    
  }
  myTextEdit->setAlignment( alignmentH | Qt::AlignVCenter );
  // is a	Qt::TextFlag textFlag Qt::TextExpandTabs ); // TODO ..
  // callbacks
  
}


void GuiTextEdit::setTextAsPlainText()
{
   //myTextEdit->setTextFormat( Qt::PlainText );
   QString tmp = myTextEdit->toPlainText();
   myTextEdit->setPlainText( tmp );
}


void GuiTextEdit::clearString()
{
  myTextEdit->clear();
}


void GuiTextEdit::addString( const QString & str )
{
  myTextEdit->append( str );
}


void GuiTextEdit::addString( const char * str )
{
  myTextEdit->append( str );
}


QString GuiTextEdit::getString()
{
  return myTextEdit->toPlainText();
}


void GuiTextEdit::getString( QString & str )
{
  QString tmp = myTextEdit->toPlainText();
  str += tmp ;
}


void GuiTextEdit::setCursorPosition( int paragraph , int index )
{
  // TODO myTextEdit->setCursorPosition( paragraph , index );
}


void GuiTextEdit::scrollToBottom()
{
  QScrollBar * scrollBar = myTextEdit->verticalScrollBar();
  if ( scrollBar != 0 ) {
    scrollBar->setValue( scrollBar->maximum() );
  }
}


/** add text (test if not empty) */
void GuiTextEdit::addTextAtTheEnd( const QString & text , bool testItsNotBlank , bool scroll )
{
  // test it's not empty
  if ( testItsNotBlank == true && GuiUtl::isBlank(text) == true ) { return ; }
  // add text
  myTextEdit->append( text );
  // scroll
  if ( scroll == true ) { scrollToBottom(); }
}


//============================
// STATIC HELPER FUNCTIONS 
//============================


void GuiTextEdit::scrollToBottom( QTextEdit * textEdit )
{
  QScrollBar * scrollBar = textEdit->verticalScrollBar();
  if ( scrollBar != 0 ) {
    scrollBar->setValue( scrollBar->maximum() );
  }  
}


/** add text (test if not empty) */
void GuiTextEdit::addTextAtTheEnd( QTextEdit * textEdit , const QString & text , bool testItsNotBlank , bool scroll )
{
  // test it's not empty
  if ( testItsNotBlank == true && GuiUtl::isBlank(text) == true ) { return ; }
  // add text
  textEdit->append( text );
  // scroll
  if ( scroll == true ) { GuiTextEdit::scrollToBottom( textEdit ); }
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER :  GuiStackedWidget                        //
//-------------------------------------------------------------------------------------//



GuiStackedWidget::GuiStackedWidget( GuiTeam & wg , int id , const GuiStackedWidget::CreateInfo & createInfo )
: QObject( wg.getGuiItem(id)->getWidget() ) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_STACKED_WIDGET,createInfo.myId)
{
  myInitialize( wg.getGuiItem(id)->getWidget() , createInfo );
}


GuiStackedWidget::GuiStackedWidget( GuiTeam & wg , GuiItem * e , const GuiStackedWidget::CreateInfo & createInfo )
: QObject( e->getWidget() ) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_STACKED_WIDGET,createInfo.myId)
{
  myInitialize( e->getWidget() , createInfo );
}


GuiStackedWidget::GuiStackedWidget( GuiTeam & wg , QWidget * parent , const GuiStackedWidget::CreateInfo & createInfo )
: QObject(parent) ,GuiItem(wg,createInfo.myName,this,GuiItem::WT_STACKED_WIDGET,createInfo.myId)
{
  myInitialize( parent , createInfo );
}


void GuiStackedWidget::myInitialize( QWidget * parent , const GuiStackedWidget::CreateInfo & createInfo )
{ 
  // buddy combobox
  myComboBox = 0 ;
  // create it
  myStackedWidget  = new QStackedWidget(parent) ;
  myStackedWidget->setObjectName(createInfo.myName);
  myInitializeFont( myStackedWidget );
  myInternalWidget = new QWidget(myStackedWidget);
  // customize the widget stack 
  if ( createInfo.myToolTip != 0 ) {
    // No toolTip is defined for a stacked widget ..... myStackedWidget-setToolTip( createInfo.myToolTip );
  }
  // create the page (if provided)
  for ( int i = 0 ; i < createInfo.myNumberOfGroupBoxes ; ++i ) {
    addGroupBox( new GuiGroupBox( myTeam , myInternalWidget , createInfo.myGroupBoxes[i] ) );
  }
  // callbacks 
  QObject::connect( myStackedWidget , SIGNAL( currentChanged(int) ) , this , SLOT( slotAboutToShow(int) ) ); 
} 


GuiStackedWidget::~GuiStackedWidget() 
{
}


void GuiStackedWidget::slotAboutToShow( int i ) 
{ 
  // send event
  GuiEvent e( this , GuiEvent::ET_ABOUT_TO_SHOW ); // should be 'ET_VALUE_CHANGED'
  e.setInt( getUserValue() ); 
  myTeam.receiveEvent( e ); 
} 


void GuiStackedWidget::slotComboBoxActivsted( int )
{
  setUserValue( myComboBox->getInt() ) ;
}


void GuiStackedWidget::setComboBox( GuiComboBox * comboBox )
{
  if ( comboBox == 0 ) return ;
  myComboBox = comboBox ;
  // clean the combobox (both display and internal map)
  myComboBox->clearValues();
  // get each page and add the title to the combobox with the appropriate Id.
  for ( auto iter = myGroupBoxes.begin() ; iter != myGroupBoxes.end() ; ++iter ) {
    GuiGroupBox * groupBox = *iter ;
    // use the title and the id
    myComboBox->addValue( GuiUtl::getString(groupBox->getString()) , 0 , 0 , groupBox->getId() );
    // avoid the title
    QString emptyString ;
    groupBox->setString( emptyString );
    // change the frame aspect
    groupBox->getGroupBox()->isFlat(); // setFrameShape( QFrame::NoFrame );
  }
  // set the initial page
  if ( myGroupBoxes.empty() == false ) {
    //myComboBox->setUserValu( 0 ) ;
    //myStackedWidget->setCurrentWidget( 0 ) ;
  }
  // connect
  QObject::connect( myComboBox->getWidget() , SIGNAL( activated(int) ) , this , SLOT( slotComboBoxActivsted(int) ) );  
}


void GuiStackedWidget::addWidget( QWidget * w , int userId ) 
{ 
  static const char * METHOD_NAME = "addWidget()" ;
  if ( w == 0 ) { 
    MscDg::error( CLASS_NAME , METHOD_NAME , "widget for userId:%d is null" , userId );
    return ; 
  } 
  // already present 
  if ( myStackedWidget->indexOf( w ) != -1 ) { 
    MscDg::error( CLASS_NAME , METHOD_NAME , "userId %d already present" , userId );
    return ; 
  } 
  // add it 
  int id = myMap.size() ;  
  myMap[ id ] = userId ; 
  myStackedWidget->addWidget( w ); 
} 


void GuiStackedWidget::addWidget( GuiItem * e , int userId ) 
{
  QWidget * w = (e != 0) ? e->getWidget() : 0 ;
  addWidget( w , userId );
}


void GuiStackedWidget::addGroupBox( GuiGroupBox * groupBox ) 
{ 
  myGroupBoxes.push_back( groupBox );
  addWidget( groupBox->getWidget() , groupBox->getId() ); 
  
} 


int  GuiStackedWidget::getUserValue( int indexOfItem , bool * isOkPtr ) 
{ 
  int value = 0 ; 
  bool isOk = false ; 
  const int numberOfItems = myMap.size() ; 
  // no value has been defined 
  if ( numberOfItems == 0 ) { 
    MscDg::error( CLASS_NAME , "getUserValue()" , "Widget Stack is empty." );
    value = 0 ; 
    isOk  = false ; 
  } 
  // default is current item. 
  else if ( indexOfItem < 0 ) { 
    value = myMap[ myStackedWidget->currentIndex() ];//id( myStackedWidget->visibleWidget() ) ]; 
    isOk  = true ;
  } 
  // out of range (error) 
  else if ( numberOfItems <= indexOfItem ) { 
    MscDg::error( CLASS_NAME , "getUserValue()" , "Index:%d is out of bounds. 0<-<%d" , indexOfItem , numberOfItems );
    value = myMap[ myStackedWidget->currentIndex() ];//id( myStackedWidget->visibleWidget() ) ]; 
    isOk  = false ; 
  } 
  // in range 
  else {
    value = myMap[ indexOfItem ]; 
    isOk  = true ;
  } 
  if ( isOkPtr != 0 ) *isOkPtr = isOk; 
  return value ; 
} 



void GuiStackedWidget::setUserValue( int userValue , bool forceMessage ) 
{ 
  static const char * METHOD_NAME = "setUserValue()" ;
  for ( auto iter=myMap.begin() ; iter != myMap.end() ; ++iter ) {
    if ( iter->second == userValue ) { 
      myStackedWidget->setCurrentIndex( iter->first ); 
      if ( forceMessage == true ) {
        MscDg::error( CLASS_NAME , METHOD_NAME , "Value:%d . Don't know how to force the message" , userValue );
      }
      return ; 
    } 
  } 
  MscDg::error( CLASS_NAME , METHOD_NAME , "Unknown value:%d" , userValue );
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER :  GuiSeparator                            //
//-------------------------------------------------------------------------------------//


GuiSeparator::GuiSeparator( GuiTeam & wg , QWidget * parent , const GuiSeparator::CreateInfo & createInfo )
  : GuiItem(wg,createInfo.myName,0,GuiItem::WT_SEPARATOR,createInfo.myId)
{
  myMenu    = 0 ;
  myToolBar = 0 ;
}


GuiSeparator::~GuiSeparator()
{
}



//-------------------------------------------------------------------------------------//
//                             EVENT SENDER :  GuiWidget                               //
//-------------------------------------------------------------------------------------//



GuiWidget::GuiWidget( GuiTeam & wg , QWidget * parent , const GuiWidget::CreateInfo & createInfo )
  : QObject(parent) , GuiItem(wg,createInfo.myName,this,GuiItem::WT_WIDGET,createInfo.myId)
{
  // create if needed
  myWidget = new QWidget(parent);
  myWidget->setObjectName(createInfo.myName) ;
  // customize
  if ( createInfo.myToolTip != 0 ) {
    myWidget->setToolTip( createInfo.myToolTip );
  }
  GuiItem::setSizes( myWidget , createInfo.mySizes );
}


GuiWidget::~GuiWidget()
{
}





//-------------------------------------------------------------------------------------//
//                               "WIDGET MANAGEMENT"                                   //
//                  Page Holder : display pages in a QTabWidget, a QSplitter ..     .  //
//-------------------------------------------------------------------------------------//



GuiPageHolder::GuiPageHolder( GuiForm & form , QWidget * parent , const GuiPageHolder::CreateInfo & createInfo )
  : QObject(parent) , GuiItem(form,createInfo.myName,this,GuiItem::WT_PAGE_HOLDER,createInfo.myId) , myForm(form)
{
  myBeingDeleted   = false ;
  myId             = 1000 ;
  myCurrentPage    = 0 ;

  // stacked widget
  myStackedWidget  = new QStackedWidget( parent ) ;
  myStackedWidget->setSizePolicy( QSizePolicy::Expanding , QSizePolicy::Expanding );

  // dummy
  myInternalWidget = new QWidget(myStackedWidget);

  // tab widget
  myTabWidget      = new QTabWidget( myInternalWidget ) ;
  myStackedWidget->addWidget(myTabWidget);
  myTabWidget->setSizePolicy( QSizePolicy::Expanding , QSizePolicy::Expanding );
  QObject::connect( myTabWidget , SIGNAL( currentChanged( QWidget * ) ) , this , SLOT( slotPageChanged( QWidget * ) ) );

  // scrollview
  myScrollView     = new QScrollArea( myInternalWidget ); // , "QScrollView" , WStaticContents );
  myScrollView->setAlignment( Qt::AlignLeft );
  myScrollView->setSizePolicy( QSizePolicy::Expanding , QSizePolicy::Expanding );
  myScrollView->setHorizontalScrollBarPolicy( Qt::ScrollBarAsNeeded );
  myScrollView->setVerticalScrollBarPolicy  ( Qt::ScrollBarAsNeeded );

  myStackedWidget->addWidget(myScrollView);
  // TODO . What was it for ???? myScrollView->enableClipper(true);

  // create widget to act as viewport
  myScrollWidget   = new QWidget( myScrollView );
  myScrollWidget->setObjectName("myScrollWidget");
  myScrollWidget->setSizePolicy( QSizePolicy::Expanding , QSizePolicy::Expanding );
  myScrollLayout   = new QHBoxLayout( myScrollWidget );
  myScrollLayout->setObjectName( "myScrollLayout" ); //   , 2 , 2 ,
  // add it now as view port
  //myScrollWidget->show();
  myScrollView->setWidget(myScrollWidget);
  myScrollViewX    = 0 ;
  myScrollViewY    = 0 ;

  // type of display
  myType           = createInfo.myType ;
  myType = GuiPageHolder::PHT_TAB ; // TODO ....
  switch( createInfo.myType ) {
  case GuiPageHolder::PHT_TAB :
    {
      myStackedWidget->setCurrentWidget( myTabWidget );
    } break ;
  case GuiPageHolder::PHT_SIDE_BY_SIDE :
    {
      myStackedWidget->setCurrentWidget( myScrollView );
    } break ;
  }
  // add it the list of the form that created it
  myForm.addPageHolderToList( this );
}


GuiPageHolder::~GuiPageHolder()
{
  MscDg::trace( CLASS_NAME , "~GuiPageHolder()" );
  myBeingDeleted  = true ;
  myForm.removePageHolderFromList( this );
}


QWidget * GuiPageHolder::getWidget() const
{
  QWidget * widget = myStackedWidget ;
  return widget ;
}


bool GuiPageHolder::setInt( int pageId , bool forceMessage )
{
  static const char * METHOD_NAME = "setInt()" ;

  QWidget * widget = getWidgetOfPage( pageId );
  if ( widget != 0 && myTabWidget != 0 && myTabWidget->indexOf(widget) != -1 ) {
    myTabWidget->setCurrentWidget( widget );
    if ( forceMessage == true ) {
      slotPageChanged( widget );
    }
    return true ;
  }
  else {
    MscDg::error( CLASS_NAME , METHOD_NAME , "PageId %d can't be set" , pageId );
    return false ;
  }
}


int GuiPageHolder::getInt() const
{
  QWidget * widget = (myTabWidget != 0) ? myTabWidget->currentWidget() : 0 ;
  if ( widget != 0 ) {
    return getPageId( widget );
  }
  else {
    // not present
    MscDg::error( CLASS_NAME , "getInt()" , "Can't get page" );
    return 0 ;
  }
}


GuiPage * GuiPageHolder::getPage( int id ) const
{
  // find the page with this id
  for ( auto iter = myPages.cbegin() ; iter != myPages.cend() ; ++iter ) {
    GuiPage * page = *iter;
    if ( page->getId() == id ) {
      return page;
    }
  }
  // not present
  MscDg::error( CLASS_NAME , "getPage()" , "PageId '%d' is not found" , id );
  return 0 ;
}


int GuiPageHolder::getPageId( QWidget * widget ) const
{
  // find the page with this widget
  for ( auto iter = myPages.cbegin() ; iter != myPages.cend() ; ++iter ) {
    GuiPage * page = *iter;
    if ( page->getWidget() == widget ) {
      return page->getId();
    }
  }
  // not present
  MscDg::error( CLASS_NAME , "getPageId()" , "Widget '%s' is not found" , GuiItem::objectName(widget) );
  return 0 ;
}


QWidget * GuiPageHolder::getWidgetOfPage( int pageId ) const
{
  // find the page with this id
  for ( auto iter = myPages.cbegin() ; iter != myPages.cend() ; ++iter ) {
    GuiPage * page = *iter;
    if ( page->getId() == pageId ) {
      return page->getWidget();
    }
  }
  // not present
  MscDg::error( CLASS_NAME , "getWidgetOfPage()" , "Page %d is not found" , pageId );
  return 0 ;
}


bool GuiPageHolder::getPageIsActive( GuiPage * page ) const
{
  return page->isActive();
}


bool GuiPageHolder::isPageShownToTheUser( GuiPage * page ) const
{
  if ( myType == GuiPageHolder::PHT_TAB && page != 0 ) {
    QWidget * w = myTabWidget->currentWidget() ;
    MscDg::trace( CLASS_NAME , "isPageShownToTheUser()" , "CurrentTab:'%s'  *  PageId:%d PageName:'%s' " ,
                 GuiItem::objectName(w) , page->getId() , GuiItem::objectName( getWidgetOfPage( page->getId() ) ) );
    return ( w == getWidgetOfPage( page->getId() ) );
  }
  else if ( myType == GuiPageHolder::PHT_SIDE_BY_SIDE ) {
    return true ;
  }
  else {
    // not present
    MscDg::error( CLASS_NAME , "isPageShownToTheUser()" , "unknown case" );
    return false ;
  }
}


GuiPage * GuiPageHolder::setActivePage( QWidget * widget )
{
  // find the page with this widget
  for ( auto iter = myPages.begin() ; iter != myPages.end() ; ++iter ) {
    GuiPage * page = *iter;
    if ( page->getWidget() == widget ) {
      myCurrentPage = page;
      return  myCurrentPage ;
    }
  }
  // not present
  MscDg::error( CLASS_NAME , "setActivePage()" , "Widget '%s' is not found" , GuiItem::objectName(widget) );
  return 0 ;
}


bool GuiPageHolder::addPage( GuiPage * page )
{
  if ( page == 0 ) {
    return false ;
  }
  MscDg::trace( CLASS_NAME , "addPage()" , "PageId:%d" , page->getId() );
  // add it the form (if not already present). If present it does show a message
  addPageToList( page );
  // add to the page holde
  QString iconName = page->getIcon() ;
  QWidget * widget = page->getWidget();
  //widget->show();
  // make sure it fill in the area
  widget->setSizePolicy( QSizePolicy::Expanding , QSizePolicy::Expanding );
  // add the page
  switch( myType ) {
  case GuiPageHolder::PHT_TAB :
    {
      if ( iconName.isEmpty() == true ) {
        myTabWidget->addTab( widget ,
                             page->getTitle() );
      }
      else {
        myTabWidget->addTab( widget ,
                             GuiUtl::getIcon(iconName,myFormatHint.myPixmapPercentage) ,
                             page->getTitle() );
      }
      page->showFrame(false);
      // inform the user
      slotPageChanged( widget );
    } break ;
  case GuiPageHolder::PHT_SIDE_BY_SIDE :
    {
      // new size of the widget
      int height  =  widget->height();
      int width   = (myScrollLayout->count() + 1) * (widget->width() + 2);
      if ( width  < 200 ) { width  = 200; } // should not happen
      if ( height < 200 ) { height = 200; } // should not happen
      // add to scrollview
      myScrollLayout->addWidget( widget );
      // dimension
      myScrollViewX += widget->sizeHint().width() ;
      myScrollViewX += 20 ;
      page->showFrame(true);
      if ( myScrollViewY < widget->sizeHint().height() ) {
        myScrollViewY = widget->sizeHint().height() ;
      }
      // myScrollView->viewport()->resize( myScrollViewX , myScrollViewY );
      myScrollWidget->resize( myScrollViewX , myScrollViewY );
    } break ;
  }
  return true ;
}


void  GuiPageHolder::toggleDisplay()
{
  MscDg::trace( CLASS_NAME , "toggleDisplay()" , "Type %d" , myType );
  // return ; // TODO // NEED TO CHECK THE Scrolled View CREATION FIRST

  switch( myType ) {
  case GuiPageHolder::PHT_TAB :
    {
      myType = GuiPageHolder::PHT_SIDE_BY_SIDE ;
      myScrollViewX = 0 ;
      myScrollViewY = 0 ;
      for ( auto iter = myPages.begin() ; iter != myPages.end() ; ++iter ) {
        GuiPage * page = *iter ;
        QWidget * widget = page->getWidget();
        // remove from tab (if present)
        int  id = myTabWidget->indexOf(widget);
        if ( id !=  -1 ) { myTabWidget->removeTab(id); }
        //myTabWidget->removePage( widget );
        // add to scrollview
        myScrollLayout->addWidget( widget );
        page->showFrame(true);
        myScrollViewX += widget->sizeHint().width() ;
        myScrollViewX += 20 ;
        if ( myScrollViewY < widget->sizeHint().height() ) {
          myScrollViewY = widget->sizeHint().height() ;
        }
        //page->showFrame(true);
      }
      // myScrollView->viewport()->resize( myScrollViewX , myScrollViewY );
      myScrollWidget->resize( myScrollViewY , myScrollViewY );
      myStackedWidget->setCurrentWidget( myScrollView );
    } break ;
  case GuiPageHolder::PHT_SIDE_BY_SIDE :
    {
      myType = GuiPageHolder::PHT_TAB ;
      myScrollViewX = 0 ;
      myScrollViewY = 0 ;
      GuiPage * firstPage = 0 ;
      for ( auto iter = myPages.begin() ; iter != myPages.end() ; ++iter ) {
        GuiPage * page = (*iter);
        if ( firstPage == 0 ) { firstPage = page ; }
        // remove from scrollview layout
        myScrollLayout->removeWidget( page->getWidget() );
        // add to tab
        if ( page->getIcon().isEmpty() == true ) {
          myTabWidget->addTab( page->getWidget() , page->getTitle() );
        }
        else {
          myTabWidget->addTab( page->getWidget() ,
                               GuiUtl::getIcon(page->getIcon(),myFormatHint.myPixmapPercentage) ,
                               page->getTitle() );
        }
        page->showFrame(false);
      }
      myStackedWidget->setCurrentWidget( myTabWidget );
      // inform
      if ( firstPage != 0 ) { slotPageChanged( firstPage->getWidget() ); }
    } break ;
  }
}



bool GuiPageHolder::setPageIsEnabled( int pageId , bool showIt )
{
  static const char * METHOD_NAME = "setPageIsEnabled()" ;
  bool hasDoneIt = false ;

  GuiPage * page = getPage( pageId );
  if ( page == 0 ) return hasDoneIt ;

  switch( myType ) {
  case GuiPageHolder::PHT_TAB :
    {
      if ( myTabWidget->isTabEnabled( myTabWidget->indexOf(page->getWidget()) ) != showIt ) {
        myTabWidget->setTabEnabled( myTabWidget->indexOf(page->getWidget()) , showIt );
        hasDoneIt = true ;
      }
    } break;
  case GuiPageHolder::PHT_SIDE_BY_SIDE :
    {
      MscDg::error( CLASS_NAME , METHOD_NAME , "to check" );
      page->getWidget()->setEnabled( showIt );
    } break;
  }
  return hasDoneIt ;
}


bool GuiPageHolder::showTabOfPage( GuiPage * page , bool showIt )
{
  static const char * METHOD_NAME = "showTabOfPage()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "ShowIt %d" , showIt );
  bool hasDoneIt = false ;
  if ( page == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Page is null" );
    return hasDoneIt ;
  }

  // Tab
  switch( myType ) {
  case GuiPageHolder::PHT_TAB :
    {
      // TODO: how to test it's already displayed ?
      if ( showIt == false ) {
        myTabWidget->removeTab( myTabWidget->indexOf(page->getWidget()) );
        hasDoneIt = true ;
      }
      else {
        myTabWidget->setCurrentWidget( page->getWidget() );
        hasDoneIt = true ;
      }
    } break;
  case GuiPageHolder::PHT_SIDE_BY_SIDE :
    {
      MscDg::error( CLASS_NAME , METHOD_NAME , "TO DO ...." );
    } break;
  }
  return hasDoneIt ;
}



bool GuiPageHolder::showTabOfPageId( int pageId , bool showIt )
{
  static const char * METHOD_NAME = "showTabOfPageId()" ;
  GuiPage * page = getPage(pageId);
  if ( page == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Page is null" );
    return false ;
  }
  return showTabOfPage( page , showIt );
}



bool GuiPageHolder::removePage( GuiPage * page )
{
  return removePageFromList( page ) ;
}


bool GuiPageHolder::addPageToList( GuiPage * page )
{
  static const char * METHOD_NAME = "addPageToList()" ;

  // find if the page is present
  for ( auto iter = myPages.begin() ; iter != myPages.end() ; ++iter ) {
    GuiPage * p = *iter;
    if ( p == page ) {
      // if the page has a page holder, it has already been added (at the creation)
      if ( page->getPageHolder() != 0 ) {
        if ( page->getPageHolder() == this ) {
          MscDg::error( CLASS_NAME  , METHOD_NAME , "PageId:%d is already owned by SAME page holder" , page->getId() );
        }
        // error
        else {
          MscDg::error( CLASS_NAME  , METHOD_NAME , "PageId:%d is already owned by a DIFFERENT page holder" , page->getId() );
        }
      }
      // no page holder. So it's an error
      else {
        MscDg::error( CLASS_NAME  , METHOD_NAME , "PageId:%d is already owned" , page->getId() );
      }
      return false ;
    }
  }
  // add the page
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Add page %d to existing %ld pages" , page->getId() , myPages.size() );
  myPages.push_back(page);
  return true ;
}


bool GuiPageHolder::removePageFromList( GuiPage * page )
{
  MscDg::trace( CLASS_NAME , "removePageFromList()" , "PageSize:%d" , int(myPages.size()) );
  // find if the page is present
  bool is_found = false ;
  for ( auto iter = myPages.begin() ; iter != myPages.end() ; ++iter ) {
    GuiPage * p = *iter;
    if ( p == page ) {
      MscDg::trace( CLASS_NAME , "removePageFromList()" , "found it" );
      // remove from the vector
      myPages.erase( iter );
      is_found = true ;
      break ;
    }
  }
  if ( is_found == true ) {
    // update the list of files
    // UNUSED ... updateUserParameters();
    return true ;
  }
  else {
    // not present
    MscDg::error( CLASS_NAME , "removePageFromList()" , "PageId:%d Name:'%s' is not prsent amongst the %d pages" ,
                 page->getId() , GuiItem::objectName(page->getWidget()) , int(myPages.size()) );
    return false ;
  }
}


void  GuiPageHolder::slotPageChanged( QWidget * widget )
{
  if ( widget == 0 ) { widget = myTabWidget->currentWidget() ; }
  // save in the form
  myForm.setActivePageHolder( this );
  setActivePage( widget );
  // send event
  GuiEvent e( this , GuiEvent::ET_VALUE_CHANGED );
  GuiPage * page = getActivePage() ;
  QString title ;
  if ( page != 0 ) {
    e.setInt( page->getId() );
    e.setString( title.sprintf( "StratiSI:  %s" , GuiUtl::getString(page->getTitle()) ) );
  }
  else {
    e.setString( title.sprintf( "StratiSI" ) );
  }
  myTeam.receiveEvent( e );
}


bool GuiPageHolder::pageHolderKeyPressEvent( QKeyEvent * e )
{
  MscDg::trace( CLASS_NAME , "pageHolderKeyPressEvent()" , "KeyId:%d" , e->key() );
  // the derived class has implemented and considered the case */
  if ( derivedPageHolderKeyPressEvent( e ) == true ) {
    // send the event to the active(s) page(s)
    for ( auto iter = myPages.begin() ; iter != myPages.end() ; ++iter ) {
      if ( getPageIsActive( *iter ) == true ) {
        (*iter)->pageKeyPressEvent( e );
      }
    }
    return true ;
  }
  else {
    return false ;
  }
}


bool GuiPageHolder::pageHolderKeyReleaseEvent( QKeyEvent * e )
{
  MscDg::trace( CLASS_NAME , "pageHolderKeyReleaseEvent()" , "Key:%d" , e->key() );
  // the derived class has implemented and considered the case */
  if ( derivedPageHolderKeyReleaseEvent( e ) == true ) {
    // send the event to the active(s) page(s)
    for ( auto iter = myPages.begin() ; iter != myPages.end() ; ++iter ) {
      if ( getPageIsActive( *iter ) == true ) {
        (*iter)->pageKeyReleaseEvent( e );
      }
    }
    return true ;
  }
  else {
    return false ;
  }
}


bool GuiPageHolder::transferParameters( int transferType , bool activePageOnly , QString & message )
{
  // transfer
  for ( auto iter = myPages.begin() ; iter != myPages.end() ; ++iter ) {
    if ( activePageOnly == false || getPageIsActive( *iter ) == true ) {
      bool transferResult = (*iter)->transferParameters( transferType , message );
      if ( transferResult == false ) {
        return false ;
      }
    }
  }
  return true ;
}


void GuiPageHolder::refresh()
{
  static const char * METHOD_NAME = "refresh()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "getId %d" , getId() );
  refresh( myType == GuiPageHolder::PHT_TAB );
}


void GuiPageHolder::refresh( int id )
{
  static const char * METHOD_NAME = "refresh()" ;
  // TODO ?? CHECK WHY THE 'id' IS NOT TAKEN INTO ACCOUNT
  MscDg::warning( CLASS_NAME , METHOD_NAME , "TODO getId %d= Id %d IS NOT TAKEN INTO ACCOUNT" , getId() , id );
  refresh( myType == GuiPageHolder::PHT_TAB );
}


void GuiPageHolder::refresh( bool activePageOnly )
{
  for ( auto iter = myPages.begin() ; iter != myPages.end() ; ++iter ) {
    if ( activePageOnly == false || getPageIsActive( *iter ) == true ) {
      (*iter)->setIsDirty();
      (*iter)->refresh();
    }
    else {
      (*iter)->setIsDirty();
    }
  }
}


void GuiPageHolder::setIsDirty( int i )
{
  for ( auto iter = myPages.begin() ; iter != myPages.end() ; ++iter ) {
    (*iter)->setIsDirty(i);
  }
}










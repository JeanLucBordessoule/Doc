#include "GuiDataDefinitions.hpp"
#include "TypStructure.hpp"

#include <map>
#include <fstream>

// Qt
#include <QColor>


//===============================================================================================
//===============================================================================================
//===============================================================================================
// ****    COLORS : BASE COLOURS 
//===============================================================================================
//===============================================================================================
//===============================================================================================

/** storage of the color components */
static std::map< int , Defs::ColorComponents > StaticColorComponentsMap ; // initialized below in "Defs::getColor()".

const Defs::ColorComponents & Defs::getColorComponents( /*Typ::ColorId*/ int colorId , /*Typ::ColorId*/ int * foundId )
{
  // initialize pre-defined values
  if ( StaticColorComponentsMap.empty() == true ) {
    StaticColorComponentsMap[ Typ::COL_BLACK        ] = Defs::ColorComponents(   0 ,   0 ,   0 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_DARK_RED     ] = Defs::ColorComponents( 128 ,   0 ,   0 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_DARK_GREEN   ] = Defs::ColorComponents(   0 , 128 ,   0 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_DARK_YELLOW  ] = Defs::ColorComponents( 128 , 128 ,   0 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_DARK_BLUE    ] = Defs::ColorComponents(   0 ,   0 , 128 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_DARK_MAGENTA ] = Defs::ColorComponents( 128 ,   0 , 128 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_DARK_CYAN    ] = Defs::ColorComponents(   0 , 128 , 128 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_LIGHT_GRAY   ] = Defs::ColorComponents( 192 , 192 , 192 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_GRAY         ] = Defs::ColorComponents( 128 , 128 , 128 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_RED          ] = Defs::ColorComponents( 255 ,   0 ,   0 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_GREEN        ] = Defs::ColorComponents(   0 , 255 ,   0 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_YELLOW       ] = Defs::ColorComponents( 255 , 255 ,   0 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_BLUE         ] = Defs::ColorComponents(   0 ,   0 , 255 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_MAGENTA      ] = Defs::ColorComponents( 255,    0 , 255 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_WHITE        ] = Defs::ColorComponents( 255 , 255 , 255 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_CYAN         ] = Defs::ColorComponents(   0 , 255 , 255 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_FRAME        ] = Defs::ColorComponents( 212 , 208 , 200 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_DARK_GRAY    ] = Defs::ColorComponents(  96 ,  96 ,  96 , Typ::COL_ALPHA );
    StaticColorComponentsMap[ Typ::COL_ORANGE       ] = Defs::ColorComponents( 255 , 170 ,   0 , Typ::COL_ALPHA );
  }
  
  // find  the color
  if ( foundId != nullptr ) { *foundId = colorId; }
  std::map< int , Defs::ColorComponents >::const_iterator iter = StaticColorComponentsMap.find( colorId );
  
  // not found so provide an existing color
  if ( iter == StaticColorComponentsMap.end() ) {
    int numberOfColors = StaticColorComponentsMap.size();
    // use round-trip of existing colours
    if ( foundId != nullptr ) { *foundId = (colorId % numberOfColors); }
    iter = StaticColorComponentsMap.find( colorId % numberOfColors );
  }
  return iter->second ;
}



/** storage of the colors */
static std::map< int , QColor > StaticQColorMap ; // initialized when needed

const QColor & Defs::getColor( /*Typ::ColorId*/ int colorId )
{
    // color already registered
    std::map< int , QColor >::const_iterator iter = StaticQColorMap.find( colorId );
    if ( iter != StaticQColorMap.end() ) {
        return iter->second ;
    }
    // get the components
    int foundId = colorId ;
    const Defs::ColorComponents & colorComponents = Defs::getColorComponents( colorId , &foundId );
    // it could be a round trip
    if ( foundId != colorId && (iter = StaticQColorMap.find( foundId )) != StaticQColorMap.end() ) {
        return iter->second ;
    }
    // create it
    QColor color( colorComponents.myRed , colorComponents.myGreen , colorComponents.myBlue , colorComponents.myAlpha );
    StaticQColorMap[ foundId ] = color ;
    return StaticQColorMap.find( foundId )->second ;
}



/** user color is added to the existing ones  */
bool Defs::addUserColor( const QColor & c , int * addedId )
{
    return Defs::addUserColor( c.red() , c.green() , c.blue() , c.alpha() , addedId );
}


bool Defs::addUserColor( int r , int g , int b , int a , int * addedId )
{
    // too many of them
    if ( StaticColorComponentsMap.size() >= Typ::COL_LAST_USER_COLOR ) {
        return false;
    }
    // index to add it to
    int colorId = StaticColorComponentsMap.size();
    if ( addedId != nullptr ) { *addedId = colorId ; }
    StaticColorComponentsMap[ colorId ] = Defs::ColorComponents( r , g , b , a );
    // correctly added
    return true ;
}



bool Defs::hasUserColorsToSave()
{
    return (StaticColorComponentsMap.size() < Typ::COL_FIRST_USER_COLOR );
}


bool Defs::saveUserColors( std::ofstream * )
{
    return false;
}


bool Defs::readUserColors( std::ifstream * )
{
    return false;
}


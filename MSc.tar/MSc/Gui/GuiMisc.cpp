#include "MscDebug.hpp"

#include "GuiItem.hpp"
#include "GuiUtilities.hpp"

#include <QAction>
#include <QFont>
#include <QIcon>
#include <QObject>
#include <QPushButton>
#include <QTableWidget>
#include <QWidget>






/**************************************************************************************************
**************************************************************************************************
** GuiWidgetAspect
**************************************************************************************************
*************************************************************************************************/



const char * GuiWidgetAspect::CLASS_NAME = "GuiWidgetAspect" ;



/** save the initial aspect */
GuiWidgetAspect::GuiWidgetAspect( QObject * obj , float fontPercentage , float pixmapPercentage )
{
  static const char * METHOD_NAME = "GuiWidgetAspect()" ;

  myPointSize = GuiItem::DEFAULT_POINT_SIZE ;
  myObject    = obj   ;
  myWidget    =  0    ;
  myWidth     = -1    ;
  myMinWidth  = -1    ;
  myMinHeight = -1    ;
  myMaxWidth  = -1    ;
  myMaxHeight = -1    ;
  myTableRow  = -1    ;
  // previous percentages
  myFontPercentage    = 1.0f ;
  myPixmapPercentage  = 1.0f ;

  //================
  // action
  //================
  if ( myObject->inherits("QAction") == true ) {
    if ( ((QAction*)myObject)->icon().isNull() == false ) {
      // ISSUE : MODIFIED THE IMAGE . myImage = ((QAction*)myObject)->icon().pixmap().convertToImage();
    }
  }
  // not a widget
  else if ( myObject->isWidgetType() == false ) {
    return ;
  }

  //================
  // widget
  //================
  myWidget = (QWidget*)obj ;
  QFont font( myWidget->font() );
  if ( myPointSize != font.pointSizeF() ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "'%s' Mismatch %g %g" ,
                   GuiItem::objectName(myObject) , myPointSize , font.pointSizeF() );
      myPointSize = font.pointSizeF();
  }
  // debug
  MscDg::trace( CLASS_NAME , METHOD_NAME ,
               "'%s'   Widget %d -> %d -> %d -> %d   Height %d -> %d" ,
               GuiItem::objectName(myWidget) ,
               myWidget->minimumWidth()  , myWidget->width() , myWidget->maximumWidth() ,
               myWidget->minimumHeight() , myWidget->maximumHeight() );

  // save values
  myWidth     = myWidget->width()         ;
  myMinWidth  = myWidget->minimumWidth()  ;
  myMaxWidth  = myWidget->maximumWidth()  ;
  myMinHeight = myWidget->minimumHeight() ;
  myMaxHeight = myWidget->maximumHeight() ;

  // pushbutton
  if ( myWidget->inherits("QPushButton") == true ) {
    QIcon icon = ((QPushButton*)myWidget)->icon();
    if ( icon.isNull() == false ) {
      // ISSUE: MODIFIES THE IMAGE myImage = icon->pixmap().convertToImage();
    }
  }
  // table
  else if ( myWidget->inherits("QTableWidget") == true ) {
    QTableWidget * table = (QTableWidget*)myWidget ;
    if ( table->rowCount() > 0 ) {
      myTableRow = table->rowHeight(0);
    }
  }
  // update
  if ( fontPercentage != 1.0f && pixmapPercentage != 1.0f ) {
    update( fontPercentage , pixmapPercentage );
  }
}




void GuiWidgetAspect::update( float fontPercentage , float pixmapPercentage )
{
  static const char * METHOD_NAME = "update()" ;
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME , "Font %g  Pixmap %g" , fontPercentage , pixmapPercentage );
  if ( fontPercentage <= 0.1f || pixmapPercentage <= 0.1f ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Font %g  Pixmap %g" , fontPercentage , pixmapPercentage );
    return ;
  }

  // pixmap
#if 0
  // NOT WORKING
  if ( myImage.isNull() == false ) {
    // ISSUE: RESIZE IS NOT WORKING CORRECTLY ****
     // scaledToHeight
     // scaledToWidth
    // QImage image = GuiMisc::resizeImage(myImage,pixmapPercentage);
    QPixmap pixmap( myImage );
    QIcon icon( pixmap );
    if ( myObject->inherits("QAction") == true ) {
      ((QAction*)myObject)->setIcon( icon);
    }
    if ( myObject->inherits("QPushButton") == true ) {
      ((QPushButton*)myObject)->setIcon( icon );
    }
  }
#endif
  // font
  if ( myWidget != 0 ) {
    // change font
    QFont font( myWidget->font() );
    font.setPointSizeF( myPointSize * fontPercentage );
    myWidget->setFont( font );
    // min / max
    if ( myMaxWidth  < 20000 ) { myWidget->setMaximumWidth ((int)(myMaxWidth  * fontPercentage)) ; }
    myWidget->resize( (int)(myWidth  * fontPercentage) , myWidget->height() );
    if ( myMinWidth  > 0     ) { myWidget->setMinimumWidth ((int)(myMinWidth  * fontPercentage)) ; }
    if ( myMaxHeight < 20000 ) { myWidget->setMaximumHeight((int)(myMaxHeight * fontPercentage)) ; }
    if ( myMinHeight > 0     ) { myWidget->setMinimumHeight((int)(myMinHeight * fontPercentage)) ; }
    // pushbutton
    if ( myObject->inherits("QPushButton") == true ) {

    }
    // table
    if ( myObject->inherits("QTableWidget") == true ) {
      QTableWidget * table = (QTableWidget*)myObject ;
      int numberOfRows = table->rowCount();
      if ( myTableRow == -1 ) {
        myTableRow = table->rowHeight(0);
      }
      for ( int row=0 ; row < numberOfRows ; ++row ) {
        // TODO ... check what can be done table->adjustRow(row);
      }
      for ( int col=0 ; col < table->columnCount() ; ++col ) {
        int colWidth =  table->columnWidth(col);
        colWidth = (int)( colWidth * (fontPercentage / myFontPercentage) );
        // debug
        if ( dbOn == true ) {
          GuiUtl::print( "  Table column[%d]  %d -> %d" ,
                       col ,  table->columnWidth(col) , colWidth );
        }
        // table->setColumnWidth( col , colWidth );
      }
      //
      // TODO .... table->horizontalHeader()->adjustHeaderSize();
    }
  }
  // save
  myFontPercentage   = fontPercentage   ;
  myPixmapPercentage = pixmapPercentage ;
}




//-----------------------------------------//
// Static Methods of "GuiTable"            //
//-----------------------------------------//
#if 0
void GuiTable::resizeInVisibleArea( Q3Table * table )
{
  if ( table == 0 ) { return ; }
  // width that can be seen : NOT OK at the start (as it's not visible)
  // int newWidth = table->visibleWidth() ;
  int scrollWidth = table->verticalScrollBar()->isShown() ? table->verticalScrollBar()->width() : 0 ;
  int headerWidth = table->verticalHeader() ? table->verticalHeader()->width() : 0 ;
  int newWidth    = table->width() - scrollWidth - headerWidth - 4 ; // why 4 ? 2 for the border

  if ( newWidth < 200 ) { return ; }

  // find the widths
  int   col=0 ;
  float previousTotalWidths = 0 ;
  int   lastColumn = (table->numCols() - 1);
  int   tableWidth = table->width() ;
  vector< int > mapColWidth ;
  for ( col=0 ; col <= lastColumn ; ++col ) {
    int colWidth = table->columnWidth( col );
    mapColWidth.push_back(colWidth);
    previousTotalWidths += colWidth ;
  }
  if ( previousTotalWidths == 0 ) { return ; }

  // resize
  int totalWidth = 0 ;
  float ratio =  newWidth / previousTotalWidths ; // to multiply the width with
  for ( col=0 ; col <= lastColumn ; ++col ) {
    int colWidth = (int)(ratio * mapColWidth[ col ]); // issue: size shrinks....
    //colWidth = (int)((1.0f * newWidth) / table->numCols()); // same size....
    //if ( col == lastColumn ) { colWidth = (newWidth - totalWidth); }
    //if ( colWidth < 50 ) { colWidth = 50 ; }
    table->setColumnWidth( col , colWidth );
    totalWidth += colWidth ;
  }
}
#endif

// DEFAULT:
//     <property name="columnMovingEnabled">
//     <bool>false</bool>
//     </property>
//     <property name="sorting">
//     <bool>false</bool>
//    </property>
// *****
// TODO     myOutputTable->setColumnStretchable(col,true);
// TODO     myO  // initial aspect
//for ( col=0 ; col < 5 ; ++col ) {
//  //myOutputTable->setColumnStretchable(col,true);
//}utputTable->adjustColumn(j);

// vqVelocityOperationsDialog   myCptLoadTable  setSelectionMode( QAbstractItemView::ExtendedSelection );
//      </property>
//      <property name="selectionMode">
//      <enum>QTableWidget::MultiRow</enum>
//      </property>
// */
// vqVelocityOperationsDialog   myCptAnalyseContentTable ;
// /*** myCptAnalyseContentTable
//      <property name="resizePolicy">
//      <enum>QScrollView::Default</enum>
//      </property>
// */

// vqSessionDialog table (setReadOnly)  TODO
// TODO   myStrTable->setReadOnly(true);
// resize the headers
//myStrTable->horizontalHeader()->setResizeEnabled(true);
//myStrTable->horizontalHeader()->adjustHeaderSize();

// myCptLoadTable->horizontalHeader()->resizeSection( 0 , HEADER_WIDTH_FILE    ) ;
// myCptLoadTable->horizontalHeader()->resizeSection( 1 , HEADER_WIDTH_STATUS  ) ;
// myCptLoadTable->horizontalHeader()->resizeSection( 2 , HEADER_WIDTH_COMMENT ) ;

// customize the QTable   *** TODO ***
#if 0
myTable->setReadOnly( false ) ;
myTable->setResizePolicy( QTableWidget::Default );
myTable->setShowGrid( true );
myTable->setRowMovingEnabled( FALSE );
myTable->setColumnMovingEnabled( FALSE );
#endif

#if 0
shared_ptr< GuiWidgetPM > GuiForm::myGuiWidgetPM       ;
GuiForm::FormList         GuiForm::myApplicationForms  ;
#endif

#if 0


bool  GuiForm::retrieveSizeOfWidget( QWidget *w )
{
  if ( w != 0 && myGuiWidgetPM.isEmpty() == false ) {
    return myGuiWidgetPM->retrieveResizeMove(w , true , false );
  }
  else {
    return false ;
  }
}


bool  GuiForm::retrieveSizeLocationOfWidget( QWidget *w )
{
  if ( w != 0 && myGuiWidgetPM.isEmpty() == false ) {
    return myGuiWidgetPM->retrieveResizeMove(w , true , true );
  }
  else {
    return false ;
  }
}


bool GuiForm::storeSizeLocationOfWidget( QWidget *w )
{
  // don't continue
  if ( w == 0 || w->isShown() == false || myGuiWidgetPM.isEmpty() == true ) return false ;
  // no save to do
  if ( w->isMinimized() == true || w->isMaximized() == true ) return true ;
  // save
  return myGuiWidgetPM->store(w) ;
}


bool GuiForm::storeSizeLocationOfWidgetAndClose( QWidget *w )
{
  if ( storeSizeLocationOfWidget( w ) == true ) {
    w->close() ;
    return true ;
  }
  else if ( w != 0 ) {
    w->close() ;
    return false ;
  }
  else {
    return false ;
  }
}


#endif

#if 0
  bool isOk = false ;
  switch ( myWidgetType ) {
  case GuiItem::WT_LINE_EDIT :
    {
      isOk = GuiLineEdit::geti_c( dynamic_cast<GuiLineEdit*>(myDerivedClass)->getLineEdit() , &value , name , true );
    } break;
  default:
    MscDg::error( CLASS_NAME , "getInt_c()" , "method not implemented for Type:%d Id:%d" ,
                 myWidgetType , myId );
    isOk = false ;
  }
  return isOk ;

#endif


#if 0
class GuiRadioButton : public QObject , public GuiItem
{
  Q_OBJECT

public :
  static const char * CLASS_NAME  ;
  static const char * CANCEL_TEXT ;
  typedef struct {
    int          myId        ;
    const char * myName      ;
    // labels
    const char * myText      ;
    const char * myAccelText ;
    const char * myToolTip   ;
    const char * myIconName  ;
    // size
    int          myMaxWidth  ;
    int          myMaxHeight ;
    // callbacks
    int          myCallbackTypes ;
    // VALUE : the added member
  } CreateInfo ;
  GuiRadioButton( GuiTeam & wg , QWidget * , const CreateInfo & );
  GuiRadioButton( GuiGroupBox & , const CreateInfo & );
  ~GuiRadioButton() ;
  void updateIcon();
  QRadioButton * getPushButton() { return myPushButton ; }

  /** static member (required when dealing with "ui" generated widgets) */
  typedef struct Item {
    QRadioButton * myItem  ;
    int            myValue ;
  };
  QRadioButton * createButtonGroup

private slots :

  void  slotClicked();

private :
  QRadioButton * myPushButton ;
} ;
#endif

/*
GuiTableTrackingEvent * GuiTable::getTrackingEvent()
{
  static const char * METHOD_NAME = "getValuesToTrack()";
  int r,c;
  return myTrackingEvent.getRowColumn(r,c) ? myTrackingEvent.getValues() : 0 ;
}
*/



#if 0
void GuiTable::resizeInVisibleArea( QTableWidget * table )
{
  if ( table == 0 ) { return ; }
  // width that can be seen : NOT OK at the start (as it's not visible)
  // int newWidth = table->visibleWidth() ;
  int scrollWidth = table->verticalScrollBar()->isShown() ? table->verticalScrollBar()->width() : 0 ;
  int headerWidth = table->verticalHeader() ? table->verticalHeader()->width() : 0 ;
  int newWidth    = table->width() - scrollWidth - headerWidth - 4 ; // why 4 ? 2 for the border

  if ( newWidth < 200 ) { return ; }

  // find the widths
  int   col=0 ;
  float previousTotalWidths = 0 ;
  int   lastColumn = (table->columnCount() - 1);
  int   tableWidth = table->width() ;
  vector< int > mapColWidth ;
  for ( col=0 ; col <= lastColumn ; ++col ) {
    int colWidth = table->columnWidth( col );
    mapColWidth.push_back(colWidth);
    previousTotalWidths += colWidth ;
  }
  if ( previousTotalWidths == 0 ) { return ; }

  // resize
  int totalWidth = 0 ;
  float ratio =  newWidth / previousTotalWidths ; // to multiply the width with
  for ( col=0 ; col <= lastColumn ; ++col ) {
    int colWidth = (int)(ratio * mapColWidth[ col ]); // issue: size shrinks....
    //colWidth = (int)((1.0f * newWidth) / table->numCols()); // same size....
    //if ( col == lastColumn ) { colWidth = (newWidth - totalWidth); }
    //if ( colWidth < 50 ) { colWidth = 50 ; }
    table->setColumnWidth( col , colWidth );
    totalWidth += colWidth ;
  }
}
#endif



#if 0

void GuiForm::storeIcon( QObject * w , const char * iconName )
{
  static const char * METHOD_NAME = "storeIcon()" ;
  if ( w == 0 || iconName == 0 ) { return ; }
  // store it

  // set it
  if ( w->inherits("QAction") == true ) {
    ((QAction*)w)->setIcon( QIcon( GuiUtl::getIcon( iconName ) ) );
  }
  else if ( w->inherits("QPushButton") == true ) {
    ((QPushButton*)w)->setIcon( QIcon( GuiUtl::getIcon( iconName ) ) );
  }
  else if ( w->inherits("QLabel") == true ) {
    ((QLabel*)w)->setPixmap( GuiUtl::getIcon( iconName ) );
  }
  else if ( w->inherits("QCheckBox") == true ) {
    ((QCheckBox*)w)->setIcon( QIcon( GuiUtl::getIcon( iconName ) ) );
  }
  else {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Undefined object type '%s'" , w->name("") );
  }
}


void GuiForm::storeIcon( QTabWidget * tab , QWidget * page , const char * iconName )
{
  if ( tab == 0 || page == 0 || iconName == 0 ) { return ; }
  // existing label
  QString label = tab->tabLabel( page );
  // change icon
  tab->changeTab( page , QIcon(GuiUtl::getIcon(iconName)) , label );
}
#endif







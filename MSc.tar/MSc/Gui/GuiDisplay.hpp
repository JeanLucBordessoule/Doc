#ifndef GUI_DISPLAY_HPP
#define GUI_DISPLAY_HPP

// C++
#include <set>

// Qt
class QString ;



/*! ************************************************
 * \class GuiFormatHint Format Hints
 * in order to customize from the initial one
 * ************************************************* */

class GuiFormatHint {
public :
    static const char * CLASS_NAME ;
    /** constructor used by the application .
     *  'initializeApplicationFormatHint' must be called after that  */
    GuiFormatHint( float fontPercentage   = 1.0f ,
                   float pixmapPercentage = 1.0f ) {
        myFontPercentage   = fontPercentage   ;
        myPixmapPercentage = pixmapPercentage ;
  }
  /** constructor used by the items and groups */
  GuiFormatHint( const GuiFormatHint & m ) {
        *this = m ;
  }
  /** copy of parameters */
  const GuiFormatHint & operator= ( const GuiFormatHint & m ) {
      if ( &m != this ) {
          myFontPercentage   = m.myFontPercentage   ;
          myPixmapPercentage = m.myPixmapPercentage ;
       }
      return *this ;
  }
  /** destructor */
  ~GuiFormatHint() {}

public :

  float myFontPercentage   ;
  float myPixmapPercentage ;

} ;




/*! ************************************************
 * \class GuiDisplayMessage
 * Message from the Display (application)
 * that propasgates along the screens and the forms.
 * ************************************************* */

class GuiDisplayMessage ;



/*! ************************************************
 * \class GuiScreen
 * managed the forms that are on the screen
 * ************************************************* */

class GuiTeam    ;
class GuiDisplay ;


class GuiScreen {
public :
    GuiScreen( GuiDisplay & d , int id ) : myDisplay(d) , myScreenId(id) {}
    /** manage the (top-level forms) teams . If 'addIt' is true it's added to 'myGuiTeams', else removed */
    bool addGuiTeam( GuiTeam * , bool addIt );
    const GuiFormatHint & getFormatHint() { return myFormatHint ; }
    const QString & getName() const;
private :
    GuiDisplay &  myDisplay    ;
    const int     myScreenId   ;
    GuiFormatHint myFormatHint ;
};



/*! ************************************************
 * \class GuiDisplay
 * information about the display (e.g.: propagation of information pertaining to a screen)
 * Manages the screens.
 * It enables to keep the information about the font size and propagates it.
 * ************************************************* */

class GuiDisplay {
public :
    GuiDisplay() {}
    static GuiDisplay * instance();
    GuiScreen * getDefaultScreen();
};



#endif

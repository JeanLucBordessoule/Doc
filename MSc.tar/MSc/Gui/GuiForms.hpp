#ifndef GUI_FORMS_HPP
#define GUI_FORMS_HPP

#include <map>
#include <set>
#include <vector>
#include <utility>

#include "MscDebug.hpp"

#include "GuiDataDefinitions.hpp"
#include "GuiItem.hpp"
#include "GuiUtilities.hpp"
#include "GuiWidgets.hpp"

#include "TypStructure.hpp"



/**************************************************************************************************
 **************************************************************************************************
 ** Creation of Items
 **************************************************************************************************
 *************************************************************************************************/


class GuiWidgetGroup : public GuiTeam
{
public :
  static const char * CLASS_NAME ;

  /*! define the gui items to create .
   *  useful to create a toolbars or menus in a main window */
  typedef struct {
    // the Actions and Widgets to put in the toolbars and menus.
    int                         myActionsBPnumber     ;
    GuiAction::CreateInfo      * myActionsBP           ;
    int                         myActionGroupBPnumber ;
    GuiActionGroup::CreateInfo * myActionGroupBP       ;
    int                         mySpinBoxBPnumber     ;
    GuiSpinBox::CreateInfo     * mySpinBoxBP           ;
    int                         myLabelBPnumber       ;
    GuiLabel::CreateInfo       * myLabelBP             ;
    int                         myPushButtonBPnumber  ;
    GuiPushButton::CreateInfo  * myPushButtonBP        ;
    int                         myCheckBoxBPnumber    ;
    GuiCheckBox::CreateInfo    * myCheckBoxBP          ;
    int                         myLineEditBPnumber    ;
    GuiLineEdit::CreateInfo    * myLineEditBP          ;
    int                         myComboBoxBPnumber    ;
    GuiComboBox::CreateInfo    * myComboBoxBP          ;
    int                         mySeparatorBPnumber   ;
    GuiSeparator::CreateInfo   * mySeparatorBP         ;
    // the toolbars and menus have the above items
    int                         myToolBarBPnumber     ;
    GuiToolBar::CreateInfo     * myToolBarBP           ;
    int                         myPopupMenuBPnumber   ;
    GuiPopupMenu::CreateInfo   * myPopupMenuBP         ;
    // special commands (modifiers...)
    int                         myGenericBPnumber     ;
    GuiItem::CreateInfo        * myGenericBP           ;
  } CreateInfo ;

  /** enum to modify the aspect */
  enum BoldType {
    BOLD_IGNORED = -1 ,
    BOLD_NO      =  0 ,
    BOLD_YES     =  1
  };

  /** constructor / destructor */
  GuiWidgetGroup( GuiTeam::TeamType teamType /*= GuiTeam::TP_GROUP*/ , int id = GuiItem::ID_UNDEFINED , QWidget * parent = 0 ,
                  const char * name = 0 , GuiTeam * teamLeader = 0 , GuiScreen * screen = 0 );
  virtual ~GuiWidgetGroup() {}

  /** add items */
  void createItems( GuiForm * , const CreateInfo & bp );

  /** manage the items */
  void addExistingItemToCaller( GuiItem * caller , int itemId , int & numberOfItemsSinceLastSeparator ) ;

  /** find the parent widget and / or the layout */
  void getParentAndLayout( int parentId , QWidget * &parent , GuiItem * & guilayout );

  /*! create specific items . BoldValue:  (-1): don't modify   (0): is not bold  (1): is bold .
   *  the Id of the related Data Item can be provided. It enables information transfer . */
  GuiCheckBox   * createCheckBox  ( const GuiCheckBox::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiComboBox   * createComboBox  ( const GuiComboBox::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiFrame      * createFrame     ( const GuiFrame     ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiGroupBox   * createGroupBox  ( const GuiGroupBox  ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_YES ,
                                    int dataId = MscDataItem::ID_UNDEFINED   , int row = -1 , int col = -1 );
  GuiLabel      * createLabel     ( const GuiLabel     ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiLineEdit   * createLineEdit  ( const GuiLineEdit  ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiListBox    * createListBox   ( const GuiListBox   ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiListView   * createListView  ( const GuiListView  ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiLayout     * createLayout    ( const GuiLayout    ::CreateInfo & ,
                                    int parentId = GuiItem::ID_UNDEFINED , int row=-1 , int col=-1 );
  GuiPushButton * createPushButton( const GuiPushButton::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiSlider     * createSlider    ( const GuiSlider    ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiSpinBox    * createSpinBox   ( const GuiSpinBox   ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiSplitter   * createSplitter  ( const GuiSplitter  ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int row = -1 , int col = -1 );
  GuiStackedWidget * createStackedWidget( const GuiStackedWidget::CreateInfo & ,
                                          int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                          int row = -1 , int col = -1 );
  GuiTable      * createTable     ( const GuiTable     ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiTabWidget  * createTabWidget ( const GuiTabWidget ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int row = -1 , int col = -1 );
  GuiTextEdit   * createTextEdit  ( const GuiTextEdit  ::CreateInfo & ,
                                    int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_NO ,
                                    int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  GuiWidget     * createWidget    ( const GuiWidget    ::CreateInfo & ,
                                    int parentId = GuiItem::ID_UNDEFINED ,
                                    int row = -1 , int col = -1 );
  
  /** according to the content of views in the frame, show or hide the items */
  void modifySensitivityOfTheItems( int modifierId );
  void modifyVisibilityOfTheItems();
  bool receiveEventOfSender( int senderId , GuiEvent::EventType = GuiEvent::ET_ACTIVATED );

  /** implemented method for the above (CUSTOMIZE IT it if needed) */
  virtual bool isTheItemSensitive( int id , int viewId ) const { return true ; }

  /** implemented method for the above (CUSTOMIZE IT if needed) */
  virtual bool isTheItemVisible( int id ) const { return true ; }

  /** refresh */
  virtual void refresh(); // re-implement the 'refresh()' of 'GuiTeam'
  virtual void refresh( int ); // re-implement the 'refresh()' of 'GuiTeam'

protected :

  /** return the widget of the id. 
  * Else, the parent provided by the constructor . 
  * Used  by the "GuiWidgetGroup::createXXX()" and "GuiForm::createPageHolder()" methods */
  QWidget    * myGetWidgetAndLayout( int id , GuiLayout* &guiLayout , GuiItem **guiItemPtr=0  );

} ;




/**************************************************************************************************
 **************************************************************************************************
 ** Page : items in a Tab or a Side by Side widget
 **************************************************************************************************
 *************************************************************************************************/


// parameter storages 
class GuiFrameOfPage ;
class GuiForm        ;

class GuiPage : public QObject , public GuiWidgetGroup
{
  Q_OBJECT
  
public :
  static const char * CLASS_NAME ;
  // TODO RECEIVERCLASS ;
  
  /** the way the page is implemented * UNUSED * */
  enum FormType {
    FT_UNDEFINED   = 0 ,
    FT_FRAME
  };
  
  enum TransferType {
    TF_DATA_TO_USER = 0 ,
    TF_USER_TO_DATA
  };
  
  /** parameters for the page */
  typedef struct {
    /** id of the item     */
    int          myId       ;
    /** name of the widget */
    const char * myName     ;
    /** tooltip */
    const char * myToolTip  ;
    /** group box (has title and icon) */
    GuiGroupBox::CreateInfo  * myGuiGroupBox ;
    /** size of the page   */
    GuiItem::SizesCreateInfo * mySizes ;
    /** link between the GUI and the parameters items (data transfer) */
    int          myNumberOfLinks ;
    GuiTeam::IdsLink * myLinks ;
    /** help page */
    const char * myHelpPage ; 
  } CreateInfo ;

  /** page */
  GuiPage( QWidget * parent , const CreateInfo & );
  GuiPage( GuiPageHolder *  , const CreateInfo & );
  ~GuiPage();

  /** the top level widget */
  QWidget       * getWidget() ;
  /** page holder and form . It's relevant with the second constructor */
  GuiPageHolder * getPageHolder() const { return myPageHolder ; }
  GuiForm       * getForm() const { return myPageHolder ? myPageHolder->getForm() : 0 ; }
  
  /** set / get the values */
  void         setBoolean( bool ) ;
  bool         getBoolean() const ;
  
  /** modify aspect of the frame (title , checked or not) */
  void         showFrame( bool ) ;
  
  /** return 'true' if the frame is not checkable or if it is checked */
  bool         isActive() ;
  
  /**  id , title , icon of the page */
  int          getId()       const { return myId       ; }
  QString      getIcon()     const { return myIcon     ; }
  QString      getTitle()    const { return myTitle    ; }
  QString      getHelpPage() const { return myHelpPage ; }

  /** the last message of the transfer */
  const QString & getTransferMessage() const { return myTransferMessage ; }
  
  /** storage and read / write of the parameters : 'read_write' 'launch_method' **/
  virtual bool transferParameters( int transferId , QString & message ) { return false ; } ;
  
  /** called by the top widget implemented in this class */
  bool         pageKeyPressEvent( QKeyEvent * e ) ;
  bool         pageKeyReleaseEvent( QKeyEvent * e ) ;
  
  /** user pressed a key on the top widget encapsulated in this class
   * .Reimplemented by the derived class. */
  virtual void refresh();
  virtual void refresh( int id );
  
  /** "GuiTeam" method: treat the request of the item. */
  virtual bool receiveEvent( GuiEvent & );
  
protected :
  
  /** CUSTOMIZE IT if needed.
   *  User pressed a key on the top widget encapsulated in this class 
   *  Return 'true' to have the event treated by the base class */
  virtual bool derivedPageKeyPressEvent  ( QKeyEvent * e );
  virtual bool derivedPageKeyReleaseEvent( QKeyEvent * e );
  
private :
    
  /** initialize the page */
  void                  myInitialize( QWidget * parent , GuiPageHolder * pageHolder , const CreateInfo & createInfo );
  
  /** id of the page and other parameters provided by the constructor */
  int                   myId              ;
  QString               myIcon            ;
  QString               myTitle           ;
  QString               myHelpPage        ;
  QString               myTransferMessage ;

  /** implementation of the top widget of the page */
  GuiGroupBox         * myFrame           ;
  QGroupBox           * myGroupBox        ;

  /** state of the page */
  bool                  myIsActive        ;

  /** form or page holder that created it */
  GuiPageHolder       * myPageHolder      ;

  /** links between the GUI and the items */
  int                   myNumberOfLinks   ;
  GuiTeam::IdsLink    * myLinks           ;

  /** last key pressed . See also : Qt::KeyboardModifier */
  int                   myKey             ;
  Qt::KeyboardModifiers myModifiers       ;

} ;

  


/**************************************************************************************************
 **************************************************************************************************
 ** Form : QDialog or a QMainWindow
 **************************************************************************************************
 *************************************************************************************************/

// created here, the implementation of the shell window.
class GuiDialogOfForm     ;
class GuiMainWindowOfForm ;


class GuiForm : public GuiWidgetGroup
{
public :
  static const char * CLASS_NAME ;
  // TODO RECEIVERCLASS ;

  //-------------------------------------------------------//
  // register all the forms (at the application level)     //
  //-------------------------------------------------------//
  typedef std::list < GuiForm * > FormList ;
  
  /** Interface for the user of this class */
  class Interface {
  public :
    Interface() {}
    ~Interface() {}
    virtual GuiViewPopupMenu * createPopupMenuId( GuiForm * ) = 0 ;
    virtual void               popupMenuAboutToShow( GuiViewPopupMenu * menu ) = 0 ;
  private:
    /** not implemented */
    Interface( const Interface & );
  } ;

  /** interface is like a callback method . It's used to access the popup */
  static void setInterface( Interface * f ) { myInterface = f ; }
  
  /** the way the form is implemented */
  enum FormType {
    FT_UNDEFINED          = 0 ,
    /** QDialog without or with destructive close */
    FT_DIALOG_ONLY        , // same as FT_DIALOG_KEEP . Used with Qt designer
    FT_DIALOG_KEEP        ,
    FT_DIALOG_DESTROY     ,
    /** QMainWindow */
    FT_MAINWINDOW_ONLY    , // same as FT_MAINWINDOW_KEEP . Used with Qt designer
    FT_MAINWINDOW_KEEP    ,
    FT_MAINWINDOW_DESTROY
  }  ;
 
  /** parameters for the form */
  typedef struct {
    /** id of the form     */
    Defs::FormId myId       ;
    /** name of the widget */
    const char * myName     ;
    /** tooltip            */
    const char * myToolTip  ;
    /** title of the form  */
    const char * myTitle    ;
    /** icon for the form  */
    const char * myIcon     ;
    /** icon text          */
    const char * myIconText ;
    /** type of the form   */
    FormType     myType     ;
    /** top splitter used by the main widget  */
    GuiSplitter::CreateInfo  * mySplitterBP ;
    /** top layout used by the main widget */
    GuiLayout::CreateInfo    * myLayoutBP ;
    /** size of the form   */
    GuiItem::SizesCreateInfo * mySizesBP  ;
  } CreateInfo ;
  
public :
  /** constructor */
  GuiForm( const CreateInfo & createInfo  ,
           GuiForm         * teamLeader = 0 ,
           GuiScreen       * screen     = 0 );

  /** general aspect . dealing with icons */
  void           removeDefaultButton();

  /** drop & icons */
  void           setAcceptDrops( bool b );
  void           setMinimumSize( int widget , int height );
  void           setIconText( const char * iconText );
  void           setIconName( const char * iconName=0 );
  void           showAppIcon( QWidget * w );
  /** set hierarchy . modify aspect */    
  void           updateFont();
  void           updateIcon();
  void           setTeamLeader( GuiTeam * teamLeader , bool updateAspect );
  void           reparentForm( GuiForm * newOne );
  void           setScreen( GuiScreen * screen , bool updateAspect );
  void           finishAspect( GuiItem::SizesCreateInfo * size = 0 , bool doRetrieveSize = true );
  /** message from 'GuiDialogOfForm' or 'GuiMainWindowOfForm' */
  bool           messageFromBaseForm( GuiEvent::EventType );
  void           destroy ( bool destroyWindow , bool destroySubWindows );

  /** destructor */
  virtual       ~GuiForm() ;

  /** View type. Provided by the constructor, it's given to the base class
   *  GuiWidgetGroup -> GuiTeam::myId */
  Defs::FormId   getFormId() const { return (Defs::FormId)myId; }

  /** creation number for each type (same 'myId' = 'buPaceFormIds::FormType') */
  int            getSameTypeCreationIndex() const { return mySameTypeCreationIndex ; }
  void           setSameTypeCreationIndex( int i ) { mySameTypeCreationIndex = i ; }

  /** set the title */
  void           setTitle( const QString & );

  /** center the form on a given widget, or on the active window .
   * For that the height of ther frame has to be determioned (TODO) */
  int            getHeightOfTheTopFrame(); // TODO currently it's constant
  bool           centerFormOnItem( int itemId );

  /** find out if the form is visible ('myShowEventHappened' uses 'QHideEvent' or 'QShowEvent') .
   *  Raise it if needed  */
  bool           isFormShown() const ;
  void           raiseForm( bool mustBeShown=true ); // if not shown, it's a pop-up
  /** find out it 's it modal */
  bool           isFormModal() const ;
  void           setFormModal( bool );
  /** adjust */
  void           adjustFormSize();

  /** show / hide the form . Arguments are meaningful for a 'FT_DIALOG' only. */
  bool           showForm( bool isModal = false );
  void           hideForm( bool accepIt = true  );

  /** the below two are generally reimplemented in the derived class */
  virtual bool   doPopUp( bool isModal  = false ) { return showForm( isModal ); }
  virtual void   doPopDown() { hideForm(); }

  /** message propagated from the screen (see: GuiDisplay::propagateDisplayMessage()) .
   *  It could be re-implemented in the derived class */
  virtual void   propagateDisplayMessage( GuiDisplayMessage & );

  /********************************
   * Services provided by the form . Remark: "getTopWidget()" to access the main widget
   *******************************/

  /** the top window */
  QMainWindow * getMainWindow() const ; // hidden implementation with "GuiMainWindowOfForm"
  QDialog     * getDialog() const ; // hidden implementation with "GuiDialogOfForm"
  QWidget     * getForm() const ;

  /** align forms . store / retrieve their location / size */
  bool          alignViewWithSource( GuiForm * , int & x , int & y , int & w , int & h );
  void          storeSizeLocationOfForm();
  void          retrieveSizeOfForm();

  /** message facilities (message displayed in the status bar of a QMainWindow)
   *  If permanentt, added to the message area (and it can be retrieved) */
  void          setStatusMessage( QString msg ) ;
  void          addMessage( const QString & , bool isPermanent=true , bool doFlush=false );
  /** copy the messages and put them in the provided QString .
   * It can be customized in the derived class */
  virtual void  getMessages( QString & );

  /********************************
   * Message Boxes
   *******************************/

  /** message box . In fact, it can change its aspect according to the needs .
   * If only one parameter is present, it's an information dialog box *
   * Answer is : MscDg::ANS_YES (button 1) MscDg::ANS_NO (button 2) MscDg::ANS_CANCEL (button 3) */
  MscDg::UserAnswer messageBox( QString message ,
                               QString title   = Defs::getAppName() ,
                               /** button numbers are between 1 and 'numberOfButtons' */
                               int     numberOfButtons = 1 ,
                               /** default button. by default, the first one */
                               int     defaultButton   = 1 ,
                               /** by default . icon is 'Information' for numberOfButtons=1 else it's 'Question' */
                               MscDg::UserCallbackType messageBoxType = MscDg::CALLBACK_DIALOG ,
                               /** default is 'Ok' for one button else it's 'Yes', 'No', 'Cancel' */
                               const char * btn1 = 0 ,
                               const char * btn2 = 0 ,
                               const char * btn3 = 0 ,
                               /** escape button number . by default, the last one (numberOfButtons) */
                               int escapeButton  = 0 );

  MscDg::UserAnswer questionBox( const QString & message , const QString & title = Defs::getAppName() ,
                                int defaultButton = MscDg::ANS_YES )
  { return messageBox(message,title,2,defaultButton,MscDg::CALLBACK_QUESTION_BOX); }

  void             warningBox( const QString & message , const QString & title = Defs::getAppName() )
  { (void)messageBox(message,title,1,1,MscDg::CALLBACK_WARNING_BOX); }

  void             informationBox( const QString & message , const QString & title = Defs::getAppName() )
  { (void)messageBox(message,title,1,1,MscDg::CALLBACK_INFO_BOX); }


  /********************************
   * read / save , directory facilities
   ********************************/

  QString           getOpenFileName ( const QString & directoryOrFile ,
                                      const QString & types ,
                                      const QString & caption );
  std::vector< QString > getOpenFileNames( const QString & directoryOrFile ,
                                      const QString & types ,
                                      const QString & caption );
  QString           getSaveFileName ( const QString & directoryOrFile ,
                                      const QString & types ,
                                      const QString & caption ,
                                      const char    * extension = 0 ); // add extension if messing
  QString           getExistingDirectory( const QString & directoryOrFile ,
                                          const QString & caption ); // dir only . resolveSymlinks

  /********************************
   * Progress bar . Either in the status bar of QMainWindow or in a separate QProgressDialog.
   *******************************/

  void  indicateProgressStart( bool stopButton=false , const char * message=0 , const char *title=0 );
  bool  indicateProgress( float percentage , const char * message=0 );
  void  indicateProgressEnd( const char * message=0 );


  /********************************
   * Management of the Page Holders
   *******************************/
  
  /** create page holder . It becomes "myCurrentPageHolder" */
  GuiPageHolder   * createPageHolder( const GuiPageHolder::CreateInfo & ,
                                      int parentId = GuiItem:: ID_UNDEFINED , BoldType isBold=BOLD_YES ,
                                      int dataId   = MscDataItem::ID_UNDEFINED , int row = -1 , int col = -1 );
  
  /** get the id of a page holder . '0' if not found */
  int               getPageHolderId( QWidget * ) const ;

  /** get the widget of the page holder with a specific id */
  QWidget         * getWidgetOfPageHolder( int id ) const ;

  /** find out if the page holder is active (shown) */
  bool              getPageHolderIsActive( GuiPageHolder * ) const ;

  /** the active page holder */
  GuiPageHolder   * getActivePageHolder() const { return myCurrentPageHolder ; }

  /** page holder has changed the active page holder */
  GuiPageHolder   * setActivePageHolder( QWidget * );
  bool              setActivePageHolder( GuiPageHolder * );

  /** add / remove the page holder from the internally managed list */
  bool              addPageHolderToList( GuiPageHolder * );
  bool              removePageHolderFromList( GuiPageHolder * );

  /** get the help page of the currect active page */
  QString           getActiveHelpPage();
  void              showActiveHelpPage( const char * defaultHelpPage = 0 );
  void              showHelpPage( const QString & = "" );

  /********************************
   * Event dealt by the form
   *******************************/

  /** called by the top widget implemented in this class .
   * return 'true' if the action has been treated (should not be dispatched to the base class)
   * return 'false' if the action has not been treated (should be dispatched to the base class) */
  bool         baseMousePressEvent( QMouseEvent * e );
  void         mouseEvent( QMouseEvent * e ) { (void)baseMousePressEvent(e); }
  
  /** action on a specific page */
  bool         formKeyPressEvent( QKeyEvent * e ) ;
  bool         formKeyReleaseEvent( QKeyEvent * e ) ;

  /** popup menu. by default, all the dialog boxes of the application have the same main popup-menu */
  void         createPopupMenuId();
  void         deletePopupMenu();

  /** implemented in 'vqBaseWindows' .... */
  virtual void redrawCursor() {}

  /** for the pages : storage and read / write of the parameters : 'read_write' 'launch_method' **/
  bool         transferParameters( int transferId , bool activeHolderOnly , bool activePageOnly  , QString & message ) ;

  /*! refresh all the pages . It forces the update of the GUI parameter
   *  Transfer from Data Item to Gui Items. */
  virtual void refresh();
  virtual void refresh( int id );
  void         refresh( bool activeHolderOnly , bool activePageOnly );
  void         setIsDirty( int = GuiTeam::FLAG_ALL_DIRTY );



protected :

  /** mouse event
   *  Reimplemented by the derived class.
   *  Return 'true' to have the event treated by the base class */
  virtual bool derivedMousePressEvent( QMouseEvent * e ) { return true; }

  /** user pressed a key on the top widget encapsulated in this class
   *  Reimplemented by the derived class.
   *  Return 'true' to have the event treated by the base class */
  virtual bool derivedFormKeyPressEvent  ( QKeyEvent * e ) { return true ; }
  virtual bool derivedFormKeyReleaseEvent( QKeyEvent * e ) { return true ; }

protected :

  /** timer can be created outside */
  void                        setTimer( GuiTimer * );
  GuiTimer                  * getTimer() { return myTimer ; }
  
  /** management of the page holders */
  GuiTabWidget              * myGuiTabWidget      ;
  std::vector< GuiPageHolder * > myPageHolders       ;
  GuiPageHolder             * myCurrentPageHolder ;
  
  /** pop-up menu . by default, all the forms have the same pop-up menu (application's one) */
  bool                        myIsFirstPopUp      ;
  GuiViewPopupMenu          * myPopupMenu         ;

  /** implementation of the form . Only one of the exist . created if nothing is provided */
  GuiDialogOfForm           * myDialog            ;
  GuiMainWindowOfForm       * myMainWindow        ;

  /** progress bar . for the main window it's in the status bar */
  GuiProgressBar            * myProgressBar       ;

private :

  /** service provider for the popup-menu .
   *  Hence, by default, any dialog box or windows of the application has the same popup menu */
  static Interface * myInterface        ;

  /** implementation of the form . See the enum : QDialog, QMainWindow, deleted at close or not ... */
  FormType           myType ;

  /** counting the index of the same "Defs::FormId" */
  int                mySameTypeCreationIndex ;

  /** flag to avoid some actions */
  bool               myShowEventHappened ;
  bool               myBeingDeleted   ;

  /** timer */
  GuiTimer         * myTimer ;

  /** format */
  int                myFormatInt ;
  static int         myApplicationFormat ;
};



#endif



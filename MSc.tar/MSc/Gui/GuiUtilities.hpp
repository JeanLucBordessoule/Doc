#ifndef GUI_UTILITIES_HPP
#define GUI_UTILITIES_HPP

#include <fstream>

#include "MscString.hpp"
#include "TypStructure.hpp"

#include <QString>
#include <QImage>

class GuiForm ;

class QObject ;
class QWidget ;
class QColor  ;
class QIcon   ;
class QObject ;
class QPixmap ;
class QWidget ;


/**
 * The Utilities namespace contains facilities mainly used by the GUI.
 */

namespace GuiUtl
{
    /*! ===========================================================
     *  FUNCTIONS
     *  ======================================================== */

    /** find out if the string has no meaningful information */
    bool            isBlank( const char * str );
    bool            isBlank( const QString & );

    /** remove spaces at the end and at the begining */
    void            stripString( QString & );

    /** get the character string */
    const char    * getObjectName     ( QObject * );
    const char    * getObjectClassName( QObject * );
    const char    * getString( const QString & );
    MscString       getMscString( const QString & );

    /** numbers facilities */
    int             toInt   ( float ); //
    int             toInt   ( const QString & , bool * isOk=nullptr );
    float           toFloat ( const QString & , bool * isOk=nullptr );
    double          toDouble( const QString & , bool * isOk=nullptr );

    /** colors and colormap */
    const QColor  & getColor( Typ::ColorId );
    const QPixmap & getPixmap( const char * xpm[] , float resizeFactor=1.0f );
    const QIcon   & getIcon( const QString & , float resizeFactor=1.0f );

    /** flush . indicate the caller */
    void            processEvents( const char * className , const char * methodName );

    /** put it on the front. if minimized, show it */
    void            raise( QWidget * );
    void            removeDefaultButton( QObject * obj );

    /** directories used by the storage (might be customized by the application) */
    enum  DirectoryType { DIR_HOME };
    const QString & getDirectory( DirectoryType = DIR_HOME );

    /** show help page */
    void            launchBrowser( GuiForm * , const QString & ) ;

    /** The print out is customized by the application. Only the required messages are displayed. */
    typedef struct { const char * myClassName ; const char * myMethodName ; } TrackerInfo ;
    bool                getShowTrackerTraces() ;
    void                tracker( int type , const char * className , const char * methodName );
    const TrackerInfo * getTrackerInfo( int & arraySize , int & lastIndex , int & rank );
    QString             getTrackerString();

    /** just make a print-out */
    void print( const char * format , ... );
};





namespace GuiMisc
{
  bool enterWhatsThisMode( const QWidget * , const QString & );
}


/*! =============================== **
 ** GuiWidgetAspect .
 ** Keep the state of an object.
 ** (use is deprecated)
 ** =============================== **/

class GuiWidgetAspect
{
public :
  static const char * CLASS_NAME ;
  /** save the initial aspect */
  GuiWidgetAspect( QObject * obj , float fontPercentage = 1.0f , float pixmapPercentage = 1.0f );
  void update( float fontPercentage , float pixmapPercentage );
  /** members */
  QObject * myObject           ;
  QWidget * myWidget           ;
  float     myPointSize        ;
  int       myMinWidth         ;
  int       myMinHeight        ;
  int       myMaxWidth         ;
  int       myMaxHeight        ;
  int       myWidth            ;
  // used by GuiTable
  int       myTableRow         ;
  /** image */
  QImage    myImage            ;
  /** percentages */
  float     myFontPercentage   ;
  float     myPixmapPercentage ;
};


#endif


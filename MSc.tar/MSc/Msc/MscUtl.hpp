#ifndef MSC_UTL_HPP
#define MSC_UTL_HPP

#include <list>
#include <set>
#include <vector>

#include "MscString.hpp"


/** MscUtl Convenience namespace to basic string operations */



class MscUtl 
{
public :
  static const char * CLASS_NAME ;
  /** Type of data when reading data in text file */
  enum WordType { WT_UNDEFINED=0 , WT_INT , WT_FLOAT , WT_ALPHA } ;

  //-----------------------------------------------------------//
  //-----------------------------------------------------------//
  //    STATIC UTILITIES                                       //
  //-----------------------------------------------------------//
  //-----------------------------------------------------------//

  /** remove duplicate from list */
  static void removeDuplicate( std::list< MscString > & );

  /** convert from std::set to strd:list and vice versa */
  static std::list< MscString > toStringsList( const std::set < MscString > & ) ;
  static std::set < MscString > toStringsSet ( const std::list< MscString > & ) ;

  /** convert from std::vector to strd:list and vice versa */
  static std::list  < MscString > toStringsList  ( const std::vector< MscString > & ) ;
  static std::vector< MscString > toStringsVector( const std::list  < MscString > & ) ;

  /** keep latest version only */
  static void    keepLatestVersionOnly( std::list< MscString > & ) ;

  /** remove prefix or suffix after stripping from empty characters */
  static bool    removePrefix( MscString & , const char * prefix );
  static bool    removeSuffix( MscString & , const char * suffix );

  /** remove version */
  static MscString removeVersion( const MscString & str , bool & hasPoint );

  /** remove space(s) in the name . Returns the number of space removed */
  static int     removeSpace( MscString & );
  /** remove space(s), capitalyze after a space and return the result */
  static MscString removeSpaceCamelCase( const MscString & );

  /** string is null or blank */
  static bool    isBlank( const char * );

  /** compare two character strings (can be null) . Uses 'strcmp' */
  static bool    isSame  ( const char * , const char * ) ;

  /** find out if the charavter string stores an integer */
  static bool    isInt( const MscString &  , int & value ) ;

  /** identify if a string contains another (pointers can be null) . uses 'strstr' . 
      ( Return (-1) if it does not contain . Returns the index of first character in first string */
  static int     getIndexInside( const char * containerString , const char * researchedString ) ;

  /** identify if a string contains a character (pointer can be null) . uses 'strchr' . 
      ( Return (-1) if it does not contain . Returns the index of character */
  static int     getIndexInside( const char * containerString , char researchedChar ) ;

  /** split the line into words . 'convertSeparators' will characters ',' '\t' '=' by a space */
  static std::vector< MscString > getWords( const char * , bool convertSeparators );

  /** detect up to 'number' words (characters with no space in between them) on a line 
   * Separators are space or , or ; 
   * Fills in the array of 'wordsStartEnd' up to 'number' .
   * Returns the number of words identified in the line */
  static int     detect( const char * containerString , std::vector< std::pair< WordType , std::pair<int,int> > > & wordsStartEnd , int number = -1 ) ;

  /** detect the word at a given position (1,2,3,...). 
   * If found, fill in the 'str' and return 'true '
   * Else do *not* alter the 'str' and return 'false'  */
  static bool    detect( const char * containerString , int position , MscString & str , bool readTillEndOfLine = false );

  /** behaves as the above (with 'readTillEndOfLine' = false)
   * Detect the word at a given position
   * If found, fill in the 'str' and return 'true '
   * Else do *not* alter the 'str' and return 'false'  */
  static bool    getString( const char * containerString , const std::pair<int,int> & wordStartEnd , MscString & str ) ;

  /** get a float from a word in a line . Location have been detected betfore and *must* be correct .
   * Set '*isOk' to 'true' or 'false' (if pointer is provided) */
  static float   getFloat( const char * containerString ,  const std::pair<int,int> & wordStartEnd , bool * isOk = 0 );

  /** returns 'true' if the 'flag' was present and has been removed ('input' is modified) */
  static bool    removeFlag( MscString & input , const char * flag );
  static bool    removeFlag( MscString & input , const char   flag );
  /** extract a word . Modify the input . returns 'true' if a word has been found */
  static bool    removeWord( MscString & input , MscString & word ); 

  /* Returns '0' if none else index of last character read */
  static int     extractIntegers( const MscString & s , int & value , int * value2=0 , int * value3=0 );
  /** extract the first integer (consecutive digits) found in the string . Returns 'true' if found */
  static bool    extractInteger ( const MscString & s , int & value ) { return (extractIntegers(s,value) != 0) ; }
  /** extract and remove (same as 'extract' Typt the 'input' is modified')*/
  static bool    removeIntegers ( MscString & input , int   & value , int   * value2=0 , int   * value3=0 );

  /** extract floats (consecutive digits) found in the string . 
   * Returns '0' if none else index of last character read */
  static int     extractFloats( const MscString & s , float & value , float * value2=0 , float * value3=0 );
  /** extract the first integer (consecutive digits) found in the string . Returns 'true' if found */
  static bool    extractFloat ( const MscString & s , float & value ) { return (extractFloats(s,value) != 0) ; }
  /** extract and remove (same as 'extract' Typt the 'input' is modified')*/
  static bool    removeFloats ( MscString & input , float & value , float * value2=0 , float * value3=0 );

  /** unique way to create the name of the line . At the moment, ignore '2D' unless forced .
   * If 'twoD=0=false' : 3D , If 'twoD=1=true' : 2D . else  'twoD=-1' consider 'isInline' only */
  static MscString TypildLineString( int lineNumber , bool isInline , int is2D = -1 );

  /** extract the line number *
   * If 'twoD=0=false' : 3D , If 'twoD=1=true' : 2D . else  'twoD=-1' unknown 
   * Return 'errorMessage' if error */
  static MscString analyzeLineString( const MscString & lineString , int & lineNumber , bool & isInline , int & is2D );

  /** extract the line number that is in the provided list . It returns the 'lineNumber/Orientation' string 
   *  It supports different formats .
   *  If it's not found, the returns an empty string */
  static MscString analyzeLineStringList( const std::list<MscString> & lineStrings , int lineNumber , bool isInline );

  /** return the character string with the time in it */
  static MscString getDateTimeAsString();

  /*======================================================================
   *======================================================================
   * Directory and File Utilities
   *======================================================================
   *====================================================================*/

  //static const MscString & homeDirectory();
  //static bool fileExists( const MscString & );
  static bool fileExists( const char * );
  static bool directoryExists( const MscString & );
  static bool directoryExists( const char * );
  static bool mkDir( const MscString & , int );
  static bool mkDir( const char * , int );
  static void unlink( const MscString & );
  static void unlink( const char    * );
  //int  toInt( const MscString & );
  //int  toInt( const char    * );
  static int  toInt( float );

  /** add extension if not present (tolerate the second extension) .
  * Returns 'true' if a change occurred */
  static bool    addExtensionIfMissing( MscString & s , const char * ext , const char * possibleExt = 0 );

  /** get the extension */
  static MscString getExtension( const MscString & s , bool convertToLowerCase = true );

  /** remove last '/' in the name */
  static void    removeEndSlash( MscString & s );

  /** convert the path : turn '\' into '/' */
  static void    convertPath( MscString & s );

  /** home directory (without final /) */
  static MscString homeDirectory();

  /** directory exists . Create it if required */
  static bool    directoryExists( const MscString & , bool createIt );
  static bool    fileExists( const MscString & );

  /** remove any text before a / . In fact directory might not exist . Check if valid directory if path provided */
  static MscString removeDirectoryPath( MscString & s , MscString * providedDirectory );

  /** get the directory name . Error message if the file doesn't exist */
  static MscString extractDirectoryOfExistingFile ( const MscString & s , MscString * errorMessage = 0 );

  /** returns the existing drectory name, Empty string if the directory does not exist. */
  static MscString getDirectoryName( const char * className , const char * methodName , 
                                   const MscString & filePath , MscString & fileName , MscString * extPtr = 0 ); 
  static MscString getDirectoryName( const MscString & filePath , MscString & fileName , MscString * extPtr = 0 )
  { return       getDirectoryName( 0 , 0 , filePath , fileName , extPtr ); }

  /** decompose a directory path */
  static bool    decomposeFilename( const MscString & f , MscString & directory , MscString & fileName ,
                                    int & version , const char * extensionString );

private :

  /** Not Implemented */

  MscUtl() ;
  MscUtl( const MscUtl & );
  const MscUtl & operator= ( const MscUtl & );
  ~MscUtl();


} ;

#endif

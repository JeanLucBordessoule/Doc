#include "MscFileSystem.hpp"

// #include <filesystem>  // C++17

#include "MscDebug.hpp"
#include "MscUtl.hpp"




//===============================================================
//===============================================================
//===============================================================
//       STATIC VALUES .
//===============================================================
//===============================================================
//===============================================================


int MscDirectoryInfo::myLastSessionIdNumber = 0 ;
const char * MscDirectoryInfo::CLASS_NAME   = "MscDirectoryInfo" ;

// TODO REPLACE IT BY SOURCE IN 'myAnalyzeDirectory'
MscDirectoryInfo::AnalyzeDirectoryCallback MscDirectoryInfo::myAnalyzeDirectory = 0 ;
std::set< MscString > MscDirectoryInfo::myRestrictedDirectories ;




//===============================================================
//===============================================================
//===============================================================
//       HELPER CLASS : FileDescription
//===============================================================
//===============================================================
//===============================================================



MscDirectoryInfo::FileDescriptor::FileDescriptor()
{
  myInitialize();
}


MscDirectoryInfo::FileDescriptor::FileDescriptor( const FileDescriptor & model )
{
  // initialize
  myInitialize();
  // copy (if not the same)
  *this = model;
}


const MscDirectoryInfo::FileDescriptor & MscDirectoryInfo::FileDescriptor::operator= ( const FileDescriptor & model )
{
  if ( &model != this ) {
    myDirectory    = model.myDirectory    ;
    myFileType     = model.myFileType     ;
    myFileName     = model.myFileName     ;
    myFullFileName = model.myFullFileName ;
    myDate         = model.myDate         ;
    myTime         = model.myTime         ;
    mySize         = model.mySize         ;
    myPosition     = model.myPosition     ;
    myHasChanged   = model.myHasChanged   ;
    myIsPresent    = model.myIsPresent    ;
  }
  return *this;
}



MscDirectoryInfo::FileDescriptor::FileDescriptor( MscDirectoryInfo * d ,
                                                 MscDirectoryInfo::FileType t ,
                                                 MscString fileName , int p ,
                                                 MscString date ,
                                                 time_t timeSec ,
                                                 int size )
  : myDirectory(d)
  , myFileType(t)
  , myPosition(p)
  , myDate(date)
  , myTime(timeSec)
  , mySize(size)
  , myHasChanged(true)
  , myIsPresent(true)
{
  MscUtl::convertPath( fileName );
  // decompose
  const char * extensionString = 0;
  MscString directory ;
  int version = 0;
  MscUtl::decomposeFilename( fileName , directory , myFileName , version , extensionString );
  // save
  if ( directory.isBlank() == true ) {
    if ( myDirectory != 0 ) {
      directory = myDirectory->getPathName(); 
    }
    else {
      directory = "." ;
    }
  }  
  myFullFileName.printf( "%s/%s" , directory.c_str() , myFileName.c_str() );
}



MscString  MscDirectoryInfo::FileDescriptor::getFileNameWithDate() const
{
  MscString str ;
  str.printf( "%s      (%s)" , myFileName.c_str() , myDate.c_str() );
  return str;
}


MscString  MscDirectoryInfo::FileDescriptor::getString( MscDirectoryInfo::NameType type ) const
{
  switch ( type ) {
  case MscDirectoryInfo::NT_ID       : return getIdName()       ;
  case MscDirectoryInfo::NT_TITLE    : return getTitleName()    ;
  case MscDirectoryInfo::NT_COMBOBOX : return getComboBoxName() ;
  case MscDirectoryInfo::NT_FILENAME : return getFullFileName() ;
  }
  return "undefined" ;
}


MscString  MscDirectoryInfo::FileDescriptor::getIdName() const
{
  MscString name ;
  name.printf( "(%d_%d) " , myDirectory ? myDirectory->getId() : 0 , myPosition );
  return name ;
}


MscString  MscDirectoryInfo::FileDescriptor::getTitleName() const
{
  return myFileName;
}


MscString  MscDirectoryInfo::FileDescriptor::getComboBoxName() const
{
  MscString name = getIdName() ;
  name += myFileName;
  name += "          (" ;
  name += myDate ;
  name += ")"    ;
  return name ;
}


void MscDirectoryInfo::FileDescriptor::myInitialize()
{
  myDirectory    = 0 ;
  myFileType     = MscDirectoryInfo::FT_UNDEFINED ;
  myFileName     = "undefined.txt";
  myFullFileName = "./undefined.txt";
  myDate         = "";
  myTime         = 0 ;
  mySize         = 0 ;
  myPosition     = 0 ;
  myHasChanged   = false ;
  myIsPresent    = false ;
}




//===============================================================
//===============================================================
//===============================================================
//       HELPER CLASS : MscDirectoryInfo . STATIC METHODS 
//===============================================================
//===============================================================
//===============================================================



MscString MscDirectoryInfo::getHomeDirectoryFile( const char * fileName , bool *doesExist )
{
  MscString pathName = MscUtl::homeDirectory();
  MscString file(fileName);
  file.strip();
  if ( file.isBlank() == false ) {
    pathName += "/";
    pathName += file ;
    pathName.strip();
  }
  if ( doesExist != nullptr ) {
    *doesExist = MscUtl::fileExists(pathName);
  }
  return pathName ;  
}



const MscString & MscDirectoryInfo::getRestrictedDirectory()
{
  static const char * METHOD_NAME = "getRestrictedDirectory()" ;
  if ( myRestrictedDirectories.empty() == false ) {
    return *myRestrictedDirectories.begin();
  }
  else {
    static const MscString dirPath("/");
    MscDg::error( CLASS_NAME , METHOD_NAME , "no directory is present. Test with 'hasRestrictedDirectory()' first..." );
    return dirPath ;
  }
}



//===============================================================
//===============================================================
//===============================================================
//       HELPER CLASS : MscDirectoryInfo
//===============================================================
//===============================================================
//===============================================================



MscDirectoryInfo::MscDirectoryInfo( const MscString & directoryName ,
                                  const MscString & filterString  ,
                                  MscDirectoryInfo::FileType fileType )
{
  static const char * METHOD_NAME = "MscDirectoryInfo()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Name '%s' Filter '%s'  FileType %d" ,
               directoryName.c_str() , filterString.c_str() , fileType );

  myInitialize( fileType );
  // populate
  refreshFiles( directoryName , filterString , fileType );
}



MscDirectoryInfo::MscDirectoryInfo( const MscString & directoryName ,
                                  MscDirectoryInfo::FileType fileType )
{
  static const char * METHOD_NAME = "MscDirectoryInfo()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Name '%s' FileType %d" , directoryName.c_str() , fileType );

  myInitialize( fileType );
  // populate
  refreshFiles( directoryName , fileType );
}



MscDirectoryInfo::MscDirectoryInfo( const MscString & directoryName )
{
  static const char * METHOD_NAME = "MscDirectoryInfo()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Session Directory '%s'" , directoryName.c_str() );

  myInitialize( MscDirectoryInfo::PC_SESSION );
  myPathName = directoryName ;
  MscUtl::convertPath( myPathName );
  // populate
  refreshSessionFiles();
}



MscDirectoryInfo::~MscDirectoryInfo()
{
  static const char * METHOD_NAME = "~MscDirectoryInfo()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME );
}



int MscDirectoryInfo::refreshFiles( const MscString & pathName , 
                                   const MscString & filterString  ,
                                   MscDirectoryInfo::FileType fileType )
                                   
{
  const char * METHOD_NAME = "refreshFiles()" ;

  //===================
  // *** DIRECTORY ***
  //===================

  MscString selectedFile;
  // extract directory from the file name
  if ( MscUtl::fileExists(pathName) == true ) {
    selectedFile.setFilePath(pathName) ;
    myPathName = selectedFile.getDirectoryPath();
  }
  // pathname is a directory
  else if ( MscUtl::directoryExists(pathName) == true ) {
    myPathName.setDirectoryPath(pathName) ;
  }
  // directory should exist
  if ( myPathName.isBlank() == true || MscUtl::directoryExists(myPathName) == false ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "new path name: using home directory" );
    myPathName = MscUtl::homeDirectory();
  } 
  // change of directory
  if ( myPathName != pathName ) {
    // should not happen for the session
    if ( fileType == MscDirectoryInfo::PC_SESSION ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "change of session directory" ) ;
    }
  }
  
  // deTypg
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Name '%s' => '%s'  FilterString '%s'" ,
               pathName.c_str() , myPathName.c_str() , filterString.c_str() );

  //===================
  // *** FILE ACCESS **
  // Build new list
  //===================

  // mark all the files as absent (some could have been deleted)
  MscDirectoryInfo::Files::iterator iter ;
  for ( iter=myFileDescriptors.begin() ; iter != myFileDescriptors.end() ; ++iter ) {
    iter->setIsPresent(false) ;
  } 

  // the position of the directory . It analyzes the directory and update the file description .
  int position = 0 ;
  if ( MscDirectoryInfo::myAnalyzeDirectory != 0 ) {
    MscDirectoryInfo::myAnalyzeDirectory( this , myPathName , filterString , fileType , 
                                         myFileDescriptors , position );
  }
  else {
    MscDg::fatal( CLASS_NAME , METHOD_NAME , "'MscDirectoryInfo::myAnalyzeDirectory' must be implemented" );
  }

  // re-order according to the (time) position
  int i , numberOfChanges = 0 ;
  MscDirectoryInfo::Files files ;
  for ( i=1 ; i <= position ; ++i ) {
    for ( iter=myFileDescriptors.begin() ; iter != myFileDescriptors.end() ; ++iter ) {
      if ( iter->getPosition() == i && iter->getIsPresent() == true ) {
        files.push_back(*iter);
        if ( iter->getHasChanged() == true ) {
          numberOfChanges += 1 ;
        }
        break;
      }
    }
  }
  myFileDescriptors = files;

  // selected file
  if ( myFileDescriptors.empty() == true ) {
    myDefaultFileDescriptor = -1 ;
  }
  else if ( selectedFile.isEmpty() == true ) {
    myDefaultFileDescriptor =  0 ;
  }
  else {
    myDefaultFileDescriptor =  0 ;
    for ( i=0 ; i < myFileDescriptors.size() ; ++i ) {
      if ( selectedFile == myFileDescriptors[i].getFileName() ) {
        myDefaultFileDescriptor = i ;
        break;
      }
    }
  }

  return numberOfChanges ;
}



int MscDirectoryInfo::refreshFiles( const MscString & pathName , 
                                   MscDirectoryInfo::FileType fileType )
{
  static const char * METHOD_NAME = "refreshFiles()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Directory '%s' Type %d" , pathName.c_str() , fileType );

  MscString filterString("*");
  switch ( fileType ) {
  case MscDirectoryInfo::PC_PARAMETER :
    filterString = "*.pm";
    break ;
  case MscDirectoryInfo::PC_SESSION :
    filterString = "*.ses";
    break ;
  case MscDirectoryInfo::PC_FRAME :
    filterString = "*.fcf";
    break ;
  case MscDirectoryInfo::PC_VELOCITY :
    filterString = "*.vel";
    break;
  default: 
    MscDg::error( CLASS_NAME , METHOD_NAME , "Undefined value %d" , fileType );
  }
  return refreshFiles( pathName , filterString , fileType );
}



const MscDirectoryInfo::FileDescriptor * MscDirectoryInfo::getFileDescriptor( const MscString & name ,
                                                                            MscDirectoryInfo::NameType type ) const
{
  static const char * METHOD_NAME = "getFileDescriptor()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Directory '%s' Type %d" , name.c_str() , type );

  const MscDirectoryInfo::Files & descriptors = getFileDescriptors() ;
  MscDirectoryInfo::Files::const_iterator decrIter ;
  for ( decrIter=descriptors.begin() ; decrIter != descriptors.end() ; ++decrIter ) {
    if ( decrIter->getFileType() != MscDirectoryInfo::PC_SESSION ) continue ;
    // Fix: the id name returns with a space so it needs to get stripped
    // in order to make comparison with input name
    MscString inputName = name;
    if ( inputName.strip() == decrIter->getString(type).strip() ) {
      return  &(*decrIter) ;
    }
  }
  MscDg::error( CLASS_NAME , METHOD_NAME , "File '%s' not present" , name.c_str() );
  return 0 ;
}



const MscDirectoryInfo::FileDescriptor * MscDirectoryInfo::getFileDescriptor( int i ) const
{
  static const char * METHOD_NAME = "getFileDescriptor()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Index %d" , i );

  if ( 0 <= i && i < (int)myFileDescriptors.size() ) {
    return & myFileDescriptors[i];
  }
  else {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Index %d not found" , i );
    return 0 ;
  }
}



void MscDirectoryInfo::myInitialize( MscDirectoryInfo::FileType fileType )
{
  static const char * METHOD_NAME = "myInitialize()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Type %d" , fileType );

  myDefaultFileDescriptor = -1 ;
  if ( fileType == MscDirectoryInfo::PC_SESSION ) {
    MscDirectoryInfo::myLastSessionIdNumber += 1 ;
    myId = MscDirectoryInfo::myLastSessionIdNumber ;
  }
  else {
    myId = 0 ;
  }
}



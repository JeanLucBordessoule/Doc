#ifndef MSC_DATA_HOLDER_HPP
#define MSC_DATA_HOLDER_HPP

// C++
#include <memory>
#include <set>

// Qt
#include <QObject>

#include "MscMessageProvider.hpp"
#include "MscString.hpp"
#include "MscUtl.hpp"

// enables the read/write of the parameters in a file.
class MscDataAccess ;



/** **************************************
 *  **************************************
 *  DATA ; storage of ONE parameter.
 *  **************************************
 ** *************************************/

class MscDataItem {
public:
  static const char * CLASS_NAME ;
  
  /** ------------------------------------
  * DataType : type of the data storage.
  * see 'TypeEnumeration' for the values of each enumeration.
  * ------------------------------------ */
  enum DataType {
    DT_UNDEFINED  = -1 ,
    // START FLAG : MUST be provided at the START
    DT_START_FLAG = 0  ,
    // NO OPERATION: used for flags that have no meaning in current release
    DT_NOOP     , // no value after this flag
    // DEFAULT VALUES
    DT_BOOL     , // boolean value
    DT_BOOL_I   , // boolean value written as int.
    DT_INT      , // int, can be enum (if so virtual method can be used to customize it)
    DT_FLOAT    ,
    DT_DOUBLE   ,
    DT_STRING   ,
    //*****************************//
    // COLOURS, COLOURMAPS (enum) //
    //*****************************//
    DT_INT_Color           ,  DT_INT_FIRST = DT_INT_Color ,
    DT_INT_ColorShort      ,
    DT_INT_Colormap        ,
    //*****************************//
    // DRAWING PARAMETERS      //
    //*****************************//
    // Attribute types for drawing line, text or font.
    DT_INT_LineStyle       ,
    DT_INT_LineStyleShort  ,
    DT_INT_LineEndCap      ,
    DT_INT_LineJoin        ,
    DT_INT_DimUnit         ,
    DT_INT_MarkerStyle     ,
    DT_INT_MarkerStyleShort,
    DT_INT_FillStyle       ,
    DT_INT_FontWeight      ,
    DT_INT_FontSize        ,
    DT_INT_FontSlant       ,
    DT_INT_FontAttribute   ,
    DT_INT_FontFamily      ,
    DT_INT_FontTechnology  ,
    DT_INT_FontSizeMode    ,
    // Alignment, Order of graphics layers
    DT_INT_Alignment       ,
    DT_INT_PointTag        ,
    DT_INT_Order           ,
    // Float array (e.g.: seismic image).
    DT_INT_TraceType       ,
    DT_INT_SampleUnits     ,
    DT_INT_SeismicInterpolationType ,
    DT_INT_SeismicClipType ,
    DT_INT_SeismicPlotType ,
    DT_INT_SeismicNormMode ,
    //*****************************//
    // IMAGE , PRINTER         //
    //*****************************//
    DT_INT_ImageOutput     ,
    DT_INT_ImageDepth      ,
    DT_INT_ImageFormat     ,
    DT_INT_ImageScaling    ,
    DT_INT_PrinterColorMode   ,
    DT_INT_PrinterOrientation ,
    DT_INT_PrinterResolution  ,
    //*************************//
    // FONT , AXIS , OPTIONS   //
    //*************************//
    DT_INT_FontType        ,
    DT_INT_AxisType        ,
    DT_INT_CursorMode      ,
    DT_INT_SoundMode       ,
    DT_INT_DeleteMode      ,
    //*************************//
    // OTHERS enumerations     //
    //*************************//
    DT_INT_BUILDIN_LAST    = DT_INT_DeleteMode ,
    // allow the application to add some values.
    DT_INT_DEFINED_FIRST   = DT_INT_BUILDIN_LAST  + 1 ,
    DT_INT_DEFINED_LAST    = DT_INT_DEFINED_FIRST + 100 ,
    // enumeration values are between 'DT_INT_FIRST' and 'DT_INT_LAST'
    DT_INT_LAST            = DT_INT_DEFINED_LAST  ,
    // END FLAG . this flag MUST BE PROVIDED AT THE END  (the flags after are ignored).
    DT_END_FLAG            = 999999
  };
  static bool getTypeIsEnum( int dataType )
  { return ( DT_INT_FIRST <= dataType && dataType <= DT_INT_LAST ); }
  /** ------------------------------------------------------------------------
   * Definition of the data (usely flags and default values for a parameter model)
   * Copy of these values are made in 'DefaultValue'
   * ------------------------------------------------------------------------ */
  enum  {
    ID_UNDEFINED = -999999
  };
  typedef struct {
    int          myId       ; // unique identification number . MUST be different from 'ID_UNDEFINED'
    const char * myFlag     ; // flag used to identify the data & start-end flags. MUST NOT be 0.
    DataType     myDataType ; // type of value being dealt with
    // values
    int          myInt      ; // used by DT_BOOL, DT_BOOL_I, DT_INT : default value
    float        myFloat    ; // used by DT_FLOAT  : default value
    double       myDouble   ; // used by DT_DOUBLE : default value
    const char * myString   ; // used by DT_STRING : default value
    const char * myComment  ;
  } CreateInfo ;

  MscDataItem( const CreateInfo * def = 0 )
  {
    myId            = def ? def->myId       : ID_UNDEFINED ;
    myFlag          = def ? def->myFlag     : 0            ;
    myDataType      = def ? def->myDataType : DT_NOOP      ;
    myComment       = def ? def->myComment  : ""           ;
    // default value
    myDefaultInt    = def ? def->myInt      : 0 ;
    myDefaultFloat  = def ? def->myFloat    : 0 ;
    myDefaultDouble = def ? def->myDouble   : 0 ;
    myDefaultString = def ? def->myString   : 0 ;
    // user value
    myInt           = myDefaultInt    ;
    myFloat         = myDefaultFloat  ;
    myDouble        = myDefaultDouble ;
    myString        = myDefaultString ;
  }
  MscDataItem( const MscDataItem & model )
  {
    *this = model;
  }
  const MscDataItem & operator= ( const MscDataItem & model )
  {
    if ( this != &model ) {
      myId            = model.myId            ;
      myFlag          = model.myFlag          ;
      myDataType      = model.myDataType      ;
      myComment       = model.myComment       ;
      // default value
      myDefaultInt    = model.myDefaultInt    ;
      myDefaultFloat  = model.myDefaultFloat  ;
      myDefaultDouble = model.myDefaultDouble ;
      myDefaultString = model.myDefaultString ;
      // user value
      myInt           = model.myInt           ;
      myFloat         = model.myFloat         ;
      myDouble        = model.myDouble        ;
      myString        = model.myString        ;
    }
    return *this;
  }
  /** compare the type of data and value are the same */
  bool operator== ( const MscDataItem & model )
  {
    if ( this == &model ) { return true; }
    return ( myId       == model.myId       && // not sure about it.
             myDataType == model.myDataType &&
             myInt      == model.myInt      &&
             myFloat    == model.myFloat    &&
             myDouble   == model.myDouble   &&
             myString   == model.myString   );
  }
  bool operator!= ( const MscDataItem & model )
  {
    return ( *this == model ) ? false : true ;
  }
  ~MscDataItem()
  {
  }
  /** get members */
  int             getId()         const { return myId      ; }
  const MscString & getFlag()     const { return myFlag    ; }
  bool            getTypeIsEnum() const
  { return ( DT_INT_FIRST <= myDataType && myDataType <= DT_INT_LAST ); }
  DataType        getDataType() const
  { return getTypeIsEnum() ? DT_INT : myDataType ; } // enum are seen as 'DT_INT'
  DataType        getRealType() const { return myDataType  ; }
  const MscString & getComment()  const { return myComment   ; }
  /** customized (set both defaults and user values) */
  void            setComment     ( const MscString & value ) { myComment = value ; }
  void            customizeBool  ( bool   value ) { myInt    = myDefaultInt    = int(value); }
  void            customizeInt   ( int    value ) { myInt    = myDefaultInt    = value ;     }
  void            customizeFloat ( float  value ) { myFloat  = myDefaultFloat  = value ;     }
  void            customizeDouble( double value ) { myDouble = myDefaultDouble = value ;     }
  void            customizeString( const MscString & value ) { myString = myDefaultString = value ; }
  /** restore default values */
  bool            restoreDefaultValues()
  {
    if ( myInt    != myDefaultInt    ||
         myFloat  != myDefaultFloat  ||
         myDouble != myDefaultDouble ||
         myString != myDefaultString ) {
      myInt    = myDefaultInt    ;
      myFloat  = myDefaultFloat  ;
      myDouble = myDefaultDouble ;
      myString = myDefaultString ;
      return true  ;
    }
    else {
      return false ;
    }
  }
  // data
  bool            getBool( bool *hasChanged=0 )   const
  {
    if ( hasChanged != 0 ) { *hasChanged = (myInt != myDefaultInt); }
    return (myInt != 0);
  }
  int             getInt( bool *hasChanged=0 )    const
  {
    if ( hasChanged != 0 ) { *hasChanged = (myInt != myDefaultInt); }
    return myInt       ;
  }
  float           getFloat( bool *hasChanged=0 )  const
  {
    if ( hasChanged != 0 ) { *hasChanged = (myFloat != myDefaultFloat); }
    return myFloat     ;
  }
  double          getDouble( bool *hasChanged=0 ) const
  {
    if ( hasChanged != 0 ) { *hasChanged = (myDouble != myDefaultDouble); }
    return myDouble    ;
  }
  const MscString & getString( bool *hasChanged=0 ) const
  {
    if ( hasChanged != 0 ) { *hasChanged = (myString != myDefaultString); }
    return myString    ;
  }
  // set members
  bool setBool( bool value )
  {
    if ( myInt != (int)value ) {
      myInt = (int)value;
      return true;
    }
    else {
      return false;
    }
  }
  bool setInt( int value )
  {
    if ( myInt != value ) {
      myInt = value;
      return true;
    }
    else {
      return false;
    }
  }
  bool setInt( float value )
  {
    return setInt( MscUtl::toInt(value) );
  }
  bool setFloat( float value )
  {
    if ( myFloat != value ) {
      myFloat = value;
      return true;
    }
    else {
      return false;
    }
  }
  bool setDouble( double value )
  {
    if ( myDouble != value ) {
      myDouble = value;
      return true;
    }
    else {
      return false;
    }
  }
  bool setString( const MscString & value )
  {
    if ( myString != value ) {
      myString = value;
      return true;
    }
    else {
      return false;
    }
  }
  // tracking the changes
  bool needsToBeSaved() const
  {
    return ( myInt    != myDefaultInt    ||
             myFloat  != myDefaultFloat  ||
             myDouble != myDefaultDouble ||
             myString != myDefaultString );
  }
private :
  /** characteristics */
  int          myId            ; // unique identification number . MUST be different from 'ID_UNDEFINED'
  MscString    myFlag          ; // flag used to identify the data & start-end flags. MUST NOT be 0.
  DataType     myDataType      ; // type of value being dealt with
  MscString    myComment       ; // comment about this value
  /** default values */
  int          myDefaultInt    ; // used by DT_BOOL, DT_BOOL_I, DT_INT : default value
  float        myDefaultFloat  ; // used by DT_FLOAT  : default value
  double       myDefaultDouble ; // used by DT_DOUBLE : default value
  MscString    myDefaultString ; // used by DT_STRING : default value
  /** user value */
  int          myInt           ;
  float        myFloat         ;
  double       myDouble        ;
  MscString    myString        ;
};







/** Storage of SEVERAL parameters from/to a PARAMETER MODEL (PM) file.
*
* Class 'MscDataTeam' for the recursive storage  of bools, ints, floats, doubles, strings,
* generally for the parameters.
*
* An unique 'id' (identification number) defines the item (e.g.: an 'int' value).
* When a change occurs, the sent message is the 'set' of the 'id's where a change occurred.
* 
* The derived clas provides the 'CreateInfos' that MUST NOT be changed 
* (especially the character strings) else the results are unexpected.
*
* The derived class can customize the storage of the values by reimplementing
* the 'derivedSetBool' , 'derivedSetInt' , ... virtual methods. 
*
* Persistence is granted thanks to the 'MscDataAccess' class.
* Only the values that differ from the default value defined in the 'CreateInfo'
* are saved.
*
*/

class MscDataTeam : public QObject
{
  Q_OBJECT // required as it emits a signal.
public :
  static const char * CLASS_NAME   ;

  /** flag used for the read / write */
  static const char * STRING_SPACE ; // separator must be the same for the read & write
  static const char * READ_SPACE   ; // " " . Could be 0
  static const char * WRITE_SPACE  ; // " "   Could be "    "
  static const char * LAST_CALL    ; // flag to inform the derived class

  /** **************************************
   *  ClassType: it enables to make a safe dynamic_cast.
   * It's CT_<ClassName>
   * Yes RTTI could be used as well...
   ** *************************************/

  enum ClassType {
    // base class
    CT_MscDataHolder         ,
    // Velocity::resources
    CT_TypImagePM            ,
    CT_TypLinePM             ,
    CT_TypFontPM             ,
    CT_TypAxisPM             ,
    CT_TypColormapPM         ,
    CT_TypMinMaxPM           ,
    CT_TypOptionsPM          ,
    CT_TypAppPM              ,
    // layers
    CT_TypDrawingLayerPM     ,
    CT_TypVelocityLayerPM    ,
    CT_TypHorizonLayerPM     ,
    CT_TypGraphicsPM         ,
    CT_TypSemblanceLayersPM  ,
    CT_TypVelocityTablePM    ,
    CT_TypOverlayLayersPM    ,
    CT_TypLayerManagerPM     ,
    // frame & configuration
    CT_TypFrameConfiguration ,
    CT_TypFrameConfigurationPM ,
    CT_TypViewConfiguration
  };
  
  /** Send the set of 'ids' that have changed (stored value is changed) */
  typedef struct {
    MscDataTeam * myDataHolder ;
    std::set<int>  mySignals    ;
  } Changes ;
protected:
  Changes myChanges ;
signals:
  void signalChangedSet( std::set<int> * );
  void signalChangedHolder( Changes * );

public :
  /** How to copy */
  enum CopyType {
    COPY_APPLICATION = 1 , /** copy the parameter that are shared */
    COPY_VIEW        = 2 , /** copy the parameters specific to this view */
    COPY_ALL         = 3   /** copy both . REMARK: 1 + 2 = 3 so KEEP the values */
  } ;
  
  /** Default Constructor */
  MscDataTeam( ClassType classType = CT_MscDataHolder ,
                 int numberOfBp = 0 , MscDataItem::CreateInfo * bpArray = 0 ,
                 const char *startFlag = 0 , const char *endFlag = 0 ,
                 int subClass = 0 , const char * comment = 0 );
  
  /** copy constructor. the children aren't copied as the subclass might defer.
   * Use the derived class copy to implement the copy of the children.
   */
  MscDataTeam( const MscDataTeam & ) ;

  /** how to copy the values . Reimplemented */
  virtual bool copy( const MscDataTeam  &  ,
                     MscDataTeam::CopyType = COPY_ALL ,
                     const std::set<int>   * = nullptr   ,
                     bool doSendSignals      = true      );

  /** copy components but not the children */
  void copyDataHolder( const MscDataTeam& );

  const MscDataTeam & operator= ( const MscDataTeam & ) ;
  bool operator== ( const MscDataTeam & ) ;
  bool operator!= ( const MscDataTeam & ) ;

  /** Destructor . it also destroy the tree. */
  virtual ~MscDataTeam() ;

  /** get the start / end flags (it should exist) . Datype is 'DT_START_FLAG' and 'DT_END_FLAG' */
  const MscString     & getStartFlag() const { return myStartFlag ; }
  const MscString     & getEndFlag  () const { return myEndFlag   ; }

  /** static method to get the start flag . Simply returns the flag for 'DT_START_FLAG'
  * 0 else. */
  static const char * getClassStartFlag( int numberOfBp , MscDataItem::CreateInfo * bpArray  ) ;

  /** the type of data that is associated with the id */
  MscDataItem::DataType getDataType( int , bool * hasBeenFound=0  );
  MscDataItem::DataType getRealType( int , bool * hasBeenFound=0  );

  /** set / get the identification number . It might be used to identify the class type */
  ClassType           getClassType() const { return myClassType; }
  static const char * getClassStr( ClassType );
  const char        * getClassStr()  const { return getClassStr(myClassType); }
  void                setSubClass( int i ) { mySubClass = i ; }
  int                 getSubClass() const  { return mySubClass ; }
  void                setUserId( int i )   { setSubClass(i); }       /** deprecated */
  int                 getUserId() const    { return getSubClass(); } /** deprecated */
  const MscString   & getComment() const   { return myComment ; }
  void                setComment ( const MscString & value ) { myComment = value ; }
  /** active state. Is this part active ? */
  void                setIsActive( bool i ) { myIsActive = i ; }
  bool                getIsActive() const { return myIsActive ; }
  /** see if there is something to save (a value differs from the default) */
  bool                needsToBeSaved() ;
  /** enable / disable the write ... By default, it's enabled */
  void                setIsWriteEnabled( bool b ) { myIsWriteEnabled = b ; }

  /** data access  & customize the read / write values */
  const MscDataItem  * getDataPtr( int id ) const ;
  MscDataItem        * getDataPtr( int id ) ;
  MscDataItem        * getDataPtr( const MscString & cc ) ;
  MscDataItem        & getData( int id ) ;
  MscDataItem        & getData( const MscString & cc ) ;

  /** children management . Index is (-1) if not found or added at the end */
  typedef std::vector< std::shared_ptr< MscDataTeam > > ChildrenMap ;

  /** ad a child */
  void                addChild( std::shared_ptr< MscDataTeam > & );
  void                addChild( MscDataTeam * d ) { std::shared_ptr< MscDataTeam > dh(d); addChild(dh); }
  void                addChildAtIndex( MscDataTeam * d , int indexOfChild  );
  /** remove a child. Return the removed child */
  std::shared_ptr< MscDataTeam > removeChild( int indexOfChild );
  std::shared_ptr< MscDataTeam > removeChild( std::shared_ptr< MscDataTeam > c ) { return removeChild( getIndexOfChild(c) ); }
  /** find out if a child exists */
  bool                hasChild( int pmType , std::shared_ptr< MscDataTeam > & , bool oneGenerationOnly = true ) const ;
  bool                hasChild( int pmType ) { std::shared_ptr< MscDataTeam > c ; return hasChild(pmType,c,true); }
  /** children management */
  ChildrenMap       & getChildren() { return myChildren ; } // 08/01/2016: was not a reference ...
  const ChildrenMap & getChildren() const { return myChildren ; }
  void                setChildren( const ChildrenMap & c ) { myChildren = c ; } // change of genome
  void                clearChildren() { myChildren.clear(); } // irresponsible father
  int                 getNumberOfChildren() const { return myChildren.size(); }

  /** set the lone child ("little emperor" syndrome) */
  void                    setChild( MscDataTeam * c ) { clearChildren(); addChild(c); }
  /** get the first child */
  std::shared_ptr< MscDataTeam > getChild() const ;
  /** get the first of a given sub class , or get the one at a given index */
  std::shared_ptr< MscDataTeam > getChild( MscDataTeam::ClassType );
  std::shared_ptr< MscDataTeam > getChild( MscDataTeam::ClassType , int subClass , bool firstGenerationOnly = true );
  std::shared_ptr< MscDataTeam > getChildAtIndex( int indexOfTheChild );
  int                              getIndexOfChild( std::shared_ptr< MscDataTeam > & c );

private :

  /** check start & end flags are present */
  void                myCheckFlags();

  /** free the owned memory . Delete the OWNED children (the ones created by this class) */
  void                myFreeMemory() ;

  /** id number defined to the user (application specific). State */
  ClassType           myClassType      ;
  int                 mySubClass       ;
  bool                myIsActive       ;
  bool                myIsWriteEnabled ; // used to enable / disable the write
  MscString           myComment        ;

  /** provided default values */
  MscString           myStartFlag      ; // in fact the string of 'DT_START_FLAG'
  MscString           myEndFlag        ; // string of 'DT_END_FLAG' or generated from 'DT_START_FLAG'
  int                 myEpitome        ; // avoid to present some parameters in the GUI

  /** STORAGE OF THE VALUES */
  std::vector<MscDataItem>  myData     ;

protected :

  /** Internal storage of the values . NO COPIED AS THE CLASS MIGHT DEFER !! */
  ChildrenMap         myChildren  ;


  /** ---------------------------------- */
  /** set the values.                    */
  /** ---------------------------------- */

public :

  /** restore the default values . Returns the ids that have changed .
   * Add to signal (call 'mySendSignal(id)') if required */
  std::set<int> restoreDefaultValues( bool sendMessage = true );
  
  /** 'set' methods return 'true' if the value has changed.
  * The implementation is very similar for all of them (except the storage in tye map).
  **/
  bool setBool  ( int id , bool              , bool sendMessage = true ) ; // stores in 'myInts' (bool => int)
  bool setInt   ( int id , int               , bool sendMessage = true ) ; // stores in 'myInts'
  bool setInt   ( int id , float value       , bool sendMessage = true ) { return setInt(id,MscUtl::toInt(value),sendMessage); }
  bool setFloat ( int id , float             , bool sendMessage = true ) ; // stores in 'myFloats'
  bool setDouble( int id , double            , bool sendMessage = true ) ; // stores in 'myDoubles'
  bool setString( int id , const MscString & , bool sendMessage = true ) ; // stores in 'myStrings'
  
protected :

  /** the virtual methods of the derived class is called first .
  * If implemented, it will do the data storage itself .
  * and the base class does not treat the value.
  *
  * Usage: treat the values of an enumeration for instance.
  *
  * it return 'true' if the derived class has treated the value.
  * The derived class is responsible for the storage of the data in
  * the appropriate map.
  */

  virtual bool derivedSetBool  ( int id , bool            , bool & valueHasChanged ) { return false ; }
  virtual bool derivedSetInt   ( int id , int             , bool & valueHasChanged ) { return false ; }
  virtual bool derivedSetFloat ( int id , float           , bool & valueHasChanged ) { return false ; }
  virtual bool derivedSetDouble( int id , double          , bool & valueHasChanged ) { return false ; }
  virtual bool derivedSetString( int id , const MscString & , bool & valueHasChanged ) { return false ; }
  
  /** ---------------------------------- */
  /** get the values.                    */
  /** ---------------------------------- */
  
public :

  MscDataItem::DataType getDataType( int id , bool *isDefined=0 ) const ;
  MscDataItem::DataType getRealType( int id , bool *isDefined=0 ) const ;
  bool                  getBool    ( int id , bool *isDefined=0 ) const ;
  int                   getInt     ( int id , bool *isDefined=0 ) const ;
  float                 getFloat   ( int id , bool *isDefined=0 ) const ;
  double                getDouble  ( int id , bool *isDefined=0 ) const ;
  const MscString     & getString  ( int id , bool *isDefined=0 ) const ;

  /** ---------------------------------- */
  /** read / write the data              */
  /** ---------------------------------- */

public :

  /** provide the vehicle for the data input / output */
  bool            dataAccess( MscDataAccess & ) ;

  /** convenient functions
  * (a 'MscDataAccess' class is created on the fly and the above method is used) */
  bool            dataAccess( const std::shared_ptr< std::ifstream > & , MscMessageProvider::Listener * = 0 , const char * fileName = 0 ) ; // DA_READ_ASCII
  bool            dataAccess( const std::shared_ptr< std::ofstream > & , MscMessageProvider::Listener * = 0 , const char * fileName = 0 ) ; // DA_WRITE_ASCII

protected :

  /** customize the derived class .
  * Used when a flag 'cc' is not recognized by the base class.
  *
  * Returns 'true' if the base class has dealt successfully with the id. */
  virtual bool    derivedDataAccess( MscDataAccess & , MscString & , const MscDataItem * = 0 ) { return false ; }
  /** "derivedNeedToBeSaved" returns true if there is something to save */
  virtual bool    derivedNeedsToBeSaved() { return true ; }

  /** ---------------------------------- */
  /** message sending to the application */
  /** ---------------------------------- */
  
public :

  /** accumulate all the signals (changes) that can be done in this class
  * Can be used to force the update of a GUI.
  * It simply creates the list of IDs if the items.
  */
  std::set<int>    getFullSignalSet() const ;
  void             sendAllSignals() { mySignals=getFullSignalSet() ; sendSignals() ; }

  /** accumulate the messages in 'mySignals' when a value has changed
  * if 'myAllowSendingSignals' is 'true' , 'sendSignals()' is called .
  *
  * When a value (with 'id') is  changed, 'mySendSignal(id)' is called
  * and the 'id' is added to 'mySignals' .
  *
  * If 'myAllowSendingSignals' is 'true', 'sendSignals()' is called and
  * the 'ChangedSignalsSet' signal is emitted (Send).
  *
  * 'saveSignals(false)' will flush the existiscopyng signals.
  * Calling 'sendSignals()' directly does the same .
  */
  void                  saveSignals( bool b=true) ;
  void                  addSignal( int id ) { mySignals.insert( id ) ; }
  std::set<int>         discartSignals()          ;
  void                  sendSignals()             ;
  const std::set<int> & getSignalSet() const      { return mySignals ; }
  const std::set<int> & getSentSignals() const    { return mySentSignals ; }

  /** is the message in the list ? . Might want to count the number of changes. */
  static bool hasMessage( std::set<int> * msg , int m ) { return msg ? (msg->find(m) != msg->end()) : true; }
  static bool hasMessage( std::set<int> * msg , int m , int & n ) { bool b=hasMessage(msg,m); if (b) n+=1 ; return b; }

  /** utilities to save the sent signals
   * setSentSignal  : unique value
   * setSentSignals : set of values stored in an int, a list or a set */
  void             setSentSignal ( const int              );
  void             setSentSignals( const int              );
  void             setSentSignals( const std::list<int> & );
  void             setSentSignals( const std::set <int> & );
  /** ---------------------------------- */
  /** send a specific signal             */
  /** ---------------------------------- */
  void             sendSignals( std::set<int> * ) ;
  void             sendSignals( int s ) { std::set<int> sg ; sg.insert(s) ; sendSignals(&sg) ; }

private :
  bool             myAllowSendingSignals  ;
  /** signals that have been accumulated and available to be sent */
  std::set< int >  mySignals              ;
  /** 'mySendSignal' add the signal to 'mySignals' */
  void             mySendSignal( int id ) ;
  
protected :

  /** signals that have been sent the last time (or have been discarded) */
  std::set< int >  mySentSignals          ;

  /** the virtual methods of the derived class is called first .
  * If implemented, it can modify the behaviour of the 'mySendSignal' method,
  * If it returns 'true' no action is done by 'mySendSignal'.
  */
  virtual bool derivedSendSignal( int id ) { return false ; }

  /** the virtual methods of the derived class is called first .
   * The derived class could mofiy the set of items.
   * If it returns 'true' no action is done by 'sendSignals'.
   * else if the item's set is not empty.
   */
  virtual bool derivedSendSignals( std::set<int> & sentSignals ) { return false ; }

  /** ---------------------------------- */
  /** reference PM                       */
  /** ---------------------------------- */

protected :

  /** is currently copying it ? (avoid recursice calls )*/
  bool         myIsCopyingReferencePM ;

} ;





/** Tell the caller that "Apply" has been pressed (in a dialog box) **/

class MscInterface {
public : 
  MscInterface() {}
  virtual ~MscInterface() {}
  virtual void apply( MscDataTeam * ) = 0 ;
} ;


#endif




















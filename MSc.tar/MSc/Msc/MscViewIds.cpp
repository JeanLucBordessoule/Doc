/**
 * Convertion Enumeration <=> Character String for the Ids of the Views.
 */

#include "MscString.hpp"
#include "MscViewIds.hpp"


/**
 * Storage of the values
 */


static struct {
  MscViewIds::ViewType myValue  ;
  const char *            myString ;
} ENUM_VALUES[] = {
  { MscViewIds::UNDEFINED         , "UNDEFINED"         } ,
  { MscViewIds::MAIN              , "MAIN"              } ,
  { MscViewIds::MAP               , "MAP"               } ,
  { MscViewIds::VELOCITY_TABLE    , "VELOCITY_TABLE"    } ,
  { MscViewIds::SEMBLANCE         , "SEMBLANCE"         } ,
  { MscViewIds::GATHER            , "GATHER"            } ,
  { MscViewIds::STACK             , "STACK"             } ,
  { MscViewIds::VELOCITY_GRAPH    , "VELOCITY_GRAPH"    } ,
  { MscViewIds::VTKVIEW           , "VTKVIEW"           } ,
  { MscViewIds::TEAM_FORM         , "TEAM_FORM"         } 
};
static const int NUMBER_ENUM_VALUES = sizeof(ENUM_VALUES) / sizeof(ENUM_VALUES[0]) ;


const char * MscViewIds::getFlag( int value )
{
  for ( int i=0 ; i < NUMBER_ENUM_VALUES ; ++i ) {
    if ( ENUM_VALUES[i].myValue == value ) {
      return ENUM_VALUES[i].myString ;
    }
  }
  return ENUM_VALUES[0].myString ;
}



MscViewIds::ViewType MscViewIds::getValue( const MscString & str )
{
  for ( int i=0 ; i < NUMBER_ENUM_VALUES ; ++i ) {
    if ( str == ENUM_VALUES[i].myString ) {
      return ENUM_VALUES[i].myValue ;
    }
  }
  return ENUM_VALUES[0].myValue ;
}








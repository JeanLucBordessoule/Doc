#include "MscString.hpp"


MscString::MscString( const char * , bool )
{
}


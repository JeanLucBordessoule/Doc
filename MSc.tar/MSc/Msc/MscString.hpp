#ifndef MSC_STRING_HPP
#define MSC_STRING_HPP

#include <cstring>
#include <string>


class MscString : public std::string
{
public :
  enum { ERROR=-1 };
  MscString( const char * = nullptr , bool isFormat=false );
  void    setFilePath( const MscString & );
  void    setDirectoryPath( const MscString & );
  MscString getDirectoryPath() const ;
  MscString getExtension( bool toLowerCase=false ) const ;
  MscString get( int firstIndex , int lastIndex ) const;
  int     getIndexOfLastToken( char token ) const ;
  //int     splitAtLastToken( MscString & beforeToken , MscString & afterToken , MscString & token ) const ;
  int     splitAtLastToken( MscString & beforeToken , MscString & afterToken , char token ) const ;
  int     search( const char * flag ); // return index of start of flag. ERROR if not found.
  int     replace( char from , char to );
  // MscString file ; // (void)selectedFile.splitAtLastToken( myPathName , file , "/" );
  //const MscString & operator= ( const char [] );
  //MscUtl::reformatInt64(vformat);
  bool   isEmpty() const { return empty(); }
  bool   isBlank() const { return empty(); }
  int    getSize() const ; // get length.
  const MscString & strip( bool eraseIfEmptyString = false );
  const MscString & removeEndSlash(); // Remove directory final '/' or '\\'
  const MscString & stripForPath( bool removeEndSlash=true ); // path with '/' and no '\\'. Remove directory final '/'.
  bool   truncate( int newLength );
  void   toLowerCase();
  MscString& printf(const char *format,...);
  int    readi();
  float  readf();
  double readd();
  bool   isInteger();
};


#endif

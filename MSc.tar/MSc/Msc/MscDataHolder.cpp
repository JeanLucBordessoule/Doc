#include "MscDataHolder.hpp"

#include "MscString.hpp"
#include "MscDataAccess.hpp"
#include "MscDebug.hpp"
#include "MscUtl.hpp"


// MUST keep the same for the write/read of a string (else spaces are added or removed)
const char * MscDataTeam::STRING_SPACE = " " ;

// minimum space required for reading. ISSUE: it has its limitation. 
// Anyway spaces are ignored when reasding a word. So it could be turned to 0.
const char * MscDataTeam::READ_SPACE   = " " ;

// Space used when writting: between a flag and a value. Could be turned to any space.
const char * MscDataTeam::WRITE_SPACE  = " " ;

// Last call
const char * MscDataTeam::LAST_CALL    = "Last call before closing the file." ;
const char * MscDataTeam::CLASS_NAME   = "MscDataTeam" ;
const char * MscDataItem::CLASS_NAME   = "MscDataItem"   ;




MscDataTeam::MscDataTeam(  MscDataTeam::ClassType classType ,
                             int n , MscDataItem::CreateInfo * bp ,
                             const char *startFlag , const char *endFlag , 
                             int subClass , const char * comment )
  : myClassType( classType )
  , mySubClass ( subClass  )
  , myStartFlag( startFlag )
  , myEpitome  ( 0         )
  , myComment  ( comment   )
  , myEndFlag  ( endFlag   )
  , myIsActive ( true      )
  , myIsWriteEnabled( true )
  , myIsCopyingReferencePM( false )
{
  MscDg::trace( CLASS_NAME , "MscDataTeam()" , "ClassType:%d" , myClassType );
  int numberOfCreateInfos = ( (bp != 0 && n > 0) ? n : 0 ) ;
  for ( int i=0 ; i < numberOfCreateInfos ; ++i ) {
    myData.push_back( MscDataItem( &bp[i] ) );
    // use the comment and epitome
    if ( bp[i].myDataType == MscDataItem::DT_START_FLAG ) {
      myEpitome = bp[i].myInt ;
      if ( myComment.isEmpty() == true ) {
        myComment = bp[i].myComment ;
      }
    }
  }
  // check the flags
  myCheckFlags() ;
}



MscDataTeam::MscDataTeam( const MscDataTeam & model )
: myClassType( model.myClassType )
, mySubClass ( model.mySubClass  )
, myIsActive ( model.myIsActive  )
, myIsWriteEnabled( true ) // allow write by default . if needed, set the flag before the write
, myStartFlag( model.myStartFlag )
, myEpitome  ( model.myEpitome   )
, myComment  ( model.myComment   )
, myEndFlag  ( model.myEndFlag   )
, myData     ( model.myData      )
, myIsCopyingReferencePM( false )
{
  MscDg::trace( CLASS_NAME , "MscDataTeam()" , "Copy. ClassType:%d" , myClassType );
  // check the flags
  myCheckFlags();
}



bool MscDataTeam::copy( const MscDataTeam & model , MscDataTeam::CopyType cp ,
                          const std::set<int> * dataIds , bool doSendSignals )
{
  MscDg::trace( CLASS_NAME , "copy()" , "Class:%d SubClass:%d %s: not implemented" ,
               myClassType , mySubClass , myComment.c_str() );
  if ( cp == MscDataTeam::COPY_ALL && dataIds == 0 ) {
    copyDataHolder( model );
  }
  return false ; 
}


void MscDataTeam::copyDataHolder( const MscDataTeam & model )
{
  // copy the id number defined by the user 
  myClassType      = model.myClassType ;
  mySubClass       = model.mySubClass  ;
  myIsActive       = model.myIsActive  ;
  myIsWriteEnabled = true ; // leave it enabled 
  // copy the values
  myStartFlag      = model.myStartFlag ;
  myEpitome        = model.myEpitome   ;
  myComment        = model.myComment   ;
  myEndFlag        = model.myEndFlag   ;
  myData           = model.myData      ;
}


const MscDataTeam & MscDataTeam::operator= ( const MscDataTeam & model )
{
  MscDg::trace( CLASS_NAME , "operator=()" );
  if ( this == & model ) {
    // nothing to do
  }
  else if ( copy( model , MscDataTeam::COPY_ALL , 0 , true ) == true ) {
    // dealt with by the derived class
  }
  else {
    copyDataHolder( model );
  }
  return *this ;
}



bool MscDataTeam::operator== ( const MscDataTeam & model )
{
  if ( this == & model ) { return true ; }
  // if number is not compared

  // compare own values
  if ( myData.size() != model.myData.size() ) { 
    return false ;
  }
  for ( int i=0 ; i < myData.size() ; ++i ) {
    if ( myData[i] != model.myData[i] ) {
      return false ;
    }
  }

  // compare children's ones
  if ( myChildren.size() != model.myChildren.size() ) {
    return false ;
  }
  ChildrenMap::iterator iter ;  
  ChildrenMap::const_iterator modelIter = model.myChildren.begin();
  for ( iter=myChildren.begin() ; iter != myChildren.end() ; ++iter , ++modelIter ) {
    if ( **iter != **modelIter ) return false ;
  }
  return true ;
}


bool MscDataTeam::operator!= ( const MscDataTeam & model )
{ 
  return ((*this == model) ? false : true) ; 
}


MscDataTeam::~MscDataTeam()
{
  myFreeMemory() ;
}



void MscDataTeam::myCheckFlags()
{
  static const char * METHOD_NAME = "myCheckFlags()";
  myAllowSendingSignals = false ;

  // create the items
  for ( unsigned int i=0 ; i < myData.size() ; ++i ) {

    // programming error ?? NO . At the moment, all the values could be saved.
    if ( myData[i].getFlag().isBlank() == true ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Class %d %s : SubClass:%d %s: Flag of data[%d] %d is blank." ,
                   myClassType , getClassStr() , mySubClass , myComment.c_str() , i , myData[i].getId() );
    }

    // create the items
    switch ( myData[i].getDataType() ) {
      // start flag
    case MscDataItem::DT_START_FLAG :
      if ( myStartFlag.isEmpty() == true ) {
        myStartFlag = myData[i].getFlag() ;
      }
      
      break ;

      // no operation
    case MscDataItem::DT_NOOP     :
      {
        int  addedSpace = myData[i].getInt() ;
        if ( addedSpace < -5 ) { addedSpace = -5 ; }
        if ( addedSpace > +5 ) { addedSpace = +5 ; }
        if ( addedSpace != myData[i].getInt() ) {
          MscDg::error( CLASS_NAME , METHOD_NAME ,
                       "Class:%d SubClass:%d %s: modified the increment data[%d] %d to %d" ,
                        myClassType , mySubClass , myComment.c_str() , i , myData[i].getInt() , addedSpace );
          myData[i].customizeInt(addedSpace);
        }
      } break ;

      // default values
    case MscDataItem::DT_BOOL   :
    case MscDataItem::DT_BOOL_I :
    case MscDataItem::DT_INT    :
    case MscDataItem::DT_FLOAT  :
    case MscDataItem::DT_DOUBLE :
    case MscDataItem::DT_STRING :
      // values
      break ;
      
      // end flag
    case MscDataItem::DT_END_FLAG :
      if ( myEndFlag.isBlank() == true ) {
        myEndFlag = myData[i].getFlag() ;
      }
      break ;
    default :
      MscDg::error( CLASS_NAME , METHOD_NAME , "Class:%d SubClass:%d %s: undefined DataType[%d] %d" ,
                   myClassType , mySubClass , myComment.c_str() , i , myData[i].getDataType() ); 
    }
  }

  MscDg::trace( CLASS_NAME , METHOD_NAME , "Class:%d SubClass:%d %s: StartFlag:%s Number:%d" ,
               myClassType , mySubClass , myComment.c_str() , myStartFlag.c_str() , getFullSignalSet().size() ); 

  // create end flag if start flag is something like "<xxxxx>" 
  // end flag becomes: "</xxxxx>" 
  int startLength = myStartFlag.length() ;
  if ( myEndFlag.isBlank() == true && 
       startLength         >  2    &&
       myStartFlag[0]      == '<'  && 
       myStartFlag[ startLength - 1 ] == '>' ) {
    myEndFlag = "</" ;
    for ( int i=1 ; i < startLength ; ++i ) {
      myEndFlag += myStartFlag[i] ;
    }
  }

  // check
  if ( myData.size() != 0 ) {
    if ( myStartFlag.isBlank() == true ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Class:%d SubClass:%d %s: missing DT_START_FLAG" ,
                   myClassType , mySubClass , myComment.c_str() );
    }
    if ( myEndFlag.isBlank() == true ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Class:%d SubClass:%d %s: missing DT_END_FLAG" ,
                   myClassType , mySubClass , myComment.c_str() );
    }
  }
  // by default ALLOWS signals at the start (24/01/2012)
  myAllowSendingSignals = true ;
}


void MscDataTeam::myFreeMemory()
{
  // clean up own values
  myData.clear();
  // clean up existings children
  myChildren.clear() ;
}



// STATIC METHOD
const char * MscDataTeam::getClassStartFlag( int numberOfBps , MscDataItem::CreateInfo * createInfos )
{
  const char * flag = 0 ;
  int i=0;
  for ( i=0 ; i < numberOfBps ; ++i ) {
    if ( createInfos[i].myDataType == MscDataItem::DT_START_FLAG ) {
      flag = createInfos[i].myFlag ;
      break ;
    }
  }
  if ( MscUtl::isBlank(flag) == true ) {
    MscDg::error( CLASS_NAME , "getClassStartFlag()" , "DT_START_FLAG not found amongst the %d values" ,
                 i );
  }
  return flag ;
}



bool MscDataTeam::needsToBeSaved()
{
  // the derived class has ..
  if ( derivedNeedsToBeSaved() == true ) { return true; }
  // one of the items needs to be saved
  for ( int i=0 ; i < myData.size() ; ++i ) {
    if ( myData[i].needsToBeSaved() == true ) {
      return true;
    }
  }
  // children
  ChildrenMap::iterator iter ;
  for ( iter=myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
    if ( (*iter)->needsToBeSaved() == true ) {
      return true;   
    }
  }
  // nothing to save
  return false;
}



const MscDataItem * MscDataTeam::getDataPtr( int id ) const
{
  for ( int i=0 ; i < myData.size() ; ++i ) {
    if ( id == myData[i].getId() ) {
      return & myData[i] ;
    }
  }
  return 0 ;  
}


MscDataItem * MscDataTeam::getDataPtr( int id )
{
  for ( int i=0 ; i < myData.size() ; ++i ) {
    if ( id == myData[i].getId() ) {
      return & myData[i] ;
    }
  }
  return 0 ;  
}


MscDataItem & MscDataTeam::getData( int id )
{
  MscDataItem * dataPtr = getDataPtr(id);
  if ( dataPtr == 0 ) {
    MscDg::error( CLASS_NAME , "getData()" , "Class:%d SubClass:%d %s: data not found for Id %d" ,
                 myClassType , mySubClass , myComment.c_str() , id );
    static MscDataItem data;
    dataPtr = &data ;
  }
  return *dataPtr ;  
}


MscDataItem * MscDataTeam::getDataPtr( const MscString & cc )
{
  for ( int i=0 ; i < myData.size() ; ++i ) {
    if ( myData[i].getFlag() == cc ) {
      return & myData[i] ;
    }
  }
  return 0 ;  
}


MscDataItem & MscDataTeam::getData( const MscString & cc )
{
  MscDataItem * dataPtr = getDataPtr(cc);
  if ( dataPtr == 0 ) {
    MscDg::error( CLASS_NAME , "getData()" , "Class:%d SubClass:%d %s: error: no data for '%s'" ,
                 myClassType , mySubClass , myComment.c_str() , cc.c_str() );
    static MscDataItem data;
    dataPtr = &data ;
  }
  return *dataPtr ;  
}



/** ---------------------------------- */
/** children management                */
/** ---------------------------------- */


void MscDataTeam::addChild( std::shared_ptr< MscDataTeam > & c )
{
  myChildren.push_back(c);
}


void MscDataTeam::addChildAtIndex( MscDataTeam * dh , int indexOfChild )
{ 
  std::shared_ptr< MscDataTeam > c(dh);
  int numberOfChildren = myChildren.size() ;

  if ( c.get() != nullptr ) {
    // out of the bound: add at the end
    if ( indexOfChild < 0 || numberOfChildren <= indexOfChild ) {
      myChildren.push_back(c);
    }
    // add it after an existing one
    else {
      MscDataTeam::ChildrenMap children ;
      for ( int i=0 ; i < numberOfChildren ; ++i ) {
        children.push_back( myChildren[i] );
        if ( i == indexOfChild ) {
          children.push_back(c);
        }
      }
      myChildren = children ;
    }
  }
  MscDg::trace( CLASS_NAME , "addChild()" , "Index %d: Size: %d -> %d" , indexOfChild , numberOfChildren , myChildren.size() );
}



std::shared_ptr< MscDataTeam >  MscDataTeam::removeChild( int indexOfChild )
{
  static const char * METHOD_NAME = "removeChild()" ;
  std::shared_ptr< MscDataTeam > c ;
  // out of the bound: error
  int numberOfChildren = myChildren.size() ;
  if ( indexOfChild < 0 || numberOfChildren <= indexOfChild ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Index %d out of bounds [0-%d]" , indexOfChild , numberOfChildren );
  }
  else {
    MscDataTeam::ChildrenMap children ;
    for ( int i=0 ; i < numberOfChildren ; ++i ) {
      if ( i == indexOfChild ) {
        c = myChildren[i];
      }
      else {
        children.push_back( myChildren[i] );
      }
    }
    myChildren = children ;
    MscDg::trace( CLASS_NAME , METHOD_NAME , "Index %d: Size: %d -> %d" , indexOfChild , numberOfChildren , myChildren.size() );
  }
  return c ;
}



bool MscDataTeam::hasChild( int userId , std::shared_ptr< MscDataTeam > & c , bool oneGenerationOnly ) const
{
  ChildrenMap::const_iterator iter ;
  for ( iter=myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
    if ( (*iter)->getUserId() == userId ) {
      c = (*iter);
      return true;
    }
    // find recursively 
    if ( oneGenerationOnly == false && (*iter)->hasChild(userId,c,false) == true ) {
      return true;
    }
  }  
  return false ;
}



std::shared_ptr< MscDataTeam > MscDataTeam::getChild() const
{
  std::shared_ptr< MscDataTeam > dataHolder ;
  ChildrenMap::const_iterator iter=myChildren.begin() ;
  if ( iter != myChildren.end() ) {
    dataHolder = *iter ;
  }
  return dataHolder ;
}


std::shared_ptr< MscDataTeam > MscDataTeam::getChild( MscDataTeam::ClassType classType )
{
  std::shared_ptr< MscDataTeam > dataHolder ;
  ChildrenMap::const_iterator iter ;
  for ( iter=myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
    if ( (*iter)->getClassType() == classType ) {
      dataHolder = (*iter);
      break;
    }
  } 
  return dataHolder ;
}



std::shared_ptr< MscDataTeam > MscDataTeam::getChild( MscDataTeam::ClassType classType , int userId , bool oneGenerationOnly )
{
  std::shared_ptr< MscDataTeam > dataHolder ;
  ChildrenMap::const_iterator iter ;
  for ( iter=myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
    if ( (*iter)->getClassType() == classType && (*iter)->getUserId() == userId ) {
      dataHolder = (*iter);
    }
    // find recursively 
    else if ( oneGenerationOnly == false ) {
      dataHolder = (*iter)->getChild(classType,userId,false);
    }
    // done
    if ( dataHolder.get() != nullptr ) { //  isEmpty() == false ) {
      break;
    }
  }    
  return dataHolder ;
}



std::shared_ptr< MscDataTeam > MscDataTeam::getChildAtIndex( int indexOfTheChild )
{
  std::shared_ptr< MscDataTeam > dataHolder ;
  if ( 0 <= indexOfTheChild && indexOfTheChild < myChildren.size() ) {
    dataHolder = myChildren[ indexOfTheChild ];
  }
  return dataHolder ;
}



int MscDataTeam::getIndexOfChild( std::shared_ptr< MscDataTeam > & c )
{
  static const char * METHOD_NAME = "getIndexOfChild()" ;
  int indexOfChild = -1 ;
  if ( c.get() != nullptr ) {
    for ( int i=0 ; i < myChildren.size() ; ++i ) {
      if ( myChildren[i].get() == c.get() ) {
        indexOfChild = i ;
        break;
      }
    }
  }
  if ( indexOfChild == -1 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "can't fin index" );
  }
  else {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "Index %d" , indexOfChild );
  }
  return indexOfChild;
}



/** ---------------------------------- */
/** set the values.                    */
/** ---------------------------------- */



std::set<int> MscDataTeam::restoreDefaultValues( bool sendMessage )
{
  std::set<int> ids ;
  for ( int i=0 ; i < myData.size() ; ++i ) {
    if ( myData[i].restoreDefaultValues() == true ) {
      ids.insert( myData[i].getId() );
      if ( sendMessage == true ) {
        mySendSignal( myData[i].getId() );
      }
    }
  } 
  return ids ;
}



bool MscDataTeam::setBool( int id , bool value , bool sendMessage )
{
  bool valueHasChanged = false ;

  // check the parameter is ok.
  MscDataItem * data = MscDataTeam::getDataPtr(id);
  if ( data == 0 ) {
    MscDg::error( CLASS_NAME , "setBool()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                 myClassType , mySubClass , myComment.c_str() , id );
    valueHasChanged = false ;
  }
  // if the storage is not done by the derived class , do it here
  // Remark: it's safe for the derived class to use the 'id' to access the map
  // as it has been tested above.
  else if ( derivedSetBool( id , value , valueHasChanged ) == false ) {
    valueHasChanged = data->setBool(value);
  }
  // send message if needed.
  if ( valueHasChanged == true && sendMessage == true ) {
    mySendSignal( id );
  }
  return valueHasChanged ;
}


bool MscDataTeam::setInt( int id , int value , bool sendMessage )
{
  bool valueHasChanged = false ;

  // check the parameter is ok.
  MscDataItem * data = MscDataTeam::getDataPtr(id);
  if ( data == 0 ) {
    MscDg::error( CLASS_NAME , "setInt()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                 myClassType , mySubClass , myComment.c_str() , id );
    valueHasChanged = false ;
  }
  // if the storage is not done by the derived class , do it here
  // Remark: it's safe for the derived class to use the 'id' to access the map
  // as it has been tested above.
  else if ( derivedSetInt( id , value , valueHasChanged ) == false ) {
    valueHasChanged = data->setInt(value);
  }
  // send message if needed.
  if ( valueHasChanged == true && sendMessage == true ) {
    mySendSignal( id );
  }
  return valueHasChanged ;
}


bool MscDataTeam::setFloat( int id , float value , bool sendMessage )
{
  bool valueHasChanged = false ;

  // check the parameter is ok.
  MscDataItem * data = MscDataTeam::getDataPtr(id);
  if ( data == 0 ) {
    MscDg::error( CLASS_NAME , "setFloat()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                 myClassType , mySubClass , myComment.c_str() , id );
    valueHasChanged = false ;
  }
  // if the storage is not done by the derived class , do it here
  // Remark: it's safe for the derived class to use the 'id' to access the map
  // as it has been tested above.
  else if ( derivedSetFloat( id , value , valueHasChanged ) == false ) {
    valueHasChanged = data->setFloat(value);
  }
  // send message if needed.
  if ( valueHasChanged == true && sendMessage == true ) {
    mySendSignal( id );
  }
  return valueHasChanged ;
}


bool MscDataTeam::setDouble( int id , double value , bool sendMessage )
{
  bool valueHasChanged = false ;

  // check the parameter is ok.
  MscDataItem * data = MscDataTeam::getDataPtr(id);
  if ( data == 0 ) {
    MscDg::error( CLASS_NAME , "setDouble()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                 myClassType , mySubClass , myComment.c_str() , id );
    valueHasChanged = false ;
  }
  // if the storage is not done by the derived class , do it here
  // Remark: it's safe for the derived class to use the 'id' to access the map
  // as it has been tested above.
  else if ( derivedSetDouble( id , value , valueHasChanged ) == false ) {
    valueHasChanged = data->setDouble(value);
  }
  // send message if needed.
  if ( valueHasChanged == true && sendMessage == true ) {
    mySendSignal( id );
  }
  return valueHasChanged ;
}


bool MscDataTeam::setString( int id , const MscString & value , bool sendMessage )
{
  bool valueHasChanged = false ;

  // check the parameter is ok.
  MscDataItem * data = MscDataTeam::getDataPtr(id);
  if ( data == 0 ) {
    MscDg::error( CLASS_NAME , "setString()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                 myClassType , mySubClass , myComment.c_str() , id );
    valueHasChanged = false ;
  }
  // if the storage is not done by the derived class , do it here
  // Remark: it's safe for the derived class to use the 'id' to access the map
  // as it has been tested above.
  else if ( derivedSetString( id , value , valueHasChanged ) == false ) {
    valueHasChanged = data->setString(value);
  }
  // send message if needed.
  if ( valueHasChanged == true && sendMessage == true ) {
    mySendSignal( id );
  }
  return valueHasChanged ;
}



/** ---------------------------------- */
/** get the values.                    */
/** ---------------------------------- */




MscDataItem::DataType MscDataTeam::getDataType( int id , bool *isDefined  )
{
  const MscDataItem * data = getDataPtr(id);
  if ( data == 0 ) {
    if ( isDefined != 0 ) { *isDefined = false ; }
    else { MscDg::error( CLASS_NAME , "getDataType()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                        myClassType , mySubClass , myComment.c_str() , id ); }
    return MscDataItem::DT_NOOP ;
  }
  else {
    if ( isDefined != 0 ) { *isDefined = true; }
    return data->getDataType();
  }
}



MscDataItem::DataType MscDataTeam::getRealType( int id , bool *isDefined  )
{
  const MscDataItem * data = getDataPtr(id);
  if ( data == 0 ) {
    if ( isDefined != 0 ) { *isDefined = false ; }
    else { MscDg::error( CLASS_NAME , "getRealType()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                        myClassType , mySubClass , myComment.c_str() , id ); }
    return MscDataItem::DT_NOOP ;
  }
  else {
    if ( isDefined != 0 ) { *isDefined = true; }
    return data->getRealType();
  }
}


const char * MscDataTeam::getClassStr( MscDataTeam::ClassType classType )
{
  static struct {
    MscDataTeam::ClassType myClassType ;
    const char             * myString    ;
  }
  TheClassStrings[] = {
    // base class
    { CT_MscDataHolder         , "CT_MscDataHolder"        },
    // resources
    { CT_TypLinePM             , "CT_TypLinePM"            },
    { CT_TypFontPM             , "CT_TypFontPM"            },
    { CT_TypAxisPM             , "CT_TypAxisPM"            },
    { CT_TypColormapPM         , "CT_TypColormapPM"        },
    // layers
    { CT_TypDrawingLayerPM     , "CT_TypDrawingLayerPM"    },
    { CT_TypVelocityLayerPM    , "CT_TypVelocityLayerPM"   },
    { CT_TypGraphicsPM         , "CT_TypGraphicsPM"   },
    { CT_TypHorizonLayerPM     , "CT_TypHorizonLayerPM"    },
    { CT_TypSemblanceLayersPM  , "CT_TypSemblanceLayersPM" },
    { CT_TypVelocityTablePM    , "CT_TypVelocityTablePM"   },
    { CT_TypOverlayLayersPM    , "CT_TypOverlayLayersPM"   },
    { CT_TypLayerManagerPM     , "CT_TypLayerManagerPM"    },
    // frame & configuration
    { CT_TypFrameConfiguration , "CT_TypFrameConfiguration"     },
    { CT_TypFrameConfigurationPM , "CT_TypFrameConfigurationPM" },
    { CT_TypViewConfiguration  , "CT_TypViewConfiguration"      },
    // application
    { CT_TypAppPM              , "CT_TypAppPM"        },
    { CT_TypMinMaxPM           , "CT_TypMinMaxPM"     },
    { CT_TypOptionsPM          , "CT_TypOptionsPM"    }
  };
  static const int NumberOfStrings = sizeof(TheClassStrings) / sizeof(TheClassStrings[0]);
  for ( int i=0 ; i < NumberOfStrings ; ++i ) {
    if ( TheClassStrings[i].myClassType == classType ) {
      return TheClassStrings[i].myString ;
    }
  }
  return "undefined" ;
}


bool MscDataTeam::getBool  ( int id , bool *isDefined ) const
{
  const MscDataItem * data = getDataPtr(id);
  if ( data == 0 ) {
    if ( isDefined != 0 ) { *isDefined = false ; }
    else { MscDg::error( CLASS_NAME , "getBool()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                        myClassType , mySubClass , myComment.c_str() , id ); }
    return false ;
  }
  else {
    if ( isDefined != 0 ) { *isDefined = true; }
    return data->getBool();
  }
}


int MscDataTeam::getInt( int id , bool *isDefined ) const
{
  const MscDataItem * data = getDataPtr(id);
  if ( data == 0 ) {
    if ( isDefined != 0 ) { *isDefined = false ; }
    else { MscDg::error( CLASS_NAME , "getInt()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                        myClassType , mySubClass , myComment.c_str() , id ); }
    return 0 ;
  }
  else {
    if ( isDefined != 0 ) { *isDefined = true; }
    return data->getInt();
  }
}


float MscDataTeam::getFloat ( int id , bool *isDefined ) const
{
  const MscDataItem * data = getDataPtr(id);
  if ( data == 0 ) {
    if ( isDefined != 0 ) { *isDefined = false ; }
    else { MscDg::error( CLASS_NAME , "getFloat()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                        myClassType , mySubClass , myComment.c_str() , id ); }
    return 0.0f ;
  }
  else {
    if ( isDefined != 0 ) { *isDefined = true; }
    return data->getFloat();
  }
}


double MscDataTeam::getDouble( int id , bool *isDefined ) const
{
  const MscDataItem * data = getDataPtr(id);
  if ( data == 0 ) {
    if ( isDefined != 0 ) { *isDefined = false ; }
    else { MscDg::error( CLASS_NAME , "getDouble()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                        myClassType , mySubClass , myComment.c_str() , id ); }
    return 0.0 ;
  }
  else {
    if ( isDefined != 0 ) { *isDefined = true; }
    return data->getDouble();
  }
}


const MscString & MscDataTeam::getString( int id , bool *isDefined ) const
{
  const MscDataItem * data = getDataPtr(id);
  if ( data == 0 ) {
    if ( isDefined != 0 ) { *isDefined = false ; }
    else { MscDg::error( CLASS_NAME , "getString()" , "Class:%d SubClass:%d %s: failed for Id %d" ,
                        myClassType , mySubClass , myComment.c_str() , id ); }
    static MscString DefaultEmptyString ;
    return DefaultEmptyString ;
  }
  else {
    if ( isDefined != 0 ) { *isDefined = true; }
    return data->getString();
  }
}



/** ---------------------------------- */
/** Read / Write the data              */
/** ---------------------------------- */



bool MscDataTeam::dataAccess( MscDataAccess & da )
{
  static const char * METHOD_NAME = "dataAccess()";
  // utility string
  MscString tmp ; 

  //------------------------------------------------------------------------//
  // save : similar to the constructor Typt with a test of the default value //
  // (default value is not saved).                                          //
  //------------------------------------------------------------------------//
  
  if ( da.getDataAccessType() == MscDataAccess::DA_WRITE_ASCII ) {

    // write if it's allowed and there is something to save
    bool continueTheWrite = (myIsWriteEnabled == true) && (needsToBeSaved() == true);

    // stream to consider
    std::ofstream * streamPtr = nullptr;
    if ( continueTheWrite == true ) {
      streamPtr = da.getOFstream() ;
      if ( streamPtr == nullptr ) { continueTheWrite = false; }
    }

    // write
    for ( int i=0 ; (continueTheWrite==true) && (da.isOk()==true) && (i < myData.size()) ; ++i ) {
      
      // no flag , so the value is not saved
      tmp = myData[i].getFlag();
      if ( tmp.isBlank() == true ) {
        continue ;
      }

      // *** this is managed by the derived class ?
      if ( derivedDataAccess( da , tmp , &myData[i] ) == true ) {
        continue ;
      }

      // stream to consider
      std::ofstream & stream = *streamPtr ;

      // deal with it here
      switch ( myData[i].getDataType() )
      {
        // NO OPERATION
        // Can be dealt with by the derived class generally
        // Here, it's used to add a flag and a given number of spaces
        case MscDataItem::DT_NOOP :
        {
          int addedSpace = myData[i].getInt() ;
          if ( addedSpace < 0 ) { da.modifyNestingLevel( addedSpace ); }
          da.writeSpaces() ;
          stream << myData[i].getFlag() << std::endl ;
          if ( addedSpace > 0 ) { da.modifyNestingLevel( addedSpace ); }
        } break ;

        // START FLAG : MUST be provided at the START
        case MscDataItem::DT_START_FLAG :
        {
          da.writeSpaces() ;
          stream << myData[i].getFlag() <<  std::endl ;
          da.incrementNestingLevel();
          // user Id
          if ( mySubClass != 0 ) {
            da.writeSpaces() ;
            stream << "UserId " << MscDataTeam::WRITE_SPACE << mySubClass <<  std::endl ;
          }
        } break ;

        // VALUES
        case MscDataItem::DT_BOOL   :
        {
          bool hasChanged = false;
          bool value = myData[i].getBool( &hasChanged );
          if ( hasChanged == true ) {
            da.writeSpaces() ;
            stream << myData[i].getFlag() << MscDataTeam::WRITE_SPACE << (value ? "true" : "false") <<  std::endl ;
          }
        } break ;

        case MscDataItem::DT_BOOL_I :
        case MscDataItem::DT_INT    :
        {
          bool hasChanged = false;
          int value = myData[i].getInt( &hasChanged );
          if ( hasChanged == true ) {
            da.writeSpaces() ;
            // enum are seen as 'DT_INT' . Treat it .
            if (  myData[i].getTypeIsEnum() == true ) {
              // values and flags related to this data type
              // TODO TODO
              //stream << myData[i].getFlag() << MscDataTeam::WRITE_SPACE
              //       << Typ::getValue( myData[i].getRealType() , value ).myFlag <<  std::endl ;
            }
            else {
              stream << myData[i].getFlag() << MscDataTeam::WRITE_SPACE
                     << value <<  std::endl ;
            }
          }
        } break ;

        case MscDataItem::DT_FLOAT   :
        {
          bool hasChanged = false;
          float value = myData[i].getFloat( &hasChanged );
          if ( hasChanged == true ) {
            da.writeSpaces() ;
            stream << myData[i].getFlag() << MscDataTeam::WRITE_SPACE << value <<  std::endl ;
          }
        } break ;

        case MscDataItem::DT_DOUBLE   :
        {
          bool hasChanged = false;
          double value = myData[i].getDouble( &hasChanged );
          if ( hasChanged == true ) {
            da.writeSpaces() ;
            stream << myData[i].getFlag() << MscDataTeam::WRITE_SPACE << value <<  std::endl ;
          }
        } break ;

        case MscDataItem::DT_STRING   :
        {
          bool hasChanged = false;
          MscString value = myData[i].getString( &hasChanged );
          if ( hasChanged == true ) {
            if ( value.isBlank() == true ) { value = MscDataAccess::EMPTY_STRING_FLAG ; }
            da.writeSpaces() ;
            stream << myData[i].getFlag() << MscDataTeam::STRING_SPACE << value <<  std::endl ;
          }
        } break ;

          // END FLAG ; in the value that are provided MUST BE AT THE END
        case MscDataItem::DT_END_FLAG :
        {
          //--------------------------------
          // recursively write the children
          //--------------------------------
          ChildrenMap::iterator iter ;
          for ( iter=myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
            (*iter)->dataAccess( da );
          }
          //------------------------------------------------------
          // allow the derived class to do a write BEFORE the end.
          //------------------------------------------------------
          tmp =  MscDataTeam::LAST_CALL ;
          (void)derivedDataAccess( da , tmp , 0 ) ;
          // the DT_END_FLAG must be the last one.
          da.decrementNestingLevel();
          da.writeSpaces() ;
          // end flag
          stream << myData[i].getFlag() <<  std::endl ;
          continueTheWrite = false ;
        } break ;

        default:
          break;
      }
    }
  }
  
  //------------------------------------------------------------------------//
  // read                                                                   //
  //------------------------------------------------------------------------//
  
  else if ( da.getDataAccessType() == MscDataAccess::DA_READ_ASCII ) {
    
    MscString cc ;
    bool doTheRead = true ;
    // stream to consider
    std::ifstream * streamPtr = nullptr ;
    if ( doTheRead == true ) {
      streamPtr = da.getIFstream() ;
      if ( streamPtr == nullptr ) { doTheRead = false ; }
    }

    // get the flag (so don't move forward)
    while ( (doTheRead == true) && (da.isOk()==true) && (da.getWord(cc)==true) ) {
      
      // end of the read
      if ( cc == myEndFlag ) {
        doTheRead = false;
        continue ;
      }

      // user Id
      if ( cc == "UserId" ) {
        if ( (doTheRead = da.getWord(MscDataTeam::READ_SPACE,cc)) == true ) {
          mySubClass = cc.readi() ;
        }
        continue ;
      }

      // find the data type pertaining to this flag
      MscDataItem * data = getDataPtr(cc);
      if ( data == 0 ) {
        // find out if it is from a child
        bool consideredByChild = false ;
        ChildrenMap::iterator iter ;
        for ( iter=myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
          if ( cc == (*iter)->getStartFlag() ) {
            (*iter)->dataAccess( da );
            consideredByChild = true ;
          }
        }
        // if it is not considered by a child or the derived class, ...
        if ( (consideredByChild == false) && (derivedDataAccess( da , cc ) == false) ) {
          // inform the user.
          tmp.printf( "Unknown label '%s' before character %d line %d (previous flag '%s') in '%s'" ,
                      cc.c_str() , da.getCharNumber() , da.getLineNumber() ,
                      da.getPreviousWord().c_str() , da.getFileName().c_str() );
          MscDg::trace( CLASS_NAME , METHOD_NAME , tmp.c_str() );
          da.showProgressInformation( tmp ) ;
        }
        // done, go to next one
        continue ;
      }

      // stream to consider
      std::ifstream & stream = *streamPtr ;
      
      // act according to the item
      int id = data->getId() ;

      // *** managed by the derived class ?
      if ( derivedDataAccess( da , cc , data ) == true ) {
        continue ;
      }

      // deal with it here
      switch ( data->getDataType() )
      {
        
        // NO OPERATION
        case MscDataItem::DT_NOOP     :
          // nothing to do
          break ;

          // VALUES
        case MscDataItem::DT_BOOL   :
        case MscDataItem::DT_BOOL_I :
        {
          if ( (doTheRead = da.getWord(MscDataTeam::READ_SPACE,cc)) == true ) {
            if ( cc == "true" || cc == "1" ) {
              setBool( id , true ) ;
            }
            else if ( cc == "false" || cc == "0" ) {
              setBool( id , false ) ;
            }
          }
        } break ;

        case MscDataItem::DT_INT    :
        {
          if ( (doTheRead = da.getWord(MscDataTeam::READ_SPACE,cc)) == true ) {
            bool foundIt = false ;
            int  number = 0 ;
            // enum are seen as 'DT_INT' . Treat it .
            if ( data->getTypeIsEnum() == true ) {
              // TODO TODO  number = Typ::getValue( data->getRealType() , cc ).myValue ;
            }
            else {
              number = cc.readi();
            }
            setInt( id , number ) ;
          }
        } break ;

        case MscDataItem::DT_FLOAT   :
          if ( (doTheRead = da.getWord(MscDataTeam::READ_SPACE,cc)) == true ) {
            setFloat( id , cc.readf() ) ;
          }
          break ;

        case MscDataItem::DT_DOUBLE   :
          if ( (doTheRead = da.getWord(MscDataTeam::READ_SPACE,cc)) == true ) {
            setDouble( id , cc.readd() ) ;
          }
          break ;

        case MscDataItem::DT_STRING   :
          if ( (doTheRead = da.getEndOfLine(MscDataTeam::STRING_SPACE,cc)) == true ) {
            setString( id , cc ) ;
          }
          break ;

          // END OF THE READ
        case MscDataItem::DT_END_FLAG :
          MscDg::error( CLASS_NAME , METHOD_NAME , "Class:%d SubClass:%d %s: DT_END_FLAG should not be seen as 'myEndFlag' is used." ,
                       myClassType , mySubClass , myComment.c_str() );
          doTheRead = false ;
          break ;

        default :
          break;
      }
    }
  }

  //-------------------
  // not implemented
  //-------------------

  else  {
    MscDg::error( CLASS_NAME , METHOD_NAME , "Class:%d SubClass:%d %s: implemented for read/write ASCII, not for access %d" ,
                 myClassType , mySubClass , myComment.c_str() , da.getDataAccessType() );
  }

  return da.isOk() ;
}


bool MscDataTeam::dataAccess( const std::shared_ptr< std::ifstream > & stream , MscMessageProvider::Listener * l ,
                               const char * fileName )
{
  MscDataAccess da ( stream , l , fileName );
  return dataAccess( da ) ; 
}


bool MscDataTeam::dataAccess( const std::shared_ptr< std::ofstream > & stream , MscMessageProvider::Listener * l ,
                               const char * fileName )
{
  MscDataAccess da ( stream , l , fileName );
  return dataAccess( da ) ; 
}


/** ---------------------------------- */
/** message sending to the application */
/** ---------------------------------- */


void MscDataTeam::mySendSignal( int id )
{
  if ( derivedSendSignal(id) == false ) { 
    mySignals.insert( id ) ;
    if ( myAllowSendingSignals == true ) {
      sendSignals() ;
    }
  }
}


std::set<int> MscDataTeam::getFullSignalSet() const
{
  std::set< int > values ;
  for ( int i=0 ; i < myData.size() ; ++i ) {
    switch ( myData[i].getDataType() ) {
      case MscDataItem::DT_BOOL   :
      case MscDataItem::DT_BOOL_I :
      case MscDataItem::DT_INT    :
      case MscDataItem::DT_FLOAT  :
      case MscDataItem::DT_DOUBLE :
      case MscDataItem::DT_STRING :
        values.insert( myData[i].getId() );
        break;
      default:
        break;
    }
  }
  MscDg::trace( CLASS_NAME , "getFullSignalSet()" , "StartFlag:%s NumberOfSignals:%d" ,
               myStartFlag.c_str() , values.size() );
  return values ;
}


void MscDataTeam::saveSignals( bool b )
{ 
  myAllowSendingSignals = (b==true) ? false : true ; 
  if ( myAllowSendingSignals == true ) {
    sendSignals() ;
  }
}


std::set<int> MscDataTeam::discartSignals()
{
  mySentSignals = mySignals ;
  mySignals.clear() ;
  return mySentSignals ; 
}


void MscDataTeam::sendSignals()
{ 
  if ( mySignals.empty() == false ) {
    std::set<int > s = discartSignals() ;
    if ( derivedSendSignals( s ) == false && s.empty() == false ) { 
      sendSignals( & s ) ; 
    }
  }
}


void MscDataTeam::sendSignals( std::set<int> * sentSignals )
{
  if ( sentSignals == 0 ) {
    MscDg::error( CLASS_NAME , "sendSignals()" , "Class:%d SubClass:%d %s: NULL signals" ,
                 myClassType , mySubClass , myComment.c_str() );
  }
  else {
    myChanges.myDataHolder = this;
    if ( sentSignals != nullptr ) { myChanges.mySignals = *sentSignals; }
    emit signalChangedSet( &myChanges.mySignals );
    emit signalChangedHolder( &myChanges );
  }
}


void MscDataTeam::setSentSignal( const int value )
{
  mySentSignals.clear();
  mySentSignals.insert( value );
}


void MscDataTeam::setSentSignals( const int values )
{
  mySentSignals.clear();
  for ( int i=0 ; i < 32 ; ++i ) {
    if ( values & (1L<<i) ) {
      mySentSignals.insert( (1L<<i) );
    }
  }
}


void MscDataTeam::setSentSignals( const std::list<int> & values )
{
  mySentSignals.clear();
  for ( std::list<int>::const_iterator iter=values.begin() ; iter != values.end() ; ++iter ) {
    mySentSignals.insert( *iter );
  }  
}


void MscDataTeam::setSentSignals( const std::set<int> & values )
{
  mySentSignals = values ;
}

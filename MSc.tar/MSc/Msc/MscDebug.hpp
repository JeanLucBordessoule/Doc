#ifndef MSC_DEBUG_HPP
#define MSC_DEBUG_HPP

#include <cstdarg> // ... va_list va_start
#include <list>
#include <map>

#include "MscString.hpp"
#include "MscViewIds.hpp"



/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  \class MscDg : utility namespace for timer , debug purpose .
 *  CLASS TO KEEP THE TIMER , MESSAGEW AND THE DEBUG OPTIONS
 *  OUTPUT CAN BE REDIRECTED (saee the '' method and the callbacks)
 * 
 *  It saves the information in 'DbDebugInfo' instances arranged in a tree
 *  with the 'className' , 'methodName' , 'ident' structure.
 *
 *  It works by having the list of user's choices (see: "myDebugClassMap"). 
 *  and the list of all the possibilities (see: "myReferenceClassMap").
 *  There is only a limited number of user choices (purpose if the speed).
 * 
 *  When adding traces or timers, update the content of "myReferenceClassMap" by generating its contents
 *  (see: "setOperation( DEBUG_WRITE_REFERENCE)") and integrating it in the source code
 *  of the application.
 * 
 *  REMARK: at the moment, not re-entrant (see the static buffer in the methods)
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/



class DbDebugInfo {
public:
  class Timer {
  public :
    Timer();
    void  setName( const MscString & );
    const MscString & getName() const ;
    void  start();
    void  stop();
    float getElapsedTime() const ;
    float getCpuTime() const ;
  private:
    MscString myName ;
  };
  class MemorySnapShot {
  public :
    MemorySnapShot();
    void  setName( const MscString & );
    const MscString & getName() const ;
    void  start();
    void  stop();
    MscString getString();
  private:
    MscString myName ;
  };
  /** what it's used for (might have several usages) */
  enum { USAGE_UNDEFINED = 0 ,
         USAGE_TRACE     = 1 ,
         USAGE_TIMER     = 2 ,
         USAGE_MEMORY    = 4 };
  DbDebugInfo() 
  {
    myUsage      = USAGE_UNDEFINED ;
    myTraceIsOn  = false   ;
    myTimerIsOn  = false   ;
    myMemoryIsOn = false   ;
    myTimer      = nullptr ;
    myMemory     = nullptr ;
  }
  ~DbDebugInfo() ;
  /** copy some options */
  void    copyOptions( DbDebugInfo * );
  /** what it's used for */
  bool    isUsedForTrace () { return (myUsage & USAGE_TRACE  ) ? true : false ; }
  bool    isUsedForTimer () { return (myUsage & USAGE_TIMER  ) ? true : false ; }
  bool    isUsedForMemory() { return (myUsage & USAGE_MEMORY ) ? true : false ; }
  void    useItForTrace ()  { myUsage |= USAGE_TRACE  ; }
  void    useItForTimer ()  { myUsage |= USAGE_TIMER  ; }
  void    useItForMemory()  { myUsage |= USAGE_MEMORY ; }
  /*******************
   * trace specific 
   ******************/
  void    setTraceIsOn( bool b ) { useItForTrace() ; myTraceIsOn = b ;    }
  bool    getTraceIsOn()         { useItForTrace() ; return myTraceIsOn ; }
  /*******************
   * timer specific
   ******************/
  void         setTimerIsOn( bool b ) { useItForTimer() ; myTimerIsOn = b;     }
  bool         getTimerIsOn()         { useItForTimer() ; return myTimerIsOn ; }
  /** timer functionnalities */
  void         startTimer();
  void         stopTimer();
  const char * getTimerString();
  void         setTimerName( const MscString & n );
  const char * getTimerName();
  /*******************
   * memory specific
   ******************/
  void         setMemoryIsOn( bool b ) { useItForMemory() ; myMemoryIsOn = b;     }
  bool         getMemoryIsOn()         { useItForMemory() ; return myMemoryIsOn ; }
  /** memory functionnalities */
  void         startMemory();
  void         stopMemory();
  const char * getMemoryString();
  void         setMemoryName( const MscString & n );
  const char * getMemoryName();

private:

  /** not implemented */
  DbDebugInfo( const DbDebugInfo & );

  /** the usage of this instance */
  int     myUsage       = USAGE_UNDEFINED ;
  /** debugging trace */
  bool    myTraceIsOn   = false ;
  /** timer . 'myTimer' is created when needed */
  bool    myTimerIsOn   = false  ;
  Timer * myTimer       = nullptr;
  MscString myTimerString ;
  /** timer . 'myMemory' is created when needed */
  bool    myMemoryIsOn      = false  ;
  MemorySnapShot * myMemory = nullptr;
  MscString myMemoryString ;
};




/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  MscDg: singleton for the debug utilities.
 *  The below is organized in sections , according to the functionnality
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/


class DbUserMessage  ;
class DbDebugMessage ;



class MscDg {

public :

  static const char * CLASS_NAME ;
 
  /** -----------------------------------------------------------
   * ============================================================
   * ============================================================
   * ------------------------------------------------------------
   * ============================================================
   * ============================================================
   * ------------------------------------------------------------
   * INSTANCE METHODS FOR THE USER INFORMATION
   * ALL ARE STATIC .
   * IT PROVIDE MESSAGE BOX, WAIT, MESSAGE FACILITIES
   * ------------------------------------------------------------
   * ============================================================
   * ============================================================
   * ------------------------------------------------------------
   * ============================================================
   * ============================================================
   *  ---------------------------------------------------------*/
 
  /** callback type */ 
  enum UserCallbackType {  
    // message box
    CALLBACK_FATAL_BOX    , // QMessageBox::Critical
    CALLBACK_ERROR_BOX    , // QMessageBox::Critical
    CALLBACK_WARNING_BOX  , // QMessageBox::Warning
    CALLBACK_INFO_BOX     , // QMessageBox::Information
    CALLBACK_QUESTION_BOX , // QMessageBox::Question
    CALLBACK_DIALOG       , // QMessageBox::NoIcon
    // wait cursor
    CALLBACK_WAIT         ,
    // status message
    CALLBACK_STATUS       ,
    // add message to the main list
    CALLBACK_LIST         ,
    // progress
    CALLBCK_PROGRESS
  };

  /** message box result */
  enum UserAnswer { Yes=true, No=false, Cancel=-1 , Default=Yes ,
                    // 
                    ANS_Yes=true        , ANS_No=false       , ANS_Cancel =(-1) , ANS_Default=ANS_Yes ,
                    ANS_Button1=ANS_Yes , ANS_Button2=ANS_No , AND_Button3=ANS_Cancel ,
                    ANS_YES=ANS_Yes     , ANS_NO=ANS_No      , ANS_CANCEL=ANS_Cancel  };

  /** callback : type of the callback , the values and the provided user data (pointer) */
  typedef UserAnswer (*UserCallback)( void * , DbUserMessage * ) ;
  typedef std::map< UserCallbackType , std::pair< UserCallback , void * > > UserCallbackMap ;
  
  /** set the callback for the 'DbUserMessage' user messages */
  static void       addUserCallback   ( UserCallbackType type , UserCallback cb , void * userData );
  static void       removeUserCallback( UserCallbackType type , UserCallback cb , void * userData );


  /** send a message . It will use the callback (if it's present) Else it's a print out only */

  static UserAnswer sendUserMessage( DbUserMessage & );
  
  /** -----------------------------------------------------------
   * (INSTANCE METHODS FOR THE USER INFORMATION)
   * wait cursor .
   * type is 'CALLBACK_WAIT'
   *  --------------------------------------------------------- */

  static void       setIsBusy( const char * className , const char * methodName , bool isBusy ,
                               void * widget = 0 , bool isLengthyTask = false );

  /** -----------------------------------------------------------
   * (INSTANCE METHODS FOR THE USER INFORMATION)
   * STATUS & INFORMATION message . Displayed in the status bas or accumulated in a list
   * type is 'CALLBACK_STATUS'
   *  --------------------------------------------------------- */

  static void       setStatusMessage( const char * className , const char * methodName , 
                                      MscString message , bool doFlush = false ) ;
  static void       setStatusMessage( MscString message , bool doFlush = false ) { setStatusMessage(0,0,message,doFlush); }


  /** -----------------------------------------------------------
   * (INSTANCE METHODS FOR THE USER INFORMATION)
   * STATUS & INFORMATION message . Displayed in the status bas or accumulated in a list
   * type is 'CALLBACK_LIST'
   *  --------------------------------------------------------- */

  static void       addMessage( const char * className , const char * methodName , 
                                MscViewIds::ViewType callerId , MscString message , bool doFlush = false ) ;
  static void       addMessage( const char * className , const char * methodName , MscString message ) 
  { addMessage( className , methodName , MscViewIds::UNDEFINED , message , false ); }
  static void       addMessage( MscString message )
  { addMessage( 0 , 0 , MscViewIds::UNDEFINED , message , false ); }


  /** -----------------------------------------------------------
   * (INSTANCE METHODS FOR THE USER INFORMATION)
   * MESSAGE BOXES . It creates a message that is sent by 'sendMessage'
   * Returns an answer . Yes, No, Cancel .
   * type is 'CALLBACK_DIALOG'
   *  ---------------------------------------------------------- */

  /** simple message box */
  static UserAnswer messageBox( void  * widget          ,
                                MscString message         ,
                                MscString title           ,
                                int     numberOfButtons = 1 ,
                                int     defaultButton   = 1 , 
                                UserCallbackType messageBoxType = CALLBACK_DIALOG );
  
  /** same as above but with list of messages and ability to have the 'Don't show again' */
  static UserAnswer showMessageBox( void          * widget          ,
                                    const    char * className       ,
                                    const    char * methodName      ,
                                    MscString         message         ,
                                    MscString         title   = ""    ,
                                    std::list<MscString> * msgList = 0     ,
                                    int             numberOfButtons = 1 ,
                                    int             defaultButton   = 1 ,
                                    bool          * hasBeenShown    = 0 , 
                                    UserCallbackType messageBoxType = CALLBACK_DIALOG );
  
  /** same as above but from a controller with list of messages and ability to have the 'Don't show again' */
  static UserAnswer showMessageOfController( void          * viewController  ,
                                             const    char * className       ,
                                             const    char * methodName      ,
                                             MscString         message         ,
                                             MscString         title   = ""    ,
                                             std::list<MscString> * msgList = 0     ,
                                             int             numberOfButtons = 1 ,
                                             int             defaultButton   = 1 ,
                                             bool          * hasBeenShown    = 0 , // "false" if "Don't ask me again". 
                                             UserCallbackType messageBoxType = CALLBACK_DIALOG );

  /** -----------------------------------------------------------
   * METHODS FOR THE MESSAGES AND THE PRINT-OUT
   *  ---------------------------------------------------------*/
  
  /** fatal message (by default calls "Message::fatal") */
  static void fatalBox( const char * className , const char * methodName , 
                        const char * title , const char * format , ... );
  
  /** error message (by default calls "Message::error") */
  static void errorBox( const char * className , const char * methodName , 
                        const char * title , const char * format , ... );
  
  /** error message (by default calls "Message::warning") */
  static void warningBox( const char * className , const char * methodName , 
                          const char * title , const char * format , ... );

  /** error message (by default calls "Message::info") */
  static void infoBox( const char * className , const char * methodName , 
                       const char * title , const char * format , ... );
  
  /** assert message : always an output */
  static bool check( const char * className , const char * methodName , bool ,
                     const char * format , ... );
  static bool check( const char * className , const char * methodName , bool ,
                     const MscString & );

  /** fatal message : always an output (if the message is *NOT* empty) */
  static bool fatal( const char * className , const char * methodName , 
                     const char * format , ... );
  static bool fatal( const char * className , const char * methodName , 
                     const MscString & );

  /** error message : always an output */
  static bool error( const char * className , const char * methodName , 
                     const char * format = 0 , ... );
  static bool error( const char * className , const char * methodName , 
                     const MscString & );

  /** warning message : always an output (if the message is *NOT* empty) */
  static bool warning( const char * className , const char * methodName , 
                       const char * format , ... );

  /** info message : always an output (if the message is *NOT* empty) */
  static bool info( const char * className , const char * methodName , 
                    const char * format , ... );

  /** -----------------------------------------------------------
   * METHODS FOR THE PROGRESS  // UNUSED !!!
   * At the start:   message      0.0f          showStopButton 
   * When running:   0            0 <= < 100    ignored
   * Completion  :   0            100.0f        ignored
   *  ---------------------------------------------------------*/
  
  static bool progress( const char * className , const char * methodName , 
                        const char * message=0 , float percent=100.0f , bool showStopButton=false );

private : 

  static UserCallbackMap myUserCallbackMap ;


public :

  /** -----------------------------------------------------------
   * ============================================================
   * ============================================================
   * ------------------------------------------------------------
   * ============================================================
   * ============================================================
   * ------------------------------------------------------------
   * INSTANCE METHODS FOR THE DEBUG AND TIME INFORMATION
   * Instance (singleton) of 'BdDb' is created if needed.
   * ------------------------------------------------------------
   * ============================================================
   * ============================================================
   * ------------------------------------------------------------
   * ============================================================
   * ============================================================
   *  ---------------------------------------------------------*/

  /** callback type */
  enum DebugCallbackType {
    // print-out
    CALLBACK_ASSERT  ,
    CALLBACK_FATAL   ,
    CALLBACK_ERROR   ,
    CALLBACK_WARNING ,
    CALLBACK_INFO    ,
    // trace
    CALLBACK_TRACE   ,
    // timer
    CALLBACK_TIMER   ,
    // memory
    CALLBACK_MEMORY
  };

  /** callback : type of the callback , the values and the provided user data (pointer) */
  typedef void (*DebugCallback)( void * , DbDebugMessage * ) ;
  typedef std::map< DebugCallbackType , std::pair< DebugCallback , void * > > DebugCallbackMap ;
  
  /** managed through the singleton */
  MscDg();
  ~MscDg();

  /** strings used outside 'MscDebug.cpp' */
  static const char * STR_TRACE   ;
  static const char * STR_TIMER   ;
  static const char * STR_MEMORY  ;

  /** set a DEBUG callback */
  static void    addDebugCallback( DebugCallbackType , DebugCallback , void * ) ;

  /** remove a DEBUG message */
  static void    removeDebugCallback( DebugCallbackType , DebugCallback , void * ) ;

  /** send a DEBUG message . It will use the callback (if it's present) Else it's a print out only */
  static void    sendDebugMessage( MscDg::DebugCallbackType type ,
                                   const char * className , const char * methodName , 
                                   int debugId ,
                                   const char * buffer );

  /** reference values (hard-coded) 
   * values are generated by 'myWriteMap()' with DEBUG_WRITE_REFERENCE 
   * and the resulting file is used */
  typedef struct {
    const char * myClassName  ;
    const char * myMethodName ;
    int          myDebugId    ;
    const char * myValue      ;
  } DebugInfoStruct ;

  /** customize the values 
   * values are generated with 'setOperation(DEBUG_GENERATE_REFERENCE)' and stored in an array.
   * It is integrated in the source code (see: 'myWriteMap()' with DEBUG_WRITE_REFERENCE */
  static void setReferenceValues( DebugInfoStruct * , int );

  /** define the operation . It might create the singleton . Else , no action is done . */
  enum DebugOperation { DEBUG_GENERATE_REFERENCE     ,
                        DEBUG_WRITE_REFERENCE        ,
                        // define the user file
                        DEBUG_DEFAULT_USER_FILE      ,
                        // read a file
                        DEBUG_READ_CURRENT           ,
                        // write it
                        DEBUG_WRITE_CURRENT_DEFAULT  ,
                        DEBUG_WRITE_CURRENT_SELECTED };
  static bool setOperation( DebugOperation , const char * filePathName = 0 );

  /** get the timer . Create it if required */

  static DbDebugInfo * getDebugInfo( const char * className , const char * methodName , int debugId ,
                                     bool createIt );

  /** storage of the messages: Class . Method , Ident in a tree */

  typedef std::map < int       , DbDebugInfo * > IdMap     ;
  typedef std::map < MscString , IdMap         > MethodMap ;
  typedef std::map < MscString , MethodMap     > ClassMap  ;

  /** get the reference map (this one with all the possibilities)
   * In practice, only a few items will be selected and saved in 'myDebugClassMap' 
   * when asking for it (if 'updateWithUserChoices' is true),
   * the options from 'myDebugClassMap' updates the ones in 'myReferenceClassMap' */

  static const ClassMap & getReferenceClassMap( bool updateWithUserChoices );

  /** ---------------------------------------------------------
   * METHODS FOR THE MEMORY . Generally 'Id' is 0 (only one)
   * 'selectTimer' will create the instance 'DbDebugInfo' (if it doesn't exist, ...
   * AND 'isSelected' is true)
   * else, it returns if the instance doesn't exist.
   * PURPOSE: speed if no debugging or timer or memory are required
   *  ---------------------------------------------------------*/

  /** set a memory snapshot . It is created if it's not existing and 'isSelected' is true */
  static void  selectMemory( const char * className , const char * methodName , int memoryId , bool isSelected );
  /** returns 'true' if the memory snapshot exists and is selected */
  static bool  isMemorySelected( const char * className , const char * methodName , int memoryId = 0 );

  /** start and stop the memory snapshot */
  static void  startMemory( const char * className , const char * methodName , int memoryId , MscString message="" );
  static void  startMemory( const char * className , const char * methodName , MscString message="" )
  { startMemory( className , methodName , 0 , message ); }
  static void  stopMemory ( const char * className , const char * methodName , int memoryId = 0 );


  /** ---------------------------------------------------------
   * METHODS FOR THE TIMERS . Generally 'timeId' is 0 (only one)
   * 'selectTimer' will create the instance 'DbDebugInfo' (if it doesn't exist, ...
   * AND 'isSelected' is true)
   * else, it returns if the instance doesn't exist.
   * PURPOSE: speed if no debugging or timer or memory are required
   *  ---------------------------------------------------------*/

  /** set a timer . It is created if it's not existing and 'isSelected' is true */
  static void  selectTimer( const char * className , const char * methodName , int timerId , bool isSelected );
  /** returns 'true' if the timer exists and is selected */
  static bool  isTimerSelected( const char * className , const char * methodName , int timerId = 0 );

  /** start and stop the timer */
  static void  startTimer( const char * className , const char * methodName , int timerId , const char * format , ... );
  static void  startTimer( const char * className , const char * methodName , int timerId , MscString message="" );
  static void  startTimer( const char * className , const char * methodName , MscString message="" )
  { startTimer( className , methodName , 0 , message ); }
  static void  stopTimer ( const char * className , const char * methodName , int timerId = 0 );

  /** ---------------------------------------------------------
   * METHODS FOR THE TRACES . Generally 'debugId' is 0 (only one)
   * 'selectTimer' will create the instance 'DbDebugInfo' (if it doesn't exist, ...
   * AND 'isSelected' is true)
   * else, it returns if the instance doesn't exist.
   * PURPOSE: speed if no debugging or timer or memory are required
   *  ---------------------------------------------------------*/

  /** print trace without testing (if the message is *NOT* empty) */
  static void print( const char * format , ... );
  static void print( const MscString & );

  /** enable or not the trace output */
  static void setOn( const char * className , const char * methodName , int debugId , bool isOn );
  static bool isOn ( const char * className , const char * methodName , int debugId = 0 )
  {
    if ( myInstance == 0 ) { return false ; }
    return myInstance->myGetTraceIsEnabled(className,methodName,debugId) ;
  }
  static void  startTrace( const char * className , const char * methodName , int debugId = 0 )
  { setOn( className , methodName , debugId , true  ); }
  static void  stopTrace ( const char * className , const char * methodName , int debugId = 0 )
  { setOn( className , methodName , debugId , false ); }
  static bool  isTraceSelected( const char * className , const char * methodName , int debugId = 0 )
  { return isOn( className , methodName , debugId ) ;  }

  /** print out a message . Returns 'true' if the message is enabled */
  typedef struct { const char * myClassName ; const char * myMethodName ; } TrackerInfo ;
  static bool myShowTrackerTraces ;
  static void tracker( int type , const char * className , const char * methodName );
  static const TrackerInfo * getTrackerInfo( int & arraySize , int & lastIndex , int & rank );
  static MscString      getTrackerString();
  static bool trace( const char * className , const char * methodName , int debugId ,
                     const char * format = 0 , ... );
  static bool trace( const char * className , const char * methodName , 
                     const char * format = 0 , ... );
  static bool trace( const char * className , const char * methodName , 
                     const MscString & );

private :

  /** not implemented */
  MscDg( const MscDg & );


  /** get the one that is stored. Create it if needed */
  static DbDebugInfo * myGetDebugInfo( ClassMap * classMap  ,
                                       const char * className , const char * methodName , int debugId ,
                                       bool createIt );
  /** has the message */
  bool myGetTraceIsEnabled( const char * className , const char * methodName , int debugId );
  
  /** enable the message */
  void mySetTraceIsEnabled( const char * className , const char * methodName , int debugId , bool isOn );

  /** write a map */
  bool myWriteMap( DebugOperation , const char * fileName );
  bool myReadMap ( const char * fileName );

  /** instance (singleton) */
  static MscDg * myInstance ;

  /** reference of the information for a class , method and id ,
  * THIS ONE OFFERS ALL THE EXISTING POSSIBILITIES . 
  * IT'S UPDATED WHEN 'MscDg' IS ON */
  static ClassMap myReferenceClassMap ;

  /** defautl user file */
  static MscString  myDefaultUserFile ;

  /** generate the file : flag used when generating the file */
  static MscString  myReferenceFlag     ;

  /** buffer . used by the instance */
  enum { BufferSize = 10240 };
  char myBuffer[ BufferSize ];

  /** storage of the information for a class , method and id . 
   * FOR SPEED THIS ONE IS USED IN REAL-TIME 
   * THE REASON WHY IT EXISTS IS TO REDUCE THE SPEED .
   * IF NO TRACE OR TIMER ARE REQUIRED, IT SIMPLY RETURNS .
   * (use only the required values) */
  ClassMap        myDebugClassMap ;

  /** map of the callbacks */
  static MscDg::DebugCallbackMap  myDebugCallbackMap ;
};





/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  User Message
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/


class DbUserMessage {
public:

  DbUserMessage( MscDg::UserCallbackType t , const char * c , const char * m , MscViewIds::ViewType callerId , const MscString & msg )
  {
    myCallbackType    = t        ;
    myClassName       = c        ;
    myMethodName      = m        ;
    myMessage         = msg      ;
    myWidget          = 0        ;
    myViewController  = 0        ;
    myCallerId        = callerId ;
    myNumberOfButtons = 1        ;
    myDefaultButton   = 1        ;
    myHasBeenShown    = false    ;
    myIsBusy          = false    ;
    myIsBusyWidget    = 0        ;
    myIsLengthyTask   = false    ;
    myFlush           = false    ;
  }
  DbUserMessage( MscDg::UserCallbackType t , const char * c , const char * m , MscViewIds::ViewType callerId , const char * msg )
  {
    myCallbackType    = t        ;
    myClassName       = c        ;
    myMethodName      = m        ;
    myMessage         = msg      ;
    myWidget          = 0        ;
    myViewController  = 0        ;
    myCallerId        = callerId ;
    myNumberOfButtons = 1        ;
    myDefaultButton   = 1        ;
    myHasBeenShown    = false    ;
    myIsBusy          = false    ;
    myIsBusyWidget    = 0        ;
    myIsLengthyTask   = false    ;
    myFlush           = false    ;
  }
  /** constructor / destructor */
  ~DbUserMessage() {}
  void addMessage( const MscString & m ) { myMessageList.push_back(m); }
  const MscString & getTitle() 
  { 
    if ( myTitle.isBlank() == true ) {
      if ( myClassName.isBlank() == false && myMethodName.isBlank() == false ) {
        myTitle.printf( "%s::%s" , myClassName.c_str() , myMethodName.c_str() );
      }
      else if ( myClassName.isBlank() == false ) {
        myTitle = myClassName ;
      }
      else {
        myTitle = myMethodName ; 
      }
    }
    return myTitle ;
  }
  /** message type */
  MscDg::UserCallbackType myCallbackType ;
  /** caller is a pointer that can be 'QWidget' or 'vqViewController' , Cast is required to use it */
  void          * myWidget          ;
  void          * myViewController  ;
  MscViewIds::ViewType myCallerId    ;
  /** parameters */
  MscString         myClassName       ;
  MscString         myMethodName      ;
  MscString         myMessage         ;
  MscString         myTitle           ;
  std::list< MscString > myMessageList     ;
  int             myNumberOfButtons ;
  int             myDefaultButton   ;
  /** some messages can be omitted with "Don't show me trhe message again" */
  bool            myHasBeenShown    ;
  /** wait cursor */
  bool            myIsBusy          ;
  void          * myIsBusyWidget    ;
  bool            myIsLengthyTask   ;
  /** request a flush in the GUI */
  bool            myFlush           ;
};




/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  Debug Message 
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/


class DbDebugMessage {
public:
  DbDebugMessage( MscDg::DebugCallbackType t , const char * c , const char * m , int i )
  {
    myCallbackType = t ;
    myClassName    = c ;
    myMethodName   = m ;
    myIdent        = i ;
  }
  ~DbDebugMessage() 
  {
  }
  // values
  MscDg::DebugCallbackType myCallbackType ;
  MscString myClassName  ;
  MscString myMethodName ;
  int     myIdent      ;
  MscString myMessage    ;
  MscString myTitle      ;
  // functionnality
  const MscString & getTitle() 
  { 
    if ( myTitle.isBlank() == true ) {
      if ( myClassName.isBlank() == false && myMethodName.isBlank() == false ) {
        myTitle.printf( "%s::%s" , myClassName.c_str() , myMethodName.c_str() );
      }
      else if ( myClassName.isBlank() == false ) {
        myTitle = myClassName ;
      }
      else {
        myTitle = myMethodName ; 
      }
    }
    return myTitle ;
  }
};



#endif




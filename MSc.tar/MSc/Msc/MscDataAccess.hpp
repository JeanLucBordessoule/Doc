#ifndef MSC_DATA_ACCESS_HPP
#define MSC_DATA_ACCESS_HPP

#include <memory>
#include <fstream>

#include "MscMessageProvider.hpp"
#include "MscString.hpp"


/** Convenience utilities to read line or words in an ASCII file */


class MscDataAccess : public MscMessageProvider
{
public :
  static const char * CLASS_NAME ;
  /** Type of file & empty string flag */
  enum DataAccessType { DA_UNDEFINED    = -1 ,
                        DA_READ_ASCII   =  0 , // File -> Data
                        DA_WRITE_ASCII  ,      // Data -> File
                        DA_VALIDATE_GUI ,      // GUI  -> Data
                        DA_SHOW_GUI     };     // Data -> GUI
  /** add spaces at the start of a line */
  static int          NUMBER_OF_SPACES_FOR_NESTING ;
  /** flag for the parameter writing */
  static const char * EMPTY_STRING_FLAG ;
  static const char * DEFINITION_START  ;
  static const char * DEFINITION_END    ;
  /** size of the read Typffer */
  enum { READ_BUFFER_SIZE = 512 } ;

  /** Default Constructor */
  MscDataAccess( MscMessageProvider::Listener * = 0 ) ;

  /** Open a text input or output stream */
  MscDataAccess( const char * , DataAccessType accessType , MscMessageProvider::Listener * = 0 ) ;

  /** Use an existing open stream . In this case , stream is not owned and MUST not be modified (closed)
  * Hence action of 'open' and 'close' are not relevant in this case. */
  MscDataAccess( const std::shared_ptr< std::ifstream > & , MscMessageProvider::Listener * = 0 , const char * fileName = 0 ) ; // DA_READ_ASCII
  MscDataAccess( const std::shared_ptr< std::ofstream > & , MscMessageProvider::Listener * = 0 , const char * fileName = 0 ) ; // DA_WRITE_ASCII
  /** utility function for the above */
  MscDataAccess( std::ifstream * s , MscMessageProvider::Listener * l = 0 , const char * f = 0 ) ; // DA_READ_ASCII
  MscDataAccess( std::ofstream * s , MscMessageProvider::Listener * l = 0 , const char * f = 0 ) ; // DA_WRITE_ASCII

  /** Destructor */
  ~MscDataAccess() ;

  /** functionnalities for the lock / unlock
   *  it simply write a file with "#locked" at the end of the name 
   *  and add some text in this lock .
   * The caller (className, methodName) must be provided (used in the error message) */
  static bool isLocked( const char * className , const char * methodName ,
                        const MscString & filePath , MscString & lockName ) ;
  static bool lock    ( const char * className , const char * methodName ,
                        const MscString & filePath , const MscString & userMessageInTheLock );
  static bool unlock  ( const char * className , const char * methodName ,
                        const MscString & filePath );

  /** Return the contents of text file 'filePath' into a string 'contents'. Add a final \n to the string 
   * Returns 'false' if error */
  static bool textFileContentToString( const MscString & filePath , MscString & contents );
  
  /** know about the type and the values */
  DataAccessType getDataAccessType() const { return myDataAccessType ; }
  int            getCharNumber()     const { return myCharNumber     ; }
  int            getLineNumber()     const { return myLineNumber     ; }
  MscString        getFileName()       const { return myFileName       ; }

  /** know if the file exists , and if it has been overwritten (in the write) */
  bool           getFileExists()      const { return myFileExists      ; }
  bool           getFileOverwritten() const { return myFileOverwritten ; }

  /** access to the stream . relevant if the data storage class is ok and for the correct data type. */
  std::ifstream * getIFstream() { return myIFstream ; }
  std::ofstream * getOFstream() { return myOFstream ; }

  /** open a stream . Relevant only if the stream is NOT provided (created stream are OWNED) */
  bool           open( const char * , DataAccessType accessType ) ;

  /** write facilities (write mode only in 'myOFstream') . Printout if issue */
  MscDataAccess & operator << ( const MscString & );
  MscDataAccess & operator << ( const char * );
  MscDataAccess & operator << ( double );
  MscDataAccess & operator << ( float );
  MscDataAccess & operator << ( size_t );
  MscDataAccess & operator << ( int );

  /** fastest data access . Returns the 'myBuffer' storage.. Copy if neeed  */
  const char   * getNonEmptyLineWithFinalSpace( int & length ) ;

  /** stop at the first line that is not empty . Does get rid of the first empty spaces . 
  * Usually used for the read of the parameter models */
  bool    readNextNewLineThatIsNotEmpty( MscString * = 0 ) ;

  /** read a new line */
  bool    readNewLine() ;

  /** move along the line */
  bool    moveInLine( const char * separator ) ;

  /** check the word  */
  void    checkWordIsNotEmptyString( MscString & cc ) ;

  /** read a word (start after the separator) and related functions */
  bool    getWord  ( const char * separator , MscString & cc ) ;
  bool    getBool  ( const char * separator , bool    & cc ) ;
  bool    getInt   ( const char * separator , int     & cc ) ;
  bool    getFloat ( const char * separator , float   & cc ) ;
  bool    getDouble( const char * separator , double  & cc ) ;
  /** return the previous word that has been read */
  const MscString & getPreviousWord() const { return myPreviousWord; }
  /** convenience function (tabke first item ...) */
  bool    getWord  ( MscString & cc ) { return getWord  (0,cc); }
  bool    getBool  ( bool    & cc ) { return getBool  (0,cc); }
  bool    getInt   ( int     & cc ) { return getInt   (0,cc); }
  bool    getFloat ( float   & cc ) { return getFloat (0,cc); }
  bool    getDouble( double  & cc ) { return getDouble(0,cc); }

  /** return till the end of the line (start after the separator) */
  bool    getEndOfLine( const char * separator , MscString & cc ) ;

  /** cosmetics: number of spacxes at the start of a line (used by DA_WRITE_ASCII) */
  void    incrementNestingLevel() ;
  void    decrementNestingLevel() ;
  void    modifyNestingLevel( int );
  int     getNestingLevel() const { return myNestingLevel ; }
  void    writeSpaces() ;

  /** find out if it can write or if it's the end of stream (reading mode) */
  bool    canWrite();
  bool    canRead();

  /** close any opened OWNED stream */
  bool    close() ;

private :

  /** initialize values in the constructor */
  void                myInitialize()    ;

  /** reference values for the line reading */
  int                 myLineNumber      = 0 ;
  int                 myCharNumber      = 0 ;
  int                 myBufferLength    = 0 ;

  /** Typffer used for the read in an ASCII file . Current and Previously words read by 'getWord()' */
  char                myBuffer[ READ_BUFFER_SIZE ] ;
  MscString             myCurrentWord     ;
  MscString             myPreviousWord    ;

  /** type of data access */
  DataAccessType      myDataAccessType  = DA_UNDEFINED ;
  
  /** used streams */
  MscString             myFileName        ;
  bool                myFileExists      = false ;
  bool                myFileOverwritten = false ;
  bool                myStreamIsOwned   = false ; // if true, allocated memory must be deleted.
  std::ifstream     * myIFstream        = nullptr ;
  std::ofstream     * myOFstream        = nullptr ;

  /** number of spaces at the start of a line */
  int                 myNestingLevel   ;
} ;


#endif

#include "MscDebug.hpp"

// C++
#include <string.h> // strstr

// Miscellaneous (Msc)
#include "MscString.hpp"
#include "MscDataAccess.hpp"
#include "MscFileSystem.hpp"
#include "MscUtl.hpp"




/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  THIS PART PERTAINS TO THE USER MESSAGE SENDING
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/


MscDg::UserCallbackMap MscDg::myUserCallbackMap ;



/** THE CALLBACK USED BY THE MESSAGE HANDLING */

void  MscDg::addUserCallback( MscDg::UserCallbackType type , MscDg::UserCallback cb , void * userData )
{
  // null : so remove it if present
  if ( cb == nullptr ) {
    MscDg::UserCallbackMap::iterator iter = MscDg::myUserCallbackMap.find( type );
    if ( iter != MscDg::myUserCallbackMap.end() ) {
      std::cerr << "MscDg::addUserCallback() already present" << std::endl ;
      MscDg::myUserCallbackMap.erase(iter);
    }
  }
  // save it
  if ( cb != nullptr ) {
    std::pair< MscDg::UserCallback , void * > pr( cb , userData );
    MscDg::myUserCallbackMap[ type ] = pr ;
  }  
}



void MscDg::removeUserCallback( MscDg::UserCallbackType type , MscDg::UserCallback cb , void * userData )
{
  MscDg::UserCallbackMap::iterator iter = MscDg::myUserCallbackMap.find( type );
  if ( iter != MscDg::myUserCallbackMap.end() ) {
    MscDg::myUserCallbackMap.erase(iter);
  }
  else {
    std::cerr << "MscDg::removeUserCallback(" << type << ") NOT FOUND" << std::endl ;
  }
}



MscDg::UserAnswer MscDg::sendUserMessage( DbUserMessage & message )
{
  MscDg::UserAnswer answer = MscDg::Yes ;
  // local 
  MscDg::UserCallbackMap::iterator iter = MscDg::myUserCallbackMap.find( message.myCallbackType );
  if ( iter == MscDg::myUserCallbackMap.end() ) {
    std::cerr << "MscDg::sendMessage(CALLBACK NOT PROVIDED)  " << message.myCallbackType
              << "  " << message.myMessage <<  std::endl ;
  }
  // delegated
  else {
    return iter->second.first( iter->second.second , & message );
  }
  return answer ;
}


/** THE MESSAGE TO SEND */


void MscDg::setIsBusy( const char * className , const char * methodName , bool isBusy ,
                      void * widget , bool isLengthyTask )
{
  DbUserMessage msg( MscDg::CALLBACK_WAIT , className , methodName , MscViewIds::UNDEFINED , 0 );
  msg.myIsBusy        = isBusy        ;
  msg.myIsBusyWidget  = widget        ;
  msg.myIsLengthyTask = isLengthyTask ;
  // send message
  (void)MscDg::sendUserMessage( msg );  
}


void MscDg::setStatusMessage( const char * className , const char * methodNane , MscString message , bool doFlush )
{
  DbUserMessage msg( MscDg::CALLBACK_STATUS , className , methodNane , MscViewIds::UNDEFINED , message );
  // send message
  (void)MscDg::sendUserMessage( msg );
}



void MscDg::addMessage( const char * className , const char * methodNane , MscViewIds::ViewType callerId , MscString message , bool doFlush )
{
  DbUserMessage msg( MscDg::CALLBACK_LIST , className , methodNane , callerId , message );
  // send message
  (void)MscDg::sendUserMessage( msg );
}



MscDg::UserAnswer MscDg::messageBox( void  * widget          ,
                                   MscString message         ,
                                   MscString title           ,
                                   int     numberOfButtons ,
                                   int     defaultButton   ,
                                   MscDg::UserCallbackType messageBoxType )
{
  DbUserMessage msg( messageBoxType , 0 , 0 , MscViewIds::UNDEFINED , message );
  msg.myWidget          = widget          ;
  msg.myTitle           = title           ;
  msg.myNumberOfButtons = numberOfButtons ;
  msg.myDefaultButton   = defaultButton   ;
  // build title if it's empty
  msg.getTitle();
  // send message
  return MscDg::sendUserMessage( msg );
}



MscDg::UserAnswer MscDg::showMessageBox( void          * widget          ,
                                       const    char * className       ,
                                       const    char * methodName      ,
                                       MscString         message         ,
                                       MscString         title           ,
                                       std::list<MscString> * msgList         ,
                                       int             numberOfButtons ,
                                       int             defaultButton   ,
                                       bool          * hasBeenShown    ,
                                       MscDg::UserCallbackType messageBoxType )
{
  DbUserMessage msg( messageBoxType , className , methodName , MscViewIds::UNDEFINED , message );
  msg.myWidget          = widget          ;
  msg.myTitle           = title           ;
  if ( msgList != 0 ) { msg.myMessageList = *msgList ; }
  msg.myNumberOfButtons = numberOfButtons ;
  msg.myDefaultButton   = defaultButton   ;
  // build title if it's empty
  msg.getTitle();
  // send message
  MscDg::UserAnswer userAnswer = MscDg::sendUserMessage( msg );
  if ( hasBeenShown != 0 ) { *hasBeenShown = msg.myHasBeenShown ; }
  return userAnswer ;
}



MscDg::UserAnswer MscDg::showMessageOfController( void          * viewController  ,
                                                const    char * className       ,
                                                const    char * methodName      ,
                                                MscString         message         ,
                                                MscString         title           ,
                                                std::list<MscString> * msgList         ,
                                                int             numberOfButtons ,
                                                int             defaultButton   ,
                                                bool          * hasBeenShown    ,
                                                MscDg::UserCallbackType messageBoxType )   
{
  DbUserMessage msg( messageBoxType , className , methodName , MscViewIds::UNDEFINED , message );
  msg.myViewController  = viewController  ;
  msg.myTitle           = title           ;
  if ( msgList != 0 ) { msg.myMessageList = *msgList ; }
  msg.myNumberOfButtons = numberOfButtons ;
  msg.myDefaultButton   = defaultButton   ;
  // build title if it's empty
  msg.getTitle();
  // send message
  MscDg::UserAnswer userAnswer = MscDg::sendUserMessage( msg );
  if ( hasBeenShown != 0 ) { *hasBeenShown = msg.myHasBeenShown ; }
  return userAnswer ;
}




/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 * METHODS FOR THE PRINT-OUT
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/




void MscDg::fatalBox( const char * className , const char * methodName , const char * title , const char * format , ... )
{
  // No message if nothing to print-out
  if ( MscUtl::isBlank( format ) == true ) { return ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::fatalBox()"
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Format " << format <<  std::endl ;
#endif

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;
  
  // format is not 0
  va_list ap;
  int nwrit = -1;
  try {
    va_start( ap , format );
    MscString vformat(format,true);
#ifdef WIN32
    nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
    nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
  }
  catch( ... ) {
    std::cerr << "Exception while printing format '" << format
         << "' Check for using %%d when printing might use %%lld instead." << std::endl ;
  }
  va_end(ap);
  if ( nwrit >= MscDg::BufferSize ) {
    std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }
  if ( nwrit < 0 ) {
    std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }
  
  // messsage
  DbUserMessage msg( MscDg::CALLBACK_FATAL_BOX , className , methodName , MscViewIds::UNDEFINED , Buffer );
  // build title if it's empty
  msg.getTitle();
  // send message
  MscDg::sendUserMessage( msg );
}



void MscDg::errorBox( const char * className , const char * methodName , const char * title , const char * format , ... )
{
  // No message if nothing to print-out
  if ( MscUtl::isBlank( format ) == true ) { return ; }

#ifdef DEBUGGING_TRACE
  std::cerr << "MscDg::errorBox()"
            << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "")
            << " Format " << format <<  std::endl ;
#endif

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;

  // format is not 0
  va_list ap;
  int nwrit = -1;
  try {
    va_start( ap , format );
    MscString vformat(format,true);
#ifdef WIN32
    nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
    nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
  }
  catch( ... ) {
    std::cerr << "Exception while printing format '" << format
              << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
  }
  va_end(ap);
  if ( nwrit >= MscDg::BufferSize ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }
  if ( nwrit < 0 ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }

  // messsage
  DbUserMessage msg( MscDg::CALLBACK_ERROR_BOX , className , methodName , MscViewIds::UNDEFINED , Buffer );
  // build title if it's empty
  msg.getTitle();
  // send message
  MscDg::sendUserMessage( msg );
}




void MscDg::warningBox( const char * className , const char * methodName , const char * title , const char * format , ... )
{
  // No message if nothing to print-out
  if ( MscUtl::isBlank( format ) == true ) { return ; }

#ifdef DEBUGGING_TRACE
  std::cerr << "MscDg::warningBox()"
            << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "")
            << " Format " << format <<  std::endl ;
#endif

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;
  
  // format is not 0
  va_list ap;
  int nwrit = -1;
  try {
    va_start( ap , format );
    MscString vformat(format,true);
#ifdef WIN32
    nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
    nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
  }
  catch( ... ) {
     std::cerr << "Exception while printing format '" << format
         << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
  }
  va_end(ap);
  if ( nwrit >= MscDg::BufferSize ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }
  if ( nwrit < 0 ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }

  // messsage
  DbUserMessage msg( MscDg::CALLBACK_WARNING_BOX , className , methodName , MscViewIds::UNDEFINED , Buffer );
  // build title if it's empty
  msg.getTitle();
  // send message
  MscDg::sendUserMessage( msg );
}



void MscDg::infoBox( const char * className , const char * methodName , const char * title , const char * format , ... )
{
  // No message if nothing to print-out
  if ( MscUtl::isBlank( format ) == true ) { return ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::infoBox()"
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Format " << format <<  std::endl ;
#endif

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;
  
  // format is not 0
  va_list ap;
  int nwrit = -1;
  try {
    va_start( ap , format );
    MscString vformat(format,true);
#ifdef WIN32
    nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
    nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
  }
  catch( ... ) {
     std::cerr << "Exception while printing format '" << format
         << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
  }
  va_end(ap);
  if ( nwrit >= MscDg::BufferSize ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }
  if ( nwrit < 0 ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }

  // messsage
  DbUserMessage msg( MscDg::CALLBACK_INFO_BOX , className , methodName , MscViewIds::UNDEFINED , Buffer );
  // build title if it's empty
  msg.getTitle();
  // send message
  MscDg::sendUserMessage( msg );
}



bool MscDg::progress( const char * className , const char * methodName , const char * message , float percent , bool  )
{
  static const char * METHOD_NAME = "progress()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "Called by '%s::%s': Percent %g : Message '%s'" , 
               className  , methodName  , percent , message ? message : "" );
  return true ;
}


/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  METHODS FOR THE PRINT-OUT
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/



bool MscDg::check( const char * className , const char * methodName , bool condition , const char * format , ... )
{
  // Condition is met, so no problem
  if ( condition == true ) { return true ; }
  
#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::assert()"
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Format " << format <<  std::endl ;
#endif

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;

  // No message if nothing to print-out
  if ( MscUtl::isBlank( format ) == false ) {
    // format is not 0
    va_list ap;
    int nwrit = -1;
    try {
      va_start( ap , format );
      MscString vformat(format,true);
#ifdef WIN32
      nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
      nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
    }
    catch( ... ) {
       std::cerr << "Exception while printing format '" << format
           << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
    }
    va_end(ap);
    if ( nwrit >= MscDg::BufferSize ) {
       std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
    }
    if ( nwrit < 0 ) {
       std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
    }
  }
  
  // message
  MscDg::sendDebugMessage( MscDg::CALLBACK_ASSERT , 
                          className             ,
                          methodName            ,
                          0                     ,
                          Buffer                );
  return true ;
}



bool MscDg::check( const char * className , const char * methodName , bool condition , const MscString & msg )
{
  // Condition is met, so no problem
  if ( condition == true ) { return true ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::assert()"
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Message " << msg <<  std::endl ;
#endif

  // message
  MscDg::sendDebugMessage( MscDg::CALLBACK_ASSERT , 
                          className             ,
                          methodName            ,
                          0                     ,
                          msg.c_str()           );
  return true ;
}




bool MscDg::fatal( const char * className , const char * methodName , const char * format , ... )
{
  // No message if nothing to print-out
  if ( MscUtl::isBlank( format ) == true ) { return true ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::fatal()"
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Format " << format <<  std::endl ;
#endif

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;

  // format is not 0
  va_list ap;
  int nwrit = -1;
  try {
    va_start( ap , format );
    MscString vformat(format,true);
#ifdef WIN32
    nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
    nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
  }
  catch( ... ) {
     std::cerr << "Exception while printing format '" << format
         << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
  }
  va_end(ap);
  if ( nwrit >= MscDg::BufferSize ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }
  if ( nwrit < 0 ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }
  
  // message
  MscDg::sendDebugMessage( MscDg::CALLBACK_FATAL  , 
                          className             ,
                          methodName            ,
                          0                     ,
                          Buffer                );
  return true ;
}



bool MscDg::fatal( const char * className , const char * methodName , const MscString & msg )
{
  // No error message if nothing to print-out
  if ( msg.isBlank() == true ) { return true ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::fatal()"
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Message " << msg <<  std::endl ;
#endif

  // message
  MscDg::sendDebugMessage( MscDg::CALLBACK_FATAL  , 
                          className             ,
                          methodName            ,
                          0                     ,
                          msg.c_str()           );
  return true ;
}



bool MscDg::error( const char * className , const char * methodName , const char * format , ... )
{
  MscDg::tracker( 1 , className , methodName );
  // No message if nothing to print-out
// 16 Jan 2014 ***   if ( MscUtl::isBlank( format ) == true ) { return true ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::error()"
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Format " << format <<  std::endl ;
#endif

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;

  // format is not null
  if ( MscUtl::isBlank( format ) == false ) {
    va_list ap;
    int nwrit = -1;
    try {
      va_start( ap , format );
      MscString vformat(format,true);
#ifdef WIN32
      nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
      nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
    }
    catch( ... ) {
       std::cerr << "Exception while printing format '" << format
           << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
    }
    va_end(ap);
    if ( nwrit >= MscDg::BufferSize ) {
       std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
    }
    if ( nwrit < 0 ) {
       std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
    }
  }
  // message
  MscDg::sendDebugMessage( MscDg::CALLBACK_ERROR , 
                          className            ,
                          methodName           ,
                          0                    ,
                          Buffer               );
  return true ;
}



bool MscDg::error( const char * className , const char * methodName , const MscString & msg )
{
  MscDg::tracker( 1 , className , methodName );
  // No error message if nothing to print-out
// 16 Jan 2014 *** if ( msg.isBlank() == true ) { return true ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::error()"
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Message " << msg <<  std::endl ;
#endif

  // message
  MscDg::sendDebugMessage( MscDg::CALLBACK_ERROR , 
                          className            ,
                          methodName           ,
                          0                    ,
                          msg.c_str()          );
  return true ;
}



bool MscDg::warning( const char * className , const char * methodName , const char * format , ... )
{
  // No message if nothing to print-out
  if ( MscUtl::isBlank( format ) == true ) { return true ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::warning()"
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Format " << format <<  std::endl ;
#endif

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;
  
  // format is not 0
  va_list ap;
  int nwrit = -1;
  try {
    va_start( ap , format );
    MscString vformat(format,true);
#ifdef WIN32
    nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
    nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
  }
  catch( ... ) {
     std::cerr << "Exception while printing format '" << format
         << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
  }
  va_end(ap);
  if ( nwrit >= MscDg::BufferSize ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }
  if ( nwrit < 0 ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }

  // message
  MscDg::sendDebugMessage( MscDg::CALLBACK_WARNING , 
                          className              ,
                          methodName             ,
                          0                      ,
                          Buffer                 );
  return true ;
}



bool MscDg::info( const char * className , const char * methodName , const char * format , ... )
{
  // No message if nothing to print-out
  if ( MscUtl::isBlank( format ) == true ) { return true ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::info()"
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Format " << format <<  std::endl ;
#endif

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;

  // format is not 0
  va_list ap;
  int nwrit = -1;
  try {
    va_start( ap , format );
    MscString vformat(format,true);
#ifdef WIN32
    nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
    nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
  }
  catch( ... ) {
     std::cerr << "Exception while printing format '" << format
         << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
  }
  va_end(ap);
  if ( nwrit >= MscDg::BufferSize ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }
  if ( nwrit < 0 ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }

  // message
  MscDg::sendDebugMessage( MscDg::CALLBACK_INFO , 
                          className           ,
                          methodName          ,
                          0                   ,
                          Buffer              );
  return true ;
}



//-------------------------------------------------------------------
// TRACKER UTILITY
//-------------------------------------------------------------------

static MscDg::TrackerInfo TRACKER[] = {
  { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , 
  { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , // 10
  { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , 
  { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , // 20
  { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , 
  { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" } , { "" , "" }   // 30
};
static int NumberOfTraces  = sizeof(TRACKER) / sizeof(TRACKER[0]) ;
static int LastTrackerIndex = 0;
static int LastTrackerRank  = 0;
bool MscDg::myShowTrackerTraces = false ;

const MscDg::TrackerInfo * MscDg::getTrackerInfo( int & arraySize , int & lastIndex , int & rank )
{
  arraySize = NumberOfTraces   ;
  lastIndex = LastTrackerIndex ;
  rank      = LastTrackerRank  ;
  return TRACKER ;
}

MscString MscDg::getTrackerString()
{
  MscString str ;
  str.printf( "Last %d traces of %d, starting from the most recent:\n" , NumberOfTraces , LastTrackerRank );
  int i=0 , lstIdx=LastTrackerIndex ;
  for ( i=0 ; i < NumberOfTraces ; ++i ) {
    // add 
    MscString tmp ;
    tmp.printf( "   %s::%s\n" , TRACKER[lstIdx].myClassName , TRACKER[lstIdx].myMethodName );
    str += tmp ;
    // next
    lstIdx -= 1 ;
    if ( lstIdx < 0 ) { lstIdx += NumberOfTraces ; }
  }
  return str ;
}

void MscDg::tracker( int type , const char * className , const char * methodName )
{ 
  if ( className  == 0 ) { className  = "" ; }
  if ( methodName == 0 ) { methodName = "" ; }
  // compare with previous
  if ( TRACKER[LastTrackerIndex].myClassName != className || TRACKER[LastTrackerIndex].myMethodName != methodName ) {
    // next one
    LastTrackerIndex += 1 ;
    LastTrackerIndex %= NumberOfTraces ;
    // save
    TRACKER[LastTrackerIndex].myClassName  = className  ;
    TRACKER[LastTrackerIndex].myMethodName = methodName ;
    // show
    if ( MscDg::myShowTrackerTraces == true ) {
       std::cerr << LastTrackerRank << " " << type << "  "
           << TRACKER[LastTrackerIndex].myClassName << "::" << TRACKER[LastTrackerIndex].myMethodName <<  std::endl ;
    }
  }
  // update the rank
  LastTrackerRank += 1 ;
}




void MscDg::print( const char * format , ... )
{
  // No message if nothing to print-out
  if ( MscUtl::isBlank( format ) == true ) { return ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::print()" << (myInstance ? " HasInstance " : " NoInstance ")
       << " Format " << format <<  std::endl ;
#endif

  // nothing to do
  if ( myInstance == 0 ) {
    return ;
  }

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;
  
  // format is not 0
  va_list ap;
  int nwrit = -1;
  try {
    va_start( ap , format );
    MscString vformat(format,true);
#ifdef WIN32
    nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
    nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
  }
  catch( ... ) {
     std::cerr << "Exception while printing format '" << format
         << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
  }
  va_end(ap);
  if ( nwrit >= MscDg::BufferSize ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }
  if ( nwrit < 0 ) {
     std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
  }

  // messsage
  MscDg::sendDebugMessage( MscDg::CALLBACK_INFO  ,
                          0                    ,
                          0                    ,
                          0                    ,
                          Buffer               );
}




void MscDg::print( const MscString & msg )
{
  // No message if nothing to print-out
  if ( msg.isBlank() == true ) { return ; }

#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::print()" << (myInstance ? " HasInstance " : " NoInstance ")
       << " Message " << msg <<  std::endl ;
#endif

  // nothing to do
  if ( myInstance == 0 ) {
    return ;
  }

  // messsage
  MscDg::sendDebugMessage( MscDg::CALLBACK_INFO  ,
                          0                    ,
                          0                    ,
                          0                    ,
                          msg.c_str()          );
}



/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  THIS PART PERTAINS TO THE DEBUG AND TIMER MESSAGE SENDING
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/


/**************************************************************
 *  WARNING: use print outs and not the 'MscDg' functionnalities
 *  for the trace print-out (MscDg::trace(), ... )
 *  identified with 'DEBUGGING'.
 *  Else it can go round and round (infinite loop)
 *************************************************************/

//#define DEBUGGING

//#define DEBUGGING_READ
//#define DEBUGGING_TRACE
//#define DEBUGGING_OPERATION
//#define DEBUGGING_SET



/** DEFAULT VALUES TO PRINT INSIDE
 * DEBUG_REFERENCE_FILE : generated file to include in the application (move it, rename it
 * DEBUG_USER_FILE      : default user values (name can be customized in 'setOperation()')
 */
static const char * DEBUG_REFERENCE_FILE = "ReferenceDebugValues.hpp"   ;
static const char * APPLICATION_REFERENCE_FILE = "ApplicationReferenceDebugValues.hpp";
static const char * DEBUG_USER_FILE      = "UserDebugValues.txt"        ;
static const char * DEBUG_REFERENCE_FLAG = "DEBUG_REFERENCE_Flag" ;


/** FLAGS */
static const char * STR_TRUE         = "true"      ;
static const char * STR_FALSE        = "false"     ;
const  char * MscDg::STR_MEMORY      = "MEMORY"    ;
static const char * STR_MEMORY_ON    = "memoryOn"  ;
static const char * STR_MEMORY_OFF   = "memoryOff" ;
const  char * MscDg::STR_TIMER       = "TIMER"     ;
static const char * STR_TIMER_ON     = "timerOn"   ;
static const char * STR_TIMER_OFF    = "timerOff"  ;
const  char * MscDg::STR_TRACE       = "trace"     ;
static const char * STR_TRACE_ON     = "traceOn"   ;
static const char * STR_TRACE_OFF    = "traceOff"  ;


/** VALUES */
MscDg * MscDg::myInstance = 0 ;
const char * MscDg::CLASS_NAME = "MscDg";
MscDg::ClassMap MscDg::myReferenceClassMap ;
MscString MscDg::myDefaultUserFile ;
MscString MscDg::myReferenceFlag   ;



MscDg::DebugCallbackMap MscDg::myDebugCallbackMap ;



static MscString INT_TO_STRING( int i ) 
{
  MscString str ;
  str.printf( "%d" , i );
  return str ;
}





/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 * CLASS TO KEEP THE TIME-OUT AND THE TRACE INFORMATION
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/



DbDebugInfo::~DbDebugInfo()
{
  delete myTimer  ;
  delete myMemory ;
}



void DbDebugInfo::copyOptions( DbDebugInfo * debugInfo )
{
  if ( debugInfo != 0 ) {
    myUsage      = debugInfo->myUsage      ;
    myTraceIsOn  = debugInfo->myTraceIsOn  ;
    myTimerIsOn  = debugInfo->myTimerIsOn  ;
    myMemoryIsOn = debugInfo->myMemoryIsOn ;
  }
#ifdef DEBUGGING_SET
   std::cerr << "DbDebugInfo::copyOptions(" << debugInfo << ")" ;
   std::cerr << " myUsage " << myUsage << " Trace " << myTraceIsOn << " " << myTimerIsOn ;
   std::cerr <<  std::endl ;
#endif
}



void DbDebugInfo::startTimer()
{
  if ( myTimer == nullptr ) {
    myTimer = new DbDebugInfo::Timer();
  }
  myTimer->start(); 
  // increase the spacing
}



void DbDebugInfo::stopTimer()
{
  if ( myTimer != nullptr ) {
    myTimer->stop();
    // decrease the spacing
  }
}


const char * DbDebugInfo::getTimerString()
{
  if ( myTimer != nullptr ) {
    myTimerString.printf( "Ellapsed %g CPU %g" , myTimer->getElapsedTime() , myTimer->getCpuTime() );
  }
  else {
    myTimerString = "noTimer" ;
  }
  return myTimerString.c_str();
}


void DbDebugInfo::setTimerName( const MscString & n ) 
{
  if ( myTimer != nullptr ) {
    myTimer->setName( n ) ;
  }
}



const char * DbDebugInfo::getTimerName()
{
  if ( myTimer != nullptr ) {
    return myTimer->getName().c_str(); 
  }
  else {
    return "noTimer" ;
  }
}



void DbDebugInfo::startMemory()
{
  if ( myMemory == nullptr ) {
    myMemory = new DbDebugInfo::MemorySnapShot();
  }
  myMemory->start(); 
}



void DbDebugInfo::stopMemory()
{
  if ( myMemory != nullptr ) {
    myMemory->stop();
  }
}


const char * DbDebugInfo::getMemoryString()
{
  if ( myMemory != nullptr ) {
    myMemoryString = "Memory: ";
    myMemoryString += myMemory->getString() ;
  }
  else {
    myMemoryString = "noMemory" ;
  } 
  return myMemoryString.c_str();
}



void DbDebugInfo::setMemoryName( const MscString & n )
{
  if ( myMemory != nullptr ) {
    myMemory->setName( n ) ;
  }  
}



const char * DbDebugInfo::getMemoryName()
{
  if ( myMemory != nullptr ) {
    return myMemory->getName().c_str(); 
  }
  else {
    return "noMemory" ;
  }
}



/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  OUTPUTS
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/





/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 * SINGLETON
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/


MscDg::MscDg()
{
  if ( myInstance != 0 ) {
    MscDg::error( CLASS_NAME , "MscDg()" , "instance already defined." );
  }
  myInstance = this ;
}



MscDg::~MscDg()
{
  if ( myInstance != this ) {
    MscDg::error( CLASS_NAME , "~MscDg()" , "instance already defined." );
  }
  myInstance = 0 ;
}



void MscDg::addDebugCallback( DebugCallbackType type , DebugCallback cb , void * userData )
{
  // null : so remove it if present
  if ( cb == 0 ) {
    MscDg::DebugCallbackMap::iterator iter = MscDg::myDebugCallbackMap.find( type );
    if ( iter != MscDg::myDebugCallbackMap.end() ) {
      MscDg::myDebugCallbackMap.erase(iter);
    }
  }
  // save it
  if ( cb != 0 ) {
    std::pair< MscDg::DebugCallback , void * > pr( cb , userData );
    MscDg::myDebugCallbackMap[ type ] = pr ;
  }
}


void MscDg::removeDebugCallback( MscDg::DebugCallbackType type , MscDg::DebugCallback cb ,
                                void * userData )
{
  MscDg::DebugCallbackMap::iterator iter = MscDg::myDebugCallbackMap.find( type );
  if ( iter != MscDg::myDebugCallbackMap.end() ) {
    MscDg::myDebugCallbackMap.erase(iter);
  }
  else {
     std::cerr << "MscDg::(removeDebugCallback() NOT FOUND" <<  std::endl ;
  }
}



void MscDg::sendDebugMessage( MscDg::DebugCallbackType type , 
                             const char * className , const char * methodName , 
                             int debugId ,
                             const char * buffer )
{
#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::sendDebugMessage()"
             << "  Type "   <<  type
             << "  Class "  << (className ? className : "")
             << "  Method " << (methodName ? methodName : "")
             << "  Id "     <<  debugId
             << "  Buffer '" << (buffer ? buffer : "") << "'" <<  std::endl ;
#endif

  // messsage
  DbDebugMessage message( type ,
                          className ,
                          methodName ,
                          debugId );
  
  // local 
  MscDg::DebugCallbackMap::iterator iter = MscDg::myDebugCallbackMap.find( message.myCallbackType );
  if ( iter == MscDg::myDebugCallbackMap.end() ) {
    switch ( type ) {
    case MscDg::CALLBACK_ASSERT :
    case MscDg::CALLBACK_FATAL  :
       std::cerr << message.getTitle() << buffer <<  std::endl ;
      exit(0);
      break;
    default :
       std::cerr << message.getTitle() << buffer <<  std::endl ;
    }
  }
  // delegated
  else {
    message.myMessage = buffer ;
    iter->second.first( iter->second.second , & message );
  }
}



void MscDg::setReferenceValues( DebugInfoStruct * values , int n )
{
  static const char * METHOD_NAME = "setReferenceValues()" ;
  if ( values == 0 ) { n=0 ; }
  for ( int i=0 ; i < n ; ++i ) {
    // check the extra apaces for the class...
    MscString str ;
    str = values[i].myClassName ;
    str.strip();
    if ( str != values[i].myClassName ) { 
      MscDg::error( CLASS_NAME , METHOD_NAME , "extra space in class '%s'  ('%s' '%s'  %d)" , values[i].myClassName , 
                   values[i].myClassName , values[i].myMethodName , values[i].myDebugId );
    }
    // ... and for the method
    str = values[i].myMethodName ;
    str.strip();
    if ( str != values[i].myMethodName ) { 
      MscDg::error( CLASS_NAME , METHOD_NAME , "extra space in method '%s'  ('%s' '%s'  %d)" , values[i].myMethodName ,
                   values[i].myClassName , values[i].myMethodName , values[i].myDebugId ); 
    }
    // create the storage
    DbDebugInfo * referenceDebugInfo = myGetDebugInfo( & myReferenceClassMap ,
                                                       values[i].myClassName , values[i].myMethodName  , values[i].myDebugId ,
                                                       true );
    MscString value( values[i].myValue );
    if ( value == STR_TRACE ) {
      referenceDebugInfo->useItForTrace();
    }
    else if ( value == STR_TIMER ) {
      referenceDebugInfo->useItForTimer();
    }
    else if ( value == STR_MEMORY ) {
      referenceDebugInfo->useItForMemory();
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "undefined value '%s'" , value.c_str() );
    }
  }  
}



bool MscDg::setOperation( MscDg::DebugOperation operation , const char * filePathName )
{
  static const char * METHOD_NAME = "setOperation()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Operation %d FileName '%s'" ,
               operation , (filePathName ? filePathName : "") );
  bool isOk = false ;

  //------------------------------
  // create the instance if needed
  //------------------------------
  MscString pathname ;
  
  switch ( operation ) {
    //------------------------------
    // *** GENERATE THE FILE, SO USER VALUES MUST BE KEPT
    //------------------------------
  case MscDg::DEBUG_GENERATE_REFERENCE :
    // flag in the generated (include) file
    myReferenceFlag = filePathName ? filePathName : DEBUG_REFERENCE_FLAG ;
    if ( myInstance == 0 ) { 
      new MscDg();
    }
    break;
    //------------------------------
    // *** FILE GENERATION MUST HAVE BEEN DECIDED BEFORE
    //------------------------------
  case MscDg::DEBUG_WRITE_REFERENCE        :
    // will do it ONLY if it has been initialized before by 
    // 'MscDg::setOperation( MscDg::DEBUG_GENERATE_REFERENCE )'
    if ( myReferenceFlag.isEmpty() == true ) {
      return false ;
    }
    break;
    //------------------------------
    // *** DEFINE THE USER DEBUG FILE
    //------------------------------
  case MscDg::DEBUG_DEFAULT_USER_FILE :
    myDefaultUserFile = filePathName ;
    break;
    //------------------------------
    // *** FILE MUST EXIST
    //------------------------------
  case MscDg::DEBUG_READ_CURRENT :   
    // the file name
    pathname = filePathName ;
    if ( pathname.isBlank() == true ) {
      pathname = myDefaultUserFile ;
    }
    if ( pathname.isBlank() == true ) {
      pathname.printf( "%s%s" , MscUtl::homeDirectory().c_str() , DEBUG_USER_FILE );
      pathname.replace( '\\' , '/' );
    }
    // file must exist
    if ( MscUtl::fileExists( pathname ) == false ) {
      MscDg::trace( CLASS_NAME , METHOD_NAME , "File '%s' does not exist." , pathname.c_str() );
      return false ;
    }
    filePathName = pathname.c_str();
    // instance must exist
    if ( myInstance == 0 ) { 
      new MscDg();
    }
    break;
    //------------------------------
    // *** USER FORCE A WRITE
    //------------------------------
  case MscDg::DEBUG_WRITE_CURRENT_SELECTED :    
    if ( myInstance == 0 ) { 
      new MscDg();
    }
    break;
    //------------------------------
    // *** DEFAULT SAVE: NOTHING TO DO IF NOTHING  IS SELECTED
    //------------------------------
  case MscDg::DEBUG_WRITE_CURRENT_DEFAULT :
    break;
  }

  //------------------------------
  // nothing to do
  //------------------------------

  if ( myInstance == 0 ) { 
    return isOk ;
  }

  //------------------------------
  // define what to do
  //------------------------------

  switch ( operation ) {
  case MscDg::DEBUG_WRITE_REFERENCE        :
    // will do it ONLY if it has been initialized before by 
    // 'MscDg::setOperation( MscDg::DEBUG_GENERATE_REFERENCE )'
    if ( myReferenceFlag.isEmpty() == false ) {
      isOk = myInstance->myWriteMap( operation , filePathName );
    }
    break;
  case MscDg::DEBUG_WRITE_CURRENT_DEFAULT  :
  case MscDg::DEBUG_WRITE_CURRENT_SELECTED :
    isOk = myInstance->myWriteMap( operation , filePathName );
    break;
  case MscDg::DEBUG_READ_CURRENT   :
    isOk = myInstance->myReadMap( filePathName );
    break;
  }
  return isOk ;
}



DbDebugInfo * MscDg::getDebugInfo( const char * className , const char * methodName , int debugId ,
                                  bool createIt )
{
  if ( myInstance == 0 && createIt == false ) {
    return 0 ;
  }
  // instance is created if it does not exist
  if ( myInstance == 0 ) {
    new MscDg();
  }  
  return myGetDebugInfo( & myInstance->myDebugClassMap ,
                         className , methodName , debugId ,
                         createIt );
}



const MscDg::ClassMap & MscDg::getReferenceClassMap( bool updateWithUserChoices ) 
{
  // add the items that are selected
  if ( updateWithUserChoices == true && myInstance != 0 ) {
    MscDg::ClassMap::iterator classIter ;
    for ( classIter=myInstance->myDebugClassMap.begin() ; classIter != myInstance->myDebugClassMap.end() ; ++classIter ) {
      MscDg::MethodMap::iterator methodIter ;
      for ( methodIter=classIter->second.begin() ; methodIter != classIter->second.end() ; ++methodIter ) {
        MscDg::IdMap::iterator idIter ;
        for ( idIter=methodIter->second.begin() ; idIter != methodIter->second.end() ; ++idIter ) {
          DbDebugInfo * currentDebugInfo = idIter->second ;
          if ( currentDebugInfo != 0 ) {
            // create it if needed
            DbDebugInfo * referenceDebugInfo = myGetDebugInfo( & myReferenceClassMap     ,
                                                               classIter->first.c_str()  ,
                                                               methodIter->first.c_str() ,
                                                               idIter->first             ,
                                                               true );
            referenceDebugInfo->copyOptions( currentDebugInfo );
#ifdef DEBUGGING_SET
             std::cerr << "MscDg::getReferenceClassMap() "
                 << classIter->first.c_str() << " "
                 << methodIter->first.c_str() << " "
                 << idIter->first  ;
            if ( referenceDebugInfo->isUsedForTrace() == true ) { 
              if ( referenceDebugInfo->getTraceIsOn() == true ) {
                 std::cerr << STR_TRACE_ON  ;
              }
              else {
                 std::cerr << STR_TRACE_OFF ;
              }
            }
             std::cerr << " " ;
            if ( referenceDebugInfo->isUsedForTimer() == true ) {
              if ( referenceDebugInfo->getTimerIsOn() == true ) {
                 std::cerr << STR_TIMER_ON  ;
              }
              else {
                 std::cerr << STR_TIMER_OFF ;
              }
            }
             std::cerr << " " ;
            if ( referenceDebugInfo->isUsedForMemory() == true ) {
              if ( referenceDebugInfo->getMemoryIsOn() == true ) {
                 std::cerr << STR_MEMORY_ON  ;
              }
              else {
                 std::cerr << STR_MEMORY_OFF ;
              }
            }
             std::cerr <<  std::endl ;
#endif            
          }
        }
      }
    }
  }
  // return the values
  return myReferenceClassMap ; 
}





/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 * METHODS FOR THE MEMORY
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/



void MscDg::selectMemory( const char * className , const char * methodName , int debugId , bool isSelected )
{
  // CREATE the memory snapshot if it needs to be selected
  // (by default, if it doesn't exist, it is not selected)
  DbDebugInfo * info = getDebugInfo( className , methodName , debugId , isSelected );
  if ( info != 0 ) {
    info->setMemoryIsOn(isSelected);
  }
#ifdef DEBUGGING_SET
   std::cerr << "MscDg::selectMemory() "
             << className << " " << methodName << " " << debugId
             << " IsSelected " << isSelected
             << (info ? "  " : " NOT FOUND")
             <<  std::endl ;
#endif
}



bool MscDg::isMemorySelected( const char * className , const char * methodName , int debugId )
{
  // generate
  if ( myReferenceFlag.isEmpty() == false ) {
    DbDebugInfo * referenceMemory = myGetDebugInfo( & myReferenceClassMap , className , methodName , debugId , true );
    // indicate memory snapshot facility is used
    referenceMemory->useItForMemory();
  }
  // find the memory snapshot. Do not create it if it does not exist
  DbDebugInfo * info = getDebugInfo( className , methodName , debugId , false );
  // if the memory snapshot does not exist , it is not selected
  return info ? info->getMemoryIsOn() : false ;
}



void MscDg::startMemory( const char * className , const char * methodName , int debugId , MscString message )
{
  if ( isMemorySelected( className , methodName , debugId ) == true ) {
    DbDebugInfo * info = getDebugInfo( className , methodName , debugId , false ) ;
    if ( info != 0 ) {
      info->setMemoryName( message );
      info->startMemory();
      // message
      MscDg::sendDebugMessage( MscDg::CALLBACK_MEMORY , 
                              className             ,
                              methodName            ,
                              debugId               ,
                              message.c_str()       );
    }
  }
}



void MscDg::stopMemory( const char * className , const char * methodName , int debugId )
{
  if ( isMemorySelected( className , methodName , debugId ) == true ) {
    DbDebugInfo * info = getDebugInfo( className , methodName , debugId , false ) ;
    if ( info != 0 ) {
      info->stopMemory();
      // message
      MscDg::sendDebugMessage( MscDg::CALLBACK_MEMORY   ,
                              className               ,
                              methodName              ,
                              debugId                 ,
                              info->getMemoryString() );
    }
  }
}



/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 * METHODS FOR THE TIMERS
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/



void MscDg::selectTimer( const char * className , const char * methodName , int debugId , bool isSelected )
{
  // CREATE the timer if it needs to be selected
  // (by default, if it doesn't exist, it is not selected)
  DbDebugInfo * info = getDebugInfo( className , methodName , debugId , isSelected );
  if ( info != 0 ) {
    info->setTimerIsOn(isSelected);
  }
#ifdef DEBUGGING_SET
   std::cerr << "MscDg::selectTimer() "
       << className << " " << methodName << " " << debugId 
       << " IsSelected " << isSelected 
       << (timer ? "  " : " NOT FOUND")
       <<  std::endl ;
#endif
}



bool MscDg::isTimerSelected( const char * className , const char * methodName , int debugId )
{
  // generate
  if ( myReferenceFlag.isEmpty() == false ) {
    DbDebugInfo * referenceTimer = myGetDebugInfo( & myReferenceClassMap , className , methodName , debugId , true );
    // indicate timer facility is used
    referenceTimer->useItForTimer();
  }
  // find the timer. Do not create it if it does not exist
  DbDebugInfo * info = getDebugInfo( className , methodName , debugId , false );
  // if the timer does not exist , it is not selected
  return info ? info->getTimerIsOn() : false ;
}



void MscDg::startTimer( const char * className , const char * methodName , int debugId , const char * format , ... )
{
  if ( isTimerSelected( className , methodName , debugId ) == true ) {
    DbDebugInfo * info = getDebugInfo( className , methodName , debugId , false ) ;
    if ( info != 0 ) {
      // the buffer: same as in 'MscString::printf'
      static char Buffer[ MscDg::BufferSize ];
      Buffer[0] = '\0' ;
      // message
      MscString message ;
      // format is not 0
      if ( format != 0 ) {
        va_list ap;
        int nwrit = -1;
        try {
          va_start( ap , format );
          MscString vformat(format,true);
#ifdef WIN32
          nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
          nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
        }
        catch( ... ) {
           std::cerr << "Exception while printing format '" << format
               << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
        }
        va_end(ap);
        if ( nwrit >= MscDg::BufferSize ) {
           std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
        }
        if ( nwrit < 0 ) {
           std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
        }
        // storage of the buffer
        message = Buffer ;
      }
      // set message
      info->setTimerName( message );
      info->startTimer();
      // message
      MscDg::sendDebugMessage( MscDg::CALLBACK_TIMER , 
                              className            ,
                              methodName           ,
                              debugId              ,
                              message.c_str()      );
    }
  }
}


void MscDg::startTimer( const char * className , const char * methodName , int debugId , MscString message )
{
  if ( isTimerSelected( className , methodName , debugId ) == true ) {
    DbDebugInfo * info = getDebugInfo( className , methodName , debugId , false ) ;
    if ( info != 0 ) {
      info->setTimerName( message );
      info->startTimer();
      // message
      MscDg::sendDebugMessage( MscDg::CALLBACK_TIMER , 
                              className            ,
                              methodName           ,
                              debugId              ,
                              message.c_str()      );
    }
  }
}



void MscDg::stopTimer ( const char * className , const char * methodName , int debugId )
{
  if ( isTimerSelected( className , methodName , debugId ) == true ) {
    DbDebugInfo * info = getDebugInfo( className , methodName , debugId , false ) ;
    if ( info != 0 ) {
      info->stopTimer();
      // message
      MscDg::sendDebugMessage( MscDg::CALLBACK_TIMER , 
                              className ,
                              methodName ,
                              debugId ,
                              info->getTimerString() );
    }
  }
}




/** ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 * METHODS FOR THE TRACES
 *  ------------------------------------------------------------------------------------------------
 *  ------------------------------------------------------------------------------------------------
 *  ----------------------------------------------------------------------------------------------*/



void MscDg::setOn( const char * className , const char * methodName , int debugId , bool isOn )
{
  if ( myInstance == 0 ) {
    // create it only if needed
    if ( isOn == true ) {
      new MscDg();
    }
    else {
      return ;
    }
  }
  myInstance->mySetTraceIsEnabled(className,methodName,debugId,isOn) ; 
}



bool MscDg::trace( const char * className , const char * methodName , const char * format , ... )
{
  MscDg::tracker( 0 , className , methodName );
#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::trace()" << (myInstance ? " HasInstance " : " NoInstance ")
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Format " << (format ? format : "") <<  std::endl ;
#endif

  // nothing to do
  if ( myInstance == 0 || myInstance->myGetTraceIsEnabled(className,methodName,0) == false ) {
    return false ;
  }

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;

  // format is not null
  if ( format != 0 ) {
    va_list ap;
    int nwrit = -1;
    try {
      va_start( ap , format );
      MscString vformat(format,true);
#ifdef WIN32
      nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
      nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
    }
    catch( ... ) {
       std::cerr << "Exception while printing format '" << format
           << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
    }
    va_end(ap);
    if ( nwrit >= MscDg::BufferSize ) {
       std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
    }
    if ( nwrit < 0 ) {
       std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
    }
  }
  // messsage
  MscDg::sendDebugMessage( MscDg::CALLBACK_TRACE , 
                          className            ,
                          methodName           ,
                          0                    ,
                          Buffer               );
  return true ;
}



bool MscDg::trace( const char * className , const char * methodName , const MscString & msg )
{
  MscDg::tracker(  0 , className , methodName );
#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::trace()" << (myInstance ? " HasInstance " : " NoInstance ")
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Message " << msg <<  std::endl ;
#endif

  // nothing to do
  if ( myInstance == 0 || myInstance->myGetTraceIsEnabled(className,methodName,0) == false ) {
    return false ;
  }

  // messsage
  MscDg::sendDebugMessage( MscDg::CALLBACK_TRACE , 
                          className            ,
                          methodName           ,
                          0                    ,
                          msg.c_str()          );
  return true ;
}



bool MscDg::trace( const char * className , const char * methodName , int debugId , const char * format , ... )
{
  MscDg::tracker(  0 , className , methodName );
#ifdef DEBUGGING_TRACE
   std::cerr << "MscDg::trace()" << (myInstance ? " HasInstance " : " NoInstance ")
       << " Class " << (className ? className : "") << " Method " << (methodName ? methodName : "") 
       << " Format " << (format ? format : "") <<  std::endl ;
#endif

  // nothing to do
  if ( myInstance == 0 || myInstance->myGetTraceIsEnabled(className,methodName,debugId) == false ) {
    return false ;
  }

  // the message: same as in 'MscString::printf'
  static char Buffer[ MscDg::BufferSize ];
  Buffer[0] = '\0' ;

  // format can be 0
  if ( format != 0 ) {
    va_list ap;
    int nwrit = -1;
    try {
      va_start( ap , format );
      MscString vformat(format,true);
#ifdef WIN32
      nwrit = _vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#else
      nwrit =  vsnprintf(Buffer,MscDg::BufferSize,vformat.c_str(),ap);
#endif
    }
    catch( ... ) {
       std::cerr << "Exception while printing format '" << format
           << "' Check for using %%d when printing might use %%lld instead." <<  std::endl ;
    }
    va_end(ap);
    if ( nwrit >= MscDg::BufferSize ) {
       std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
    }
    if ( nwrit < 0 ) {
       std::cerr << "Message buffer overflow for format '" << format << "'" <<  std::endl ;
    }
  }

  // messsage
  MscDg::sendDebugMessage( MscDg::CALLBACK_TRACE , 
                          className            ,
                          methodName           ,
                          debugId              ,
                          Buffer               );
  return true ;
}



DbDebugInfo * MscDg::myGetDebugInfo( MscDg::ClassMap * classMap , 
                                    const char * className , const char * methodName , int debugId ,
                                    bool createIt )
{
  DbDebugInfo * timer = 0 ;
#ifdef DEBUGGING_OPERATION
   std::cerr << "MscDg::myGetDebugInfo() " << className << " " << methodName << " " << debugId << " CreateIt " << createIt <<  std::endl ;
#endif
  // find 'className'
  MscDg::ClassMap::iterator classIter = classMap->find(className);
  if ( classIter == classMap->end() ) { 
    if ( createIt == false ) { return 0 ; }
    MscDg::IdMap tm ;
    tm[ debugId ] = 0 ;
    MscDg::MethodMap md ; 
    md[ methodName ] = tm ;
    (*classMap)[ className ] = md ;
    classIter = classMap->find(className);
  }
  // find 'methodName'
  MscDg::MethodMap::iterator methodIter = classIter->second.find(methodName);
  if ( methodIter == classIter->second.end() ) {
    if ( createIt == false ) { return 0 ; }
    MscDg::IdMap tm ;
    tm[ debugId ] = 0 ;
    classIter->second[ methodName ] = tm ;
    methodIter = classIter->second.find(methodName); 
  }
  // find 'debugId'
  MscDg::IdMap::iterator idIter = methodIter->second.find(debugId);
  if ( idIter == methodIter->second.end() ) {
    if ( createIt == false ) { return 0 ; }
    methodIter->second[ debugId ] = 0 ;
    idIter = methodIter->second.find(debugId);
  }
  // create 'DbDebugInfo'
  if ( idIter->second == 0 ) {
    if ( createIt == false ) { return 0 ; }
    idIter->second = new DbDebugInfo();
  }
#ifdef DEBUGGING_OPERATION
   std::cerr << "MscDg::myGetDebugInfo() " << className << " " << methodName << " " << debugId << " DONE " << idIter->second <<  std::endl ;
#endif
  return idIter->second ;  
}



bool MscDg::myGetTraceIsEnabled( const char * className , const char * methodName , int debugId )
{
  if ( className == 0 || methodName == 0 ) {
    return false ;
  }
  // generate
  if ( myReferenceFlag.isEmpty() == false ) {
    DbDebugInfo * referenceTimer = myGetDebugInfo( & myReferenceClassMap , className , methodName , debugId , true );
    // indicate trace facility is used
    referenceTimer->useItForTrace();
  }

  //------------------------------------------
  // First try to find the specific value
  //
  // FIRST  LOOP : test with the "className" class name
  // SECOND LOOP : test with "*" class name
  //------------------------------------------
  
  MscDg::ClassMap::iterator  classIter  = myDebugClassMap.end() ;
  MscDg::MethodMap::iterator methodIter ;
  MscDg::IdMap::iterator     idIter     ;
  DbDebugInfo             * debugInfo  = 0 ;

  for ( int loop=1 ; loop <= 2 ; ++loop ) {
    
    // not found for this class . try any.
    classIter = myDebugClassMap.find( (loop == 1) ? className : "*" );
    if ( classIter == myDebugClassMap.end() ) { 
      continue ;
    }
    // avoid class startig with "TT" . It's a test for the such as ""
    if ( loop == 2 && ::strstr( className , "TT" ) == className ) {
       std::cerr << className << " starts with TT" <<  std::endl ;
      continue ;
    }

    // specific method : accept this method of any class : "className methodName ? true"  
    methodIter = classIter->second.find(methodName);
    if ( methodIter != classIter->second.end() ) {
      // specific ident
      idIter = methodIter->second.find(debugId);
      if ( idIter != methodIter->second.end() && idIter->second != 0 ) {
        debugInfo = idIter->second ;
        break;
      }
      // any ident
      idIter = methodIter->second.find(-1);
      if ( idIter != methodIter->second.end() && idIter->second != 0 ) {
        debugInfo = idIter->second ;
        break;
      }
    }

    // any method : accept any method : "className * ? true" 
    methodIter = classIter->second.find("*");
    if ( methodIter != classIter->second.end() ) {
      // specific ident
      idIter = methodIter->second.find(debugId);
      if ( idIter != methodIter->second.end() && idIter->second != 0 ) {
        debugInfo = idIter->second ;
        break;
      }
      // any ident
      idIter = methodIter->second.find(-1);
      if ( idIter != methodIter->second.end() && idIter->second != 0 ) {
        debugInfo = idIter->second ;
        break;
      }
    }

    // not found ... try next loop
  }

  //------------------------------------------
  // Results . ARNING : do NOT use MscDg::trace
  // here ( std::endless loop ...)
  //------------------------------------------

#ifdef DEBUGGING
   std::cerr << "MscDg::myGetTraceIsEnabled( Class '" << className
       << "' Method '" << methodName << "' Id  " << debugId << " ) " ;
#endif
  
  // Seen it
  if ( debugInfo != 0 ) {
#ifdef DEBUGGING
     std::cerr << "Info with " << (debugInfo->getTraceIsOn() ? STR_TRUE : STR_FALSE) <<  std::endl ;
#endif
    return debugInfo->getTraceIsOn() ;
  }
  // not found
  else if ( classIter == myDebugClassMap.end() ) {
#ifdef DEBUGGING
     std::cerr << "Class not found"  <<  std::endl ;
#endif
    return false ;
  }
  else if ( methodIter == classIter->second.end() ) {
#ifdef DEBUGGING
     std::cerr << "Method not found"  <<  std::endl ;
#endif
    return false ;
  }
  else if ( idIter == methodIter->second.end() ) {
#ifdef DEBUGGING
     std::cerr << "Ident not found"  <<  std::endl ;
#endif
    return false ;
  }
  else {
#ifdef DEBUGGING
     std::cerr << "Info is null"  <<  std::endl ;
#endif
    return false ;
  }
}



void MscDg::mySetTraceIsEnabled( const char * className , const char * methodName , int debugId ,
                                bool enableIt )
{
#ifdef DEBUGGING
   std::cerr << "MscDg::mySetTraceIsEnabled( " << className << " " << methodName << " " << debugId
       << " ) Enabled " << enableIt <<  std::endl ;
#endif
  DbDebugInfo * debugInfo = myGetDebugInfo( & myDebugClassMap ,
                                            className , methodName , debugId ,
                                            enableIt );
  if ( debugInfo != 0 ) {
    debugInfo->setTraceIsOn( enableIt );
  }
}




bool MscDg::myWriteMap( MscDg::DebugOperation operation , const char * filePathName )
{
  static const char * METHOD_NAME = "myWriteMap()" ;

  // reference to write : first copy the current options
  if ( operation == MscDg::DEBUG_WRITE_REFERENCE ) {    
    // first copy the current options (update it)
    getReferenceClassMap( true ) ;
  }

  // the data to write and the filename
  MscDg::ClassMap * classMap = 0 ;
  MscString pathname(filePathName);
  switch( operation ) {
    case MscDg::DEBUG_WRITE_REFERENCE :
    {
      // data
      classMap = & myReferenceClassMap ;
      // file name
      if ( pathname.isBlank() == true ) {
        pathname = MscDirectoryInfo::getHomeDirectoryFile(DEBUG_REFERENCE_FILE);
      }
    } break;
    case MscDg::DEBUG_WRITE_CURRENT_DEFAULT  :
    case MscDg::DEBUG_WRITE_CURRENT_SELECTED :
    {
      // data
      classMap = & myDebugClassMap ;
      // file name
      if ( pathname.isBlank() == true ) {
        pathname = myDefaultUserFile ;
      }
      if ( pathname.isBlank() == true ) {
        pathname = MscDirectoryInfo::getHomeDirectoryFile(DEBUG_USER_FILE);
      }
    } break;
    default:
      break;
  }
  if ( classMap == 0 ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "operation %d is not considered" , operation );
    return false ;
  }

  // nothing to save (user values)
  if ( operation == MscDg::DEBUG_WRITE_CURRENT_DEFAULT  ||
       operation == MscDg::DEBUG_WRITE_CURRENT_SELECTED ) { 
    bool doTheWrite = false ;
    MscDg::ClassMap::iterator classIter ;
    for ( classIter=classMap->begin() ; classIter != classMap->end() ; ++classIter ) {
      MscDg::MethodMap::iterator methodIter ;
      for ( methodIter=classIter->second.begin() ; methodIter != classIter->second.end() ; ++methodIter ) {
        MscDg::IdMap::iterator idIter ;
        for ( idIter=methodIter->second.begin() ; idIter != methodIter->second.end() ; ++idIter ) {
          DbDebugInfo * debugInfo = idIter->second ;
          if ( debugInfo != 0 ) {
            if ( operation == MscDg::DEBUG_WRITE_CURRENT_DEFAULT  ||
                 operation == MscDg::DEBUG_WRITE_CURRENT_SELECTED ) { 
              if ( debugInfo->isUsedForTrace() == true ) {
                if ( debugInfo->getTraceIsOn() == true || operation == MscDg::DEBUG_WRITE_CURRENT_DEFAULT ) {
                  doTheWrite = true ;
                  break ;
                }
              }
              if ( debugInfo->isUsedForTimer() == true ) {
                if ( debugInfo->getTimerIsOn() == true || operation == MscDg::DEBUG_WRITE_CURRENT_DEFAULT ) {
                  doTheWrite = true ;
                  break ;
                }
              }
              if ( debugInfo->isUsedForMemory() == true ) {
                if ( debugInfo->getMemoryIsOn() == true || operation == MscDg::DEBUG_WRITE_CURRENT_DEFAULT ) {
                  doTheWrite = true ;
                  break ;
                }
              }
            }
          }
        }
      }
    }
    if ( doTheWrite == false ) {
      // file exists: delete it
      if ( MscUtl::fileExists( pathname ) == true ) {
        MscDg::info( CLASS_NAME , METHOD_NAME , "Nothing to save in the file, so it has been deleted (%s)" ,
                    pathname.c_str() );
        MscUtl::unlink(pathname);
      }
      // nothing to do
      return false ;  
    }
  }

  // open the file
  MscDataAccess da( pathname.c_str() , MscDataAccess::DA_WRITE_ASCII );
  if ( da.isOk() == false ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "file %s is not ok" , pathname.c_str() );
    return false ;
  }

  // header 
  if ( operation == MscDg::DEBUG_WRITE_REFERENCE ) {
    MscString tmp;
    tmp.printf( "#ifndef %s\n" , myReferenceFlag.c_str() );
    da << tmp.c_str() ;
    tmp.printf( "#define %s\n" , myReferenceFlag.c_str() );
    da << tmp.c_str() ;
    da << " \n" ;
    da << " \n" ;
    da << "/**\n" ;
    da << " * \n" ;
    da << " * GENERATED FILE containing the trace and timer options.\n" ;
    da << " * \n" ;
    da << " * It is generated and will pick up the use of 'MscDg::trace()' and 'MscDg::startTimer()'\n" ;
    da << " * that are called in an application and add them to the existing list (so to this file).\n" ; 
    da << " * This list shows all the possibilities that can be offered to the user.\n" ;
    da << " * \n" ;
    da << " * \n" ;
    da << " * To generate in application: \n";
    da << " * \n" ;
    da << " * (1) once the timer and trace methods are added ('MscDg::startTimer()', 'MscDg::trace()') in the source code,\n";
    da << " * (2) run 'application.<ext> -generate' and make sure the source code is activated.\n";
    da << " *       it will add the newly added functions and create this file '~/" << DEBUG_REFERENCE_FILE << "'\n";
    da << " * (3) copy to the correct location:\n" ;
    da << " *       vp4 edit " << APPLICATION_REFERENCE_FILE << "\n";
    da << " *       cp ~/" << DEBUG_REFERENCE_FILE << " " << APPLICATION_REFERENCE_FILE << "\n" ;
    da << " *       vp4 submit " << APPLICATION_REFERENCE_FILE << "\n";
    da << " * \n" ;
    da << " * \n" ;
    da << " * How this file is generated (source code to add in order to benefit from the functionnalities):\n";
    da << " * \n" ;
    da << " * Use 'MscDg::setReferenceClassMap()' to set the values of this list.\n" ;
    da << " * \n" ;
    da << " * Use at the start : MscDg::setOperation( MscDg::DEBUG_GENERATE_REFERENCE , <flagOfTheFile> )\n" ;
    da << " *                    Remark: could be triggered by a line command such as '-generate' \n";
    da << " * Use at the end   : MscDg::setOperation( MscDg::DEBUG_WRITE_REFERENCE , <fileName > )\n" ;
    da << " * \n" ;
    da << " * In APPLICATION: the '-generate' option triggers the above.\n";
    da << " * \n" ;
    da << " * By default the flag <flagOfTheFile> is '" << DEBUG_REFERENCE_FLAG << "')\n" ;
    da << " * \n" ;
    da << " * Rename the generated file (<filename> default is '~/" << DEBUG_REFERENCE_FILE << "')\n" ;
    da << " * move it, save it in perforce and use it in the application:\n" ;
    da << " * Example: '" << APPLICATION_REFERENCE_FILE << "'\n" ;
    da << " * \n" ;
    da << " * #include \"" << DEBUG_REFERENCE_FILE << "\" // once it is moved, renamed, and save in perforce\n" ;   
    da << " * Use the values   : MscDg::getReferenceValues( ReferenceDebugValues , NumberOfReferenceDebugValues );\n" ;
    da << " * Show the values to the user with 'MscDg::getReferenceValues()'. It picks up values and the user choices\n";
    da << " *\n";
    da << " * Remark: use 'MscDg::setCallback()' to redirect the ouput.\n";
    da << " * \n" ;
    da << " * \n" ;
    da << " * Alternatively, rather than generating this file, add the description of the trace or timer to it.\n" ;
    da << " * Example: '" << APPLICATION_REFERENCE_FILE << "'\n" ;
    da << " * \n" ;
    da << " */\n" ;
    da << " \n" ;
    da << " \n" ;
    da << "static MscDg::DebugInfoStruct ReferenceDebugValues[] = {\n" ;
    da << "  " ;
  }

  // values
  int numberOfWrite = 0 ;
  MscString str , tmp ;
  static const int LENGTH_OF_CLASS  = 35 ;
  static const int LENGTH_OF_METHOD = 70 ;
  MscDg::ClassMap::iterator classIter ;
  for ( classIter=classMap->begin() ; classIter != classMap->end() ; ++classIter ) {
    MscDg::MethodMap::iterator methodIter ;
    for ( methodIter=classIter->second.begin() ; methodIter != classIter->second.end() ; ++methodIter ) {
      MscDg::IdMap::iterator idIter ;
      for ( idIter=methodIter->second.begin() ; idIter != methodIter->second.end() ; ++idIter ) {
        DbDebugInfo * debugInfo = idIter->second ;
        if ( debugInfo != 0 ) {
          if ( operation == MscDg::DEBUG_WRITE_REFERENCE ) {
            for ( int loop=1 ; loop <= 3 ; ++loop ) {
              // method to save
              MscString flagStr("undefined");
              switch ( loop ) 
                {
                case 1 :
                  if ( debugInfo->isUsedForTrace() == false ) {
                    continue ;
                  }
                  flagStr.printf( "\"%s\" }" , STR_TRACE  );
                  break ;
                case 2 :
                  if ( debugInfo->isUsedForTimer() == false ) { 
                    continue ; 
                  }
                  flagStr.printf( "\"%s\" }" , STR_TIMER  );
                  break ;
                case 3 :
                  if ( debugInfo->isUsedForMemory() == false ) { 
                    continue ; 
                  }
                  flagStr.printf( "\"%s\" }" , STR_MEMORY );
                  break ;
                }
              // finish previous line
              if ( str.isEmpty() == false ) { da << " ,\n  " ; }
              // class
              str  = "{ \"" ;
              str += classIter->first ;
              str += "\"" ;
              // add spaces
              int i=0 ;
              for ( i=(LENGTH_OF_CLASS  - str.length()) ; i > 0 ; --i ) { str += " " ; }
              // method
              str += " , \"" ;
              str += methodIter->first ;
              str += "\"" ;
              // add spaces    
              for ( i=(LENGTH_OF_METHOD - str.length()) ; i > 0 ; --i ) { str += " " ; }
              // ident
              str += " , " ;
              str += INT_TO_STRING(idIter->first);
              str += " , " ;
              // falg
              str += flagStr ;
              // number to write
              numberOfWrite += 1 ;
              // write it
              da << str ;
            }
          }
          // DEBUG_WRITE_CURRENT_DEFAULT
          else if ( operation == MscDg::DEBUG_WRITE_CURRENT_DEFAULT ) {
            // keep the used values for the traces
            if ( debugInfo->isUsedForTrace() == true ) {
              da << classIter->first << "  " << methodIter->first << "  " ;
              da << INT_TO_STRING(idIter->first) << "  " ;
              da << (debugInfo->getTraceIsOn() ? STR_TRACE_ON : STR_TRACE_OFF) << "\n" ;
              numberOfWrite += 1 ;
            }
            // only keep the timer that are used
            if ( debugInfo->isUsedForTimer() == true ) {
              da << classIter->first << "  " << methodIter->first << "  " ;
              da << INT_TO_STRING(idIter->first) << "  " ;
              da << (debugInfo->getTimerIsOn() ? STR_TIMER_ON : STR_TIMER_OFF) << "\n" ;
              numberOfWrite += 1 ;
            }
            // only keep the memory that are used
            if ( debugInfo->isUsedForMemory() == true ) {
              da << classIter->first << "  " << methodIter->first << "  " ;
              da << INT_TO_STRING(idIter->first) << "  " ;
              da << (debugInfo->getMemoryIsOn() ? STR_MEMORY_ON : STR_MEMORY_OFF) << "\n" ;
              numberOfWrite += 1 ;
            }
          }
          // DEBUG_WRITE_CURRENT_SELECTED
          else if ( operation == MscDg::DEBUG_WRITE_CURRENT_SELECTED ) {
            // keep the used values for the rtraces
            if ( debugInfo->isUsedForTrace() == true && debugInfo->getTraceIsOn() == true ) {
              da << classIter->first << "  " << methodIter->first << "  " ;
              da << INT_TO_STRING(idIter->first) << "  " << STR_TRACE_ON << "\n" ;
              numberOfWrite += 1 ;
            }
            // only keep the timer that are used
            if ( debugInfo->isUsedForTimer() == true && debugInfo->getTimerIsOn() == true ) {
              da << classIter->first << "  " << methodIter->first << "  " ;
              da << INT_TO_STRING(idIter->first) << "  " << STR_TIMER_ON  << "\n" ;
              numberOfWrite += 1 ;
            }
            // only keep the memory that are used
            if ( debugInfo->isUsedForMemory() == true && debugInfo->getMemoryIsOn() == true ) {
              da << classIter->first << "  " << methodIter->first << "  " ;
              da << INT_TO_STRING(idIter->first) << "  " << STR_MEMORY_ON  << "\n" ;
              numberOfWrite += 1 ;
            }
            MscDg::trace( CLASS_NAME , METHOD_NAME , "Wrote Class '%s' Method '%s' Id %d" ,
                         classIter->first.c_str() , methodIter->first.c_str() , idIter->first );
          }
        }
        else {
          MscDg::error( CLASS_NAME , METHOD_NAME , "Can't find debug info for Class '%s' Method '%s' Id %d" ,
                       classIter->first.c_str() , methodIter->first.c_str() , idIter->first );
        }
      }
    }
  }

  // close file
  if ( operation == MscDg::DEBUG_WRITE_REFERENCE ) {
    da << "\n};\n";
    da << "\n" ;
    da << "static const int NumberOfReferenceDebugValues = sizeof(ReferenceDebugValues) / sizeof(ReferenceDebugValues[0]) ; \n" ;
    da << "\n" ;
    da << "\n" ;
    da << "#endif\n";
    da << "\n" ;
  }
  da.close();

  // no values: delete the file
  if ( numberOfWrite  == 0 ) {
    MscDg::info( CLASS_NAME , METHOD_NAME , "Nothing to save in the file, so it has been deleted (%s)" ,
                pathname.c_str() );
    MscUtl::unlink(pathname);
    return false ; 
  }
  // written correctly
  else {
    MscDg::info( CLASS_NAME , METHOD_NAME , "%d lines saved in '%s'" , 
                numberOfWrite , pathname.c_str() );
    return true ;
  }
}



bool MscDg::myReadMap( const char * filePathName )
{
  static const char * METHOD_NAME = "myReadMap()" ;
  bool isOk = false ;
  // the file name (called by MscDg::DEBUG_READ_CURRENT only. So, it's the user file name)
  MscString pathname(filePathName);
  if ( pathname.isBlank() == true ) {
    pathname = myDefaultUserFile ;
  }
  if ( pathname.isBlank() == true ) {
    pathname.printf( "%s%s" , MscUtl::homeDirectory().c_str() , DEBUG_USER_FILE );
    pathname.replace( '\\' , '/' );
  }
  // open the file ... if it exists
  if ( MscUtl::fileExists( pathname ) == false ) {
    MscDg::info( CLASS_NAME , METHOD_NAME , "File '%s' does not exist." , pathname.c_str() );
  }
  else {
    MscDataAccess da( pathname.c_str() , MscDataAccess::DA_READ_ASCII );
    if ( da.isOk() == false ) {
      MscDg::trace( CLASS_NAME , METHOD_NAME , "File '%s' can't be opened (%s)" ,
                   pathname.c_str() , da.getErrorMessage().c_str() );
    }
    else {
      // read the values (written with 'MscDg::DEBUG_WRITE_CURRENT_XXXXX')
      int numberOfRead = 0 ;
      int lineLength   = 0 ;
      const char * lineString = 0;  
      while ( (lineString = da.getNonEmptyLineWithFinalSpace( lineLength )) != 0 ) {
        // identify the words on the line
        std::vector< std::pair< MscUtl::WordType , std::pair<int,int> > > wordsStartEnd ;
        int numberOfWords = MscUtl::detect( lineString , wordsStartEnd );
        // use the words on the line
        MscString className ;
        if ( numberOfWords >= 1 && MscUtl::getString( lineString , wordsStartEnd[0].second , className  ) == false ) {
          continue ;
        }
        className.strip();
        // nothing or commented out
        if ( className.isBlank() == true || className == "//" ) { 
          continue ; 
        } 
        MscString methodName("*");
        if ( numberOfWords >= 2 && MscUtl::getString( lineString , wordsStartEnd[1].second , methodName ) == false ) {
          continue ;
        }
        methodName.strip();
        MscString debugStr("0");
        if ( numberOfWords >= 3 && MscUtl::getString( lineString , wordsStartEnd[2].second , debugStr   ) == false ) {
          continue ;
        }
        debugStr.strip();
        MscString value(STR_TRUE);
        if ( numberOfWords >= 4 && MscUtl::getString( lineString , wordsStartEnd[3].second , value      ) == false ) {
          continue ;
        }
        value.strip();
        // print-out
#ifdef DEBUGGING_READ
         std::cerr << "MscDg::myReadMap() " << lineString << " => "
             << className << " " << methodName << " " << debugStr << " value '" << value << "'" <<  std::endl ;
#endif
        // add it
        numberOfRead += 1 ;
        if ( value == STR_TRACE_ON || value == STR_TRUE ) {
          mySetTraceIsEnabled( className.c_str()  ,
                               methodName.c_str() ,
                               debugStr.readi()   ,
                               true               );
        }
        else if ( value == STR_TRACE_OFF || value == STR_FALSE ) {
          mySetTraceIsEnabled( className.c_str()  ,
                               methodName.c_str() ,
                               debugStr.readi()   ,
                               false              );
        }
        else if ( value == STR_TIMER_ON  ) {
          selectTimer( className.c_str()   ,
                       methodName.c_str()  ,
                       debugStr.readi()    ,    
                       true                );
        }
        else if ( value == STR_TIMER_OFF ) {
          selectTimer( className.c_str()   ,
                       methodName.c_str()  ,
                       debugStr.readi()    ,    
                       false               );
        }
        else if ( value == STR_MEMORY_ON ) {
          selectMemory( className.c_str()  ,
                        methodName.c_str() ,
                        debugStr.readi()   ,    
                        true               );
        }
        else if ( value == STR_MEMORY_OFF ) {
          selectMemory( className.c_str()  ,
                        methodName.c_str() ,
                        debugStr.readi()   ,    
                        false              );
        }
      }
      // inform
      isOk = (numberOfRead != 0);
      // no values
      if ( numberOfRead == 0 ) {
        MscDg::info( CLASS_NAME , METHOD_NAME , "Nothing to read in the file (%s)" ,
                    pathname.c_str() );
      }
      // read correctly
      else {
        MscDg::info( CLASS_NAME , METHOD_NAME , "%d lines read in '%s'" , 
                    numberOfRead , pathname.c_str() );
      }
    }
  }
  return isOk ;
}




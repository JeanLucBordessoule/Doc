#ifndef MSC_VIEW_IDS_HPP
#define MSC_VIEW_IDS_HPP



/** ========================================================
 * namespace . Storage of the Ids of the single Views used by the application.
 * ========================================================= */


class MscString ;


class MscViewIds
{
public : 

  /** definition of the views (pre-defined sets of graphic layers 
   * displaying a specific type of data ) */
  enum ViewType {
    UNDEFINED         = (0L)     , // no view.
    MAIN              = (1L<<0)  ,
    MAP               = (1L<<1)  ,
    VELOCITY_TABLE    = (1L<<2)  ,
    SEMBLANCE         = (1L<<3)  ,
    GATHER            = (1L<<4)  ,
    STACK             = (1L<<5)  ,
    VELOCITY_GRAPH    = (1L<<6)  ,
    VTKVIEW           = (1L<<7)  ,
    TEAM_FORM         = (1L<<8)  ,
    ALL_VIEWS         = (1L<<9)  - 1
  } ;

  /** provide a way to turn the enumeration value into a character string */
  static const char * getFlag( int );
  static ViewType     getValue( const MscString & str );

private:

  /** not implemented as it's used as a singleton */
  MscViewIds();
  MscViewIds( const MscViewIds & );
  const MscViewIds & operator=( const MscViewIds & );

};



#endif


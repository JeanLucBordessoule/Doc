#include "MscMessageProvider.hpp"



/***************************************************************
 ** Static Methods for the callback management.
 **************************************************************/


// Callbacks
std::map< MscMessageProvider::CallerId , std::pair< MscMessageProvider::MsgCallback , void* > > MscMessageProvider::myCallbacks ;




bool MscMessageProvider::messageIsDeTypg( MscMessageProvider::SeverityId severityId )
{
  return (severityId <= MscMessageProvider::MSG_DEBUG);
}


bool MscMessageProvider::messageIsError( MscMessageProvider::SeverityId severityId )
{
  return (severityId >= MscMessageProvider::MSG_WARNING);
}



void MscMessageProvider::setCallback( MscMessageProvider::CallerId callerId , MscMessageProvider::MsgCallback cb , void* userData )
{
  // add the callback
  if ( cb != 0 && userData != 0 ) {
    if ( MscMessageProvider::myCallbacks.find(callerId) != MscMessageProvider::myCallbacks.end() ) {
      std::cerr << "  MscMessageProvider::setCallback()  Adding PRESENT  CallerId " << callerId << std::endl ;
    }
    std::pair< MscMessageProvider::MsgCallback , void* > pr( cb , userData );
    myCallbacks[ callerId ] = pr ;
  }
  // remove the callback
  else {
    if ( MscMessageProvider::myCallbacks.find(callerId) != MscMessageProvider::myCallbacks.end() ) {
      MscMessageProvider::myCallbacks.erase( MscMessageProvider::myCallbacks.find(callerId) );
    }
    else {
      std::cerr << "  MscMessageProvider::setCallback()  Removing NOT PRESENT  CallerId " << callerId << std::endl ;
    }
  }
}



void MscMessageProvider::message( MscMessageProvider::CallerId   callerId ,
                                 const char * fct , const char * msg ,
                                 MscMessageProvider::SeverityId severity )
{
  if ( msg == 0 ) { msg = ""; }
  // local print out
  std::map< MscMessageProvider::CallerId , std::pair< MsgCallback , void* > >::iterator iter = myCallbacks.find( callerId );
  if ( iter == myCallbacks.end() ) {
    if ( fct == 0 ) {
      std::cerr << "CallerId:" << callerId << "  Message:" << msg << std::endl ;
    }
    else {
      std::cerr << "CallerId:" << callerId << "  " << fct << "  Message:" << msg << std::endl ;
    }
  }
  // provided callback
  else {
    (iter->second.first)( iter->second.second , fct , msg , severity );
  }
}



/***************************************************************
 ** Class methods
 **************************************************************/

MscMessageProvider::MscMessageProvider( MscMessageProvider::Listener * listener ) 
{
  myParent     =  0 ; 
  myFirstRow   = -1 ;
  myLastRow    = -1 ;
  myNumber     =  0 ;
  setListener( listener );
  myBuddy      =  0 ;
  myHasChanged =  false    ;
  // by default , the values are provided
  myDoProvideGUIstrings = true ;
}



MscMessageProvider::~MscMessageProvider()
{
  // tell the children they are orphans
  std::vector < MscMessageProvider * >::iterator iter ;
  for ( iter = myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
    (*iter)->myParent = nullptr ;
  }
  // tell the parent goodbye
  if ( myParent != nullptr ) {
    myParent->removeChild( this );
  }
}



void MscMessageProvider::addChild( MscMessageProvider * c )
{
  if ( c->myParent == nullptr ) { // can have one parent only
    c->myParent = this ;
    myChildren.push_back( c ) ;
    return ;
  }
  // already adopted
  std::cerr << "MscMessageProvider::addChild(): Error 1" << std::endl ;
}



void  MscMessageProvider::removeChild( MscMessageProvider * c )
{
  // illegitime child
  if ( c->myParent != this ) {
    std::cerr << "MscMessageProvider::removeChild(): Error 1" << std::endl ;
  }
  // remove from list
  std::vector < MscMessageProvider * >::iterator iter ;
  for ( iter = myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
    if ( *iter == c ) {
      myChildren.erase( iter );
      c->myParent = nullptr ;
      return ;
    }
  }
  // crook trying to take a part of the inheritance
  std::cerr << "MscMessageProvider::removeChild(): Error 2" << std::endl ;
  c->myParent = nullptr ;
}



int  MscMessageProvider::getNumberOfGUIrows( const int startIndex ) 
{
  // do not provide the strings
  // NOT USED . The implementation needs to be checked in
  // TypStoreListPM::getOwnGUIstrings
  /*
  if ( myDoProvideGUIstrings == false ) {
    myNumber   =  0 ;
    myFirstRow = -1 ;
    myLastRow  = -1 ;
    return myNumber ;
  }
  */

  // first find out how many how strings are present
  myNumber = getOwnGUIstrings() ;
  // add the lines of the children
  int number = myNumber ;
  std::vector < MscMessageProvider * >::const_iterator iter ;
  for ( iter = myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
    number += (*iter)->getNumberOfGUIrows( startIndex + number ) ;
  }
  if ( number != 0 ) {
    myFirstRow = startIndex + 1 ;
    myLastRow  = myFirstRow + number ;
  }
  else {
    myFirstRow = -1 ;
    myLastRow  = -1 ;
  }
  return number ;
}



bool MscMessageProvider::getGUIstrings( int rowIndex , std::vector< MscString > * stringArray , std::vector< MscString > * typeArray )
{
#ifdef DEBUGGING
  std::cerr << "MscMessageProvider::getGUIstrings()" << std::endl ;
#endif
  // not present
  if ( rowIndex < 0 || rowIndex < myFirstRow || myLastRow < rowIndex ) return false ;
  // own string
  if ( rowIndex < (myFirstRow + myNumber) ) {
    return ( getOwnGUIstrings( rowIndex , stringArray , typeArray ) == int(true) );
  }
  // child string
  std::vector < MscMessageProvider * >::const_iterator iter ;
  for ( iter = myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
    if ( (*iter)->getGUIstrings( rowIndex , stringArray , typeArray ) == int(true) ) {
      return true ;
    }
  }
  // should not occurr
  return false ;
}



void  MscMessageProvider::setWaitCursor( bool b )
{
  const MscMessageProvider::Listener * listener = myGetListener() ;
  if ( listener != 0 ) listener->setWaitCursor( this , b );
}



void  MscMessageProvider::showMessage( const char * m , bool isPermanentMessage )
{
  const MscMessageProvider::Listener * listener = myGetListener() ;
  if ( listener != 0 ) listener->messageFrom( this , m , isPermanentMessage ) ;
  else if ( m != 0 ) std::cerr << m << std::endl ;
}



bool MscMessageProvider::isOk() const
{
  return (myFatalErrorMessage.isEmpty() == true && myTemporaryErrorMessage.isEmpty() == true );
}



const MscString MscMessageProvider::getErrorMessage() const
{
  MscString errorMessage = myFatalErrorMessage ;
  if ( errorMessage.isEmpty() == false && myTemporaryErrorMessage.isEmpty() == false ) {
    errorMessage += "\n" ;
  }
  errorMessage += myTemporaryErrorMessage ;
  return errorMessage;
}



bool MscMessageProvider::hasChanged() const 
{
#ifdef DEBUGGING
  std::cerr << "MscMessageProvider::hasChanged(" << this << ")" << std::endl ;
#endif
  if ( myHasChanged == true ) return true ;
  std::vector < MscMessageProvider * >::const_iterator iter ;
  for ( iter = myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
    if ( (*iter)->hasChanged() == true ) {
      return true ;
    }
  }
  return false ;
}



void MscMessageProvider::cancelChanges()
{
#ifdef DEBUGGING
  std::cerr << "MscMessageProvider::cancelChanges(" << this << ")" << std::endl ;
#endif
  myHasChanged = false ;
  std::vector < MscMessageProvider * >::const_iterator iter ;
  for ( iter = myChildren.begin() ; iter != myChildren.end() ; ++iter ) {
    (*iter)->cancelChanges();
  }
}



const MscMessageProvider::Listener * MscMessageProvider::myGetListener() const
{
  // find the top
  const MscMessageProvider * provider = this ;
  const MscMessageProvider::Listener * listener = myListener ;
  while ( listener == 0 && provider->myParent != 0 ) {
    provider = provider->myParent   ;
    listener = provider->myListener ;
  }
  // found no shoulder to cry on ...
  if ( listener == 0 ) {
    // std::cerr << "No one is listening to me ..." << std::endl ;
  }
#ifdef DEBUGGING
  std::cerr << "MscMessageProvider::myGetListener() => " << listener << std::endl ;
#endif
  return listener ;  
}



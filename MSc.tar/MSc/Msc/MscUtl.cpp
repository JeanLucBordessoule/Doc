#include "MscUtl.hpp"

// C++
#include <cctype>
#include <iostream>

// Miscellaneous (Msc)
#include "MscDebug.hpp"

// Token
static const char TOKEN_DIR       = '/'  ;
static const char TOKEN_WINDIR    = '\\' ;
static const char TOKEN_SPACE     = ' '  ;
static const char TOKEN_EXTENSION = '.'  ;


const char * MscUtl::CLASS_NAME = "MscUtl" ;


//-----------------------------------------------------------//
//-----------------------------------------------------------//
//    STATIC UTILITIES                                       //
//-----------------------------------------------------------//
//-----------------------------------------------------------//


void MscUtl::removeDuplicate( std::list< MscString > & storeList )
{
  // list of stores => set of stores
  std::set< MscString > storeSet ;
  for ( auto listIter=storeList.begin() ; listIter != storeList.end() ; ++listIter ) {
    storeSet.insert( *listIter );
  }
  // set of stores => list of stores
  storeList.clear();
  std::set< MscString >::iterator setIter ;
  for ( setIter=storeSet.begin() ; setIter != storeSet.end() ; ++setIter ) {
    storeList.push_back( *setIter );
  }
}


std::list< MscString > MscUtl::toStringsList( const std::set < MscString > & stringsSet )
{
  std::list<MscString > stringsList ;
  std::set<MscString>::const_iterator iter ;
  for ( iter=stringsSet.begin() ; iter != stringsSet.end() ; ++iter ) {
    stringsList.push_back( *iter );
  }
  return stringsList ;
}


std::set < MscString > MscUtl::toStringsSet ( const std::list< MscString > & stringsList )
{
  std::set<MscString > stringsSet ;
  std::list<MscString>::const_iterator iter ;
  for ( iter=stringsList.begin() ; iter != stringsList.end() ; ++iter ) {
    stringsSet.insert( *iter );
  } 
  return stringsSet ;
}


std::list< MscString > MscUtl::toStringsList( const std::vector< MscString > & stringsVector )
{
  std::list<MscString > stringsList ;
  std::vector<MscString>::const_iterator iter ;
  for ( iter=stringsVector.begin() ; iter != stringsVector.end() ; ++iter ) {
    stringsList.push_back( *iter );
  }
  return stringsList ;
}


std::vector< MscString > MscUtl::toStringsVector( const std::list< MscString > & stringsList )
{
  std::vector<MscString > stringsVector ;
  std::list<MscString>::const_iterator iter ;
  for ( iter=stringsList.begin() ; iter != stringsList.end() ; ++iter ) {
    stringsVector.push_back( *iter );
  } 
  return stringsVector ;
}


void MscUtl::keepLatestVersionOnly( std::list< MscString > & oldList )
{
  MscString previous , previousName ; 
  std::list< MscString > newList ;
  // 
  std::list< MscString >::iterator iter ;
  for ( iter=oldList.begin() ; iter != oldList.end() ; ++iter ) {
    // current name with and without extension
    MscString currentName = *iter ;
    MscString current , version ;
    int length = currentName.length();
    // no version: should be "xxxxx.vv"
    if ( length < 4 ||
         currentName[ length - 3 ] != TOKEN_EXTENSION ||
         std::isdigit( currentName[ length - 2 ] ) == 0 ||
         std::isdigit( currentName[ length - 1 ] ) == 0 ) {
      newList.push_back(currentName);
    }
    // can't get version: store current name
    else if ( currentName.splitAtLastToken( current , version , TOKEN_EXTENSION ) == MscString::ERROR ||
              current.isBlank() == true ) {
      newList.push_back(currentName);
    }
    // different name: store previous name
    else if ( previous.isBlank() == false && current != previous ) {
      newList.push_back(previousName);
    }
    // different version
    else {
      // 
    }
    previousName = currentName ;
    previous = current ;
  }
  if ( previousName.isBlank() == false ) {
    newList.push_back(previousName);
  }
  // replace list
  oldList = newList ;
}


bool MscUtl::removePrefix( MscString & str , const char * prefix )
{  
  str.strip();
  size_t length = (prefix == 0) ? 0 : std::strlen(prefix);
  if ( str.length() <= length ) {
    return false ;
  }  
  const char * start = std::strstr( str.c_str() , prefix );
  // must start at the beginning
  if ( start != str.c_str() ) {
    return false ;
  }
  MscString newStr = (str.c_str() + length );
  str = newStr ;
  return true ;
}


bool MscUtl::removeSuffix( MscString & str , const char * suffix )
{
  str.strip();
  int length    = (suffix == 0) ? 0 : strlen(suffix);
  int strLength =  str.length();
  if ( strLength <= length ) {
    return false ;
  }  
  const char * start = ::strstr( str.c_str() , suffix );
  int    diff  = ( strLength - length );
  // must be at the end
  if ( (start - str.c_str()) != diff ) {
    return false ;
  }
  MscString newStr = str ;
  newStr[ diff ] = '\0' ;
  str = newStr ;
  return true ;  
}


MscString MscUtl::removeVersion( const MscString & str , bool & hasPoint )
{
  static const char * METHOD_NAME = "StringWithoutVersion()" ;
  int i;
  for ( i=str.getSize()-1 ; i > 0 ; --i ) {
    if ( str.c_str()[i] == TOKEN_EXTENSION ) {
      break;
    }
  }
  if ( i < 1 ) {
    hasPoint = false;
    MscDg::error( CLASS_NAME , METHOD_NAME , "'%s' has no version" , str.c_str() );
    return str;
  }
  else {
    hasPoint = true;
    return str.get(0,i-1);
  }  
}



int MscUtl::removeSpace( MscString & str )
{
  int numberOfSpaces = 0 ;
  int i , j , strLength = str.length();
  // move along the characters
  for ( i=0 , j=0 ; i < strLength ; ++i ) {
    // it's a space. So it's ignored
    if ( std::isspace( str.c_str()[i] ) != 0 ) {
      numberOfSpaces += 1 ;
    }
    // copy the character that is not a space
    else {
      // if there is no space in the string, it's the same
      if ( j != i ) { str[j] = str[i] ; }
      // next non-space character
      j += 1 ;
    }
  }
  // final '\0'
  if ( numberOfSpaces != 0 ) { str[ strLength + 1 - numberOfSpaces ] = '\0' ; }
  return numberOfSpaces ;
}


MscString MscUtl::removeSpaceCamelCase( const MscString & str )
{
  MscString camelCased ;
  int i , strLength = str.length();
  bool justAfterSpace = false ;
  // move along the characters
  for ( i=0 ; i < strLength ; ++i ) {
    char c = str[i];
    // it's a space. So it's ignored
    if ( isspace(c) != 0 ) {
      justAfterSpace = true ;
    }
    // copy the character that is not a space
    else {
      if ( justAfterSpace == true ) {
        justAfterSpace = false;
        camelCased += ((char)toupper(c));
      }
      else {
        camelCased += c ;
      }
    }
  }
  return camelCased ;
}



bool MscUtl::isBlank( const char * s )
{
  if ( s == 0 || *s == '\0' ) return true ;
  int i=0 , n=std::strlen(s);
  for ( i=0 ; i < n ; ++i ) {
    if ( std::isspace( s[i] ) == 0 ) {
      return false ;
    }
  }
  return true ;
}


int MscUtl::toInt( float value )
{
    return (int)(value + 0.5f);
}


bool MscUtl::isSame  ( const char * s1 , const char * s2 )
{ 
  if ( s1 == s2 ) return true ;
  if ( s1 == 0 || s2 == 0 ) return false ;
  return ( ::strcmp( s1 , s2 ) == 0 ) ;
}


bool MscUtl::isInt( const MscString & str , int & value )
{
  MscString tmp(str);
  tmp.strip();
  value = tmp.readi();
  tmp.printf("%d",value);
  return (str == tmp);
}


int MscUtl::getIndexInside( const char * s1 , const char * s2 )
{
  if ( s1 == s2 ) return 0 ;
  if ( s1 == 0 || s2 == 0 ) return (-1) ;
  const char * start = ::strstr( s1 , s2 );
  int result = ( start == 0 ) ? (-1) : (start - s1) ;
#ifdef DEBUGGING
  std::cerr << "MscUtl::getIndexInside '" << s1 <<  "' Search '" << s2 << "'" << std::endl ;
  std::cerr << "  Result= '" << (start ? start : "") << "'  =>" << result << std::endl ;
#endif
  return result ;
}


int MscUtl::getIndexInside( const char * s1 , char c )
{
  if ( s1 == 0 ) return (-1) ;
  if ( c  == '\0' ) return false ;
  const char * start = ::strchr( s1 , c );
  if ( start == 0 ) return (-1) ;
  return ( start - s1 );  
}


std::vector< MscString > MscUtl::getWords( const char * initialLineString , bool convertSeparators )
{
  std::vector< MscString > words ;
  MscString str(initialLineString);

  int i=0;
  int lineLength = str.length(); // length of the string
  char * lineString = const_cast<char*>(str.c_str()) ;

  // modify eventually the string
  if ( convertSeparators == true ) {
    for ( i=0 ; i < lineLength ; ++i ) {
      if ( std::strchr( ",;=" , lineString[i] ) != 0 ) {
        lineString[i] = TOKEN_SPACE;
      }
    }
  }
  // add final space to make sure to finish the word
  str += TOKEN_SPACE ;
  lineString = const_cast<char*>(str.c_str());
  lineLength = str.length() ;
  // split
  MscString currentWord ;
  for ( i=0 ; i < lineLength ; ++i ) {
    // ** inside a word
    if ( std::isspace( lineString[i] ) == 0 ) {
      // add the character
      currentWord += lineString[i] ;
    }
    // ** store a word
    else if ( currentWord.isEmpty() == false ) {
      // save the word
      words.push_back(currentWord);
      // get ready for next
      currentWord.erase() ;
    }    
  }
  return words;
}


int MscUtl::detect( const char * lineString ,
                      std::vector< std::pair < MscUtl::WordType , std::pair<int,int> > > & wordsStartEnd ,
                      int numberToSearch )
{
  wordsStartEnd.clear() ;
  // identify the items
  MscUtl::WordType currentWordType = MscUtl::WT_UNDEFINED ; 
  MscString currentWord ; 
  int wrdStart   = 0 ;
  int lineLength = std::strlen(lineString);
  for ( int i=0 ; i < lineLength ; ++i ) {
    // current character
    char c = lineString[i] ;
    // ** inside a word
    if ( std::isspace( c ) == 0 ) {
      // identify the type of the string
      if ( isdigit( c ) != 0 ) {
        if ( currentWordType < MscUtl::WT_INT ) currentWordType = MscUtl::WT_INT   ;
      }
      else if ( ::strchr( "+-Ee." , c ) != 0 ) {
        if ( currentWordType < MscUtl::WT_FLOAT ) currentWordType = MscUtl::WT_FLOAT ;
      }
      else {
        currentWordType = MscUtl::WT_ALPHA ;
      }
      // add the character
      currentWord += c ;
    }
    // ** finished a word (and keep track of where it ends)
    else if ( currentWord.isEmpty() == false ) {
      // current character is a space
      // hence the end of the previous word is not a space ...
      std::pair < int , int > startEnd( wrdStart , (i-1) ) ;
      std::pair < MscUtl::WordType , std::pair<int,int> > pr( currentWordType , startEnd ) ;
      // save the word
      wordsStartEnd.push_back( pr ) ;
      // get ready for next
      currentWordType = MscUtl::WT_UNDEFINED ; 
      currentWord.erase() ;
      wrdStart = i ;
      // stop searching
      if ( numberToSearch > 0 && (int)wordsStartEnd.size() >= numberToSearch ) {
        i = lineLength ;
      }
    }
  } 
  return wordsStartEnd.size() ;
}


bool MscUtl::detect( const char * containerString , int position , MscString & str , bool readTillEndOfLine )
{
  if ( containerString == 0 || position <= 0 ) {
    return false ;
  }
  // detect the required number of words only
  std::vector< std::pair< MscUtl::WordType , std::pair<int,int> > > wordsStartEnd ;
  if ( detect( containerString , wordsStartEnd , position ) == position ) {
    // identify *last* word
    std::vector< std::pair< MscUtl::WordType , std::pair<int,int> > >::reverse_iterator iter = wordsStartEnd.rbegin();
    int first  = iter->second.first  ;
    int last   = iter->second.second ;
    int length = last - first + 1    ;

    if ( length < 1 ) {
      return false ;
    }
    else {
      str = containerString + first ;
      // truncate
      if ( readTillEndOfLine == false ) {
        str[ length ] = '\0';
      }
      str.strip();
#ifdef DEBUGGING
      std::cerr << "MscUtl::detect '" << str << "'" << std::endl ;
#endif
      return true ;
    }
  }
  else {
    return false ;
  }
}


bool  MscUtl::getString( const char * containerString , const std::pair<int,int> & wordStartEnd , MscString & str )
{
  int first  = wordStartEnd.first  ;
  int last   = wordStartEnd.second ;
  int length = ( last - first + 1 ) ;
  
  if ( length < 1 ) {
    return false ;
  }
  else if ( (*(containerString + first) == TOKEN_SPACE || first == 0) && (*(containerString + last) != TOKEN_SPACE) ) {
    char * Typffer = new (std::nothrow) char[ length + 1 ];
    if ( Typffer != 0 ) {
      std::strncpy( Typffer , (containerString + first) , length );
      Typffer[ length ] = '\0' ;
      str = Typffer ;
      delete [] Typffer ;
      return true ;
    }
    else {
      return false ;
    }
  }
  else {
    return false ;
  } 
}


float MscUtl::getFloat( const char * containerString , const std::pair<int,int> & wordStartEnd , bool * isOk )
{
  int first  = wordStartEnd.first  ;
  int last   = wordStartEnd.second ;
  int length = ( last - first + 1 ) ;

  if ( length < 1 ) {
    if ( isOk != 0 ) { *isOk = false ; }
    return 0.0f ; 
  }
  else if ( (*(containerString + first) == TOKEN_SPACE || first == 0) && (*(containerString + last) != TOKEN_SPACE) ) {
    char * Typffer = new (std::nothrow) char[ length + 1 ];
    if ( Typffer != 0 ) {
      std::strncpy( Typffer , (containerString + first) , length );
      Typffer[ length ] = '\0' ;
      if ( isOk != 0 ) { *isOk = true ; }
      return atof( Typffer );
    }
    else {
      if ( isOk != 0 ) { *isOk = false ; }
      return 0.0f ;
    }
  }
  else {
    if ( isOk != 0 ) { *isOk = false ; }
    return 0.0f ;
  }
}


bool MscUtl::removeFlag( MscString & input , const char * flag )
{
  bool isOk = false ;
  if ( flag == 0 || flag[0] == '\0' ) { return isOk; }
  size_t length = std::strlen(flag);
  if ( input.length() < length ) { return isOk; }
#ifdef DEBUGGING_FLAGS
  MscString before(input);
#endif
  int strLoc = input.search(flag);
  if ( strLoc != MscString::ERROR ) {
    MscString tmp( & input.c_str()[strLoc+length] );
    input = tmp ;
    isOk  = true ;
  }
#ifdef DEBUGGING_FLAGS
  if ( isOk == true ) {
    std::cerr << "MscUtl FLAG='" << flag << "' INPUT='" << before << "' => '" << input << "' isOk=" << isOk << std::endl ;
  }
#endif
  return isOk ;
}



bool MscUtl::removeFlag( MscString & input , const char flag )
{
  char Typffer[2];
  Typffer[0] = flag ;
  Typffer[1] = '\0' ;
  return MscUtl::removeFlag( input , Typffer );
}



bool MscUtl::removeWord( MscString & input , MscString & word )
{
  size_t i=0 ;
  // ignore the spaces . Stop at first character.
  for ( i=0 ; i < input.length() ; ++i ) {
    if ( std::isspace(input[i]) == 0 ) {
      break;
    }
  }
  // store the word
  word.erase();
  for ( ; i < input.length() ; ++i ) {
    if ( std::isspace(input[i]) == 0 ) {
      word += input[i];
    }
    else {
      break;
    }
  }
  // ok
  if ( word.empty() == false ) {
    MscString tmp( & input[i] );
    input = tmp;
    return true;
  }
  else {
    return false;
  }
}



int MscUtl::extractIntegers( const MscString & str , int & value1 , int * value2 , int * value3 )
{
  // digits that are part of an int
  static const char * IntChar = "0123456789+-";
  // search in the string
  MscString intStr ;
  int numberOfValues=0;
  size_t strLength=str.length();
  size_t i=0;
  // add extra loop so it considers when the integer finishes at the end of the line
  for ( i=0 ; i <= strLength ; ++i ) {
    // a digit , so add it to the ones already found
    if ( i < strLength && std::strchr( IntChar , str[i] ) != 0 ) {
      intStr += str[i] ;
    }
    // Not a digit (or end of string) and some were found .
    // Use what has been found
    // End of string might have been found.
    else if ( intStr.empty() == false ) {
      int value = intStr.readi();
      switch ( numberOfValues ) {
        case 0 :
        {
          value1 = value;
          if ( value2 == 0 ) { return i; }
        } break;
        case 1 :
        {
          *value2 = value;
          if ( value3 == 0 ) { return i; }
        } break;
        case 2 :
        {
          *value3 = value;
          return i;
        }
      }
      // find next
      intStr.erase();
      numberOfValues += 1 ;
    }
  }
  // not found
  return 0;
}



bool MscUtl::removeIntegers( MscString & input , int & value1 , int * value2 , int * value3 )
{
#ifdef DEBUGGING_FLAGS
  MscString before(input);
#endif
  bool isOk = false;
  int strLoc = MscUtl::extractIntegers( input , value1 , value2 , value3 );
  if ( strLoc != 0 ) {
    MscString tmp( & input.c_str()[strLoc] );
    input = tmp ;
    isOk = true;
  }
#ifdef DEBUGGING_FLAGS
  if ( isOk == true ) {
    std::cerr << "MscUtl INTEGERS: INPUT='" << before << "' => '" << input << "' isOk=" << isOk << std::endl ;
  }
#endif
  return isOk ;
}


int  MscUtl::extractFloats( const MscString & str , float & value1 , float * value2 , float * value3 )
{
  // digits that are part of a float
  static const char * FloatChar = "0123456789+-.egf";
  // search in the string
  MscString floatStr ;
  int numberOfValues=0;
  int strLength=str.length();
  for ( int i=0 ; i <= strLength ; ++i ) {
    // a digit , so add it to the ones already found
    if ( i < strLength && ::strchr( FloatChar , str[i] ) != 0 ) {   
      floatStr += str[i] ;
    }
    // not a digit (or end of string) and some were found .
    // Use what has been found
    // End of string might have been found.
    else if ( floatStr.isEmpty() == false ) {
      float value = floatStr.readf();
      switch ( numberOfValues ) {
      case 0 : 
        {
          value1 = value;
          if ( value2 == 0 ) { return i; }
        } break;
      case 1 :
        {
          *value2 = value;
          if ( value3 == 0 ) { return i; }
        } break;
      case 2 :
        {
          *value3 = value;
          return i;
        }
      }
      // find next
      floatStr.erase();
      numberOfValues += 1 ;
    }
  }
  return 0;
}


bool MscUtl::removeFloats( MscString & input , float & value1 , float * value2 , float * value3 )
{
#ifdef DEBUGGING_FLAGS
  MscString before(input);
#endif
  bool isOk = false ;
  int strLoc = MscUtl::extractFloats( input , value1 , value2 , value3 );
  if ( strLoc != 0 ) {
    MscString tmp( & input.c_str()[strLoc] );
    input = tmp ;
    isOk = true ;
  }
#ifdef DEBUGGING_FLAGS
  if ( isOk == true ) {
    std::cerr << "MscUtl FLOATS: INPUT='" << before << "' => '" << input << "' isOk=" << isOk << std::endl ;
  }
#endif  
  return isOk ;
}



bool  MscUtl::addExtensionIfMissing( MscString & str , const char * ext , const char * snd )
{
  int extLength = ext ? strlen(ext) : 0 ;
  // nothing to add
  if ( extLength == 0 ) return false ;
  // see the other lengths
  int sndLength = snd ? strlen(snd) : 0 ;
  int strLength = str.length() ;
  
  // no extension can be present , so add it
  if ( strLength <= extLength && strLength <= sndLength ) {
    str += ext ;
    return true ;
  }

  // has the correct extension
  MscString endOfStr( str.c_str() + strLength - extLength) ;
  if ( endOfStr == ext ) {
    return false ;
  }
  // has the alternate extension
  if ( sndLength != 0 ) {
    endOfStr = MscString( str.c_str() + strLength - sndLength) ;
    if ( endOfStr == snd ) {
      return false ;
    }
  }
  // add the extension
  str += ext ;
  return true ;
}


MscString MscUtl::getExtension( const MscString & s , bool convertToLowerCase )
{
  MscString ext = MscString(s).getExtension(convertToLowerCase);
  return ext ;
}


void  MscUtl::removeEndSlash( MscString & s )
{
  s.stripForPath(true);
  /**
  MscString tmp(s);
  bool foundOne= false ;
  char * str = const_cast<char *>(s.c_str());
  int length = s.length()  ;
  for ( int i=(length-1) ; i >= 0 ; --i ) {
    if ( str[i] == TOKEN_DIR || str[i] == TOKEN_WINDIR ) {
      str[i] = '\0' ;
      foundOne = true ;
    }
    // not a slash
    else {
      break;
    }
  }
  return foundOne ;
  **/
}


void  MscUtl::convertPath( MscString & s ) 
{
  s.stripForPath();
  // remove all the final /
  removeEndSlash(s);
}


MscString MscUtl::homeDirectory()
{
  MscString str( MscUtl::homeDirectory() );
  convertPath( str );
  return str ;
}


bool MscUtl::directoryExists( const MscString & str , bool createIt )
{
  if ( MscUtl::directoryExists( str ) == true ) { return true ; }
  if ( createIt == true ) { MscUtl::mkDir( str , 0777 ); }
  return MscUtl::directoryExists( str );
}


bool MscUtl::fileExists( const MscString & str )
{
  return MscUtl::fileExists( str );
}



MscString MscUtl::extractDirectoryOfExistingFile ( const MscString & s , MscString * errorMessage )
{
  // character strings
  MscString directoryName ;
  MscString tmp;
  // test if the file exists
  if ( MscUtl::fileExists( s ) == false ) {
    tmp.printf( "'%s' does not exist." , s.c_str() );
    if ( errorMessage != 0 ) { *errorMessage = tmp; }
    else std::cerr << "MscUtl " << tmp << std::endl ;
    return directoryName ;
  }
  // decompose the file name
  MscString fileName( s );
  MscUtl::convertPath( fileName );
  fileName.splitAtLastToken(directoryName,tmp,TOKEN_DIR);
  return directoryName ;
}


MscString MscUtl::removeDirectoryPath( MscString & fileName , MscString * providedDirectory )
{
  fileName.stripForPath();
  MscString beforeToken , afterToken ;
  MscString directory ;
  // provided directory path is correct
  if ( providedDirectory != 0 && MscUtl::directoryExists(*providedDirectory) == true ) {
    directory = *providedDirectory ;
    // find the directory provided by the user
    if ( fileName.splitAtLastToken( beforeToken , afterToken , TOKEN_DIR ) != MscString::ERROR ) {
      // filename
      fileName = afterToken ;
      // full path
      if ( MscUtl::directoryExists( beforeToken ) == true ) {
        directory = beforeToken ;
      }
      // if it's not a relative path
      else if ( MscUtl::directoryExists( directory.printf( "%s/%s" , providedDirectory->c_str() , beforeToken.c_str() ) ) == false ) {
        // keep the provided directory
        directory = *providedDirectory ;
      }
    }
  }
  else {
    providedDirectory = 0 ;
  }
  // no provided directory
  if ( providedDirectory == 0 ) {
    if ( fileName.splitAtLastToken( beforeToken , afterToken , TOKEN_DIR ) != MscString::ERROR ) {
      fileName = afterToken ;
    }
  }
  // return the directory
  return directory ;
}


MscString MscUtl::getDirectoryName( const char * className , const char * methodName , 
                                    const MscString & filePath , MscString & fileName , MscString * extPtr )
{
  if ( className  == 0 ) { className  = "" ; }
  if ( methodName == 0 ) { methodName = "" ; }
#if 0
  // Could use some of the below instead 
  MscString beforeToken , afterToken
  fileName.splitAtLastToken( beforeToken , afterToken , TOKEN_DIR );
  MscString extString ;
  afterToken.splitAtLastToken( previousHorizonName , extString , TOKEN_EXTENSION );
#endif
  // erase output values (no set of the moment)
  fileName.erase();
  if ( extPtr != nullptr ) { extPtr->erase(); }
  // value to be returned
  MscString directoryPath = filePath ;
  // use '/' instead of '\' and remove end / if any.
  convertPath( directoryPath );
  // directory has been provided
  if ( MscUtl::directoryExists( directoryPath ) == true ) {
    removeEndSlash( directoryPath );
  }
  // find the file name
  else {
    int offset = 0 ;
    if ( (offset=directoryPath.getIndexOfLastToken(TOKEN_DIR)) != MscString::ERROR ) {
      fileName = directoryPath.c_str() + offset + 1 ;
      directoryPath[ offset ] = '\0' ;
    }
    // remove extension
    if ( extPtr != 0 ) {
      if ( (offset=fileName.getIndexOfLastToken(TOKEN_EXTENSION)) != MscString::ERROR ) {
        *extPtr = fileName.c_str() + offset + 1 ;
        fileName[ offset ] = '\0' ;
      }
    }
  }
  // last check
  if ( MscUtl::directoryExists( directoryPath ) == false ) {
    if ( directoryPath.isBlank() == false ) {
      std::cerr << "MscUtl::getDirectoryName(" << className << "::" << methodName
           <<") No directory:" << directoryPath << "  File=" << fileName << std::endl ;
    }
    directoryPath.erase() ;
  }
  return directoryPath ;
}



bool MscUtl::decomposeFilename( const MscString & f   , 
                                  MscString & directory ,
                                  MscString & fileName  ,
                                  int     & version   ,
                                  const char * extensionString )
{
  MscString fullPathName( f ) ;
  if ( fullPathName.isEmpty() == true ) {
    std::cerr << "MscUtl::decomposeFilename() : No input string" << std::endl ;
    return false ;
  }
  // find the directory 
  //MscString tokenDir("/") ;
  int offset = 0 ;
  if ( (offset=fullPathName.getIndexOfLastToken(TOKEN_DIR)) != MscString::ERROR ) {
    fileName  = (fullPathName.c_str() + (offset + 1)) ;
    directory =  fullPathName  ;
    directory.truncate( fullPathName.length() - fileName.length() - 1 );
  }
#ifdef WIN32
  else if ( (offset=fullPathName.getIndexOfLastToken(TOKEN_WINDIR)) != MscString::ERROR ) {
    fileName  = (fullPathName.c_str() + (offset + 1)) ;
    directory =  fullPathName   ;
    directory.truncate( fullPathName.length() - fileName.length() - 1 );
  }
#endif
  else {
    // IMPORTANT : default directory is provided at the entry .
    fileName  = fullPathName ;
  }
  // file name without extension 
  if ( extensionString != 0 ) {
    int fileLength = fileName.length() ;
    int extensionLength = std::strlen( extensionString ) ;
    if ( fileLength > extensionLength ) {
      MscString extension = (fileName.c_str() + (fileLength - extensionLength)) ;
      extension.toLowerCase() ;
      if ( extension == extensionString ) {
        fileName.truncate( fileLength - extensionLength );
      }
    } 
  }
  // find if the version exists
  version = 0 ;
  int fileLength = fileName.length() ;
  int versionLength = ::strlen( ".02" ) ;
  if ( fileLength > versionLength ) {
    MscString versionString = (fileName.c_str() + (fileLength - versionLength)) ;
    if ( versionString[0] == TOKEN_EXTENSION ) {
      versionString = (fileName.c_str() + (fileLength - versionLength) + 1) ;
      if ( versionString.length() == 2 && versionString.isInteger() == true ) {
        version = versionString.readi() ;
      }
    }
  }
  // convert
  MscUtl::convertPath( directory );
  return true ;
}



MscString MscUtl::TypildLineString( int lineNumber , bool isInline , int is2D )
{
  MscString str ;
  if ( isInline == false && is2D == int(true) ) {
    std::cerr << "MscUtl::TypildLineString: 2D line can't be crossline" << std::endl ;
  }
  if ( is2D == int(true) ) {
    str.printf( /*"%d/2D"*/ "%d/Line" , lineNumber );
  }
  else if ( isInline == true ) {
    str.printf( "%d/Inline" , lineNumber );
  }
  else {
    str.printf( "%d/Crossline" , lineNumber );
  }
  return str ;
}


MscString MscUtl::analyzeLineString( const MscString & lineString , int & lineNumber , bool & isInline , int & is2D )
{
  // should be '1999'
  MscString errorMessage, line, type;
  if ( lineString.length() == 0 ) {
    errorMessage.printf( "Can't extract line number from empty '%s')" , lineString.c_str() );
  }
  // line number only
  else if ( lineString.splitAtLastToken( line, type, TOKEN_DIR ) == MscString::ERROR ) {
    if ( MscUtl::extractInteger( line , lineNumber ) == true ) {
      isInline   = true ;
      is2D       = int(true);
    }
    else {
      errorMessage.printf( "Can't extract line number from  '%s' (no integer)" ,
                           lineString.c_str() );
    }
  }
  // should be '2000/line' '2000/inline' '2040/subline' '2040/crossline' or '2000/2d'
  else {
    if ( MscUtl::extractInteger( line , lineNumber ) == true ) {
      type.toLowerCase();
      isInline  = (type == "line" || type == "inline" || type == "subline" || type == "2d" );
      if ( type == "line" || type == "2d" ) { is2D = int(true); }
      else if ( type == "crossline" ) { is2D = int(false); }
      else is2D = -1 ; // undefined
    }
    else {
      errorMessage.printf( "Can't extract line number from  '%s' (no integer)" ,
                           lineString.c_str() );
    }
  }
  return errorMessage ;
}


MscString MscUtl::analyzeLineStringList( const std::list<MscString> & lineStrings , int lineNumber , bool isInline )
{
  for ( auto iter=lineStrings.cbegin() ; iter != lineStrings.cend() ; ++iter ) {
    // extract values
    int ln ; bool is ; int is2D ;
    analyzeLineString( *iter , ln , is , is2D );
    // identify
    if ( lineNumber == ln && isInline == is ) {
      return *iter ;
    }
  }
  return "" ;
}


MscString MscUtl::getDateTimeAsString()
{
  MscString str;
#ifdef WIN32
  // 
#else
  time_t rawtime;
  struct tm* timeinfo;
  time(&rawtime);
  timeinfo = localtime(&rawtime);
  str = asctime(timeinfo);
#endif
  return str ;
}



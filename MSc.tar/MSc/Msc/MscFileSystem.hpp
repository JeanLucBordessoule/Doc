#ifndef MSC_FILE_SYSTEM_HPP
#define MSC_FILE_SYSTEM_HPP

#include <set>
#include <vector>

#include "MscString.hpp"



class MscDirectoryInfo {

public :
  static const char * CLASS_NAME ;
  /** Type of the files that are considered . Related to the extension and filter (*.pm *.ssp *.fcf *.cpt) */
  enum  FileType { FT_UNDEFINED       ,
                   PC_PARAMETER       , // "*.pm"
                   PC_SESSION         , // "*.ses"
                   PC_FRAME           , // "*.fcf"
                   PC_VELOCITY        , // "*.vel"
                   // add others if needed (below is unused)
                   FT_LAST            } ;

  /** constructor to get the list of files in a directory */
  MscDirectoryInfo( const MscString & , const MscString & filterString , FileType fileType );
  MscDirectoryInfo( const MscString & , FileType fileType );
  /** constructor for the session files */
  MscDirectoryInfo( const MscString & ) ;
  ~MscDirectoryInfo() ;

  /** -----------------
   * STATIC METHODS 
   * --------------- */

  /** full path name of a file in the home directory */
  static MscString         getHomeDirectoryFile( const char * fileName , bool *doesExist = 0 );  

  /** manage the restricted directories */
  static bool            hasRestrictedDirectory() { return (myRestrictedDirectories.empty() == false); }
  static void            addRestrictedDirectory( const MscString & dirPath ) { myRestrictedDirectories.insert(dirPath) ; }
  static const MscString & getRestrictedDirectory();

private:  
  static std::set< MscString >  myRestrictedDirectories ;
public :


  /** -----------------
   * INSTANCE METHODS 
   * --------------- */

  /** get the pathname of the directory */
  const MscString & getPathName() const { return myPathName ; }

  /** get the Id of this directory */
  int             getId()       const { return myId ; }

  /** refresh the directory . return the numbers of changes */
  int             refreshFiles( const MscString & pathName  ,
                                const MscString & filterString  ,
                                MscDirectoryInfo::FileType fileType );
  int             refreshFiles( const MscString & pathName  ,
                                MscDirectoryInfo::FileType fileType );

  int             refreshSessionFiles() 
  { return refreshFiles( myPathName , PC_SESSION ); }


  /** description of the file */
  enum NameType { NT_ID , NT_TITLE , NT_COMBOBOX , NT_FILENAME } ;
  class FileDescriptor {
  public  :
    FileDescriptor();
    FileDescriptor( const FileDescriptor & );
    const FileDescriptor & operator= ( const FileDescriptor & );
    FileDescriptor( MscDirectoryInfo * d , FileType t , MscString f , int p , MscString date , time_t , int size );
    ~FileDescriptor() {}
    /** used during the creation */
    const FileType & getFileType()   const   { return myFileType   ; }
    const MscString  & getFileName()   const   { return myFileName   ; }
    MscString          getFileNameWithDate() const ;
    const MscString  & getDate()       const   { return myDate       ; }
    void             setTime( time_t t )     { myTime = t          ; }
    bool             getIsNewerThan( time_t t ) const { return (myTime >= t) ; }
    int              getSize()       const   { return mySize       ; }
    void             setPosition( int i )    { myPosition = i      ; }
    int              getPosition()   const   { return myPosition   ; }
    void             setHasChanged( bool b ) { myHasChanged = b    ; }
    bool             getHasChanged() const   { return myHasChanged ; }
    void             setIsPresent( bool b )  { myIsPresent  = b    ; }
    bool             getIsPresent()  const   { return myIsPresent  ; }
    /** used by the GUI */
    MscString          getString( NameType ) const ;
    MscString          getIdName()       const ; /** name used as a reference      */
    MscString          getTitleName()    const ; /** name to put in the GUI        */
    MscString          getComboBoxName() const ; /** name to put in the GUI        */
    MscString          getFullFileName() const { return myFullFileName ; } /** name with the directory in it */
  private :
    /** initialize (constructor) */
    void             myInitialize() ;
          
    MscDirectoryInfo* myDirectory    ;
    FileType         myFileType     ;
    MscString          myFileName     ;
    MscString          myFullFileName ;
    MscString          myDate         ;
    time_t           myTime         = 0 ;
    int              mySize         = 0 ;
    int              myPosition     = 0 ;
    bool             myHasChanged   = false ;
    bool             myIsPresent    = false ;
  };
  typedef std::vector < FileDescriptor > Files ;

  /** access to the list */
  const Files          & getFileDescriptors() const { return myFileDescriptors ; }

  /** get the file descriptor of an existing file (full name or GUIname) */
  const FileDescriptor * getFileDescriptor( const MscString & name , NameType ) const ;

  /** get the file descriptor */
  const FileDescriptor * getFileDescriptor( int ) const;
  const FileDescriptor * getDefaultFileDescriptor() const { return getFileDescriptor(myDefaultFileDescriptor); }


private :

  /** not implemented */
  MscDirectoryInfo() ;
  MscDirectoryInfo( const MscDirectoryInfo & ) ;
  const MscDirectoryInfo & operator= ( const MscDirectoryInfo & ) ;

  /** initialize (constructor) */
  void             myInitialize( FileType fileType ) ;

public : 
  // TODO .. PUT THE SOURCE IN 'myAnalyzeDirectory' INSTEAD OF In AN OUTSIDE FUNCTION
  /** Define the Id number (update or add the file description) */
  typedef void (*AnalyzeDirectoryCallback)( MscDirectoryInfo * caller , 
                                            const MscString & pathName ,
                                            const MscString & filterString ,
                                            FileType fileType ,
                                            // where to find / store
                                            Files & fileDescriptors ,
                                            // location (if a change occurred)
                                            int & position );
  static void setAnalyzeDirectory( AnalyzeDirectoryCallback cb ) { myAnalyzeDirectory = cb ; }
private :
  static AnalyzeDirectoryCallback myAnalyzeDirectory ; 
  /** Define the Id number (update or add the file description) */
  /** method to analyse the content of a directory */
  // static int      myAnalyzeDirectory( const MscString & , const MscString & , FileType );
  

private :
  MscString          myPathName        ; /** directory where the files are */
  int              myId              ; /** Id of the directory    */

  Files            myFileDescriptors ; /** storage of the valid session files names */
  int              myDefaultFileDescriptor ;

  static int       myLastSessionIdNumber ; /** generate the Id number */
};

#endif

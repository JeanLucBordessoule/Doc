#ifndef MSC_MESSAGE_PROVIDER_HPP
#define MSC_MESSAGE_PROVIDER_HPP

#include "MscString.hpp"

#include <iostream>
#include <list>
#include <map>
#include <vector>



/** \class MscMessageProvider
* = define callback functions
* = stores messages
* = propagate message to the user along a tree
* = provide the labels of the leaves of the branches of a tree
*/


class MscMessageProvider {

public :

  /*----------------------------------------------------
   * Enumerations for the severity of messages
   *---------------------------------------------------*/
  
  /** message severity and callback definition */
  enum SeverityId { MSG_DETAIL    = -2 ,
                    MSG_DEBUG     ,
                    MSG_INFO      ,
                    MSG_WARNING   ,
                    MSG_ERROR     ,
                    MSG_FATAL     ,
                    MSG_ERROR_BOX ,
                    MSG_FATAL_BOX
  };
  static bool messageIsDeTypg( SeverityId );
  static bool messageIsError( SeverityId );

  /** ============================================================================
   * Static Callback Functions . The "callerId" is one of the above .
   *  It adds / remove the callback in the below "MscMessageProvider::myCallbacks" 
   *  ========================================================================== */

  /** id of callers , ADD YOUR ID IF NEEDED .
   *  It is used by adding a callback with "MscMessageProvider::setCallback()" 
   *  and enables to have messages when running static functions (e.g.: in a module) */
  enum CallerId { FIRST_ID_OF_CALLER ,
                  CALLER_AUTOVEL // CALLER_AUTOVEL used in '/vega/xp/src/modules/Autovel/v5.01/AV*.cpp'
                  // add any here ....
  };

  typedef void (*MsgCallback) ( void * userData , const char * fct , const char * msg ,  SeverityId );
  /** store the callback . If 'cb' or/and 'userData' is 0 it will remove it (if presebt) */
  static void setCallback( CallerId callerId , MsgCallback cb = 0 , void * userData = 0 );
private :
  static std::map< CallerId , std::pair< MsgCallback , void* > > myCallbacks ;
public :
  /** interface to the message functions */
  static void message ( CallerId callerId , const char * fct , const char * msg , SeverityId severity );
  //
  static void detail  ( CallerId callerId , const char * fct , const char * msg ) { message( callerId , fct , msg , MSG_DETAIL   ); }
  static void deTypg   ( CallerId callerId , const char * fct , const char * msg ) { message( callerId , fct , msg , MSG_DEBUG    ); }
  static void info    ( CallerId callerId , const char * fct , const char * msg ) { message( callerId , fct , msg , MSG_INFO     ); }
  static void warning ( CallerId callerId , const char * fct , const char * msg ) { message( callerId , fct , msg , MSG_WARNING  ); }
  static void error   ( CallerId callerId , const char * fct , const char * msg ) { message( callerId , fct , msg , MSG_ERROR    ); }
  static void fatal   ( CallerId callerId , const char * fct , const char * msg ) { message( callerId , fct , msg , MSG_FATAL    ); }
  // 
  static void errorBox( CallerId callerId , const char * fct , const char * msg ) { message( callerId , fct , msg , MSG_ERROR_BOX); }
  static void fatalBox( CallerId callerId , const char * fct , const char * msg ) { message( callerId , fct , msg , MSG_FATAL_BOX); }

  /** ============================================================================
   ** Nested class .
   *  Used to define an interface for the instance of class "MscMessageProvider"
   *  ========================================================================== */
  
  class Listener { 
    public: 
      Listener() {}
      virtual ~Listener() {}
      /** pure virtual interface that must be implemented in the listener */
      /** Set the cursor on or off */
      virtual void setWaitCursor( MscMessageProvider * , bool ) const = 0 ;
      /** Return 0 no string should appear in the session dialog box */
      virtual void messageFrom( MscMessageProvider * , const char * msg , bool isPermanentMessage ) const = 0 ; 
    private :
      Listener( const Listener & );
      const Listener & operator= ( const Listener & );
  } ;


  /*--------------------------
   * Members of "MscMessageProvider"
   * It has a tree structure for the management of the error/information.
   *  It propagates message up the tree ... 
   * ... till it reaches someone willing to listen to (if any)
   *-------------------------*/
  
  /** constructor , destructor */
  MscMessageProvider( Listener * = 0 ) ;
  virtual ~MscMessageProvider() ;

  /** provide the listener to redirect the message to the user */
  void  setListener( Listener * listener ) { myListener = listener ; }

  /** not sure if it is used */
public :
  // void  setBuddy( MscMessageProvider * b ) { myBuddy = b ; }

public :
  /** add a child in the tree */
  void  addChild( MscMessageProvider * );

  /** remove a child from the tree */
  void  removeChild( MscMessageProvider * );

  /** find the position in the tree */
  int   getNumberOfGUIrows( const int startIndex = (-1) ) ;

  /** get the string for a given row */
  bool  getGUIstrings( int rowIndex , std::vector< MscString > * , std::vector< MscString > * ) ;

  /** propagate request up to the listener */
  void  setWaitCursor( bool ) ;

  /** propagate message up the tree (till it has a listener) 
  * The messages are permanent (in a list box) or not (in a text label, removed after 3 sec ) */
  void  showMessage( const char    * m , bool isPermanentMessage = false ) ;
  void  showMessage( bool isPermanentMessage = false )    { showMessage( myMessage.c_str() , isPermanentMessage ); }
  void  showMessage( const MscString & m , bool isPermanentMessage = false ) { showMessage( m.c_str() , isPermanentMessage ); }
  /** the following messages are permanent (see above) */
  void  showProgressInformation( const MscString & m )      { showMessage( m.c_str() , true ); }
  void  showProgressInformation()                         { showMessage( myMessage.c_str() , true ); }
  void  saveMessage(  const MscString & m )                 { showMessage( m.c_str() , true ); }

  /** error and information messages (reflect the state of the object) */
  /** 'isOk' returns 'false' if an error occurrs */
  bool                    isOk()                     const ; 
  const MscString           getErrorMessage()          const ;
  const MscString         & getFatalErrorMessage()     const { return myFatalErrorMessage     ; }
  const MscString         & getTemporaryErrorMessage() const { return myTemporaryErrorMessage ; }
  const std::list< MscString > & getInformationMessages()   const { return myInformationMessages   ; }

  /** the change flag */
  virtual bool            hasChanged() const ;
  virtual void            cancelChanges();

  /** provide the GUI string. 
  * In the case of the Geometry PM , the GUI strings are not provided.
  **/
  void                    doProvideGUIstrings( bool b ) { myDoProvideGUIstrings = b ; }

protected :

  MscMessageProvider              * myParent   ;
  std::vector < MscMessageProvider * >   myChildren ;
  int                              myFirstRow ;
  int                              myLastRow  ;
  int                              myNumber   ; // number of string here (not the children)
  Listener                       * myListener ;

  MscMessageProvider              * myBuddy    ; // partner that will display the messages

  /** message area . Used to store the message in before sending it */
  MscString         myMessage               ;

  /** error & information messages */
  MscString         myFatalErrorMessage     ; // fatal error message
  MscString         myTemporaryErrorMessage ; // error message that can be solved (e.g.: geometry)
  std::list< MscString > myInformationMessages   ;

  /*** change flag */
  bool            myHasChanged            ;

  /*** override behaviour */
  bool            myDoProvideGUIstrings   ;

  /** The only method that needs to be implemented .
  * If 'rowIndex' is negative , returns the number of rows (and does not set the rows)
  * If 'rowIndex' is positive, returns 'true=1' if the strings have been set, else 'false=0' .
  * The provided array is of size [ MscMessageProvider::NUMBER_OF_GUI_STRING ]
  * (If pure virtual, it must be implemented when the tree access is needed).
  */
  virtual int getOwnGUIstrings( int rowIndex = (-1) , std::vector< MscString > * stringArray = nullptr ,
                                std::vector< MscString > * typeArray = nullptr ) const { return 0 ; }

  /** the listener to provide feedback to */
  const Listener * myGetListener() const ;

private :

  /** not implemented */
  MscMessageProvider( const MscMessageProvider & );
  const MscMessageProvider & operator= ( const MscMessageProvider & );

} ;

#endif 

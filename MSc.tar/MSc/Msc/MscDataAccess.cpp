#include "MscDataAccess.hpp"

#include "MscDebug.hpp"
#include "MscUtl.hpp"


int          MscDataAccess::NUMBER_OF_SPACES_FOR_NESTING = 2          ;
static std::map< MscDataAccess::DataAccessType , MscString > DataAccessStrings ;


const char * MscDataAccess::CLASS_NAME        = "MscDataAccess"        ;
const char * MscDataAccess::EMPTY_STRING_FLAG = "<EmptyString>"       ;
const char * MscDataAccess::DEFINITION_START  = "<FormatDefinition_"  ;
const char * MscDataAccess::DEFINITION_END    = "</FormatDefinition_" ;




void MscDataAccess::myInitialize()
{
  if ( DataAccessStrings.empty() == true ) {
    DataAccessStrings[ MscDataAccess::DA_READ_ASCII  ] = "read ASCII"  ;
    DataAccessStrings[ MscDataAccess::DA_WRITE_ASCII ] = "write ASCII" ;
  }
  std::memset( myBuffer , '\0' , MscDataAccess::READ_BUFFER_SIZE * sizeof(char) );
}


MscDataAccess::MscDataAccess( MscMessageProvider::Listener * listener )
: MscMessageProvider( listener )
{
  myInitialize();
}


MscDataAccess::MscDataAccess( const char * fileName , MscDataAccess::DataAccessType accessType , MscMessageProvider::Listener * listener )
: MscMessageProvider( listener )
{
  myInitialize();
  open( fileName , accessType );
}


MscDataAccess::MscDataAccess( const std::shared_ptr< std::ifstream > & stream , MscMessageProvider::Listener * listener , const char * fileName )
: MscMessageProvider( listener )
{
  myInitialize() ;
  myDataAccessType = MscDataAccess::DA_READ_ASCII ;
  myIFstream       = stream.get() ;
  myFileName       = fileName ;
}


MscDataAccess::MscDataAccess( const std::shared_ptr< std::ofstream > & stream , MscMessageProvider::Listener * listener , const char * fileName )
: MscMessageProvider( listener )
{
  myInitialize() ;
  myDataAccessType = MscDataAccess::DA_WRITE_ASCII ;
  myOFstream       = stream.get() ;
  myFileName       = fileName ;
}


MscDataAccess::MscDataAccess( std::ifstream * stream , MscMessageProvider::Listener * listener , const char * fileName )
: MscMessageProvider( listener )
{ 
  myInitialize() ;
  myDataAccessType = MscDataAccess::DA_READ_ASCII ;
  myIFstream       = stream   ;
  myFileName       = fileName ;
}


MscDataAccess::MscDataAccess( std::ofstream * stream , MscMessageProvider::Listener * listener , const char * fileName )
: MscMessageProvider( listener )
{ 
  myInitialize() ;
  myDataAccessType = MscDataAccess::DA_WRITE_ASCII ;
  myOFstream       = stream   ;
  myFileName       = fileName ;
}



MscDataAccess::~MscDataAccess()
{
  close();
  // delete locally allocated memory
  if ( myStreamIsOwned == true ) {
    if ( myIFstream != nullptr ) {
      myIFstream->close();
      delete myIFstream;
    }
    if ( myOFstream != nullptr ) {
      myOFstream->close();
      delete myOFstream;
    }
  }
}


bool MscDataAccess::isLocked( const char * className , const char * methodName ,
                             const MscString & fileName , MscString & lockName )
{
  lockName  = fileName  ;
  lockName += "#locked" ;
  return MscUtl::fileExists( lockName );
}


bool MscDataAccess::lock( const char * className , const char * methodName ,
                         const MscString & filePath , const MscString & userMessageInTheLock )
{
  static const char * METHOD_NAME = "lock()" ;
  MscString lockName ;
  // can't do it as it's already locked
  if ( filePath.isBlank() == true ) {
    MscDg::info( CLASS_NAME , METHOD_NAME , "%s::%s: can't lock empty file..." , className , methodName );  
    return true ;
  }
  if ( isLocked(className,methodName,filePath,lockName) == true ) {
    // find out by who
    MscDataAccess da( lockName.c_str() , MscDataAccess::DA_READ_ASCII );
    MscString lockInfo("file doesn't exist");
    int length ;
    lockInfo = da.getNonEmptyLineWithFinalSpace(length);
    // inform
    MscDg::info( CLASS_NAME , METHOD_NAME , "%s::%s: '%s' exists (already locked by '%s')..." ,
                className , methodName , lockName.c_str() , lockInfo.c_str() );
    return false ;
  }
  // create it
  MscDataAccess da( lockName.c_str() , MscDataAccess::DA_WRITE_ASCII );
  // add user information
  if ( userMessageInTheLock.isEmpty() == false ) {
    da << userMessageInTheLock ;
  }
  else {
    MscString tmp;
    tmp.printf( "%s::%s" , className ? className : "" , methodName ? methodName : "" );
    da << tmp ;
  }
  da << "\n" ;
  // error 
  if ( da.isOk() == false ) {
    MscDg::info( CLASS_NAME , METHOD_NAME , "%s::%s: '%s' can't be created. (%s)..." ,
                className , methodName , lockName.c_str() , userMessageInTheLock .c_str() );
  }
  // ok if it could be done
  return da.isOk() ;
}


bool MscDataAccess::unlock( const char * className , const char * methodName ,
                           const MscString & filePath )
{
  static const char * METHOD_NAME = "unlock()" ;
  MscString lockName ;
  // ignore the lock on an empty file (as no lock is done on it)
  if ( filePath.isBlank() == true ) { 
    MscDg::info( CLASS_NAME , METHOD_NAME , "%s::%s: empty file..." , className , methodName );
    return true ;
  }
  // can't unlock
  if ( isLocked(className,methodName,filePath,lockName) == false ) {
    MscDg::info( CLASS_NAME , METHOD_NAME , "%s::%s: '%s' does not exist (can't unlock)..." ,
                className , methodName , lockName.c_str() );
    return false ;
  }
  // unlock
  MscUtl::unlink(lockName);
  return true ;
}


bool MscDataAccess::textFileContentToString( const MscString & filePath , MscString & contents )
{
  // open the file
  MscDataAccess da( filePath.c_str() , MscDataAccess::DA_READ_ASCII );
  // here it just rests the file isa open
  bool isOk = da.isOk();
  // read whilst there are lines in the file
  while ( da.isOk() == true && da.readNewLine() == true ) {
    contents += da.myBuffer ;
    contents += "\n" ;
  }
  return isOk ;
}


bool  MscDataAccess::open( const char * fileName , MscDataAccess::DataAccessType accessType )
{
  // not applicable
  if ( myStreamIsOwned == false ) {
    myMessage.printf( 
      "Can't close stream for '%s' in mode '%s' as existing stream is not owned." , 
      fileName , DataAccessStrings[ myDataAccessType ].c_str() );
    myFatalErrorMessage = myMessage ;
    showProgressInformation();
    return false ;
  }
  // apply it
  if ( fileName == 0 ) fileName = "" ;
  // close any opened one
  if ( close() == false ) return false ;
  // now save the parameters
  myDataAccessType  = accessType ;
  myFileName        = fileName   ;
  myFileExists      = false      ;
  myFileOverwritten = false      ;
  // open
  bool streamIsGood = false ;
  switch ( accessType ) {
    case MscDataAccess::DA_READ_ASCII :
      myFileExists      = MscUtl::fileExists( fileName );
      myIFstream        = new std::ifstream( fileName );
      streamIsGood      = myIFstream->good() ;
      myFileOverwritten = false ;
      break ;
    case MscDataAccess::DA_WRITE_ASCII :
      myFileExists      = MscUtl::fileExists( fileName );
      myOFstream        = new std::ofstream( fileName );
      streamIsGood      = myOFstream->good() ;
      myFileOverwritten = (myFileExists == true && streamIsGood == true);
      break ;
    default :
      break; // nothing
  }
  // test
  if ( streamIsGood == false ) {
    myMessage.printf( "Can't access '%s' in mode '%s'" , fileName , DataAccessStrings[ myDataAccessType ].c_str() );
    myFatalErrorMessage = myMessage ;
    showProgressInformation();
    close();
    return false ;
  }
  myPreviousWord.erase();
  myCurrentWord.erase();
  return true ;
}


MscDataAccess & MscDataAccess::operator<< ( const MscString & value )
{
  if ( canWrite() == true ) { *myOFstream << value ; }
  return *this ;
}


MscDataAccess & MscDataAccess::operator << ( const char * value )
{
  if ( canWrite() == true ) { *myOFstream << value ; }
  return *this ;
}


MscDataAccess & MscDataAccess::operator << ( double value )
{
  if ( canWrite() == true ) { *myOFstream << value ; }
  return *this ;
}


MscDataAccess & MscDataAccess::operator << ( float value )
{
  if ( canWrite() == true ) { *myOFstream << value ; }
  return *this ;
}


MscDataAccess & MscDataAccess::operator << ( size_t value )
{
  if ( canWrite() == true ) { *myOFstream << value ; }
  return *this ;
}


MscDataAccess & MscDataAccess::operator << ( int value )
{
  if ( canWrite() == true ) { *myOFstream << value ; }
  return *this ;
}



void  MscDataAccess::incrementNestingLevel()
{ 
  myNestingLevel += 1 ;
} 


void  MscDataAccess::decrementNestingLevel()
{
  myNestingLevel -= 1 ;
}


void  MscDataAccess::modifyNestingLevel( int i )
{
  myNestingLevel += i ;
}


void  MscDataAccess::writeSpaces()
{
  if ( myOFstream == nullptr ) { return ; }
  for ( int i=0 ; i < (myNestingLevel * MscDataAccess::NUMBER_OF_SPACES_FOR_NESTING) ; ++i ) {
    *myOFstream << " " ;
  }
}


bool  MscDataAccess::canWrite()
{
  if ( myOFstream != nullptr && myOFstream->good() == true ) {
    return true ;
  }
  else {
    MscDg::error( CLASS_NAME , "canWrite()" , "Can't write in '%s'" , myFileName.c_str() );
    return false ;
  }
}


bool  MscDataAccess::canRead()
{
  return (myIFstream != nullptr && myIFstream->good() == true && myIFstream->eof() == false);
}


bool  MscDataAccess::close()
{
  // leave the flags 'myFileExists' and 'myFileOverwritten' untouched
  if ( myStreamIsOwned == true ) {
    // this occurrs when the stresm is created in the (file name is provided)
    if ( myIFstream != nullptr ) {
      if ( myIFstream->is_open() == true ) { myIFstream->close(); }
      myIFstream = nullptr ;
    }
    if ( myOFstream != nullptr ) {
      if ( myOFstream->is_open() == true ) { myOFstream->close(); }
      myOFstream = nullptr ;
    }
    return true ;
  }
  else {
    return false ;
  }
}


const char * MscDataAccess::getNonEmptyLineWithFinalSpace( int & length )
{
  myCharNumber   = 0 ;
  myBufferLength = 0 ;
  while ( canRead() == true ) {
    // initialize to '\0' (avoid it to speed up)
    // *** memset( myBuffer , '\0' , MscDataAccess::READ_BUFFER_SIZE * sizeof(char) );
    // read (keep space for space)
    myLineNumber += 1 ;
    myIFstream->getline( myBuffer , (MscDataAccess::READ_BUFFER_SIZE - 1) , '\n' ) ;
    myBufferLength = std::strlen( myBuffer ) ;
    // if not empty ...
    if ( myBufferLength != 0 ) {
      // remove useless spaces
      for ( int i=(myBufferLength-1) ; i > 0 ; --i ) {
        // get rid of the final spaces
        if ( std::isspace(myBuffer[i]) ) {
          myBufferLength -= 1 ;
        }
        // till a non-space is found
        else {
          break ;
        }
      }
      // add only one space at the end
      myBuffer[ myBufferLength    ] = ' '  ;
      myBuffer[ myBufferLength +1 ] = '\0' ; // as not initialized MUST add the terminiating '\0'
      myBufferLength += 1 ;
      length = myBufferLength ;
      return myBuffer ;
    }
  }
  // end of file
  length = myBufferLength ;
  return 0 ;
}


bool MscDataAccess::readNextNewLineThatIsNotEmpty( MscString * outputString )
{
  while ( canRead() == true ) {
    if ( readNewLine() == true && myBufferLength != 0 ) {
      if ( outputString != 0 ) {
        *outputString = myBuffer ;
      }
      return true ;
    }
  }
  return false ;
}



bool MscDataAccess::readNewLine()
{
  MscString cc ;
  myCharNumber   = 0 ;
  myBufferLength = 0 ;
  memset( myBuffer , '\0' , MscDataAccess::READ_BUFFER_SIZE * sizeof(char) );
  if ( canRead() == false ) {
    return false ;
  }
  myLineNumber += 1 ;
  myIFstream->getline( myBuffer , MscDataAccess::READ_BUFFER_SIZE , '\n' ) ;
  // strip the line from start spaces
  cc = myBuffer ;
  myBufferLength = cc.length() ;
  // move to first non null character
  // (there are spaces before the first value as the spacing is added)
  if ( MscDataAccess::NUMBER_OF_SPACES_FOR_NESTING > 0 ) {
    while ( myCharNumber < myBufferLength ) {
      if ( myBuffer[myCharNumber] != ' ' ) {
        break ;
      }
      else {
        myCharNumber += 1 ; 
      }
    }
  }
  // done
  MscDg::trace( CLASS_NAME , "readNewLine()" , "At character %d lines is '%s'" , myCharNumber , & (cc.c_str()[myCharNumber]) );
  return true ;
}


bool  MscDataAccess::moveInLine( const char * separator )
{
  int separatorLength = separator ? strlen(separator) : 0 ;
  for ( int i=0 ; i < separatorLength ; ++i , ++myCharNumber ) {
    if ( myCharNumber >= myBufferLength ) {
      myMessage.printf( "(1) Unexpected end of line at character %d line %d (%s)" ,
                        myCharNumber , myLineNumber , myFileName.c_str() );
      showProgressInformation();
      return false ;
    }
    if ( myBuffer[ myCharNumber ] != separator[ i ] ) {
      myMessage.printf( "(1) Unexpected separator value '%c' instead of '%c' at character %d line %d (%s)" , 
                        myBuffer[ myCharNumber ] , separator[ i ] ,
                        myCharNumber , myLineNumber , myFileName.c_str() );
      showProgressInformation();
      return false ;
    }
  }
  return true ;
}


void MscDataAccess::checkWordIsNotEmptyString( MscString & cc )
{
  cc.strip( true ) ;
}


bool  MscDataAccess::getWord( const char * separator , MscString & cc )
{
  static const char * METHOD_NAME = "getWord()" ;
  // initialize output
  cc.erase();
  // check the input stream
  if ( canRead() == false ) {
    return false ;
  }
  // if the current line is empty, read a new one
  if ( myCharNumber >= myBufferLength ) {
    if ( readNextNewLineThatIsNotEmpty() == false ) {
      return false ;
    }
  }
  // move along the line (if there is a separator)
  if ( moveInLine( separator ) == false ) {
    return false ;
  }
  // nothing to read
  if ( myCharNumber >= myBufferLength ) {
    myMessage.printf( "(3) Unexpected end of line at character %d line %d (%s)" ,
                      myCharNumber , myLineNumber , myFileName.c_str() );
    showProgressInformation();
    return false ;
  }
  // read the values till a space is met
  bool readCharactersInLine = true ;
  while ( readCharactersInLine == true ) {
    // character to consider
    char c = myBuffer[ myCharNumber ] ;
    // character is a space
    if ( std::isspace(c) || c == '\0' || c == '\t' || c == '\r' || c == '\n' ) {
      // if in a word return the word
      if ( cc.isEmpty() == false ) {
        checkWordIsNotEmptyString( cc );
        MscDg::trace( CLASS_NAME , METHOD_NAME , "Word is '%s'" , cc.c_str() );
        // keep the history
        myPreviousWord = myCurrentWord ;
        myCurrentWord  = cc ;
        return true ;
      }
    }
    // character is to be saved
    else {
      // add the character
      cc += c ;
    }
    // next character
    myCharNumber += 1 ;
    // end of line
    if ( myCharNumber >= myBufferLength ) {
      checkWordIsNotEmptyString( cc );
      MscDg::trace( CLASS_NAME , METHOD_NAME , "Number %d Length %d Word is '%s'" , myCharNumber , myBufferLength , cc.c_str() );
      // keep the history
      myPreviousWord = myCurrentWord ;
      myCurrentWord  = cc ;
      return true ;
    }
  }
  MscDg::error( CLASS_NAME , METHOD_NAME , "Error with '%s'" , cc.c_str() );
  return false ;
}



bool    MscDataAccess::getBool  ( const char * separator , bool    & cc )
{
  MscString str ;
  bool isOk = getWord( separator , str );
  if ( isOk == true ) {
    str.toLowerCase();
    if ( str == "true" ) { cc = true ; }
    else if ( str == "false" ) { cc = false ; }
    else { cc = (str.readi() != 0) ; }
  }
  return isOk ;
}



bool    MscDataAccess::getInt   ( const char * separator , int     & cc )
{
  MscString str ;
  bool isOk = getWord( separator , str );
  if ( isOk == true ) {
    cc = str.readi();
  }
  return isOk ;
}


bool    MscDataAccess::getFloat ( const char * separator , float   & cc )
{
  MscString str ;
  bool isOk = getWord( separator , str );
  if ( isOk == true ) {
    cc = str.readf();
  }
  return isOk ;
}


bool    MscDataAccess::getDouble( const char * separator , double  & cc )
{
  MscString str ;
  bool isOk = getWord( separator , str );
  if ( isOk == true ) {
    cc = str.readd();
  }
  return isOk ;
}


bool  MscDataAccess::getEndOfLine( const char * separator , MscString & cc )
{
  cc.erase();
  if ( canRead() == false ) {
    return false ;
  }
  // move along the line (if there is a separator)
  if ( moveInLine( separator ) == false ) {
    return false ;
  }
  // if the current line is empty, nothing to do
  if ( myCharNumber >= myBufferLength ) {
    return true ;
  }
  // store the values till the end of the line
  cc = & myBuffer[ myCharNumber ] ;
  // all the line has been used
  myCharNumber = myBufferLength ;
  MscDg::trace( CLASS_NAME , "getEndOfLine()" , "End of line is '%s'" , cc.c_str() );
  return true ;
}


#ifndef GRA_BASE_LAYERS_HPP
#define GRA_BASE_LAYERS_HPP

#include <memory>
#include <vector>

#include "DatLocation.hpp"
#include "DatPoint.hpp"

#include "GraLibrary.hpp"

#include "MscString.hpp"
#include "MscDataHolder.hpp"

#include "TypColorsPM.hpp"

#include <QObject>

// data
class DatSlice ;

// types
class TypAxisPM ;
class TypDrawingLayerPM ;
class TypFontPM ;
class TypLayerManagerPM ;
class TypLinePM ;
class TypViewConfiguration ;

// GUI part
class GuiForm ;


/** \file GraBaseLayers .
 * It encapsulates the basic Graphic scenes and add them
 * to the plot or to a manager.
 *
 * GraColorMap   => cgColorMap
 * GraTitleLayer => cgAxisTitleScene
 * GraAxisLayer  => cgSimpleAdaptiveLinearAxis
 * GraScene      => cgMemoryScene
 *
 * See also: 'GraSeismicLayers' for cgSeismicTraceInterface , cgSeismiScene , .....
 */



//===================================================//
//===================================================//
// NAMESPACE                                         //
// Namespace for the Graphic Drawing Utilities        //
//===================================================//
//===================================================//


 

namespace Gra {
  
  /** apply 'TypFontPM' change */
  void setFontValues( cgScaledText               & , TypFontPM * , float * multiplyingFactor = 0 );
  void setFontValues( cgScaledText               & , int         , float * multiplyingFactor = 0 );
  void setFontValues( cgRestrictedText           & , TypFontPM * , float * multiplyingFactor = 0 );
  void setFontValues( cgRestrictedText           & , int         , float * multiplyingFactor = 0 );
  void setFontValues( cgSimpleAdaptiveLinearAxis & , TypFontPM * , float * multiplyingFactor = 0 );
  void setFontValues( cgSimpleAdaptiveLinearAxis & , int         , float * multiplyingFactor = 0 );
  void setFontValues( cgAttributeInterface       & , TypFontPM * , float * multiplyingFactor = 0 );

  /** apply 'TypAxisPM' change */
  void setAxisValues( cgSimpleAdaptiveLinearAxis & , TypAxisPM * , float * multiplyingFactor = 0 );
  void setAxisValues( cgSimpleAdaptiveLinearAxis & , int         , float * multiplyingFactor = 0 );

  /** apply 'TypLinePM' change */
  void setLineValues( cgSharedAttribute          & , int         , float * multiplyingFactor = 0 );
  void setLineValues( cgSharedAttribute          & , TypLinePM * , float * multiplyingFactor = 0 );
  void setLineValues( cgAttributeInterface       & , int         , float * multiplyingFactor = 0 );
  void setLineValues( cgAttributeInterface       & , TypLinePM * , float * multiplyingFactor = 0 );

  /** convert color */
  cgRgbColor getCgRgbColor( int colorId );

};




//===================================================//
//===================================================//
// RESOURCES                                         //
//===================================================//
//===================================================//


class GraLayer ;


class GraResource
{
public:
  static const char * CLASS_NAME ;

  /** constructor */
  GraResource( GraLayer & , MscDataTeam::ClassType classType , int subClassType );
  ~GraResource();

  /** get */
  GraLayer       & getLayer()     const { return myLayer        ; }
  MscDataTeam::ClassType getClassType() const { return myClassType ; }
  int             getSubClass()  const { return mySubClassType ; }
  const MscString & getName()      const { return myName         ; }

  /** update */
  bool            setSubClass( int s ) { mySubClassType=s ; return update() ; }
  virtual bool    update() = 0 ;

protected :

  /** the layer that creates this resource */
  GraLayer & myLayer ;
  /** the type of parameter model it is interested in */
  MscDataTeam::ClassType myClassType ; // e.g.: MscDataTeam::CT_TypLinePM  MscDataTeam::CT_TypFontPM
  /** the type of resource (from a given type) */
  int  mySubClassType   ; // e.g.: Typ::FontType such as 'FNT_TITLE'
  /** name */
  MscString myName ;

private :

  /** not implemented */
  GraResource();
  GraResource( const GraResource & );
  const GraResource & operator= ( const GraResource & );
};



class GraScaledText : public GraResource
{
public :
  static const char * CLASS_NAME ;
  GraScaledText( GraLayer & , int resId );
  ~GraScaledText();

  /** the Graphic resource */
  cgScaledText & getScaledText() { return myScaledText; }

  /** static method (called by "update()") . Returns "true" if a change occurred */
  static float getFontSize( int fontId );
  static bool  updateFont( cgScaledText & , int fontId );
  static bool  updateFont( cgRestrictedText & , int fontId );

  /** set values */
  void setString( const MscString & );

private :

  MscString    myString     ;
  cgScaledText myScaledText ;

  /** set values */
  bool update();

  /** not implemented */
  GraScaledText();
  GraScaledText( const GraScaledText & );
  const GraScaledText & operator= ( const GraScaledText & );
};




class GraAttribute : public GraResource
{
public :

  static const char * CLASS_NAME ;
  GraAttribute( GraLayer & , int resId );
  ~GraAttribute();

  /** the Graphic resource */
  cgSharedAttribute & getGraphicAttribute() { return myGraphicAttribute ; }

private :

  cgSharedAttribute myGraphicAttribute ;

  /** set values */
  bool update();

  /** not implemented */
  GraAttribute();
  GraAttribute( const GraAttribute & );
  const GraAttribute & operator= ( const GraAttribute & );
};




//===================================================//
//===================================================//
// COLOUR MAP and colour operations                  //
//===================================================//
//===================================================//


class GraColorMap : public QObject {
  Q_OBJECT
public :
  static const char * CLASS_NAME ;

  /** constructor */
  GraColorMap( TypColormapPM & c );

  /** desctructor */
  ~GraColorMap();

public slots:
  /** change of parameters from 'TypColormapPM' */
  void               changedSignalsSet( std::set<int> * );

public:
  /** number of colors */
  int                getNumberOfColors() const { return (myGraphicColorMap ? myGraphicColorMap->size() : 0); }

  /* index of a color */
  int                getIndexOfColor( float minV , float value , float maxV , bool & isWithinRange );

  /** access to the Graphic colormap */
  const cgColorMap & getGraphicColorMap() const { return *myGraphicColorMap; }

  /** access to a specific value withing a range */
  cgBitmapColor      getGraphicColor( float minV , float value , float maxV , bool & isWithinRange );

  /** utility function: convert from parameter value to Graphic color */
  static cgRgbColor  getGraphicColor( int colorId );

private :

  /** Not implemented */
  GraColorMap();
  GraColorMap( const GraColorMap & );
  
  /** parameter model */
  TypColormapPM & myColormapPM     ;
  /** Graphic colormap */
  cgColorMap   * myGraphicColorMap  ;
};



//===================================================//
//===================================================//
// LAYER .                                           //
// Interface for the layer of the layer manager      //
//===================================================//
//===================================================//


class GraLayerVirtualInterface ;
class GraLayerVirtualManager   ;
class GraLayerPinUpLocator     ;
class GraLayerVirtualComposite ;



class GraLayer {
public :
  static const char * CLASS_NAME ;

  /**---------------------------------------
   * Type of the Layer 
    --------------------------------------- */

  enum ClassType {
    LAYER_UNDEFINED      = 0 ,
    /*--------------------------------------*/
    /** FOLLOWING ARE ON THE FRAME          */
    /*--------------------------------------*/
    /** ** TITLE ** **/
    TITLE_TOP            ,
    TITLE_BOTTOM         ,
    TITLE_LEFT           ,
    TITLE_RIGHT          ,
    TITLE_FIRST          = TITLE_TOP   ,
    TITLE_LAST           = TITLE_RIGHT ,
    /** ** AXIS ** **/
    AXIS_TOP             ,
    AXIS_BOTTOM          ,
    AXIS_LEFT            ,
    AXIS_RIGHT           ,
    AXIS_FIRST           = AXIS_TOP   ,
    AXIS_LAST            = AXIS_RIGHT ,
    /*--------------------------------------*/
    /** LAYERS IN THE VIEW                  */
    /*--------------------------------------*/
    VIEW_DRAWING         , // GraDrawingLayer
    VIEW_OVERLAY         , // GraOverlayMgt
    VIEW_CONTOUR         , // GraContourLayer
    VIEW_GRID            , // GraGridLayer
    VIEW_CACHE           , // GraCacheLayer
    VIEW_GADGET          , // GraGadgetLayer
    // 
    VIEW_FIRST           = VIEW_DRAWING ,
    /*--------------------------------------*/
    /* DIMENSIONS : put them here else it   */
    /*              modifies the enum.      */
    /*--------------------------------------*/
    TITLE_DIMENSION      = (TITLE_LAST - TITLE_FIRST + 1) ,
    AXIS_DIMENSION       = (AXIS_LAST  - AXIS_FIRST  + 1)
  };

  /** constructor / destructor */
  GraLayer( GraLayerVirtualManager & , ClassType , int userId = (-1) );
  virtual ~GraLayer();

  /** manager */
  GraLayerVirtualManager   & getManager() { return myManager ; }
  GraLayerVirtualInterface & getInterface();
  float                      getMultiplyingFactor();

  /** Graphic scene and layer */
  virtual cgScene         & getGraphicScene() = 0 ;
  cgViewSceneLayer        & getGraphicLayer() { return myGraphicLayer ; }

  /** resources ("myAttribute" is in fact added to "") */
  GraAttribute          * getAttribute()   { return myAttribute ; } // added to "std::vector< GraResource * >" as "classTypw LineId")
  cgSharedAttribute         getGraphicAttribute( int subClass = -1 ); // if (-1), take the first one

  /** show (if 'b' is 'true') / hide (if 'b' is 'false') .
   *  "myGraphicLayer" is created and added if possible (back, front or reference is provided) */
  virtual bool show( Typ::Order = Typ::ORD_BESIDE , GraLayer * reference = 0 ) = 0;
  virtual bool hide() = 0 ;

  /** 'dirty' indicates it needs to be redrawn */
  void         addIsDirty( int i = 1 ) { myIsDirty |= i ; }
  void         setIsDirty( int i = 1 ) { myIsDirty  = i ; }
  int          getIsDirty() const { return myIsDirty ; }

  /** invalidate */
  void         update_notification( bool );
  virtual void invalidate( bool = true );

  /** draw . update when a resource has changed */
  virtual void draw( bool = true ) = 0 ;

  /** get methods: the type, userId, state of the layer, ...  */
  const MscString & getName()    const   { return myName         ; }
  ClassType    getClassType()  const   { return myClassType    ; }
  int          getSubClass()   const   { return mySubClassType ; }
  bool         getIsShown()    const   { return myIsShown      ; }
  bool         getIsEditable() const   { return myIsEditable   ; }
  void         setIsEditable( bool b ) { myIsEditable = b      ; }
  bool         typeIsHorizontal() const ;
  cgRect       getBoundingBox( bool & b ) { b=myBoundingBoxIsDefined ; return myBoundingBox ; }
  
  /** composite (ask him before redrawing) . origin of the data to ask */
  void         setComposite( GraLayerVirtualComposite * c ) { myComposite = c ; }
  void         setDataOrigin( int i )  { myDataOrigin = i ; }

  /** Resources */
  bool         changedHolderSet( MscDataTeam * dh , std::set<int> * cg );
  virtual bool update( MscDataTeam * dh , std::set<int> * cg ) = 0 ; // internal of the derived class

  /** management of the owned 'GraResource' */
  int          updateResources( MscDataTeam * dh , std::set<int> * cg ); // update the classes returns the number of changes
  bool         manageResource( GraResource * , bool addIt );
  bool         createResource( MscDataTeam::ClassType classType , int subClass );
  bool         deleteResource( MscDataTeam::ClassType classType , int subClass );
  GraResource * getResource( MscDataTeam::ClassType classType , int subClass = -1 ); // if it's (-1) it's the first one ...

  /** get the attribute of the resource */
  bool         hasColorMap() const { return (myColorMap.get() != nullptr) ; }
  void         setColorMap( const std::shared_ptr < GraColorMap > & c ) { myColorMap = c; }
  GraColorMap & getColorMap();

  /** user pressed a button . should be implemented in the derived class 
   * or dealt with by the composite */
  enum ButtonAction { BUTTON_DOWN , BUTTON_MOVE , BUTTON_UP };
  virtual void onButtonAction( ButtonAction , int button , cgCrd location , bool isInside , bool shift , bool control , bool alt ); 

protected :

  /** layer manager . It can also be used by a composite */
  GraLayerVirtualManager   & myManager     ;
  GraLayerVirtualComposite * myComposite   ;

  /** 'id' of the layer */
  ClassType                 myClassType   ;
  int                       mySubClassType;
  /** state */
private:
  bool                      myInit        ;
protected:
  int                       myIsDirty     ;
  MscString                 myName        ;
  cgViewSceneLayer          myGraphicLayer ; // crash if it's 'cgViewLayer' at 'cgISafePtr<cgViewManagerObject>::cgISafePtr$base()'
  bool                      myIsShown     ;
  /** editing: does the mouse affects it? (only one at a time) */
  bool                      myIsEditable  ;
  /** size hint: bounding box. Use to define 'myModelLimits' */
  cgRect                    myBoundingBox ;
  bool                      myBoundingBoxIsDefined ;
  /** type of data to ask . Value provided by the user */
  int                       myDataOrigin  ;

  /** the resources */
  std::vector< GraResource * > myResources   ; // std::vector of resources
  GraAttribute            * myAttribute   ; // it's added to "myResources"

private :

  /** colormap (provided else the default one). 
   *  Access protected as it might be created on the fly */
  std::shared_ptr < TypColormapPM >  myColormapPM ;
  std::shared_ptr < GraColorMap >    myColorMap   ;

private :

  /** not implemented */
  GraLayer();
  GraLayer( const GraLayer & );
  const GraLayer & operator= ( const GraLayer & );
};




/** --------------------------------------
 * GraLayerVirtualComposite : manages several base layers
 -------------------------------------- */



class GraLayerVirtualComposite {
public :
  static const char * CLASS_NAME ;

  GraLayerVirtualComposite( GraLayerVirtualManager & );
  virtual ~GraLayerVirtualComposite();
  /** show (if 'b' is 'true') / hide (if 'b' is 'false') . create only if needed */
  void      show( Typ::Order = Typ::ORD_BESIDE , GraLayer * reference = 0 );
  void      hide();
  /** services */
  int       getNumberOfLayers() const { return myLayers.size(); }
  /** rank=0: bottom layer , (-1): top layer */
  GraLayer * getLayer( int rank = (-1) );
  GraLayer * getTopLayer() { return getLayer(-1); }
  GraLayer * getEditableLayer() ;
  /** update */
  void      update_notification( bool );
  void      invalidate( bool = true ) ;
  /**--------------------------*/
  /** REQUESTS FROM THE LAYERS */
  /**--------------------------*/
  /** called when the layer is about to draw (GraLayer::draw() or get a user action ).
   * It deleguates the drawing action to the composite 
   * Return 'false' if the action has been performed by the composite. */
  virtual bool aboutToDraw( GraLayer * ) = 0 ;
  virtual bool aboutButtonAction( GraLayer * , GraLayer::ButtonAction , int button ,
                                  cgCrd location , bool isInside ,
                                  bool shift , bool control , bool alt ) = 0 ;
protected :
  /** layer manager */
  GraLayerVirtualManager & myLayerManager ;
  std::vector< GraLayer * >     myLayers       ;
};



//===================================================//
//===================================================//
// TITLE LAYER                                       //
//===================================================//
//===================================================//



class GraTitleLayer : public GraLayer {

public :

  static const char * CLASS_NAME ;

  /** construcor , destructor */
  GraTitleLayer( GraLayerVirtualManager & , GraLayer::ClassType type , const char * text="" , bool isShown=false );
  ~GraTitleLayer();

  /** add it or remove it to the plot . here, "show" parameters aren't used */
  bool show( Typ::Order = Typ::ORD_BESIDE , GraLayer * reference = 0 );
  bool hide();
  cgScene & getGraphicScene() { return myGraphicScene; }
  void draw( bool = true ) {}

  /** modify display */
  void setString( const MscString & text );

private :

  /** set values */
  bool update( MscDataTeam * dh , std::set<int> * cg );

  MscString         myString      ;
  GraScaledText   * myText        ;
  cgAxisTitleScene  myGraphicScene ;

};



//===================================================//
//===================================================//
// AXIS LAYER                                        //
// See: GraSeismicAxisDoc::myBuildVerticalAxis => cgAxisLinearTickGenerator
//    : GraSeismicTickGenerator                => cgAxisTickGenerator  Axis/TickGenerator.h
// See: Axis/TickGenerator.h
//    : cgAxisTickGenerator                     : base class . uses "cgAxisTick"
//    :    cgAxisBaseTickGenerator              : has  "no_limits"
//    :       cgAxisLinearTickGenerator         : uses "origin" "step" [myMajor...]
//    :       cgAxisAdaptiveLinearTickGenerator : uses "origin" "precision" "cgAxisAdaptiveLinearTickGenerator" [myAutoMajor...]
// See: PlotHelper/SimpleAxis.h
//    : Axis are added to "cgSimpleAxis"
//    : cgAxisScene
//    :    cgSimpleAxis
//    :       cgSimpleAdaptiveLinearAxis
//    :       cgSimpleLinearAxis
//    :       cgSimpleLogAxis
// See: Axis/AxisScene.h
//    :    cgScene                     : has "offset" "scale"
//    :       cgAxisScene              : has "offset" "scale"
// See: Plot/SimplePlot.h
//    :    cgSimplePlotObject          : has "cgPlotAxisFrame" "cgPlotFrame" "border" "weight"
//    : Plot/PlotFrames.h
//    :    cgPlotAxisFrameObject       : has "low_margin" "high_margin"
//===================================================//
//===================================================//



class GraAxisLayer : public GraLayer {
public :
  static const char * CLASS_NAME ;

  /** Location in the plot */
  GraAxisLayer(  GraLayerVirtualManager & , GraLayer::ClassType type , bool isShown=false );
  ~GraAxisLayer();

  /** add it or remove it to the plot . here, "show" parameters aren't used */
  bool show( Typ::Order = Typ::ORD_BESIDE , GraLayer * reference = 0 );
  bool hide();
  cgScene & getGraphicScene() { return myGraphicScene; }
  void draw( bool = true ) {}

private :

  /** set values */
  bool update( MscDataTeam * dh , std::set<int> * cg );

  /** resources */
  int  mySize         ;
  int  myMajorFont    ;
  int  myMinorFont    ;
  int  myAxisType     ;
  cgSimpleAxis  myGraphicScene ;
  /** tick generators */
  // linear tick generator .
  cgAxisLinearTickGenerator myMajorGenerator ;
  cgAxisLinearTickGenerator myMinorGenerator ;
};




//===================================================//
//===================================================//
// DRAWING LAYER                                     //
// Used to draw a vertical line in the background    //
// (by Default)                                      //
// In fact, can be used tio draw any number of       //
// shapes in the 'cgMemoryScene' scene               //
//===================================================//
//===================================================//

// See: "GraDrawingLayer.hpp"





//===================================================//
//===================================================//
// OVERLAY (seismic) LAYER                           //
//===================================================//
//===================================================//

// See: "GraSeismicLayer.hpp"





//===================================================//
//===================================================//
// CONTOUR LAYER                                     //
// used to draw a contour                            //
// in the 'cgContourScene' scene                     //
//===================================================//
//===================================================//


class GraContourLayer : public GraLayer {
public :
  static const char * CLASS_NAME ;

  enum SubClassType { CONTOUR_SEMBLANCE , CONTOUR_MAP };
  GraContourLayer( GraLayerVirtualManager & , int userId = CONTOUR_SEMBLANCE );
  ~GraContourLayer();

  /** add or remove the scene. Return the layer */
  bool show( Typ::Order = Typ::ORD_BESIDE , GraLayer * reference = 0 );
  bool hide();
  cgScene & getGraphicScene();

  void draw( bool = true );

private :

  /** set values */
  bool update( MscDataTeam * dh , std::set<int> * cg );

  /** CONTOUR */
  std::shared_ptr< cgGridRange >         myGraphicRange       ;
  std::shared_ptr< cgContourGrid >       myGraphicGrid        ;
  std::shared_ptr< cgContourFillVisual > myGraphicFillVisual  ;
  std::shared_ptr< cgContourScene >      myGraphicScene       ;
};




//===================================================//
//===================================================//
// CACHE LAYER                                       //
//===================================================//
//===================================================//



class GraCacheLayer : public GraLayer {
public :
  static const char * CLASS_NAME ;

  GraCacheLayer( GraLayerVirtualManager & , int userId = (-1) );
  ~GraCacheLayer();

  /** add or remove the scene. Return the layer */
  bool show( Typ::Order = Typ::ORD_BESIDE , GraLayer * reference = 0 );
  bool hide();
  cgScene                & getGraphicScene() { return myGraphicScene; }
  cgViewWindowCacheLayer & getCacheLayer()  { return myCacheLayer ; }
  void draw( bool = true ) {}
  void invalidate( bool );

private :
  /** set values */
  bool update( MscDataTeam * dh , std::set<int> * cg );
  /** dummy scene as the cache is a layer */
  cgMemoryScene          myGraphicScene ;
  /** the cache is a layer */
  cgViewWindowCacheLayer myCacheLayer  ;
};




//=======================================================================
//=======================================================================
// GraGridLayer
//=======================================================================
//=======================================================================



class GraGridLayer : public GraLayer {
public :
  static const char * CLASS_NAME ;

  enum SubClassType { GRID_DEFAULT };
  GraGridLayer( GraLayerVirtualManager & , int userId = GRID_DEFAULT );
  ~GraGridLayer();

  /** add or remove the scene. Return the layer */
  bool show( Typ::Order = Typ::ORD_BESIDE , GraLayer * reference = 0 );
  bool hide();
  cgScene & getGraphicScene() ;
  void draw( bool = true );


private :

  /** set values */
  bool update( MscDataTeam * dh , std::set<int> * cg );

  /** Graphic */
  cgGridScene               myGraphicScene ;
  std::shared_ptr<cgGridLineVisual> myVisual ;
  cgGridScene               myScene       ;
  cgAxisLinearTickGenerator myGenerator   ;
  
};






//=======================================================================
//=======================================================================
// GraGadgetLayer : it enables the selection of values in a scene.
//=======================================================================
//=======================================================================


class GraPicksInterface {

public :
  static const char * CLASS_NAME ;
  GraPicksInterface() {}
  /** common to stacks and mini-stacks */
  virtual cgRect                       getLimits();
  virtual TwoIntKey                    getKeyFromBinPos( const BinPos & );
  virtual BinPos                       getBinPosFromKey( const TwoIntKey & );
  /** flatten the data */
  virtual float                        convertFloatingToFlat( const BinPos & , double timeMs  );
  virtual float                        convertFlatToFloating( const BinPos & , double timeSec );
  /** access to the field */
  virtual int                          getPanel();
  virtual bool                         getPicksAreVisible( int );
  virtual const std::shared_ptr< DatPointFunctionType > & getDatPoint( int , BinPos & );
  virtual int                          findTraceFromHeaderWithTest( double head , bool closest );
};



class GraPickValues : public cgObject {
public:
  static const char * CLASS_NAME ;

  enum DataType {
    DT_UNDEFINED=0,
    DT_MN_CURRENT,  // pick on the line
    DT_MN_PREVIOUS, // adjacent pick
    DT_MN_NEXT,
    DT_MN_BACK,
    DT_MN_FRONT,
    DT_GF_CURRENT,  // guide function
    DT_GF_PREVIOUS,
    DT_GF_NEXT,
    DT_GF_BACK,
    DT_GF_FRONT
  };
  enum SymbolType {
    SB_UP_ARROW = 0,
    SB_DOWN_ARROW,
    SB_LEFT_ARROW,
    SB_RIGHT_ARROW,
    SB_MULTIPLY,
    SB_SQUARE,
    SB_ADD,
    SB_NONEX ,
    SB_ELLIPSE
  };

  // create / copy / delete
  GraPickValues( const BinPos & binPos , int timeMs , DataType , SymbolType );
  GraPickValues( const GraPickValues & model );
  const GraPickValues & operator= ( const GraPickValues & model );
  bool operator== ( const GraPickValues & model );
  bool isSameLocation( const BinPos & binPos , int timeMs , DataType ) const ;
  ~GraPickValues();

  // members
  BinPos     myBinPos   ;
  int        myTimeMs   ;
  DataType   myDataType ;
  SymbolType mySymbolId ;

  // data
  float myVelocity  ;
  float myFOC       ;
  float myEta       ;

  // static helper functions .
  // TwoIntKey : is how the data are stored in the display  (example: traceNumber , lineNumber ) DEPENDS On VIEW
  // BinPos    : is how the data are stored in the session  (example: inLine crossLine) ALWAYS THE  SAME
  typedef std::map< TwoIntKey , std::set< int > >             LocationTimesType  ;
  typedef std::map< TwoIntKey , std::vector< GraPickValues > > LocationValuesType ;
  static void sortByLocation( GraPicksInterface & , const std::vector< GraPickValues > & , LocationTimesType  & );
  static void sortByLocation( GraPicksInterface & , const std::vector< GraPickValues > & , LocationValuesType & );

  typedef std::map< BinPos , std::set< int > >              BinPosTimesType  ;
  typedef std::map< BinPos , std::vector< GraPickValues > > BinPosValuesType ;
  static void sortByBinPos( GraPicksInterface & , const std::vector< GraPickValues > & , BinPosTimesType  & );
  static void sortByBinPos( GraPicksInterface & , const std::vector< GraPickValues > & , BinPosValuesType & );

  static bool removePick( GraPicksInterface & , std::vector< GraPickValues > & selPoints , const BinPos & , int , DataType );
  static int  printPicks( GraPicksInterface & , const std::vector< GraPickValues > & selPoints );

};




class GraDrawingLayer ;


class GraGadgetLayer : public GraLayer {
public :
  static const char * CLASS_NAME ;

  enum SubClassType { GADGET_DEFAULT };
  GraGadgetLayer( GraLayerVirtualManager & , int userId = GADGET_DEFAULT );
  ~GraGadgetLayer();

  /** add it or remove it to the plot . here, "show" parameters aren't used */
  bool   show( Typ::Order = Typ::ORD_BESIDE , GraLayer * reference = 0 );
  bool   hide();
  void   draw( bool = true ) {}
  cgScene           & getGraphicScene() { return myGraphicScene ; }
  cgViewGadgetLayer & getGraphicLayer() { return myGraphicLayer ; }

  /** pure virtual of "GraLayer" */
  bool   update( MscDataTeam * dh , std::set<int> * cg ) { return false ; }

  /** dragbox members */
  void   startDragBox( cgCrd , GraDrawingLayer * = 0 ); // used to convert the location
  bool   isDragBoxActive();
  void   moveDragBox( cgCrd , cgRect * rect = 0 );
  cgRect stopDragBox( cgCrd );
  //     extract the picks to have an action on and do the action
  bool   stopDragBox( cgCrd             location     ,  // end location . same as in "stopDragBox"
                      const char      * titleName    ,  // title . Key word for the question if no message .action to perform
                      const char      * questionText ,  // null if only a question on the number
                      GuiForm         * guiForm      ,  // form to show the question
                      GraDrawingLayer & picksLayer   ,  // picks layer to select picks on
                      std::vector< GraPickValues > & selPoints // selected points
                      );

  /** rubber band members */
  void   startPointsBox( GraDrawingLayer & layer );
  bool   isPointsBoxActive();
  void   trackPointsBox( cgCrd location );
  void   addInPointsBox( cgCrd location );
  void   deleteLastInPointsBox();
  void   stopPointsBox( std::vector<cgCrd> * = 0 );

private :

  /** unused . needed to be a "GraLayer" */
  cgMemoryScene          myGraphicScene     ;

  /** layer added above the previous ones */
  bool                   myLayerIsShown    ;
  cgViewGadgetLayer      myGraphicLayer     ;

  /** box manapulator */
  cgDragBoxManipulator * myDragBox         ;
  GraDrawingLayer      * myDragBoxLayer    ;
  /** line manapulator */
  cgPointSetCreationManipulator * myPointsBox ;
  GraDrawingLayer      * myPointsBoxLayer  ;
  cgPolyline             myRubberBandShape ;

};






//===================================================//
//===================================================//
// LAYER MANAGER                                     //
// GraLayerVirtualManager : displays all in the plot //
//===================================================//
//===================================================//



class GraLayerVirtualManager : public QObject {
  Q_OBJECT
public :
  static const char * CLASS_NAME ;

  /** enum */
  enum ViewType { UNDEFINED_VALUE=-9999999, BOTTOM_AXIS=1, BOTTOM_TITLE, DATA_AREA, LEFT_AXIS, LEFT_TITLE,
      RIGHT_AXIS, RIGHT_TITLE, TOP_AXIS, TOP_TITLE };

  /** typedef: layer map */

  typedef std::vector< std::shared_ptr< GraLayer > > LayerMap ;

  /** values */

  static const float MS_TO_SEC ;
  static const float SEC_TO_MS ;

  /** pin-up locator functionalities added if the pin-up manager is present */

  GraLayerVirtualManager( GraLayerVirtualInterface & intf , bool sendRequest );
  virtual ~GraLayerVirtualManager();

public slots :


public:

  /** interface. provides services , data , information .
   *  Its derived instance can modify the layers */

  friend class GraLayerVirtualInterface ;
  GraLayerVirtualInterface & getInterface() { return myInterface ; }
  GraLayerVirtualInterface & getIntf()      { return myInterface ; }

  /** management of the layers in "myLayers" */

  bool      addLayer      ( GraLayer * l , bool addIt );
  bool      addLayer      ( GraLayer * l ) { return addLayer( l , true ); }
  bool      removeLayer   ( GraLayer * l ) { return addLayer( l , false ); }

  bool      hasLayer      ( GraLayer::ClassType , int subClassType = -1 ) const ; // (-1) is any.
  GraLayer* getLayer      ( GraLayer::ClassType , int subClassType = -1 );
  GraLayer* getFirstLayer ();
  GraLayer* getFirstViewLayer();
  GraLayer* getLastLayer  ();
  int       getNumberOfLayers() const { return myLayers.size(); }

  /** commands for the layers of the view (hide, show, draw) */

  void      updateLayersVisibility();
  void      setViewLayersDirty();
  void      setLayerIsDirty( GraLayer::ClassType , int subClassType );
private :
  void      hideViewLayers();
  void      showViewLayers();
public :
  void      drawViewLayers();
  void      invalidateViewLayers();

  /** the editable layer (receives the mouse inputs) */

  GraLayer* getEditableLayer() ;
  void      setEditableLayer( GraLayer * );

  /** basic graphics methods related to the interface with the widgets. */
  /** e.g.: user pressed a button . The editable layer will receive it */

  virtual void   onMouseMotion( cgCrd );
  virtual void   onButtonDown( int, cgCrd, bool, bool );
  virtual void   onButtonMove( int, cgCrd, bool, bool );
  virtual void   onButtonUp(   int, cgCrd, bool, bool );
  virtual void   onKeyPress( unsigned long, bool, bool );
  virtual void   onKeyRelease( unsigned long, bool, bool );

  virtual void   doReDraw();
  virtual bool   getDataAreaIsDefined();
  virtual cgRect getDataArea();
  virtual std::pair< cgCrd, cgCrd > getDataRange();
  virtual void   fitDataRange( cgRect limits, bool both );
  virtual void   fitScales( cgDim x, cgDim y );

  /** provide the limits. They are defined by the leading layer
   * -the one that is the "raison d'etre" of the view.
   * For instance, in a velocity graph , the leading layer is the velocity drawer . */
  virtual cgRect getModelLimits();
  virtual void   setModelLimits( const cgRect & );

  virtual cgRect getModelViewport() ;
  virtual bool   getDisplayLeftToRight() const ;

  /** cursor types */

  void      setCursorType( Typ::CursorType );

protected :

  /**---------------------------------------------------
   * invalidate , rescale , mapping . 
   * It affect the 'myPixelsPerVU' and 'myPixelsPerS' values .
   * vcResize()       : is called by the parent
   * redraw()         : invalidates all ViewSceneLayers, so forcing Graphic to redraw
   * mappingChanged() : connected to MappingChanged signal.
   *                    stores the new scale into the parameter model 
   *                    and calls redraw().
   **---------------------------------------------------*/

  /** methods */
  void      connectMapping( bool );
  void      reScale();
  void      setScaleFactors( float vu , float tu );
  void      redraw();
  void      mappingChanged();

  /** change of the parameters (connection with 'TypAppPM::instance()') */
  void      changedHolderSet( MscDataTeam * dh , std::set<int> * cg );
  
  /** flag used when connecting with the mapping */
  bool                         myViewIsConnected          = false ;
  /** interface / controller / services provider at the application level */
  GraLayerVirtualInterface   & myInterface                ;
  /** layer manager */
  std::shared_ptr< TypLayerManagerPM >  myLayerManagerPM  ;
  /** layers that are created and managed */
  LayerMap                     myLayers                   ;
  cgViewSceneLayer             myBaseLayer                ;
  /** pin-up locator (might be null) */
  GraLayerPinUpLocator        * myPinUpLocator            = nullptr ;
  /** cursor type */
  Typ::CursorType               myCursorType              ;
  /** The model limits. Technically, these are the limits of the contour data.
  *   It is also also used as the model limits for the entire display. */
  cgRect                       myViewModelLimits          ;
  /** information about the view */
  float                        myDpi                      = 70 ;
  /** Default Pixels Per Horizontal Unit scale (Velocirt: VU) and Vertical Unit (time in Second:S) */
  double                       myPixelsPerVU              ;
  double                       myPixelsPerS               ;
  /** If true, then setScaleFactors doesn't rescale or redraw (used by mapping changed) */
  bool                         myIgnoreScaleFactorRedraw  ;

};

#endif

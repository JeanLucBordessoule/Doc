#ifndef VS_LAYER_VIRTUAL_INTERFACE_HPP
#define VS_LAYER_VIRTUAL_INTERFACE_HPP

/**
 ** GraLayerVirtualInterface :
 ** virtual base class for providing services , data for "GraLayerVirtualManager"
 **/


#include <memory>

#include "DatLocation.hpp"

#include "MscDebug.hpp"
#include "DatPoint.hpp"

#include "GraLibrary.hpp"


class TypViewConfiguration      ;

class DatSlice                  ;

class GraGuiStatus              ;
class GraLayer                  ;
class GraLayerVirtualManager    ;
class GraPinUpDM                ;

class GuiForm                   ;
class GuiScrolledGraphicWidget  ;




class GraLayerVirtualInterface {

public :
  static const char * CLASS_NAME ;

  /** constructor / destructor */
  GraLayerVirtualInterface(){}
  virtual ~GraLayerVirtualInterface();
  
  virtual TypViewConfiguration          & getViewConfiguration() = 0 ;
  virtual GuiForm                       * getGuiForm();
  virtual GuiScrolledGraphicWidget      * createGraphicCanvas();
  virtual float                           getMultiplyingFactor();

  /** used by the creation */
  virtual bool                           updateVisibility( GraLayer & );
  enum RequestType { RQST_CREATE_PLOT , RQST_CREATE_LAYERS } ;
  virtual void                           layersRequest( GraLayerVirtualManager & , RequestType );

  /** needed by some layers (vertical layer with the orientation) */
  virtual bool                           getDisplayRightToLeft();

  /** common to stacks and mini-stacks */
  virtual cgRect                         getLimits();
  virtual TwoIntKey                      getKeyFromBinPos( const BinPos & );
  virtual BinPos                         getBinPosFromKey( const TwoIntKey & );
  // use "horizon" to flatten the data
  virtual float                          convertFloatingToFlat( const BinPos & , double timeMs  );
  virtual float                          convertFlatToFloating( const BinPos & , double timeSec );

  /** location */
  virtual BinPos                         getBinPos() ;
  /** provides the data section to draw the values from */
  virtual std::shared_ptr < DatSlice >   getSemblanceSection( int ) ;
  virtual std::shared_ptr < DatSlice >   getSeismicSection( int ) ;

  /** access to the field */
  virtual int                                     getPanel();
  virtual bool                                    getPicksAreVisible( int );
  virtual const std::shared_ptr< DatPointFunctionType > & getDatPoint( int , BinPos & );
  virtual int                                     findTraceFromHeaderWithTest( double head , bool closest );  

};



#endif


#include "GraLayerVirtualInterface.hpp"

#include "DatLocation.hpp"
#include "DatPoint.hpp"
#include "DatSlice.hpp"

#include "GraBaseLayers.hpp"

#include "MscDebug.hpp"



//=======================================================================
//=======================================================================
// GraLayerVirtualInterface
//=======================================================================
//=======================================================================


const char * GraLayerVirtualInterface::CLASS_NAME = "GraLayerVirtualInterface" ;


GraLayerVirtualInterface::~GraLayerVirtualInterface()
{
  
}


/** needed by the creation */



GuiForm * GraLayerVirtualInterface::getGuiForm()
{
  return 0 ; 
}


GuiScrolledGraphicWidget * GraLayerVirtualInterface::createGraphicCanvas()
{
  return 0 ; 
}


float GraLayerVirtualInterface::getMultiplyingFactor()
{
  return 1.0f ;
}


bool GraLayerVirtualInterface::updateVisibility( GraLayer & layer )
{
  // layer
  return true ;
}



void GraLayerVirtualInterface::layersRequest( GraLayerVirtualManager & , GraLayerVirtualInterface::RequestType )
{
}


bool GraLayerVirtualInterface::getDisplayRightToLeft()
{
  return true ;
}



/** common to stacks and mini-stacks */
cgRect GraLayerVirtualInterface::getLimits()
{
  MscDg::error( CLASS_NAME , "getLimits()" , "need to be re-implemented" );
  return cgRect();
}



/** access to the field */
int GraLayerVirtualInterface::getPanel()
{
  MscDg::error( CLASS_NAME , "getPanel()" , "need to be re-implemented" );
  return 0 ;
}


TwoIntKey GraLayerVirtualInterface::getKeyFromBinPos( const BinPos & binPos )
{
  MscDg::error( CLASS_NAME , "getKeyFromBinPos()" , "%d  %d  need to be re-implemented" , 
               binPos.getInline() , binPos.getCrossline() );
  TwoIntKey key(binPos);
  return key ;
}



BinPos GraLayerVirtualInterface::getBinPosFromKey( const TwoIntKey & key )
{
  MscDg::error( CLASS_NAME , "getBinPosFromKey()" , "%d  %d  need to be re-implemented" , 
               key.getPrime() , key.getSecondary() );
  BinPos binPos(key);
  return binPos ;
}



float  GraLayerVirtualInterface::convertFloatingToFlat( const BinPos & binPos , double doubleTimeMs )
{
  // cast ... in fact it's an int used to store the time in millisecond
  float timeMs = (float)doubleTimeMs ;

  MscDg::error( CLASS_NAME , "convertFloatingToFlat()" ,
               "Location %d  %d  TimeMs %g  need to be re-implemented" , 
               binPos.getInline() , binPos.getCrossline() , timeMs );

  //cgCrd headerAndTime( (cgDim)primeValue , timeMs/1000.0 );
  //cgDim time_s  = myAdjustTimeToDatum( headerAndTime );
  //float ftime_s = (float)time_s;

  //cgCrd headerAndTime( (cgDim)key.getPrime(), timeMs/1000.0 );
  // float timeSec  = 0.001f * timeMs ; // convertFloatingToFlat( headerAndTime );
  //int   timeMs  = functIter->first;
  //  float timeSec = 0.001f * timeMs;
  // myAdjustTimeToDatum( headerAndTime );
  //cgCrd headerAndTime( (cgDim)key.getPrime(), timeMs/1000.0 );
  //          float timeSec  = 0.001f * funcIter->first ; //float timeSec = convertFloatingToFlat( headerAndTime );
  //cgCrd headerAndTime( (cgDim)key.getPrime(), timeMs/1000.0 );

  return timeMs * 0.001f ;
}



float GraLayerVirtualInterface::convertFlatToFloating( const BinPos & binPos , double timeSec )
{
  MscDg::error( CLASS_NAME , "convertFlatToFloating()" ,
               "Location %d  %d  TimeMs %g  need to be re-implemented" , 
               binPos.getInline() , binPos.getCrossline() , timeSec );
  return (float)timeSec;
}


bool GraLayerVirtualInterface::getPicksAreVisible( int )
{
  return true ;
}


const std::shared_ptr< DatPointFunctionType > & GraLayerVirtualInterface::getDatPoint( int , BinPos & )
{
  MscDg::error( CLASS_NAME , "getDatPoint()" , "need to be re-implemented" );
  static std::shared_ptr<DatPointFunctionType> dm ;
  return dm;    
}


int GraLayerVirtualInterface::findTraceFromHeaderWithTest( double head , bool closest )
{
  MscDg::error( CLASS_NAME , "findTraceFromHeaderWithTest()" , "need to be reimplemented" );
  return 0 ;
}



BinPos GraLayerVirtualInterface::getBinPos()
{
  static const char * METHOD_NAME = "getBinPos()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "Not implemented" );
  BinPos binPos ;
  return binPos; 
}



/** provides the data section to draw the values from */
std::shared_ptr<DatSlice> GraLayerVirtualInterface::getSemblanceSection( int )
{
  static const char * METHOD_NAME = "getSemblanceSection()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "Not implemented" ); 
  std::shared_ptr<DatSlice> section ;
  return section; 
}



std::shared_ptr<DatSlice> GraLayerVirtualInterface::getSeismicSection( int )
{
  static const char * METHOD_NAME = "getSeismicSection()" ;
  MscDg::error( CLASS_NAME , METHOD_NAME , "Not implemented" );
  std::shared_ptr<DatSlice> section ;
  return section;
}



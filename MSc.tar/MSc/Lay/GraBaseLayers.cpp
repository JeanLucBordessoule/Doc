#include "GraBaseLayers.hpp"

#include "MscDebug.hpp"

#include "TypColorsPM.hpp"
#include "TypOptionsPM.hpp"

#include "GraBaseLayers.hpp"
#include "GraLayerVirtualInterface.hpp"



// ** Resources
static const char * GRA_CLASS_NAME = "Gra"           ;
const char * GraResource  ::CLASS_NAME = "GraResource"      ;
const char * GraScaledText::CLASS_NAME = "GraScaledText"    ;
const char * GraAttribute ::CLASS_NAME = "GraAttribute"     ;
const char * GraColorMap  ::CLASS_NAME = "GraColorMap"      ;

// ** Layers
const char * GraLayer       ::CLASS_NAME = "GraLayer"         ;
const char * GraLayerVirtualComposite::CLASS_NAME = "GraLayerVirtualComposite" ;
const char * GraTitleLayer  ::CLASS_NAME = "GraTitleLayer"    ;
const char * GraAxisLayer   ::CLASS_NAME = "GraAxisLayer"     ;
const char * GraGridLayer   ::CLASS_NAME = "GraGridLayer"     ;
const char * GraContourLayer::CLASS_NAME = "GraContourLayer"  ;
const char * GraCacheLayer  ::CLASS_NAME = "GraCacheLayer"    ;
const char * GraGadgetLayer ::CLASS_NAME = "GraGadgetLayer"   ;

// ** Manager (Pin-Up is internal)
const char * GraLayerVirtualManager::CLASS_NAME = "GraLayerVirtualManager"   ;

// constant values
const float  GraLayerVirtualManager::MS_TO_SEC  = float(1e-03);
const float  GraLayerVirtualManager::SEC_TO_MS  = 1000 ;

static const int STATIC_AXIS_WIDTH     = 50 ;
static const int STATIC_AXIS_HEIGHT    = 30 ;
static const int STATIC_DESIRED_HEIGHT = 60 ; // 30



/**  ============================================
 *   Gra
 *   Namespace for the Graphic Drawing Utilities
 *   ========================================== */




void Gra::setFontValues( cgScaledText & text , TypFontPM * fontPM , float * multiplyingFactorPtr )
{
  if ( fontPM == 0 ) { return ; }
  // multiplying factor
  float multiplyingFactor = TypAppPM::instance()->getFontPercentage();
  if ( multiplyingFactorPtr != 0 ) { multiplyingFactor = *multiplyingFactorPtr ; }
  // use the resource
  int fontSize = (int)(fontPM->getInt(TypFontPM::ID_SIZE) * multiplyingFactor );
  //text->height     ( fontSize );
  text->font_size  ( fontSize );
  text->font_weight( (cgFontWeight)fontPM->getInt(TypFontPM::ID_WEIGHT    ) );
  text->font_slant ( (cgFontSlant )fontPM->getInt(TypFontPM::ID_SLANT     ) );
  text->font_family( (cgFontFamily)fontPM->getInt(TypFontPM::ID_FAMILY    ) );
  text->line_style ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
  text->line_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
  text->fill_style ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
  text->fill_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
  // resize might be needed
  text->adjust_extent();
}


void Gra::setFontValues( cgScaledText & text , int fontId , float * multiplyingFactorPtr )
{
  Gra::setFontValues( text , TypAppPM::instance()->getFontPM(fontId).get() , multiplyingFactorPtr );
}



void Gra::setFontValues( cgRestrictedText & text , TypFontPM * fontPM , float * multiplyingFactorPtr )
{
  if ( fontPM == 0 ) { return ; }
  // multiplying factor
  float multiplyingFactor = TypAppPM::instance()->getFontPercentage();
  if ( multiplyingFactorPtr != 0 ) { multiplyingFactor = *multiplyingFactorPtr ; }
  // use the resource
  int fontSize  = (int)(fontPM->getInt(TypFontPM::ID_SIZE)       * multiplyingFactor );
  int lineWidth = (int)(fontPM->getInt(TypFontPM::ID_LINE_WIDTH) * multiplyingFactor );
  // Is not defined ... as the height is in the stext // text->height     ( fontSize );
  text->line_style ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
  text->line_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
  text->line_width ( lineWidth );
  text->fill_style ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
  text->fill_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
  //
  text->font_size  ( fontSize );
  text->font_weight( (cgFontWeight)fontPM->getInt(TypFontPM::ID_WEIGHT    ) );
  text->font_slant ( (cgFontSlant )fontPM->getInt(TypFontPM::ID_SLANT     ) );
  text->font_family( (cgFontFamily)fontPM->getInt(TypFontPM::ID_FAMILY    ) );

  // resize might be needed
  text->adjust_extent();

}



void Gra::setFontValues( cgRestrictedText & text , int fontId , float * multiplyingFactorPtr )
{
  Gra::setFontValues( text , TypAppPM::instance()->getFontPM(fontId).get() , multiplyingFactorPtr );
}



void Gra::setFontValues( cgSimpleAdaptiveLinearAxis & axis , TypFontPM * fontPM , float * multiplyingFactorPtr )
{
  static const char * METHOD_NAME = "setFontValues()" ;
  if ( fontPM == 0 ) { return ; }
  // multiplying factor
  float multiplyingFactor = TypAppPM::instance()->getFontPercentage();
  if ( multiplyingFactorPtr != 0 ) { multiplyingFactor = *multiplyingFactorPtr ; }
  // use the resource
  int   fontSize  = (int)(fontPM->getInt(TypFontPM::ID_SIZE)       * multiplyingFactor );
  int   lineWidth = (int)(fontPM->getInt(TypFontPM::ID_LINE_WIDTH) * multiplyingFactor );
  // debug
  MscDg::trace( GRA_CLASS_NAME , METHOD_NAME , "Multiplying %g  FontSize %d  LineWidth %d" ,
                multiplyingFactor , fontSize , lineWidth );

  // major or minor
  bool  isMajor = true ;
  bool  isHor   = true ;
  switch ( fontPM->getSubClass() ) {
  case Typ::FNT_VERTICAL_MAJOR            : isMajor = true  ; isHor = false ; break;
  case Typ::FNT_VERTICAL_MINOR            : isMajor = false ; isHor = false ; break;
  case Typ::FNT_HORIZONTAL_MAJOR          : isMajor = true  ; isHor = true  ; break;
  case Typ::FNT_HORIZONTAL_MINOR          : isMajor = false ; isHor = true  ; break;
  case Typ::FNT_TIMESLICE_INLINE_MAJOR    : isMajor = true  ; isHor = true  ; break;
  case Typ::FNT_TIMESLICE_CROSSLINE_MINOR : isMajor = true  ; isHor = true  ; break;
  }

  // use the resource  
  if ( isMajor == true ) {
    axis.major_label_visual.line_style ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
    axis.major_label_visual.line_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
    axis.major_label_visual.line_width ( lineWidth    );
    axis.major_label_visual.fill_style ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
    axis.major_label_visual.fill_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
    //
    axis.major_label_visual.font_size  ( fontSize     );
    axis.major_label_visual.font_slant ( (cgFontSlant )fontPM->getInt(TypFontPM::ID_SLANT     ) );
    axis.major_label_visual.font_family( (cgFontFamily)fontPM->getInt(TypFontPM::ID_FAMILY    ) );
    axis.major_label_visual.font_weight( (cgFontWeight)fontPM->getInt(TypFontPM::ID_WEIGHT    ) );
    // tick markers
    axis.major_tick_visual.line_style  ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
    axis.major_tick_visual.line_color  ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
    axis.major_tick_visual.line_width  ( lineWidth    );
    axis.major_tick_visual.fill_style  ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
    axis.major_tick_visual.fill_color  ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
    axis.major_tick_visual.font_size   ( fontSize     );
    axis.major_tick_visual.length      ( int(0.5f + 6 * multiplyingFactor)  );
    //
    // text->adjust_extent();
  }
  else {
    axis.minor_label_visual.line_style ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
    axis.minor_label_visual.line_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
    axis.minor_label_visual.line_width ( lineWidth    );
    axis.minor_label_visual.fill_style ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
    axis.minor_label_visual.fill_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
    //
    axis.minor_label_visual.font_size  ( fontSize     );
    axis.minor_label_visual.font_slant ( (cgFontSlant )fontPM->getInt(TypFontPM::ID_SLANT     ) );
    axis.minor_label_visual.font_family( (cgFontFamily)fontPM->getInt(TypFontPM::ID_FAMILY    ) );
    axis.minor_label_visual.font_weight( (cgFontWeight)fontPM->getInt(TypFontPM::ID_WEIGHT    ) );
    // tick markers
    axis.minor_tick_visual.line_style  ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
    axis.minor_tick_visual.line_color  ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
    axis.minor_tick_visual.line_width  ( lineWidth    );
    axis.minor_tick_visual.fill_style  ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
    axis.minor_tick_visual.fill_color  ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
    //
    axis.minor_tick_visual.font_size   ( fontSize     );
    axis.minor_tick_visual.length      ( int(0.5f + 6 * multiplyingFactor)  );    
  }
}



void Gra::setFontValues( cgSimpleAdaptiveLinearAxis & text , int fontId , float * multiplyingFactorPtr )
{
  Gra::setFontValues( text , TypAppPM::instance()->getFontPM(fontId).get() , multiplyingFactorPtr );
}



void Gra::setFontValues( cgAttributeInterface & attribute , TypFontPM * fontPM , float * multiplyingFactorPtr )
{
  static const char * METHOD_NAME = "setFontValues()" ;
  if ( fontPM == 0 ) { return ; }
  // multiplying factor
  float multiplyingFactor = TypAppPM::instance()->getFontPercentage();
  if ( multiplyingFactorPtr != 0 ) { multiplyingFactor = *multiplyingFactorPtr ; }
  // use the resource
  int   fontSize  = (int)(fontPM->getInt(TypFontPM::ID_SIZE)       * multiplyingFactor );
  int   lineWidth = (int)(fontPM->getInt(TypFontPM::ID_LINE_WIDTH) * multiplyingFactor );

  // debug
  MscDg::trace( GRA_CLASS_NAME , METHOD_NAME , "Multiplying %g  FontSize %d  LineWidth %d" ,
               multiplyingFactor , fontSize , lineWidth );

  attribute.line_style ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
  attribute.line_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
  attribute.line_width ( lineWidth    );
  attribute.fill_style ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
  attribute.fill_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
  //
  attribute.font_size  ( fontSize     );
  attribute.font_slant ( (cgFontSlant )fontPM->getInt(TypFontPM::ID_SLANT     ) );
  attribute.font_family( (cgFontFamily)fontPM->getInt(TypFontPM::ID_FAMILY    ) );
  attribute.font_weight( (cgFontWeight)fontPM->getInt(TypFontPM::ID_WEIGHT    ) );
}



void Gra::setAxisValues( cgSimpleAdaptiveLinearAxis & axis , TypAxisPM * axisPM , float * multiplyingFactorPtr )
{
  if ( axisPM == 0 ) { return ; }

  // use the resource  
  bool isHor   = true ; 
  switch ( axisPM->getSubClass() ) {
  case Typ::AXI_VERTICAL_TIME       : isHor = false ; break ;
  case Typ::AXI_HORIZONTAL_VELOCITY : isHor = true  ; break ;
  case Typ::AXI_HORIZONTAL_SIGNAL   : isHor = true  ; break ;
  }

  // use the resource  
  axis.major_labels_visible( axisPM->getBool( TypAxisPM::ID_MAJOR_LABELS ) );
  axis.major_ticks_visible ( axisPM->getBool( TypAxisPM::ID_MAJOR_LABELS ) );
  axis.minor_labels_visible( axisPM->getBool( TypAxisPM::ID_MINOR_LABELS ) );
  axis.minor_ticks_visible ( axisPM->getBool( TypAxisPM::ID_MINOR_LABELS ) );

}



void Gra::setAxisValues( cgSimpleAdaptiveLinearAxis & axis , int axisId , float * multiplyingFactorPtr )
{
  Gra::setAxisValues( axis , TypAppPM::instance()->getAxisPM(axisId).get() , multiplyingFactorPtr );
}


/** spply change */
void Gra::setLineValues( cgSharedAttribute & attribute , int linePM , float * multiplyingFactorPtr )
{
  Gra::setLineValues( attribute ,  TypAppPM::instance()->getLinePM(linePM).get() , multiplyingFactorPtr );
}


void Gra::setLineValues( cgSharedAttribute & attribute , TypLinePM * linePM , float * multiplyingFactorPtr )
{
  if ( linePM == 0 ) { return ; }
  // multiplying factor
  float multiplyingFactor = TypAppPM::instance()->getFontPercentage();
  if ( multiplyingFactorPtr != 0 ) { multiplyingFactor = *multiplyingFactorPtr ; }
  int lineWidth  = (int)( 0.5f + linePM->getInt(TypLinePM::ID_LINE_WIDTH  ) * multiplyingFactor );
  int markerSize = (int)( 0.5f + linePM->getInt(TypLinePM::ID_MARKER_WIDTH) * multiplyingFactor );
  // default attribute for the line
  attribute->line_width( lineWidth );
  attribute->line_color( Gra::getCgRgbColor( linePM->getInt(TypLinePM::ID_LINE_COLOR) ) );
  attribute->line_style( (cgLineStyle) linePM->getInt(TypLinePM::ID_LINE_STYLE) );
  //
  attribute->fill_color( Gra::getCgRgbColor( linePM->getInt(TypLinePM::ID_FILL_COLOR) ) );
  attribute->fill_style( (cgFillStyle) linePM->getInt(TypLinePM::ID_FILL_STYLE) );
  //
  attribute->marker_size ( markerSize );
  attribute->marker_style( (cgMarkerStyle)linePM->getInt(TypLinePM::ID_MARKER_STYLE) );

}



void Gra::setLineValues( cgAttributeInterface & attribute , int linePM , float * multiplyingFactorPtr )
{
  Gra::setLineValues( attribute ,  TypAppPM::instance()->getLinePM(linePM).get() , multiplyingFactorPtr );
}



void Gra::setLineValues( cgAttributeInterface & attribute , TypLinePM * linePM , float * multiplyingFactorPtr )
{
  if ( linePM == 0 ) { return ; }
  // multiplying factor
  float multiplyingFactor = TypAppPM::instance()->getFontPercentage();
  if ( multiplyingFactorPtr != 0 ) { multiplyingFactor = *multiplyingFactorPtr ; }
  int lineWidth  = (int)( 0.5f + linePM->getInt(TypLinePM::ID_LINE_WIDTH  ) * multiplyingFactor );
  int markerSize = (int)( 0.5f + linePM->getInt(TypLinePM::ID_MARKER_WIDTH) * multiplyingFactor );
  // default attribute for the line
  attribute.line_width( lineWidth );
  attribute.line_color( Gra::getCgRgbColor( linePM->getInt(TypLinePM::ID_LINE_COLOR) ) );
  attribute.line_style( (cgLineStyle) linePM->getInt(TypLinePM::ID_LINE_STYLE) );
  //
  attribute.fill_color( Gra::getCgRgbColor( linePM->getInt(TypLinePM::ID_FILL_COLOR) ) );
  attribute.fill_style( (cgFillStyle) linePM->getInt(TypLinePM::ID_FILL_STYLE) );
  //
  attribute.marker_size ( markerSize );
  attribute.marker_style( (cgMarkerStyle)linePM->getInt(TypLinePM::ID_MARKER_STYLE) );
}

cgRgbColor Gra::getCgRgbColor( int colorId )
{
  const Typ::ColorCreateInfo & color = Typ::getColor(colorId);
  return cgRgbColor( cgFromBitmapColor(color.myRed  ) ,
                     cgFromBitmapColor(color.myGreen) ,
                     cgFromBitmapColor(color.myBlue ) );
}


/**  ============================================
 *   GraResource
 *   Base class of the Graphic resource
 *   . cgSharedAttribute
 *   . cgFont
 *   . cgColormap
 *   ....
 *   in fact anything that can be modified by a resource 
 *   ========================================== */




GraResource::GraResource( GraLayer & layer ,MscDataTeam::ClassType classType , int subClass )
  : myLayer(layer) , myClassType(classType) , mySubClassType(subClass)
{
  myLayer.manageResource(this,true);
}



GraResource::~GraResource()
{
  myLayer.manageResource(this,false);
}




/**  ============================================
 *   GraScaledText
 *   MUST be created with a Graphic 'cgContainerScene'
 *   ========================================== */





GraScaledText::GraScaledText( GraLayer & layer , int fontId )
  : GraResource( layer , MscDataTeam::CT_TypFontPM , fontId )
{
  // Graphic resource : cgScaledText requires cgContainerScene.
  // cgAxisTitleScene inherits from cgMemoryScene
  // cgMemoryScene    inherits from cgContainerScene
  // cgContainerScene inherits from cgScene cgProxySite cgContainerSceneInterface

  myScaledText = cgScaledText( dynamic_cast<cgMemoryScene&>(myLayer.getGraphicScene()) );
  myScaledText->anchor(cgCrd(0,0));
  myScaledText->alignment(CG_V_CENTER | CG_H_CENTER);
  if ( myLayer.typeIsHorizontal() == false ) { myScaledText->rotation(-90); }

  // update the font
  update();
  setString("GraAxisTitle");
}



GraScaledText::~GraScaledText()
{
}



float GraScaledText::getFontSize( int fontId )
{
  // parameter model
  std::shared_ptr< TypFontPM > fontPM = TypAppPM::instance()->getFontPM(fontId);
  float fontSize = fontPM->getInt(TypFontPM::ID_SIZE) * TypAppPM::instance()->getFontPercentage() ;
  return fontSize ;
}



bool GraScaledText::updateFont( cgScaledText & scaledText , int fontId )
{
  // parameter model
  std::shared_ptr< TypFontPM > fontPM = TypAppPM::instance()->getFontPM(fontId);
  // use the resource
  Gra::setFontValues( scaledText , fontPM.get() );
  return true ;
}



bool GraScaledText::updateFont( cgRestrictedText & text , int fontId )
{
  // parameter model
  std::shared_ptr< TypFontPM > fontPM = TypAppPM::instance()->getFontPM(fontId);
  // use the resource
  int fontSize = (int)(fontPM->getInt(TypFontPM::ID_SIZE) *
                       TypAppPM::instance()->getFontPercentage());
  text->font_style( (cgFontFamily)fontPM->getInt(TypFontPM::ID_FAMILY) ,
                    fontSize ,
                    (cgFontSlant )fontPM->getInt(TypFontPM::ID_SLANT) ,
                    (cgFontWeight)fontPM->getInt(TypFontPM::ID_WEIGHT) );
  text->line_style( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
  text->line_color( Gra::getCgRgbColor( fontPM->getInt(TypFontPM::ID_LINE_COLOR) ) );
  text->fill_style( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
  text->fill_color( Gra::getCgRgbColor( fontPM->getInt(TypFontPM::ID_FILL_COLOR) ) );
  // done . Should test that a change occurred?
  return true ;
}



bool GraScaledText::update()
{
  // parameter model
  std::shared_ptr< TypFontPM > fontPM = TypAppPM::instance()->getFontPM(mySubClassType);
  // use the resource
  int fontSize = (int)(fontPM->getInt(TypFontPM::ID_SIZE) *
                       TypAppPM::instance()->getFontPercentage());
  myScaledText->font_style( (cgFontFamily)fontPM->getInt(TypFontPM::ID_FAMILY) ,
                            fontSize ,
                            (cgFontSlant )fontPM->getInt(TypFontPM::ID_SLANT) ,
                            (cgFontWeight)fontPM->getInt(TypFontPM::ID_WEIGHT) );
  myScaledText->line_style( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
  myScaledText->line_color( Gra::getCgRgbColor( fontPM->getInt(TypFontPM::ID_LINE_COLOR) ) );
  myScaledText->fill_style( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
  myScaledText->fill_color( Gra::getCgRgbColor( fontPM->getInt(TypFontPM::ID_FILL_COLOR) ) );
  
  return true ; 
}



void GraScaledText::setString( const MscString & str )
{
  if ( myString != str ) {
    myString = str ;    
    myScaledText->text( myString.c_str() );
    myScaledText->adjust_extent();
    // redraw when required
    //myLayer.setIsDirty();
  }
}




/**  ============================================
 *   \class GraAttribute
 *   ========================================== */





// Graphic resource : cgAttribute requires cgContainerScene.
// cgAxisTitleScene inherits from cgMemoryScene
// cgMemoryScene    inherits from cgContainerScene
// cgContainerScene inherits from cgScene cgProxySite cgContainerSceneInterface

GraAttribute::GraAttribute( GraLayer & layer , int attributeId )
  : GraResource( layer , MscDataTeam::CT_TypLinePM , attributeId )
{
  // Graphic resource
  myGraphicAttribute = cgSharedAttribute(dynamic_cast<cgContainerScene&>( myLayer.getGraphicScene() ));
  update();
}



GraAttribute::~GraAttribute()
{
}



bool GraAttribute::update()
{
  static const char * METHOD_NAME = "update()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "SubClass %d" , mySubClassType );

  // parameter model
  std::shared_ptr< TypLinePM > linePM = TypAppPM::instance()->getLinePM(mySubClassType);
  // multiplying factor
  float multiplyingFactor = myLayer.getMultiplyingFactor();
  int   lineWidth  = (int)( 0.5f + linePM->getInt(TypLinePM::ID_LINE_WIDTH  ) * multiplyingFactor );
  int markerSize = (int)( 0.5f + linePM->getInt(TypLinePM::ID_MARKER_WIDTH) * multiplyingFactor );
  // default attribute for the line
  myGraphicAttribute->line_width  ( lineWidth );
  myGraphicAttribute->line_color  ( Gra::getCgRgbColor( linePM->getInt(TypLinePM::ID_LINE_COLOR) ) );
  myGraphicAttribute->line_style  ( (cgLineStyle) linePM->getInt(TypLinePM::ID_LINE_STYLE) );
  //
  myGraphicAttribute->fill_color  ( Gra::getCgRgbColor( linePM->getInt(TypLinePM::ID_FILL_COLOR) ) );
  myGraphicAttribute->fill_style  ( (cgFillStyle) linePM->getInt(TypLinePM::ID_FILL_STYLE) );
  //
  myGraphicAttribute->marker_size ( markerSize );
  myGraphicAttribute->marker_style( (cgMarkerStyle)linePM->getInt(TypLinePM::ID_MARKER_STYLE) );
  // Usefull ?
  switch ( linePM->getInt(TypLinePM::ID_MARKER_STYLE) ) {
  case Typ::MS_DOT    :
  case Typ::MS_PLUS   :
  case Typ::MS_STAR   :
  case Typ::MS_CROSS  :
    myGraphicAttribute->line_width( lineWidth );
    break;
  case Typ::MS_CIRCLE :
  case Typ::MS_SQUARE :
    myGraphicAttribute->line_width( (int)( 0.5f + multiplyingFactor ) );
    break;     
  }

  return true ;
}




//=========================================================================
//=========================================================================
// HELPER CLASS : storage of a colors
// 
// Updates when the colormap is changed
// 
//=========================================================================
//=========================================================================



GraColorMap::GraColorMap( TypColormapPM & c ) : myColormapPM(c)
{
  myGraphicColorMap = 0 ;
  // initialize
  MscDataTeam & da = c ;
  Connect( da , da.ChangedSignalsSet , *this , &GraColorMap::changedSignalsSet );
  changedSignalsSet(0);
}


GraColorMap::~GraColorMap()
{
  delete myGraphicColorMap ;
}


void GraColorMap::changedSignalsSet( std::set<int> * )
{
  // values
  std::vector< Typ::ColorCreateInfo > colors = myColormapPM.getColors();
  // default values
  int numColors = colors.size();
  if ( numColors == 0 ) {
    const cgRgbColor * defaultValues = vcColorMaps::getSEGColormap( numColors );
    for ( int i=0 ; i < numColors ; ++i ) {
      Typ::ColorCreateInfo color( cgBitmapColorComponent(defaultValues[i].red  ()) ,
                                cgBitmapColorComponent(defaultValues[i].green()) ,
                                cgBitmapColorComponent(defaultValues[i].blue ()) ,
                                cgBitmapColorComponent(defaultValues[i].alpha()) );
      colors.push_back( color );
    }
    numColors = colors.size();
  }
  // create
  cgRgbColor *c = new cgRgbColor[numColors];
  for ( int i=0 ; i < numColors ; ++i ) {
    c[i] = cgBitmapColor( colors[i].myRed   ,
                          colors[i].myGreen ,
                          colors[i].myBlue  );
    //colors[i].myAlpha );
  }
  delete myGraphicColorMap ;
  myGraphicColorMap = new cgColorMap( c , numColors );
  delete c ;
}


int GraColorMap::getIndexOfColor( float minV , float value , float maxV , bool & isWithinRange )
{
  int numberOfColors = getNumberOfColors();
  if ( minV >= maxV || value <= minV ) {
    isWithinRange = false ;
    return 0 ;
  }
  if ( maxV <= value ) {
    isWithinRange = (maxV == value);
    return (numberOfColors-1);
  }
  isWithinRange  = true ;
  int colorIndex = int(numberOfColors * (value - minV) / (maxV - minV));
  // should not happen
  if ( colorIndex < 0 ) { colorIndex = 0 ; }
  if ( colorIndex > (numberOfColors-1) ) { colorIndex = (numberOfColors-1) ; }
  return colorIndex;  
}


cgRgbColor GraColorMap::getGraphicColor( int colorId )
{
  const Typ::ColorCreateInfo & color = Typ::getColor(colorId);
  return cgRgbColor( cgFromBitmapColor(color.myRed  ) ,
                     cgFromBitmapColor(color.myGreen) ,
                     cgFromBitmapColor(color.myBlue ) );
}


cgBitmapColor GraColorMap::getGraphicColor( float minV , float value , float maxV , bool & isWithinRange )
{
  return (*myGraphicColorMap)[ getIndexOfColor(minV,value,maxV,isWithinRange) ];
}



//===================================================//
//===================================================//
// LAYER                                             //
//===================================================//
//===================================================//



GraLayer::GraLayer( GraLayerVirtualManager & manager , GraLayer::ClassType layerType , int userId )
  : myManager(manager)
  , myComposite(0)
  , myClassType(layerType)
  , mySubClassType(userId)
{
  // created resources
  myAttribute   = 0     ;
  // Graphic
  myGraphicLayer = cgViewSceneLayer();
  myIsShown     = false ;
  myIsEditable  = false ;
  myBoundingBoxIsDefined = false;
  // add to the list
  myManager.addLayer(this);
}



GraLayer::~GraLayer()
{
  myManager.removeLayer(this);
}



GraLayerVirtualInterface & GraLayer::getInterface()
{
  return myManager.getIntf();
}



float GraLayer::getMultiplyingFactor()
{
  return myManager.getIntf().getMultiplyingFactor();
}



bool GraLayer::typeIsHorizontal() const
{
  switch ( myClassType ) {
  case GraLayer::TITLE_TOP    :
  case GraLayer::TITLE_BOTTOM :
  case GraLayer::AXIS_TOP     :
  case GraLayer::AXIS_BOTTOM  :
    return true ;
  }
  return false ;
}



GraColorMap & GraLayer::getColorMap()
{
  if ( myColorMap.get() == nullptr ) {
    myColormapPM = std::shared_ptr<TypColormapPM>(new TypColormapPM());
    myColorMap   = std::shared_ptr<GraColorMap>  (new GraColorMap( *myColormapPM ));
  }
  return *myColorMap ;
}



void GraLayer::update_notification( bool b )
{
  getGraphicScene().update_notification(b);
}



void GraLayer::invalidate( bool b )
{
  if ( myIsShown == true ) {
    getGraphicLayer()->invalidate(b);
  }
}



bool GraLayer::changedHolderSet( MscDataTeam * dh , std::set<int> * cg )
{
  if ( dh == 0 || cg == 0 ) { 
    //doIt = true ;
    return false ;
  }
  int isUsed = 0 ;

  // update internally . It might set the subclass for a resource.
  isUsed += update( dh , cg );
  // tell resources
  isUsed += updateResources( dh , cg );

  // need to update
  if ( isUsed != 0 ) {
    addIsDirty();
  }

  return ( isUsed != 0 );
}



int GraLayer::updateResources( MscDataTeam * dh , std::set<int> * cg )
{
  int isUsed = 0 ;
  std::vector< GraResource * >::iterator iter ;
  for ( iter=myResources.begin() ; iter != myResources.end() ; ++iter ) {
    if ( (*iter)->getClassType() == dh->getClassType() && 
         (*iter)->getSubClass()  == dh->getSubClass()   ) {
      isUsed += 1 ;
      (*iter)->update();
    }
  } 
  return isUsed ;
}



// Add / Remove from the list
bool GraLayer::manageResource( GraResource * layer , bool addIt )
{
  static const char * METHOD_NAME = "addResource()" ;
  // null value
  if ( layer == 0 ) {
     MscDg::trace( CLASS_NAME , METHOD_NAME , "Null value" );
    return false ;
  }  
  // find out if it's present
  std::vector< GraResource * >::iterator iter ;
  bool isPresent = false ;
  for ( iter=myResources.begin() ; iter != myResources.end() ; ++iter ) {
    // same pointer
    if ( (*iter) == layer ) {
      isPresent = true ;
      // remove it
      if ( addIt == false ) {
        myResources.erase(iter);
      }
      break;
    }
  }
  // add it
  if ( isPresent == false && addIt == true ) {
    myResources.push_back(layer);
  }
  // debug
  if ( isPresent == false && addIt == true ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "successfully added '%s'" , layer->getName().c_str() );
  }
  else if ( isPresent == true && addIt == true ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "'%s' already present" , layer->getName().c_str() );
  }
  else if ( isPresent == true && addIt == false ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "successfully removed '%s'" , layer->getName().c_str() );
  }
  else if ( isPresent == false && addIt == false ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "'%s' not present" , layer->getName().c_str() );
  }
  // done as expected
  return (isPresent != addIt);  
}



bool GraLayer::createResource( MscDataTeam::ClassType classType , int subClass )
{
  static const char * METHOD_NAME = "createResource()" ;
  bool hasBeenCreated = true ;
  switch ( classType ) {
  case MscDataTeam::CT_TypFontPM :
    new GraScaledText( *this , subClass );
    break;
  case MscDataTeam::CT_TypLinePM :
    myAttribute = new GraAttribute( *this , subClass );
    break;
  default :
    MscDg::error( CLASS_NAME , METHOD_NAME , "Resource type %d Id %d is not created" , classType , subClass );
    hasBeenCreated = false ;
  }
  return hasBeenCreated ;
}



bool GraLayer::deleteResource(MscDataTeam::ClassType classType , int subClass )
{
  static const char * METHOD_NAME = "deleteResource()" ;
  std::vector< GraResource * >::iterator iter ;
  for ( iter=myResources.begin() ; iter != myResources.end() ; ++iter ) {
    if ( (*iter)->getClassType() == classType && (*iter)->getSubClass() == subClass ) {
      if ( myAttribute == (*iter) ) { myAttribute = 0 ; }
      delete (*iter);
      return true;
    }
  }
  MscDg::error( CLASS_NAME , METHOD_NAME , "Resource type %d Id %d is not present" , classType , subClass );
  return false;    
}



GraResource * GraLayer::getResource(MscDataTeam::ClassType classType , int subClass ) // get the first one if "subClass" is (-1)
{
  static const char * METHOD_NAME = "getResource()" ;
  std::vector< GraResource * >::iterator iter ;
  for ( iter=myResources.begin() ; iter != myResources.end() ; ++iter ) {
    if ( (*iter)->getClassType() == classType ) {
      if ( subClass == -1 || (*iter)->getSubClass() == subClass ) {
        return (*iter);
      }
    }
  }
  MscDg::error( CLASS_NAME , METHOD_NAME , "Resource type %d Id %d is not present" , classType , subClass );
  return 0;  
}



cgSharedAttribute GraLayer::getGraphicAttribute( int subClass )
{
  static const char * METHOD_NAME = "getCgAttribute()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "SubClass %d" , subClass );

  cgSharedAttribute attribute ;
  GraAttribute * resource = dynamic_cast<GraAttribute*>( getResource( MscDataTeam::CT_TypLinePM , subClass ) );
  if ( resource != 0 ) { attribute = resource->getGraphicAttribute(); }
  else { MscDg::error( CLASS_NAME , METHOD_NAME , "SubClass %d has no Graphic Attribute" , subClass ); }
  return  attribute ;
}



void GraLayer::onButtonAction( GraLayer::ButtonAction action , int button ,
                              cgCrd location , bool isInside ,
                              bool shift , bool control , bool alt )
{
  if ( myComposite != 0 ) {
    myComposite->aboutButtonAction( this , action , button , location , isInside , shift , control , alt );
  }
  else {
    MscDg::error( CLASS_NAME , "onButtonAction()" , "no action is implemented" );
  }
}






//===================================================//
//===================================================//
// LAYER::COMPOSITE                                  //
//===================================================//
//===================================================//



GraLayerVirtualComposite::GraLayerVirtualComposite( GraLayerVirtualManager & m )
  : myLayerManager(m)
{
}



GraLayerVirtualComposite::~GraLayerVirtualComposite()
{
  std::vector< GraLayer * >::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    (*iter)->setComposite(0);
  }  
}



void GraLayerVirtualComposite::show( Typ::Order order , GraLayer * reference )
{
  std::vector< GraLayer * >::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    if ( iter == myLayers.begin() ) {
      (*iter)->show( order , reference );
      reference = *iter ;
    }
    else {
      (*iter)->show( Typ::ORD_ABOVE , reference );
    }
  }
}



void GraLayerVirtualComposite::hide()
{
  std::vector< GraLayer * >::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    (*iter)->hide();
  }
}



GraLayer * GraLayerVirtualComposite::getLayer( int rank )
{
  if ( rank == -1 ) {
    rank = getNumberOfLayers() - 1;
  }
  if ( 0 <= rank && rank < getNumberOfLayers() ) {
    return myLayers[rank];
  }
  else {
    MscDg::error( CLASS_NAME , "getLayer()" , "rank %d is out of bounds [0-%d[" , rank , getNumberOfLayers() );
    return 0;
  }
}



GraLayer * GraLayerVirtualComposite::getEditableLayer()
{
  std::vector< GraLayer * >::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    if ( (*iter)->getIsEditable() == true ) {
      return *iter;
    }
  }
  return 0;
}



void GraLayerVirtualComposite::invalidate( bool b )
{
  std::vector< GraLayer * >::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    (*iter)->invalidate( b );
  }
}



void GraLayerVirtualComposite::update_notification( bool b )
{
  std::vector< GraLayer * >::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    (*iter)->update_notification( b );
  }
}




//===================================================//
//===================================================//
// TITLE LAYER                                        
//===================================================//
//===================================================//




GraTitleLayer::GraTitleLayer( GraLayerVirtualManager & m , GraLayer::ClassType type , const char * text , bool isShown )
  : GraLayer( m , type )
  , myGraphicScene( CG_H_CENTER | CG_V_CENTER ,
                   typeIsHorizontal() ? CG_AO_HORIZONTAL : CG_AO_VERTICAL )
{
  static const char * METHOD_NAME = "GraTitleLayer()" ;
  if ( text == 0 ) { text = "" ; }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Type %d  IsShown %d  Text '%s'" , type , isShown , text );

  // parameters of the text drawing
  myText = new GraScaledText( *this , Typ::FNT_SECTION_TITLE );

  // set the text
  setString( text );
  // show it
  if ( isShown == true ) {
    show();
  }
  else {
    hide();
  }
}



GraTitleLayer::~GraTitleLayer()
{ 
  MscDg::trace( CLASS_NAME , "~GraTitleLayer()" );
  // remove the created text
  // else issue when dissociating in
  // cgSingleShapeGraphicProxy<cgScaledTextProxyBase, cgScaledTextData>::
  // ~cgSingleShapeGraphicProxy$delete ()
  hide();
}
 


bool GraTitleLayer::show( Typ::Order , GraLayer * )
{
  static const char * METHOD_NAME = "show()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME );

  if ( myIsShown == false ) {
    myIsShown = true ;
    myGraphicLayer = cgViewSceneLayer(myGraphicScene);
    cgSimplePlot & plot = myManager.getPlot();
    // add to the plot
    switch ( myClassType ) {
    case GraLayer::TITLE_TOP :
      plot->top_title()->add_layer( myGraphicLayer , cgPlotSpace() );
      plot->top_title()->desired_height( STATIC_DESIRED_HEIGHT ); 
      break;
    case GraLayer::TITLE_BOTTOM :
      plot->bottom_title()->add_layer( myGraphicLayer , cgPlotSpace() );
      plot->bottom_title()->desired_height( STATIC_DESIRED_HEIGHT ); 
      break;
    case GraLayer::TITLE_LEFT :
      plot->left_title()->add_layer( myGraphicLayer , cgPlotSpace() );
      plot->left_title()->desired_width( STATIC_DESIRED_HEIGHT ); 
      break;
    case GraLayer::TITLE_RIGHT :
      plot->right_title()->add_layer( myGraphicLayer , cgPlotSpace() );
      plot->right_title()->desired_width( STATIC_DESIRED_HEIGHT ); 
      break;
    }
    return true;
  }
  else {
    return false;
  }
}



bool GraTitleLayer::hide()
{
  static const char * METHOD_NAME = "hide()" ;
 
  if ( myIsShown == true ) {
    myIsShown = false ;
    cgSimplePlot & plot = myManager.getPlot();
    // remove it. The layers have already been defined (as 'myIsShown' was 'true')
    try {
      switch ( myClassType ) {
      case GraLayer::TITLE_TOP :
        plot->top_title()->remove_layer( myGraphicLayer );
        plot->top_title()->desired_height( 0 ); 
        break;
      case GraLayer::TITLE_BOTTOM :
        plot->bottom_title()->remove_layer( myGraphicLayer );
        plot->bottom_title()->desired_height( 0 ); 
        break;
      case GraLayer::TITLE_LEFT :
        plot->left_title()->remove_layer( myGraphicLayer );
        plot->left_title()->desired_width( 0 ); 
        break;
      case GraLayer::TITLE_RIGHT :
        plot->right_title()->remove_layer( myGraphicLayer );
        plot->right_title()->desired_width( 0 ); 
        break;
      }
    }
    catch ( ... ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Catched when removing layer" );
    }    
    // initialize
    myGraphicLayer = cgViewSceneLayer();
    return true;
  }
  else {
    return false;   
  }
}



void GraTitleLayer::setString( const MscString & text )
{
  MscDg::trace( CLASS_NAME , "setString()" , "%s" , text.c_str() );
  if ( myString != text ) {
    myString = text;
    myGraphicScene.update_notification(false);
    myText->setString( myString ); // text( myString.c_str() );
    myGraphicScene.update_notification(true );
  }
}



bool GraTitleLayer::update( MscDataTeam * dh , std::set<int> * cg )
{
  return false; 
}



//===================================================//
//===================================================//
// AXIS LAYER                                        //
//===================================================//
//===================================================//



GraAxisLayer::GraAxisLayer( GraLayerVirtualManager & m , GraLayer::ClassType type , bool showIt )
  : GraLayer( m , type )
  , myMajorGenerator( typeIsHorizontal() ? 1000.0 : 1000.0 / 1000.0 ) // vertically in seconds
  , myMinorGenerator( typeIsHorizontal() ?  250.0 :  100.0 / 1000.0 ) 
  , myGraphicScene   ( typeIsHorizontal() ? CG_AO_HORIZONTAL : CG_AO_VERTICAL , myMajorGenerator , myMinorGenerator )
{
  static const char * METHOD_NAME = "GraAxisLayer()" ;

  showIt = true ;

  // type of the resources
  switch ( myClassType ) {
    // horizontal : typeIsHorizontal() is "true"
  case GraLayer::AXIS_TOP    :
  case GraLayer::AXIS_BOTTOM :
    mySize         = 30   ;
    myMajorFont    = Typ::FNT_HORIZONTAL_MAJOR    ;
    myMinorFont    = Typ::FNT_HORIZONTAL_MINOR    ;
    myAxisType     = Typ::AXI_HORIZONTAL_VELOCITY ;
    break;
    // vertical : typeIsHorizontal() is "false"
  case GraLayer::AXIS_LEFT   :
  case GraLayer::AXIS_RIGHT  :
    mySize         = 50    ;
    myMajorFont    = Typ::FNT_VERTICAL_MAJOR ;
    myMinorFont    = Typ::FNT_VERTICAL_MINOR ;
    myAxisType     = Typ::AXI_VERTICAL_TIME  ;
    break;
  default :
    MscDg::fatal( CLASS_NAME , METHOD_NAME , "not implemented for %d" , myClassType );
  }

  // visibility
  if ( showIt == true ) {
    show();
  }
  else {
    hide();
  }

  // set the resource
  update(0,0);
}



GraAxisLayer::~GraAxisLayer()
{
  hide();
}




bool GraAxisLayer::show( Typ::Order , GraLayer * )
{
  static const char * METHOD_NAME = "show()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME );

  if ( myIsShown == false ) {
    myIsShown = true ;
    cgSimplePlot & plot = myManager.getPlot();
    // add to the plot
    switch ( myClassType ) {
    case GraLayer::AXIS_TOP :
      myGraphicLayer  = plot->top_axis()->add_axis( myGraphicScene , plot->space() , CG_AO_UNDEFINED , mySize );
      break;
    case GraLayer::AXIS_BOTTOM :
      myGraphicLayer  = plot->bottom_axis()->add_axis( myGraphicScene , plot->space() , CG_AO_UNDEFINED , mySize );
      break;
    case GraLayer::AXIS_LEFT :
      myGraphicLayer  = plot->left_axis()->add_axis( myGraphicScene , plot->space() , CG_AO_UNDEFINED , mySize );
      break;
    case GraLayer::AXIS_RIGHT :
      myGraphicLayer  = plot->right_axis()->add_axis( myGraphicScene , plot->space() , CG_AO_UNDEFINED , mySize );
      break;
    }
    return true ;
  }
  else {
    return false ;
  }
}


bool GraAxisLayer::hide()
{
  static const char * METHOD_NAME = "hide()" ;

  if ( myIsShown == true ) {
    myIsShown = false ;
    cgSimplePlot & plot = myManager.getPlot();
    // remove it from the plot
    try {
      switch ( myClassType ) {
      case GraLayer::AXIS_TOP :
        plot->top_axis()->remove_layer( myGraphicLayer );
        break;
      case GraLayer::AXIS_BOTTOM :
        plot->bottom_axis()->remove_layer( myGraphicLayer );
        break;
      case GraLayer::AXIS_LEFT :
        plot->left_axis()->remove_layer( myGraphicLayer );
        break;
      case GraLayer::AXIS_RIGHT :
        plot->right_axis()->remove_layer( myGraphicLayer );
        break;
      }
    }
    catch ( ... ) {
      MscDg::error( CLASS_NAME , METHOD_NAME , "Catched when removing layer" );
    }
    // initialize
    myGraphicLayer = cgViewSceneLayer();
    return true;
  }
  else {
    return false;
  }
}



bool GraAxisLayer::update( MscDataTeam * dh , std::set<int> * cg )
{
  static const char * METHOD_NAME = "update()" ;
  MscDataTeam::ClassType classType = dh ? dh->getClassType() : MscDataTeam::CT_MscDataHolder ;

  // decide what to update
  bool doMajor = false ;
  bool doMinor = false ;
  bool doAxis  = false ;
  switch ( classType ) {
    // do verything
  case MscDataTeam::CT_MscDataHolder :
    doAxis  = true ;
    doMajor = true ;
    doMinor = true ;
    break;
    // font & axis
  case MscDataTeam::CT_TypFontPM :
    doMajor = (dh->getSubClass() == myMajorFont ) ;
    doMinor = (dh->getSubClass() == myMinorFont ) ;
    doAxis  = (doMajor == true || doMinor == true);
    break;
  case MscDataTeam::CT_TypAxisPM :
    doAxis  = (dh->getSubClass() == myAxisType);
    doMajor = doAxis;
    doMinor = doAxis;
    break;
  }
  //if ( myIsShown == false ) {
  //  doAxis  = false ;    
  //  doMajor = false ;
  //  doMinor = false ;
  //}

  MscDg::trace( CLASS_NAME , METHOD_NAME , "ClassType %d  Axis %d  Major %d  Minor %d" ,
               classType , doAxis , doMajor , doMinor );


  //=======================================================
  // VISIBILITY of the Axis
  // When turned on, it needed to update the parameters
  //=======================================================

  double majorStepValue = 0.0f ;
  double minorStepValue = 0.0f ;

  if ( doAxis == true ) {
    // define the resource
    TypAxisPM * axisPM        = TypAppPM::instance()->getAxisPM(myAxisType).get();
    bool       axisIsVisible = true ;

    // major
    axisIsVisible  = axisPM->getBool ( TypAxisPM::ID_MAJOR_LABELS );
    majorStepValue = axisPM->getFloat( TypAxisPM::ID_USER_MAJOR   );
    if ( typeIsHorizontal() == false ) { majorStepValue /= 1000.0; } // vertical
    // redraw if needed
    if ( doMajor == true  && axisIsVisible == false ) { doMajor = false; }
    if ( doMajor == false && axisIsVisible == true  ) { doMajor = true ; }
    // set values
    myGraphicScene.major_labels_visible( axisIsVisible );
    myGraphicScene.major_ticks_visible ( axisIsVisible );

    // minor
    axisIsVisible  = axisPM->getBool ( TypAxisPM::ID_MINOR_LABELS );
    minorStepValue = axisPM->getFloat( TypAxisPM::ID_USER_MINOR   );
    //cerr << "GraAxisLayer::update() minorStepValue ID_USER_MINOR " << minorStepValue << endl ;
    if ( typeIsHorizontal() == false ) { minorStepValue /= 1000.0; } // vertical
    // redraw if needed
    if ( doMinor == true  && axisIsVisible == false ) { doMinor = false; }
    if ( doMinor == false && axisIsVisible == true  ) { doMinor = true ; }
    // set values
    myGraphicScene.minor_labels_visible( axisIsVisible );
    myGraphicScene.minor_ticks_visible ( axisIsVisible );
  }

  //=======================================================
  // update values
  //=======================================================

  if ( doMajor == true ) {
    // define the resource
    TypFontPM * fontPM = TypAppPM::instance()->getFontPM(myMajorFont).get();
    float multiplyingFactor = getMultiplyingFactor();
    int   fontSize  = (int)(fontPM->getInt(TypFontPM::ID_SIZE)       * multiplyingFactor );
    int   lineWidth = (int)(fontPM->getInt(TypFontPM::ID_LINE_WIDTH) * multiplyingFactor );
    // use the resource
    myGraphicScene.major_label_visual.line_style ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
    myGraphicScene.major_label_visual.line_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
    myGraphicScene.major_label_visual.line_width ( lineWidth    );
    myGraphicScene.major_label_visual.fill_style ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
    myGraphicScene.major_label_visual.fill_color ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
    myGraphicScene.major_label_visual.font_size  ( fontSize     );
    myGraphicScene.major_label_visual.font_slant ( (cgFontSlant )fontPM->getInt(TypFontPM::ID_SLANT     ) );
    myGraphicScene.major_label_visual.font_family( (cgFontFamily)fontPM->getInt(TypFontPM::ID_FAMILY    ) );
    myGraphicScene.major_label_visual.font_weight( (cgFontWeight)fontPM->getInt(TypFontPM::ID_WEIGHT    ) );
    // tick markers
    myGraphicScene.major_tick_visual.line_style  ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
    myGraphicScene.major_tick_visual.line_color  ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
    myGraphicScene.major_tick_visual.line_width  ( lineWidth    );
    myGraphicScene.major_tick_visual.fill_style  ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
    myGraphicScene.major_tick_visual.fill_color  ( Gra::getCgRgbColor (fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
    myGraphicScene.major_tick_visual.font_size   ( fontSize     );
    myGraphicScene.major_tick_visual.length      ( int(0.5f + 6 * multiplyingFactor)  );
    // steps
    //cerr << "GraAxisLayer::update() majorStepValue  " << majorStepValue << endl ;
    //if ( majorStepValue != 0 ) { myMajorGenerator = cgAxisLinearTickGenerator(majorStepValue) ; }//  myMajorGenerator.step( majorStepValue ); }
    if ( majorStepValue != 0 ) { myMajorGenerator.step( majorStepValue ); }
    // update
    myGraphicScene.major_tick_visual .tick_generator();
    myGraphicScene.major_label_visual.tick_generator();
  }

  if ( doMinor == true ) {
    // define the resource
    TypFontPM * fontPM = TypAppPM::instance()->getFontPM(myMinorFont).get();
    float multiplyingFactor = getMultiplyingFactor();
    int   fontSize  = (int)(fontPM->getInt(TypFontPM::ID_SIZE)       * multiplyingFactor );
    int   lineWidth = (int)(fontPM->getInt(TypFontPM::ID_LINE_WIDTH) * multiplyingFactor );
    // use the resource
    myGraphicScene.minor_label_visual.line_style ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
    myGraphicScene.minor_label_visual.line_color ( Gra::getCgRgbColor( fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
    myGraphicScene.minor_label_visual.line_width ( lineWidth    );
    myGraphicScene.minor_label_visual.fill_style ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
    myGraphicScene.minor_label_visual.fill_color ( Gra::getCgRgbColor( fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
    myGraphicScene.minor_label_visual.font_size  ( fontSize     );
    myGraphicScene.minor_label_visual.font_slant ( (cgFontSlant )fontPM->getInt(TypFontPM::ID_SLANT     ) );
    myGraphicScene.minor_label_visual.font_family( (cgFontFamily)fontPM->getInt(TypFontPM::ID_FAMILY    ) );
    myGraphicScene.minor_label_visual.font_weight( (cgFontWeight)fontPM->getInt(TypFontPM::ID_WEIGHT    ) );
    // tick markers
    myGraphicScene.minor_tick_visual.line_style  ( (cgLineStyle )fontPM->getInt(TypFontPM::ID_LINE_STYLE) );
    myGraphicScene.minor_tick_visual.line_color  ( Gra::getCgRgbColor( fontPM->getInt(TypFontPM::ID_LINE_COLOR) ));
    myGraphicScene.minor_tick_visual.line_width  ( lineWidth    );
    myGraphicScene.minor_tick_visual.fill_style  ( (cgFillStyle )fontPM->getInt(TypFontPM::ID_FILL_STYLE) );
    myGraphicScene.minor_tick_visual.fill_color  ( Gra::getCgRgbColor( fontPM->getInt(TypFontPM::ID_FILL_COLOR) ));
    myGraphicScene.minor_tick_visual.font_size   ( fontSize     );
    myGraphicScene.minor_tick_visual.length      ( int(0.5f + 6 * multiplyingFactor)  );
    // steps
    //cerr << "GraAxisLayer::update()  minorStepValue " << minorStepValue << endl ;
    if ( minorStepValue != 0 ) { myMinorGenerator.step( minorStepValue ); }
    // update
    myGraphicScene.minor_tick_visual .tick_generator();
    myGraphicScene.minor_label_visual.tick_generator();
  }  

  // a change occurred
  bool aChangeOccurred = (doAxis || doMajor || doMinor);
  
  return aChangeOccurred;
}




//===================================================//
//===================================================//
// SCENE . Drawing                                   //
// By default: draw a vertical line in the background//
// Can be used for any other shapes                  //
//===================================================//
//===================================================//


// See: "GraDrawingLayer.cpp"



//===================================================//
//===================================================//
// CONTOUR SCENE                                     //
// Contouring tool                                   //
//===================================================//
//===================================================//




GraContourLayer::GraContourLayer( GraLayerVirtualManager & m , int userId )
 : GraLayer( m , GraLayer::VIEW_CONTOUR , userId )
{
  // create components
  myGraphicRange = new cgGridRange(); //  0, 0, 300 , 1000 );
  // 
  myGraphicGrid  = new cgContourGrid();
  myGraphicGrid->range( *myGraphicRange );
  //
  myGraphicFillVisual = new cgContourFillVisual();
  myGraphicFillVisual->color_behaviour( CG_CMB_SIMPLE );
  // 
  myGraphicScene = new cgContourScene();
  myGraphicScene->add_visual( *myGraphicFillVisual , CG_O_BACK );
  myGraphicScene->grid ( *myGraphicGrid );
  
}



GraContourLayer::~GraContourLayer()
{
  hide();
}



bool GraContourLayer::show( Typ::Order order , GraLayer * reference )
{
  static const char * METHOD_NAME = "show()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Order %d" , order );
  
  if ( myIsShown == false ) {
    myIsShown = true ;
    cgSimplePlot & plot = myManager.getPlot();
    // add to the plot
    myGraphicLayer = plot->data_area()->add_scene( *myGraphicScene );
    if ( order == Typ::ORD_BACK ) {
      plot->data_area()->view_manager()->add( myGraphicLayer , CG_O_BACK );
    }
    else if ( reference != 0 && reference->getGraphicLayer() ) {
      plot->data_area()->view_manager()->add( myGraphicLayer , (cgOrder)order , reference->getGraphicLayer() );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "put in the front as there is no reference layer" );
      plot->data_area()->view_manager()->add( myGraphicLayer , CG_O_FRONT );
    }
    return true;
  }
  else {
    return false; 
  }
}


bool GraContourLayer::hide()
{
  cgSimplePlot & plot = myManager.getPlot();
  if ( myIsShown == true ) {
    myIsShown = false ;
    plot->data_area()->remove_layer( myGraphicLayer );
    myGraphicLayer = cgViewSceneLayer();
    return true;
  }
  else {
    return false ;
  }
}




cgScene & GraContourLayer::getGraphicScene()
{
  return *myGraphicScene;
}


void GraContourLayer::draw( bool )
{
}



bool GraContourLayer::update( MscDataTeam * dh , std::set<int> * cg )
{ 
  return false; 
}



//===================================================//
//===================================================//
// CACHE LAYER . Base scene                          //
//===================================================//
//===================================================//



GraCacheLayer::GraCacheLayer( GraLayerVirtualManager & lm , int userId )
  : GraLayer( lm , GraLayer::VIEW_CACHE , userId ) , myCacheLayer(false)
{
  myCacheLayer->flicker_buffer(true);
}



GraCacheLayer::~GraCacheLayer()
{
  hide();
}



bool GraCacheLayer::show( Typ::Order order , GraLayer * reference )
{
  static const char * METHOD_NAME = "show()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Order %d" , order );

  if ( myIsShown == false ) {
    myIsShown = true ;
    cgSimplePlot & plot = myManager.getPlot();
    if ( order == Typ::ORD_BACK ) {
      plot->data_area()->view_manager()->add( myCacheLayer , CG_O_BACK );
    }
    else if ( reference != 0 && reference->getGraphicLayer() ) {
      plot->data_area()->view_manager()->add( myCacheLayer , (cgOrder)order , reference->getGraphicLayer() );
    }
    else {
      MscDg::error( CLASS_NAME , METHOD_NAME , "put in the front as there is no reference layer" );
      plot->data_area()->view_manager()->add( myCacheLayer , CG_O_FRONT );
    }
    return true;
  }
  else {
    return false; 
  }
}



bool GraCacheLayer::hide()
{
  cgSimplePlot & plot = myManager.getPlot();
  if ( myIsShown == true ) {
    myIsShown = false ;
    plot->data_area()->remove_layer( myCacheLayer );
    return true;
  }
  else {
    return false; 
  }
}



void GraCacheLayer::invalidate( bool b )
{
  myCacheLayer->invalidate( b );
}


bool GraCacheLayer::update( MscDataTeam * dh , std::set<int> * cg )
{
  return false; 
}



//=======================================================================
//=======================================================================
// GraGridLayer
//=======================================================================
//=======================================================================


GraGridLayer::GraGridLayer( GraLayerVirtualManager & lm , int subClassType )
  : GraLayer( lm , GraLayer::VIEW_GRID , subClassType )
{
}



GraGridLayer::~GraGridLayer()
{
}

 
bool GraGridLayer::show( Typ::Order , GraLayer * reference )
{
 return true ;
}



bool GraGridLayer::hide()
{
  return false ;
}



cgScene & GraGridLayer::getGraphicScene()
{
  return myGraphicScene ;
}



void GraGridLayer::draw( bool )
{
}


bool GraGridLayer::update( MscDataTeam * dh , std::set<int> * cg )
{
  return false ;
}




//=======================================================================
//=======================================================================
// GraGadgetLayer
//=======================================================================
//=======================================================================

 

GraGadgetLayer::GraGadgetLayer( GraLayerVirtualManager & lm , int userId )
  : GraLayer( lm , GraLayer::VIEW_GADGET , userId )
{
  myLayerIsShown    = false ;
  myGraphicLayer     = cgViewGadgetLayer( cgViewManager::INTERACTIVE );
  myDragBox         = 0 ;
  myDragBoxLayer    = 0 ;
  myPointsBox       = 0 ;
  myPointsBoxLayer  = 0 ;
  myRubberBandShape = cgPolyline();
}


GraGadgetLayer::~GraGadgetLayer()
{
  delete myDragBox   ;
  delete myPointsBox ;
}


bool GraGadgetLayer::show( Typ::Order , GraLayer * reference )
{
  return false ; // TODO 
}


bool GraGadgetLayer::hide()
{
  return false ; // TODO  
}


void GraGadgetLayer::addLayerAbove( cgSimplePlot & plot , cgViewWindowCacheLayer belowLayer )
{
  if ( myLayerIsShown == false ) {
    myLayerIsShown = true ;
    plot->data_area()->view_manager()->add( myGraphicLayer , CG_O_ABOVE , belowLayer );
  }
}


void GraGadgetLayer::addLayerAbove( cgSimplePlot & plot , GraDrawingLayer & belowLayer )
{
  if ( myLayerIsShown == false ) {
    myLayerIsShown = true ;
    plot->data_area()->view_manager()->add( myGraphicLayer , CG_O_ABOVE , belowLayer.getGraphicLayer() );
  }
}



void GraGadgetLayer::addLayerAbove( cgSimplePlot & plot , GraPicksCacheLayer & belowLayer )
{
  if ( myLayerIsShown == false ) {
    myLayerIsShown = true ;
    plot->data_area()->view_manager()->add( myGraphicLayer , CG_O_ABOVE , belowLayer.getGraphicLayer() );
  }
}


void GraGadgetLayer::removeLayer( cgSimplePlot & plot )
{
  if ( myLayerIsShown == true ) {
    myLayerIsShown = false ;  
    // dragbox
    if ( myDragBox != 0 ) {
      if ( myDragBox->active() == true ) {
        myDragBox->end();
        myDragBox->deactivate();
      }
      delete myDragBox ;
      myDragBox = 0;
    }
    // rubberband
    if ( myPointsBox != 0 ) {
      if ( myPointsBox->active() == true ) {
        myPointsBox->end();
        myPointsBox->deactivate();
      }
      delete myPointsBox ;
      myPointsBox = 0;
    }
    myPointsBoxLayer = 0;
    // shape
    if ( myRubberBandShape ) {
      myRubberBandShape->destroy_shape();
      myRubberBandShape = cgPolyline();
    }    
    // remove
    plot->data_area()->remove_layer( myGraphicLayer );
    myGraphicLayer = cgViewGadgetLayer( cgViewManager::INTERACTIVE ); // MUST be created again (else it crashes)
  }
}




//=========================================
// GraPicksInterface (interface for GraGadgetLayer)
//=========================================


const char * GraPicksInterface::CLASS_NAME = "GraPicksInterface" ;



/** common to stacks and mini-stacks */
cgRect GraPicksInterface::getLimits()
{
  MscDg::error( CLASS_NAME , "getLimits()" , "need to be re-implemented" );
  return cgRect();
}


/** access to the field */
int GraPicksInterface::getPanel()
{
  MscDg::error( CLASS_NAME , "getPanel()" , "need to be re-implemented" );
  return 0 ;
}


TwoIntKey GraPicksInterface::getKeyFromBinPos( const BinPos & binPos )
{
  MscDg::error( CLASS_NAME , "getKeyFromBinPos()" , "%d  %d  need to be re-implemented" ,
               binPos.getInline() , binPos.getCrossline() );
  TwoIntKey key(binPos);
  return key ;
}



BinPos GraPicksInterface::getBinPosFromKey( const TwoIntKey & key )
{
  MscDg::error( CLASS_NAME , "getBinPosFromKey()" , "%d  %d  need to be re-implemented" ,
               key.getPrime() , key.getSecondary() );
  BinPos binPos(key);
  return binPos ;
}



float  GraPicksInterface::convertFloatingToFlat( const BinPos & binPos , double doubleTimeMs )
{
  // cast ... in fact it's an int used to store the time in millisecond
  float timeMs = (float)doubleTimeMs ;
  MscDg::error( CLASS_NAME , "convertFloatingToFlat()" ,
               "Location %d  %d  TimeMs %g  need to be re-implemented" ,
               binPos.getInline() , binPos.getCrossline() , timeMs );
  return timeMs * 0.001f ;
}



float GraPicksInterface::convertFlatToFloating( const BinPos & binPos , double timeSec )
{
  MscDg::error( CLASS_NAME , "convertFlatToFloating()" ,
               "Location %d  %d  TimeMs %g  need to be re-implemented" ,
               binPos.getInline() , binPos.getCrossline() , timeSec );
  return (float)timeSec;
}


bool GraPicksInterface::getPicksAreVisible( int )
{
  return true ;
}

const std::shared_ptr< DatPointFunctionType > & GraPicksInterface::getDatPoint( int , BinPos & )
{
  MscDg::error( CLASS_NAME , "getVelPoint()" , "need to be re-implemented" );
  static std::shared_ptr<DatPointFunctionType> dm ;
  return dm;
}


int GraPicksInterface::findTraceFromHeaderWithTest( double head , bool closest )
{
  MscDg::error( CLASS_NAME , "findTraceFromHeaderWithTest()" , "need to be reimplemented" );
  return 0 ;
}


//=========================================
// GraPickValues (selected by GraGadgetLayer)
//=========================================


const char * GraPickValues::CLASS_NAME = "GraPickValues" ;



GraPickValues::GraPickValues( const BinPos & binPos , int timeMs ,
                            GraPickValues::DataType dataType , GraPickValues::SymbolType symbolId )
{
  myBinPos   = binPos   ;
  myTimeMs   = timeMs   ;
  myDataType = dataType ;
  mySymbolId = symbolId ;
  // data
  myVelocity = 0.0f     ;
  myFOC      = 0.0f     ;
  myEta      = 0.0f     ;
}



GraPickValues::GraPickValues( const GraPickValues & model )
{
  *this = model ;
}



const GraPickValues & GraPickValues::operator= ( const GraPickValues & model )
{
  if ( this != &model ) {
    myBinPos   = model.myBinPos   ;
    myTimeMs   = model.myTimeMs   ;
    myDataType = model.myDataType ;
    mySymbolId = model.mySymbolId ;
    // data
    myVelocity = model.myVelocity ;
    myFOC      = model.myFOC      ;
    myEta      = model.myEta      ;
  }
  return *this ;
}



bool GraPickValues::operator== ( const GraPickValues & model )
{
  return ( myBinPos   == model.myBinPos   &&
           myTimeMs   == model.myTimeMs   &&
           myDataType == model.myDataType &&
           mySymbolId == model.mySymbolId &&
           // data
           myVelocity == model.myVelocity &&
           myFOC      == model.myFOC      &&
           myEta      == model.myEta      );
}



bool GraPickValues::isSameLocation( const BinPos & binPos , int timeMs , GraPickValues::DataType dataType ) const
{
  return ( myBinPos   == binPos   &&
           myTimeMs   == timeMs   &&
           myDataType == dataType );
}



GraPickValues::~GraPickValues()
{
  // std::cerr << "~GraPickValues()  : called" << std::endl ;
}


// Helper Functions (static)  with TwoIntKey output


void GraPickValues::sortByLocation( GraPicksInterface & intf , const std::vector< GraPickValues > & selPoints ,
                                   GraPickValues::LocationTimesType & selectedPicks )
{
  // define the times for each location
  GraPickValues::LocationTimesType::iterator selIter ;

  std::vector< GraPickValues >::const_iterator iter ;
  for ( iter=selPoints.begin() ; iter != selPoints.end() ; ++iter ) {
    // the location to add times to
    TwoIntKey key = intf.getKeyFromBinPos( iter->myBinPos );
    selIter = selectedPicks.find(key);
    if ( selIter == selectedPicks.end() ) {
      std::set<int> picks ;
      selectedPicks[ key ] = picks ;
      selIter = selectedPicks.find(key);
    }
    // add a time
    selIter->second.insert( iter->myTimeMs );
  }
}



void GraPickValues::sortByLocation( GraPicksInterface & intf , const std::vector< GraPickValues > & selPoints ,
                                   GraPickValues::LocationValuesType & selectedPicks )
{
  // define the times for each location
  GraPickValues::LocationValuesType::iterator selIter ;

  std::vector< GraPickValues >::const_iterator iter ;
  for ( iter=selPoints.begin() ; iter != selPoints.end() ; ++iter ) {
    // the location to add times to
    TwoIntKey key = intf.getKeyFromBinPos( iter->myBinPos );
    selIter = selectedPicks.find(key);
    if ( selIter == selectedPicks.end() ) {
      std::vector< GraPickValues > values ;
      selectedPicks[ key ] = values ;
      selIter = selectedPicks.find(key);
    }
    // add a time
    selIter->second.push_back( *iter );
  }
}


// Helper Functions (static)   with BinPos output


void GraPickValues::sortByBinPos( GraPicksInterface & intf , const std::vector< GraPickValues > & selPoints ,
                                 GraPickValues::BinPosTimesType & selectedPicks )
{
  // define the times for each location
  GraPickValues::BinPosTimesType::iterator selIter ;

  std::vector< GraPickValues >::const_iterator iter ;
  for ( iter=selPoints.begin() ; iter != selPoints.end() ; ++iter ) {
    // the location to add times to
    selIter = selectedPicks.find( iter->myBinPos );
    if ( selIter == selectedPicks.end() ) {
      std::set<int> picks ;
      selectedPicks[ iter->myBinPos ] = picks ;
      selIter = selectedPicks.find( iter->myBinPos );
    }
    // add a time
    selIter->second.insert( iter->myTimeMs );
  }
}



void GraPickValues::sortByBinPos( GraPicksInterface & intf , const std::vector< GraPickValues > & selPoints ,
                                 GraPickValues::BinPosValuesType & selectedPicks )
{
  // define the times for each location
  GraPickValues::BinPosValuesType::iterator selIter ;

  std::vector< GraPickValues >::const_iterator iter ;
  for ( iter=selPoints.begin() ; iter != selPoints.end() ; ++iter ) {
    // the location to add times to
    selIter = selectedPicks.find( iter->myBinPos );
    if ( selIter == selectedPicks.end() ) {
      std::vector< GraPickValues > values ;
      selectedPicks[ iter->myBinPos ] = values ;
      selIter = selectedPicks.find( iter->myBinPos );
    }
    // add a time
    selIter->second.push_back( *iter );
  }
}


// Helper Functions (static)   Manage List


bool GraPickValues::removePick( GraPicksInterface & , std::vector< GraPickValues > & selPoints ,
                               const BinPos & binPos , int timeMs , GraPickValues::DataType dataType )
{
  std::vector< GraPickValues >::iterator iter ;
  for ( iter=selPoints.begin() ; iter != selPoints.end() ; ++iter ) {
    if ( iter->myBinPos == binPos && iter->myTimeMs == timeMs && iter->myDataType == dataType ) {
      selPoints.erase(iter);
      return true ;
    }
  }
  return false ;
}


int GraPickValues::printPicks( GraPicksInterface & , const std::vector< GraPickValues > & selPoints )
{
  static const char * METHOD_NAME = "printPicks()" ;
  int numberOfPicks = selPoints.size();
  MscDg::error( CLASS_NAME , METHOD_NAME , "NumberOfPicks %d" , numberOfPicks );

  if ( numberOfPicks != 0 ) {
    MscDg::print( "Number of picks %ld" , numberOfPicks );
    std::vector< GraPickValues >::const_iterator iter ;
    for ( iter=selPoints.begin() ; iter != selPoints.end() ; ++iter ) {
      MscDg::print( "  BinPos %d %d     TimeMs %d   DataType %d" ,
                   iter->myBinPos.getInline() , iter->myBinPos.getCrossline() , iter->myTimeMs , iter->myDataType );
    }
  }
  return numberOfPicks ;
}




//=========================================
// GraGadgetLayer (Drag Box)
//=========================================



void GraGadgetLayer::startDragBox( cgCrd location , GraDrawingLayer * layer )
{
  layer = 0;

  if ( isDragBoxActive() == false ) {
    // create it and activate it
    if ( myDragBox == 0 ) { myDragBox = new cgDragBoxManipulator() ; }
    myDragBox->activate( myGraphicLayer );
    // begin
    myDragBoxLayer = layer ;
    if ( myDragBoxLayer != 0 ) {
      location = myDragBoxLayer->getGraphicLayer()->scene_to_device( location );
    }
    myDragBox->begin( location );
  }
}



bool GraGadgetLayer::isDragBoxActive()
{
  return (myDragBox != 0 && myDragBox->active() == true);
}



void GraGadgetLayer::moveDragBox( cgCrd location , cgRect * rect )
{
  if ( isDragBoxActive() == true ) {
    if ( myDragBoxLayer != 0 ) {
      location = myDragBoxLayer->getGraphicLayer()->scene_to_device( location );
    }   
    myDragBox->move( location );
    if ( rect != 0 ) { *rect = myDragBox->rectangle(); }
  }  
}


cgRect GraGadgetLayer::stopDragBox( cgCrd location )
{
  if ( isDragBoxActive() == true ) {
    if ( myDragBoxLayer != 0 ) {
      location = myDragBoxLayer->getGraphicLayer()->scene_to_device( location );
    }
    myDragBox->move( location );
    cgRect dragRect = myDragBox->rectangle();
    myDragBox->end();
    myDragBox->deactivate(); 
    myDragBoxLayer = 0;
    return dragRect ;
  }
  else {
    return cgRect();
  }
}


bool GraGadgetLayer::stopDragBox( cgCrd location ,
                                 const char * titleText , const char * questionText , GuiForm * guiForm ,
                                 GraDrawingLayer & picksLayer , std::vector< GraPickValues > & selPoints )
{
  // must clear it (size will be same as below "addedColors")
  selPoints.clear();

  if ( isDragBoxActive() == true ) {

    //---------------------------------------------
    // selected rectangles and points
    //---------------------------------------------

    if ( myDragBoxLayer != 0 ) {
      location = myDragBoxLayer->getGraphicLayer()->scene_to_device( location );
    }    
    
    // selected rectangle
    myDragBox->move( location );
    cgRect dragRect = myDragBox->rectangle();
    cgRect locRect  = picksLayer.getGraphicLayer()->device_to_scene( dragRect ); // needed ?
    myDragBox->end();
    myDragBox->deactivate();
    
    // *** not used anymore *** //
    myDragBoxLayer = 0 ;

    // selected graphics    
    cgRectangleSelection selectedShapes( picksLayer.getGraphicLayer() );
    cgGraphicList gl;
    selectedShapes.select( gl , /*locRect*/dragRect , CG_SO_MULTIPLE | CG_SO_ERASE | CG_SO_INTERSECTING );

    //---------------------------------------------
    // extract the information the selected graphics contain
    //---------------------------------------------

    std::vector< cgRgbColor > addedColors  ;
    cgGraphicList        addedGraphic ;
    cgGraphicList::Iterator iter ;
    for ( iter=gl->enumerate() ; iter ; ++iter ) {

      // information about the data
      GraPickValues * values = dynamic_cast< GraPickValues * >( cgAnyShape(*iter)->user_object() );

      // value are present
      if ( values != 0 ) {
        
        cgCrd location ;
        bool addIt = false ;

        switch( values->mySymbolId ) {
          // Polyline with 3 
        case GraPickValues::SB_LEFT_ARROW  : // < 'getSymbolBefore()'
        case GraPickValues::SB_RIGHT_ARROW : // > 'getSymbolAfter()'
        case GraPickValues::SB_DOWN_ARROW  : // \/ 'getSymbolBefore()'
        case GraPickValues::SB_UP_ARROW    : // /\ 'getSymbolAfter()'
          // Polyline with 5
        case GraPickValues::SB_MULTIPLY : // x 'getSymbol()'
        case GraPickValues::SB_ADD      : // + 'getSymbolOne()'
        case GraPickValues::SB_SQUARE   : // #
          {
            cgPolyline pl( *iter );
            if ( pl ) {
              addIt = true ;
              location = pl->point( pl->size() / 2 ); // 3->1 . 5->2 . 0 will do the job
              addedColors.push_back( pl->line_color() );
              pl->line_color( cgRgbColor( 0.25,0.25, 0.25) );
            }
          } break;
          // Shape with 1
        case GraPickValues::SB_ELLIPSE :
          {
            cgEllipse pl( *iter );
            if ( pl ) {
              addIt = true ;
              addedColors.push_back( pl->line_color() );
              pl->line_color( cgRgbColor( 0.25,0.25, 0.25) );
            }
          } break;
        }
        // add it
        if ( addIt == true ) {
          selPoints.push_back( *values );
          addedGraphic->add( *iter );
        }
      }
    }
    // clean up the initial 
    gl->remove_all();


    //---------------------------------------------
    // ask question
    //---------------------------------------------

    // title text
    MscString titleStr ;
    if ( titleText != 0 ) {
      titleStr.printf( "%s ?" , titleText );
    }

    // question to ask
    MscString questionStr ;
    switch ( selPoints.size() ) {
    case 0 : 
      break;
    case 1:
      if ( questionText != 0 ) { questionStr = questionText ; }
      else { questionStr.printf( "Do you want to %s this pick ?" , titleText ); }
      
      break;
    default:
      if ( questionText != 0 ) { questionStr = questionText ; }
      else { questionStr.printf( "Do you want to %s these %ld picks ?", titleText , selPoints.size() ); }
    }

    // get the answer from the user
    bool answer = true ;
    if ( questionStr.isEmpty() == true || guiForm == 0 || guiForm->questionBox( questionStr , titleStr ) != MscDg::ANS_Yes ) {
      selPoints.clear();
      answer = false ;
    }
    
    //---------------------------------------------
    // restore colors and clean up
    //---------------------------------------------

    int colorIndex = 0 ;
    std::vector< GraPickValues >::iterator selIter ;
    for ( selIter  = selPoints.begin() , iter = addedGraphic->enumerate() , colorIndex = 0 ;
          selIter != selPoints.end() && iter ;
          ++selIter , ++iter , ++colorIndex ) {

      // according to the drawing, restore the color
      switch( selIter->mySymbolId ) {
        // Polyline with 3 
      case GraPickValues::SB_LEFT_ARROW  : // < 'getSymbolBefore()'
      case GraPickValues::SB_RIGHT_ARROW : // > 'getSymbolAfter()'
      case GraPickValues::SB_DOWN_ARROW  : // \/ 'getSymbolBefore()'
      case GraPickValues::SB_UP_ARROW    : // /\ 'getSymbolAfter()'
        // Polyline with 5
      case GraPickValues::SB_MULTIPLY : // x 'getSymbol()'
      case GraPickValues::SB_ADD      : // + 'getSymbolOne()'
      case GraPickValues::SB_SQUARE   : // #
        {
          cgPolyline pl( *iter );
          if ( pl ) { pl->line_color( addedColors[colorIndex] ); }
        } break;
        // Shape with 1
      case GraPickValues::SB_ELLIPSE :
        {
          cgEllipse pl( *iter );
          if ( pl ) { pl->line_color( addedColors[colorIndex] ); }
        } break;
      }
    }

    // clean up
    addedGraphic->remove_all();

    
    //---------------------------------------------
    // done
    //---------------------------------------------   

    // do it if points have been selected and user validated .
    // remark: useless to empty ""
    return answer ;
  }
  else {
    return false ;
  }
}



//=========================================
// GraGadgetLayer (Rubber Band))
//=========================================



void GraGadgetLayer::startPointsBox( GraDrawingLayer & layer )
{
  if ( isPointsBoxActive() == false ) {
    if ( myPointsBox == 0 ) { myPointsBox = new cgPointSetCreationManipulator(); }
    // layer to have the shape on
    myPointsBoxLayer = &layer ;
    // create shape
    myRubberBandShape = cgPolyline( myPointsBoxLayer->getMemoryScene() );
    myRubberBandShape->line_style( CG_LS_DASH );
    myRubberBandShape->line_width( 3 );
    myRubberBandShape->line_color( cgRgbColor( 0.0, 0.0, 1.0 ) );
    // activate and start
    myPointsBox->activate( myGraphicLayer , myPointsBoxLayer->getGraphicLayer() , myRubberBandShape );
    myPointsBox->begin();
  }
}



bool GraGadgetLayer::isPointsBoxActive()
{
  return (myPointsBox != 0 && myPointsBox->active() == true);
}


void GraGadgetLayer::trackPointsBox( cgCrd location )
{
  if ( isPointsBoxActive() == true ) {
    myPointsBox->track( location );
  }  
}


void GraGadgetLayer::addInPointsBox( cgCrd location )
{
  if ( isPointsBoxActive() == true ) {
    myPointsBox->add_point( location );
  }  
}


void GraGadgetLayer::deleteLastInPointsBox()
{
  if ( isPointsBoxActive() == true ) {
    if ( myRubberBandShape->size() <= 2 ) { // WAS <=1 (bug)
      stopPointsBox();
    }
    else {
      // remove 2 last points . 
      myPointsBox->end();
      myRubberBandShape->remove( myRubberBandShape->size()-1 );
      cgCrd loc = myRubberBandShape->point( myRubberBandShape->size()-1 );
      myRubberBandShape->remove( myRubberBandShape->size()-1 );
      // add last one back (to generate a redraw?)
      myPointsBox->begin();
      loc = myPointsBoxLayer->getGraphicLayer()->scene_to_device( loc );
      myPointsBox->add_point( loc );
    }
  }
}



void GraGadgetLayer::stopPointsBox( std::vector<cgCrd> * points )
{
  if ( isPointsBoxActive() == true ) {
    // stop and desactivate
    myPointsBox->end();
    myPointsBox->deactivate();
    // store the points
    if ( points != 0 ) {
      points->clear();
      for ( int i=0 ; i < myRubberBandShape->size() ; ++i ) {
        points->push_back( myRubberBandShape->point(i) );
      }
    }
    // destroy shape
    myRubberBandShape->destroy_shape();
    myRubberBandShape = cgPolyline();
    // initialize
    myPointsBoxLayer  = 0;
  }
}




//===================================================//
//===================================================//
// LAYER::PIN UP LOCATOR                             //
//===================================================//
//===================================================//


// Below source code is similar to the one of "GraSemblance::GraSemblancePinUpLocator"



class GraLayerPinUpLocator : public GraPinUpLocator {
public :
  static const char * CLASS_NAME ;
  /** constructor */
  GraLayerPinUpLocator( GraLayerVirtualManager & layers ) : myLayerManager(layers) {}
  ~GraLayerPinUpLocator() {}
  /** pin-up locator functionnalities */
  cgCrd getModelCoordinate( const pair<BinPos,int> & location ) const
  {
    // Return a null coordinate if no specific time is given.
    int time_ms = location.second;
    if( time_ms == GraPinUpDM::NullTime ) return NullCoordinate;
    cgDim time_s = time_ms * GraLayerVirtualManager::MS_TO_SEC ;
    // Find the vertically central ordinate of the display.
    cgDim x_position = myLayerManager.getModelLimits().center().x;
    // Return the model coordinate.
    cgCrd coordinate( x_position, time_s );
    if ( coordinate < myLayerManager.getModelLimits() ) {
      return coordinate;
    } 
    else {
      return NullCoordinate;
    }
  } 
  pair<BinPos,int> getBinAndTime( const cgCrd &coordinate ) const
  {
    // Return the bin and time.
    BinPos binPos  = myLayerManager.getInterface().getBinPos();
    cgDim  time_s  = coordinate.y;
    int    time_ms = (int)( time_s * GraLayerVirtualManager::SEC_TO_MS + 0.5 );
    pair<BinPos,int> location( binPos, time_ms );
    return location;
  }
private :
  GraLayerVirtualManager & myLayerManager ;
};
const char * GraLayerPinUpLocator::CLASS_NAME = "GraLayerPinUpLocator" ;




//===================================================//
//===================================================//
// LAYER::MANAGER                                    //
//===================================================//
//===================================================//



GraLayerVirtualManager::GraLayerVirtualManager( GraLayerVirtualInterface & intf , bool sendRequest )
  : vcBaseView( true , 
                myPinUpLocator = intf.getPinUpDM() ? new GraLayerPinUpLocator(*this) : 0 ,
                intf.getPinUpDM() )
  , myInterface( intf )
{
  static const char * METHOD_NAME = "GraLayerVirtualManager()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME );

  //---------------------
  // initialize
  //---------------------

  // Parameters from "vcBaseDoc" & "vcBaseView"

  // internal parameters
  myIgnoreScaleFactorRedraw = false   ;
  myViewIsConnected    = false   ;

  // model & scaling
  myViewModelLimits         = cgRect( 0.0  ,  // min velocity (m/s)
                                      0.0  ,  // min time (sec)
                                      5000 ,  // max velocity (m/s)
                                      8000 ); // max time (sec)
  setModelLimits( myViewModelLimits );
  myPixelsPerVU             =   0.1f  ; // 10 vel units per pixel
  myPixelsPerS              = 200.0f  ; //  5 milliseconds per pixel

  // cursor
  myCursorType              = Typ::CRS_UNDEFINED ;
  setCursorType( Typ::CRS_NONE );
  
  // connect
  setFilter(1);

  //---------------------
  // Ask to finalyze the creation
  //---------------------

  if ( sendRequest == true ) {
    myInterface.layersRequest( *this , GraLayerVirtualInterface::RQST_CREATE_LAYERS );
  }

  //---------------------
  // Connect
  //---------------------

  Connect( *TypAppPM::instance() , TypAppPM::instance()->ChildChange ,
           *this , &GraLayerVirtualManager::changedHolderSet );
}



GraLayerVirtualManager::~GraLayerVirtualManager()
{ 
  MscDg::trace( CLASS_NAME , "~GraLayerVirtualManager()" );
  delete myPinUpLocator;
}



bool GraLayerVirtualManager::addLayer( GraLayer * layer , bool addIt )
{
  static const char * METHOD_NAME = "addLayer()" ;

  // null value
  if ( layer == 0 ) {
     MscDg::trace( CLASS_NAME , METHOD_NAME , "Null value" );
    return false ;
  }

  // find out if it's present
  bool isPresent = false ;
  GraLayerVirtualManager::LayerMap::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    // same pointer
    if ( iter->get() == layer ) {
      isPresent = true ;
      // remove it
      if ( addIt == false ) {
        myLayers.erase(iter);
      }
      break;
    }
  }
  // add it
  if ( isPresent == false && addIt == true ) {
    std::shared_ptr< GraLayer > hl(layer);
    myLayers.push_back(hl);
  }
  // debug
  if ( isPresent == false && addIt == true ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "successfully added '%s'" , layer->getName().c_str() );
  }
  else if ( isPresent == true && addIt == true ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "'%s' already present" , layer->getName().c_str() );
  }
  else if ( isPresent == true && addIt == false ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "successfully removed '%s'" , layer->getName().c_str() );
  }
  else if ( isPresent == false && addIt == false ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "'%s' not present" , layer->getName().c_str() );
  }
  // done as expected
  return (isPresent != addIt);
}



bool GraLayerVirtualManager::hasLayer( GraLayer::ClassType classType , int subClassType ) const
{
  GraLayerVirtualManager::LayerMap::const_iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    if ( (*iter)->getClassType() == classType ) {
      if ( (subClassType < 0) || ((*iter)->getSubClass() == subClassType) ) {  
        return true;
      }
    }
  }
  return false ;
}


GraLayer * GraLayerVirtualManager::getLayer( GraLayer::ClassType classType , int subClassType )
{
  GraLayerVirtualManager::LayerMap::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    if ( (*iter)->getClassType() == classType ) {
      if ( (subClassType < 0) || ((*iter)->getSubClass() == subClassType) ) {
        return iter->get();
      }
    }
  }
  MscDg::error( CLASS_NAME , "getLayer()" , "can't find layer of type %d (subclass %d)" , classType , subClassType );
  return 0;
}



GraLayer * GraLayerVirtualManager::getFirstLayer()
{
  if ( myLayers.empty() == true ) {
    MscDg::error( CLASS_NAME , "getFirstLayer()" , "no layer is present" );
    return 0 ;
  }
  else {
    return myLayers[0].get();
  }
}



GraLayer * GraLayerVirtualManager::getFirstViewLayer()
{
  int numberOfLayers = 0 ;
  GraLayerVirtualManager::LayerMap::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    numberOfLayers += 1 ;
    if ( (*iter)->getClassType() >= GraLayer::VIEW_FIRST ) {
      return iter->get();
    }
  }
  MscDg::error( CLASS_NAME , "getFirstViewLayer()" , "no view amongst the %d layers" , numberOfLayers );
  return 0;
}



GraLayer * GraLayerVirtualManager::getLastLayer()
{
  int number = myLayers.size();
  if ( number == 0 ) {
    MscDg::error( CLASS_NAME , "getLastLayer()" , "no layer is present" );
    return 0 ;
  }
  else {
    return myLayers[number-1].get();
  }
}



void GraLayerVirtualManager::updateLayersVisibility()
{
  static const char * METHOD_NAME = "updateLayersVisibility()" ;

  GraLayer * previousLayer = 0;
  int numberOfViewLayers = 0 , numberOfShown = 0 , numberOfViewChanges = 0 ;
  GraLayerVirtualManager::LayerMap::iterator iter ;

  // update the visibility of the layers
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    // layer
    GraLayer * layer = iter->get();
    // show it if needed after updating its properties (optional).
    if ( getInterface().updateVisibility( *layer ) == true ) {
      // view
      if ( layer->getClassType() >= GraLayer::VIEW_FIRST ) {
        numberOfViewLayers += 1 ;
        if ( previousLayer == 0 ) {
          numberOfShown += layer->show( Typ::ORD_BACK  );
          // get the base layer
          myBaseLayer = layer->getGraphicLayer() ;
        }
        else {
          numberOfShown += layer->show( Typ::ORD_ABOVE , previousLayer );
        }
        // layer to add on top of
        previousLayer = iter->get();
      }
      // axis or layer
      else {
        layer->show();
      }
    }
    // hide it
    else {
      layer->hide();
    }
  }

  // 

  MscDg::trace( CLASS_NAME , METHOD_NAME , "%d hidden out of %d" , numberOfShown , numberOfViewLayers );
}



void GraLayerVirtualManager::setViewLayersDirty()
{
  GraLayerVirtualManager::LayerMap::iterator iter ;
  // update the visibility of the layers
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    // layer
    GraLayer * layer = iter->get();
    if ( layer->getClassType() >= GraLayer::VIEW_FIRST ) {
      layer->setIsDirty();
    }
  }
}


void GraLayerVirtualManager::setLayerIsDirty( GraLayer::ClassType classType , int subClassType )
{
  GraLayer * layer = getLayer( classType , subClassType );
  layer->setIsDirty();
}



void GraLayerVirtualManager::hideViewLayers()
{
  static const char * METHOD_NAME = "hideViewLayers()" ;
  int numberOfLayers = 0 , numberOfShown = 0 ;
  GraLayerVirtualManager::LayerMap::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    if ( (*iter)->getClassType() >= GraLayer::VIEW_FIRST ) {
      numberOfLayers += 1 ;
      numberOfShown  += (*iter)->hide();
    }
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "%d hidden out of %d" , numberOfShown , numberOfLayers );
}



void GraLayerVirtualManager::showViewLayers()
{
  static const char * METHOD_NAME = "showViewLayers()" ;
  int numberOfLayers = 0 , numberOfShown = 0 ;
  GraLayerVirtualManager::LayerMap::iterator iter ;
  GraLayer * previousLayer = 0;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    if ( (*iter)->getClassType() >= GraLayer::VIEW_FIRST ) {
      numberOfLayers += 1 ;
      if ( previousLayer == 0 ) {
        numberOfShown  += (*iter)->show( Typ::ORD_BACK  );
      }
      else {
        numberOfShown  += (*iter)->show( Typ::ORD_ABOVE , previousLayer );
      }
      previousLayer   = iter->get();
    }
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "%d shown out of %d" , numberOfShown , numberOfLayers );
}


void GraLayerVirtualManager::drawViewLayers()
{
  static const char * METHOD_NAME = "drawViewLayers()" ;
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME , "START" );

  GraLayerVirtualManager::LayerMap::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    if ( (*iter)->getClassType() >= GraLayer::VIEW_FIRST && (*iter)->getIsShown() == true ) {
      MscDg::error( CLASS_NAME , "drawViewLayers()" , "layer type %d is in the view (>%d)" ,
                   (*iter)->getClassType() , GraLayer::VIEW_FIRST );
      (*iter)->draw();
    }
  }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "END" );
}



void GraLayerVirtualManager::invalidateViewLayers()
{
  static const char * METHOD_NAME = "invalidateViewLayers()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME );
  GraLayerVirtualManager::LayerMap::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    if ( (*iter)->getClassType() >= GraLayer::VIEW_FIRST && (*iter)->getIsShown() == true ) {
      (*iter)->invalidate();  
    }
  }
}



/** the editable layer (receives the mouse inputs) */
GraLayer * GraLayerVirtualManager::getEditableLayer()
{
  GraLayer * layer = 0 ;
  GraLayerVirtualManager::LayerMap::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    if ( (*iter)->getIsEditable() == true && (*iter)->getIsShown() == true ) {
      layer = iter->get() ;
      break;
    }
  }
  MscDg::trace( CLASS_NAME , "getEditableLayer()" , "FoundIt %s" , layer ? "true" : "false" );
  return layer ;
}



void GraLayerVirtualManager::setEditableLayer( GraLayer * layer )
{
  bool foundIt = false ;
  // deselect all
  GraLayerVirtualManager::LayerMap::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    (*iter)->setIsEditable( false );
    if ( iter->get() == layer ) {
      foundIt = true ;
    }
  }
  // select one
  if ( layer != 0 ) {
    layer->setIsEditable( true );
    if ( foundIt == false ) {
      MscDg::error( CLASS_NAME , "setEditableLayer()" , "can't find layer of address %ld" , layer );
    }
  }
}



void GraLayerVirtualManager::onButtonDown( int button, cgCrd location, bool shift, bool control )
{
  vcBaseView::onButtonDown( button, location, shift, control );
  
  GraLayer * layer = getEditableLayer();
  if ( layer != 0 ) {
    cgCrd modelCoord = myBaseLayer->device_to_scene(location);
    bool isInside    = ( getModelLimits() > modelCoord ) ;
    bool alt         = false ; // TODO
    layer->onButtonAction( GraLayer::BUTTON_DOWN , button , modelCoord , isInside , shift , control , alt );
  }
}



void GraLayerVirtualManager::onButtonMove( int button, cgCrd location, bool shift, bool control )
{
  vcBaseView::onButtonMove( button, location, shift, control );
  
  GraLayer * layer = getEditableLayer();
  if ( layer != 0 ) {
    cgCrd modelCoord = myBaseLayer->device_to_scene(location);
    bool isInside    = ( getModelLimits() > modelCoord ) ;
    bool alt         = false ; // TODO
    layer->onButtonAction( GraLayer::BUTTON_MOVE , button , modelCoord , isInside , shift , control , alt );
  }
}



void GraLayerVirtualManager::onButtonUp( int button, cgCrd location, bool shift, bool control )
{
  vcBaseView::onButtonUp( button, location, shift, control );
  
  GraLayer * layer = getEditableLayer();
  if ( layer != 0 ) {
    cgCrd modelCoord = myBaseLayer->device_to_scene(location);
    bool isInside    = ( getModelLimits() > modelCoord ) ;
    bool alt         = false ; // TODO
    layer->onButtonAction( GraLayer::BUTTON_UP , button , modelCoord , isInside , shift , control , alt );
  }
}



void GraLayerVirtualManager::setCursorType( Typ::CursorType cursorType )
{
  if ( myCursorType == cursorType ) return ;
  myCursorType = cursorType;
  // set the Qt cursor
  unsigned long cursor = VCCURSOR_DEFAULT ;
  switch ( cursorType ) {
  case Typ::CRS_UNDEFINED :
    cursor = VCCURSOR_DEFAULT ;
    break ;
  case Typ::CRS_NONE      :
    cursor = VCCURSOR_CROSS   ;
    break ;
  case Typ::CRS_ANY       :
    cursor = VCCURSOR_SIZEALL ;
    break ;
  case Typ::CRS_WEST_EAST :
    cursor = VCCURSOR_SIZEWE  ;
    break ;
  }
  setCursor( GraLayerVirtualManager::DATA_AREA , cursor );
}




void GraLayerVirtualManager::reScale()
{
  static const char * METHOD_NAME = "reScale()" ;
  bool dbOn = MscDg::trace( CLASS_NAME , METHOD_NAME , "PixelsPerS %g  PixelsPerVU %g" , myPixelsPerS , myPixelsPerVU );

  // Reset Scaling to current myPixelsPerVU & myPixelsPerS settings

  // Size of model, in pixels
  cgDim devh = myViewModelLimits.height() * myPixelsPerS  ;
  cgDim devw = myViewModelLimits.width()  * myPixelsPerVU ;
  if (  devh <= 0 || devw <= 0 || ! plot ) {
    MscDg::error( CLASS_NAME , METHOD_NAME , "ModelLimits Width %g  Height %g . Plot might not be present" , devw , devh );
    return ;
  }

  // Viewport size in pixels
  cgRect vport = plot->data_area()->area();
  
  // Viewport size in model units
  cgDim vbw = vport.width()  * (myViewModelLimits.width()  / devw);
  cgDim vbh = vport.height() * (myViewModelLimits.height() / devh);
  if (  vbw <= 0 || vbh <= 0 ) {
    // debug
    if ( dbOn == true ) {
      MscDg::print( "  Viewport Width %g  Height %g Plot might not be present" , vbw , vbh );
    }
    return ;
  } 
  
  // Create transformation between viewport & model limits
  double xx =  vport.width()  / vbw;
  double yy =  vport.height() / vbh;
  double dx = -vport.left();
  double dy = -vport.bottom();
  
  // cgPlotMappingTransformation only handles isotropic transforms
  cgRestrictedTransformation cgPMT(xx, yy, dx, dy);
  
  // Create & apply transformation between viewport and model limits
  doPreZoom();
  cgDim x = plot->space()->horizontal_dimension()->position();
  cgDim y = plot->space()->vertical_dimension()->position();
  plot->space()->mapping(cgPMT);
  plot->space()->horizontal_dimension()->position( x );
  plot->space()->vertical_dimension()->position( y );
  doPostZoom();
  
  //  Set the plot limits
  plot->space()->limits( myViewModelLimits );
}



void GraLayerVirtualManager::setScaleFactors( float velocityScale , float timeScale )
{
  static const char * METHOD_NAME = "setScaleFactors()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Ignore:%d Horizontal:%g Vertical:%g" ,
               myIgnoreScaleFactorRedraw , velocityScale , timeScale );
  // DPI is defined in the base class
  myPixelsPerVU = (double)( myDpi / velocityScale );
  myPixelsPerS  = (double)( myDpi / timeScale     );
  if ( myIgnoreScaleFactorRedraw == false ) {
    reScale();
    invalidateViewLayers();
  }
}



void GraLayerVirtualManager::connectMapping( bool b )
{
  if ( myViewIsConnected != b ) {
    // 'mappingChanged' is called when the mapping is connected or the view has been created.
    myViewIsConnected = b ;
  }
}



void GraLayerVirtualManager::mappingChanged()
{ 
  static const char * METHOD_NAME = "mappingChanged()" ;
  MscDg::trace( CLASS_NAME , METHOD_NAME , "START" );
  // Redraw the view
  //redraw();
  
  // Setting the PM will tell us to do a rescale & invalidate
  // Make this to be ignored when it happens
  myIgnoreScaleFactorRedraw = true;
  
  // Update the parameter model with the new scale
  float velocityScale = ( std::fabs( myDpi / plot->space()->mapping().xx ) );
  float timeScale     = ( std::fabs( myDpi / plot->space()->mapping().yy ) );
  
  // Re-enable redraws from the parameter models.
  myIgnoreScaleFactorRedraw = false;

  MscDg::trace( CLASS_NAME , METHOD_NAME , "END  Horizontal %g  Vertical %g" , velocityScale , timeScale );
}


void GraLayerVirtualManager::redraw()
{
  static const char * METHOD_NAME = "redraw()" ;
  if ( ! myBaseLayer ) { return; }
  MscDg::trace( CLASS_NAME , METHOD_NAME , "Start" );

  // invalidate the views
  invalidateViewLayers();
  container->layout_manager()->update_layout();
  container->view_manager()->invalidate( true );
  
  cgRestrictedTransformation cgPMT = plot->space()->mapping();
  myPixelsPerS  = cgPMT.yy;
  myPixelsPerVU = cgPMT.xx;

  // added
  drawViewLayers() ;
  updateLayout();
  invalidateDataArea();
  
  MscDg::trace( CLASS_NAME , METHOD_NAME , "End: PixelsPerS:%g PixelsPerVU:%g" , myPixelsPerS , myPixelsPerVU );
}




void GraLayerVirtualManager::changedHolderSet( MscDataTeam * dh , std::set<int> * cg )
{
  static const char * METHOD_NAME = "changedHolderSet()" ;

  int result = 0 ;
  LayerMap::iterator iter ;
  for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
    result += (*iter)->changedHolderSet( dh , cg );
  }

  // refresh
  if ( result != 0 ) {
    MscDg::trace( CLASS_NAME , METHOD_NAME , "Result %d" , result );
    for ( iter=myLayers.begin() ; iter != myLayers.end() ; ++iter ) {
      if ( (*iter)->getIsDirty() != 0 ) {
        (*iter)->setIsDirty(0);
        (*iter)->invalidate();
      }
    }
    container->layout_manager()->update_layout();
    container->view_manager()->invalidate( true );
  }
}








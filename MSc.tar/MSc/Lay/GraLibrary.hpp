#ifndef GRA_LIBRARY_HPP
#define GRA_LIBRARY_HPP


// Graphic library classes.
class cgAttributeInterface;
class cgColorMap
{
  public :
    size_t size() const ;
};
class cgScene {};

class cgObject {};
class cgContourFillVisual ;
class cgContourGrid ;
class cgContourScene ;
class cgDragBoxManipulator  ;
class cgGridRange ;
class cgRestrictedText ;
class cgSharedAttribute {};
class cgSimpleAdaptiveLinearAxis ;
class cgPointSetCreationManipulator ;

// required here:
class cgScaledText {};
class cgSimplePlot {};
class cgCrd {};
class cgBitmapColor {};
class cgRgbColor {};
class cgViewSceneLayer {};
class cgAxisTitleScene : public cgScene {};
class cgSimpleAxis : public cgScene {};
class cgViewWindowCacheLayer {};
class cgGridLineVisual {};
class cgAxisLinearTickGenerator {};
class cgGridScene {};
class cgRect {};
class cgMemoryScene : public cgScene {};
class cgViewGadgetLayer {};
class cgPolyline {};
typedef double cgDim ;


#endif
